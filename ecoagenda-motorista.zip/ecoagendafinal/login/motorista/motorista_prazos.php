<?php
// Mesma regra do administrador: cinco dias de segunda a sexta após data_pedido.
function prazoMotorista(array $pedido, ?string $hoje = null): array
{
    $fuso = new DateTimeZone('America/Sao_Paulo');
    $hoje = $hoje ?: (new DateTimeImmutable('now', $fuso))->format('Y-m-d');
    $status = mb_strtolower(trim((string)($pedido['status'] ?? '')), 'UTF-8');
    $ativo = in_array($status, ['encaminhado', 'agendado', 'confirmado', 'a caminho', 'em andamento'], true);
    $base = substr((string)($pedido['data_pedido'] ?? ''), 0, 10);
    $data = DateTimeImmutable::createFromFormat('!Y-m-d', $base, $fuso);
    if (!$data || $data->format('Y-m-d') !== $base) {
        return ['ativo'=>$ativo, 'limite'=>'', 'classe'=>'sem-prazo', 'texto'=>'Prazo não informado'];
    }
    for ($dias=0; $dias<5;) {
        $data = $data->modify('+1 day');
        if ((int)$data->format('N')<=5) $dias++;
    }
    $limite = $data->format('Y-m-d');
    $classe = !$ativo ? 'encerrado' : ($limite<$hoje ? 'vencido' : ($limite===$hoje ? 'hoje' : 'valido'));
    $restantes=0;
    for ($cursor = new DateTimeImmutable($hoje, $fuso); $cursor<$data;) {
        $cursor=$cursor->modify('+1 day');
        if ((int)$cursor->format('N')<=5) $restantes++;
    }
    $texto = match ($classe) {
        'vencido'=>'Prazo vencido', 'hoje'=>'Prazo hoje', 'encerrado'=>'Pedido encerrado',
        default=>$restantes . ($restantes===1 ? ' dia útil restante' : ' dias úteis restantes')
    };
    return ['ativo'=>$ativo, 'limite'=>$limite, 'classe'=>$classe, 'texto'=>$texto];
}
