<?php

session_start();

require_once "../../config.php";
require_once __DIR__ . "/motorista_prazos.php";


/*
|--------------------------------------------------------------------------
| PROTEÇÃO
|--------------------------------------------------------------------------
*/

if (
    !isset($_SESSION["email"]) ||
    !isset($_SESSION["perfil"]) ||
    $_SESSION["perfil"] !== "motorista"
) {
    header("Location: ../login.html");
    exit();
}


$motoristaEmail =
    $_SESSION["email"];

$nomeMotorista =
    $_SESSION["nome"] ?? "Motorista";


$mensagem = "";
$tipoMensagem = "success";


/*
|--------------------------------------------------------------------------
| FUNÇÕES
|--------------------------------------------------------------------------
*/

function e($valor): string
{
    return htmlspecialchars(
        (string)$valor,
        ENT_QUOTES,
        "UTF-8"
    );
}


function dataBR(?string $data): string
{
    if (empty($data)) {
        return "—";
    }

    $timestamp =
        strtotime($data);

    return $timestamp
        ? date("d/m/Y", $timestamp)
        : "—";
}


function dataHoraBR(?string $data): string
{
    if (empty($data)) {
        return "—";
    }

    $timestamp =
        strtotime($data);

    return $timestamp
        ? date("d/m/Y H:i", $timestamp)
        : "—";
}


function horaBR(?string $data): string
{
    if (empty($data)) {
        return "—";
    }

    $timestamp =
        strtotime($data);

    return $timestamp
        ? date("H:i", $timestamp)
        : "—";
}


function classeStatus(string $status): string
{
    $statusNormalizado = mb_strtolower(
        trim($status),
        "UTF-8"
    );

    switch ($statusNormalizado) {
        case "encaminhado":
            return "confirmado";

        case "a caminho":
            return "a-caminho";

        case "em andamento":
            return "andamento";

        case "concluído":
        case "concluido":
            return "concluido";

        case "suspenso":
            return "cancelado";

        default:
            return "pendente";
    }
}


/*
|--------------------------------------------------------------------------
| DEFINIR USUÁRIO DA TRIGGER
|--------------------------------------------------------------------------
|
| A trigger trg_agendamento_update usa:
|
| @usuario_logado
|
*/

function definirUsuarioLogado(
    mysqli $conn,
    string $email
): void {

    $sql = "
        SET @usuario_logado = ?
    ";

    $stmt =
        $conn->prepare($sql);

    if (!$stmt) {
        throw new Exception(
            "Erro ao definir usuário da operação: " .
            $conn->error
        );
    }

    $stmt->bind_param(
        "s",
        $email
    );

    if (!$stmt->execute()) {
        throw new Exception(
            "Erro ao definir usuário da operação: " .
            $stmt->error
        );
    }

    $stmt->close();
}


/*
 * Envia aviso de mudança de status por e-mail.
 * Falhas no envio não desfazem uma alteração já salva no banco.
 */
function enviarEmailStatusEcoAgenda(mysqli $conn, array $pedido, string $statusNovo): void
{
    try {
        require_once __DIR__ . "/../../login/notificar_status.php";

        $emailMorador = trim((string)($pedido["morador_email"] ?? ""));
        $agendamentoId = (int)($pedido["id"] ?? 0);

        if ($emailMorador === "" || $agendamentoId <= 0 ||
            !function_exists("notificarMoradorStatus")) {
            return;
        }

        $nomeMorador = "Morador";
        $stmtNome = $conn->prepare(
            "SELECT nome FROM usuario WHERE email = ? LIMIT 1"
        );

        if ($stmtNome) {
            $stmtNome->bind_param("s", $emailMorador);
            if ($stmtNome->execute()) {
                $dadosNome = $stmtNome->get_result()->fetch_assoc();
                if (!empty($dadosNome["nome"])) {
                    $nomeMorador = (string)$dadosNome["nome"];
                }
            }
            $stmtNome->close();
        }

        if (!notificarMoradorStatus(
            $emailMorador,
            $nomeMorador,
            $agendamentoId,
            $statusNovo
        )) {
            error_log(
                "EcoAgenda: não foi possível enviar e-mail de status do pedido #" .
                $agendamentoId
            );
        }
    } catch (Throwable $erroNotificacao) {
        error_log("EcoAgenda: falha na notificação de status: " . $erroNotificacao->getMessage());
    }
}


/*
|--------------------------------------------------------------------------
| DADOS DO MOTORISTA
|--------------------------------------------------------------------------
*/

$sqlMotorista = "

    SELECT

        m.email,
        m.cnh,
        m.cpf,
        m.telefone,
        m.ativo,

        u.nome

    FROM motorista m

    INNER JOIN usuario u
        ON u.email = m.email

    WHERE m.email = ?

    LIMIT 1
";


$stmtMotorista =
    $conn->prepare(
        $sqlMotorista
    );


if (!$stmtMotorista) {

    die(
        "Erro ao carregar motorista: " .
        $conn->error
    );
}


$stmtMotorista->bind_param(
    "s",
    $motoristaEmail
);


$stmtMotorista->execute();


$dadosMotorista =
    $stmtMotorista
        ->get_result()
        ->fetch_assoc();


$stmtMotorista->close();


if (!$dadosMotorista) {

    session_destroy();

    die(
        "Cadastro do motorista não encontrado."
    );
}


if (
    (int)$dadosMotorista["ativo"] !== 1
) {

    session_destroy();

    header(
        "Location: ../login.html"
    );

    exit();
}


/*
|--------------------------------------------------------------------------
| AÇÕES DO MOTORISTA
|--------------------------------------------------------------------------
*/

if (
    $_SERVER["REQUEST_METHOD"] === "POST"
) {

    $acao =
        $_POST["acao"] ?? "";

    $agendamentoId =
        (int)(
            $_POST["agendamento_id"] ?? 0
        );


    /*
    |--------------------------------------------------------------------------
    | IR ATÉ O LOCAL — altera o status para A caminho
    |--------------------------------------------------------------------------
    */

    if ($acao === "ir_local") {
        if ($agendamentoId <= 0) {
            $mensagem = "Pedido inválido.";
            $tipoMensagem = "error";
        } else {
            $conn->begin_transaction();

            try {
                $sqlPedidoCaminho = "
                    SELECT a.id, a.morador_email, a.status
                    FROM agendamento a
                    INNER JOIN coleta c
                        ON c.agendamento_id = a.id
                       AND c.motorista_email = ?
                    WHERE a.id = ?
                    ORDER BY c.data_inicio DESC
                    LIMIT 1
                ";

                $stmtPedidoCaminho = $conn->prepare($sqlPedidoCaminho);
                if (!$stmtPedidoCaminho) {
                    throw new Exception("Erro ao buscar pedido: " . $conn->error);
                }

                $stmtPedidoCaminho->bind_param("si", $motoristaEmail, $agendamentoId);
                $stmtPedidoCaminho->execute();
                $pedidoCaminho = $stmtPedidoCaminho->get_result()->fetch_assoc();
                $stmtPedidoCaminho->close();

                if (!$pedidoCaminho) {
                    throw new Exception("Pedido não encontrado ou não está agendado para este motorista.");
                }

                if (mb_strtolower(trim($pedidoCaminho["status"]), "UTF-8") !== "encaminhado") {
                    throw new Exception("Somente pedidos agendados podem ser colocados a caminho.");
                }

                definirUsuarioLogado($conn, $motoristaEmail);
                $novoStatusCaminho = "A caminho";
                $sqlStatusCaminho = "
                    UPDATE agendamento
                    SET status = ?
                    WHERE id = ? AND status = 'Encaminhado'
                    LIMIT 1
                ";

                $stmtStatusCaminho = $conn->prepare($sqlStatusCaminho);
                if (!$stmtStatusCaminho) {
                    throw new Exception("Erro ao preparar atualização do status: " . $conn->error);
                }

                $stmtStatusCaminho->bind_param("si", $novoStatusCaminho, $agendamentoId);
                if (!$stmtStatusCaminho->execute()) {
                    throw new Exception("Erro ao atualizar o status: " . $stmtStatusCaminho->error);
                }

                if ($stmtStatusCaminho->affected_rows !== 1) {
                    $stmtStatusCaminho->close();
                    throw new Exception("O pedido não pôde ser marcado como A caminho. Atualize a página e tente novamente.");
                }

                $stmtStatusCaminho->close();
                $conn->commit();

                enviarEmailStatusEcoAgenda($conn, $pedidoCaminho, "A caminho");
                $mensagem = "Status atualizado para A caminho. Ao chegar ao endereço, clique em Iniciar coleta.";
            } catch (Throwable $e) {
                $conn->rollback();
                $mensagem = $e->getMessage();
                $tipoMensagem = "error";
            }
        }
    }


    /*
    |--------------------------------------------------------------------------
    | INICIAR COLETA
    |--------------------------------------------------------------------------
    */

    if (
        $acao === "iniciar"
    ) {

        if (
            $agendamentoId <= 0
        ) {

            $mensagem =
                "Pedido inválido.";

            $tipoMensagem =
                "error";

        } else {

            $conn->begin_transaction();

            try {

                /*
                |--------------------------------------------------------------------------
                | Buscar pedido vinculado ao motorista
                |--------------------------------------------------------------------------
                */

                $sqlPedido = "

                    SELECT

                        a.id,
                        a.criado_por,
                        a.descricao,
                        a.data_pedido,
                        a.foto,
                        a.morador_email,
                        a.status,

                        c.data_inicio,
                        c.data_chegada,
                        c.data_finalizacao,
                        c.foto AS foto_coleta

                    FROM agendamento a

                    INNER JOIN coleta c
                        ON c.agendamento_id = a.id
                       AND c.motorista_email = ?

                    WHERE a.id = ?

                    ORDER BY
                        c.data_inicio DESC

                    LIMIT 1
                ";


                $stmtPedido =
                    $conn->prepare(
                        $sqlPedido
                    );


                if (!$stmtPedido) {

                    throw new Exception(
                        "Erro ao buscar pedido: " .
                        $conn->error
                    );
                }


                $stmtPedido->bind_param(
                    "si",
                    $motoristaEmail,
                    $agendamentoId
                );


                $stmtPedido->execute();


                $pedido =
                    $stmtPedido
                        ->get_result()
                        ->fetch_assoc();


                $stmtPedido->close();


                if (!$pedido) {

                    throw new Exception(
                        "Pedido não encontrado ou não está agendado para este motorista."
                    );
                }


                /*
                | Somente pedidos marcados como A caminho
                */

                if (
                    mb_strtolower(
                        trim(
                            $pedido["status"]
                        ),
                        "UTF-8"
                    ) !== "a caminho"
                ) {

                    throw new Exception(
                        "Primeiro clique em Ir até o local para marcar o pedido como A caminho."
                    );
                }


                /*
                |--------------------------------------------------------------------------
                | Buscar registro atual da coleta
                |--------------------------------------------------------------------------
                */

                $sqlColeta = "

                    SELECT
                        motorista_email,
                        agendamento_id,
                        data_inicio,
                        data_chegada,
                        data_finalizacao,
                        foto

                    FROM coleta

                    WHERE motorista_email = ?
                      AND agendamento_id = ?

                    ORDER BY
                        data_inicio DESC

                    LIMIT 1
                ";


                $stmtColeta =
                    $conn->prepare(
                        $sqlColeta
                    );


                if (!$stmtColeta) {

                    throw new Exception(
                        "Erro ao buscar coleta: " .
                        $conn->error
                    );
                }


                $stmtColeta->bind_param(
                    "si",
                    $motoristaEmail,
                    $agendamentoId
                );


                $stmtColeta->execute();


                $coleta =
                    $stmtColeta
                        ->get_result()
                        ->fetch_assoc();


                $stmtColeta->close();


                if (!$coleta) {

                    throw new Exception(
                        "Não existe uma coleta vinculada a este pedido."
                    );
                }


                /*
                |--------------------------------------------------------------------------
                | Registrar o INÍCIO REAL da coleta
                |--------------------------------------------------------------------------
                |
                | O registro criado pela Secretaria possui data_inicio apenas
                | para satisfazer a estrutura atual da tabela coleta.
                | Quando o motorista inicia de fato, este valor é atualizado
                | para o horário real da ação.
                */

                $dataInicioAnterior =
                    $coleta["data_inicio"];


                $dataInicioNovo =
                    date("Y-m-d H:i:s");


                $sqlInicioColeta = "

                    UPDATE coleta

                    SET data_inicio = ?

                    WHERE motorista_email = ?

                      AND agendamento_id = ?

                      AND data_inicio = ?

                    LIMIT 1
                ";


                $stmtInicioColeta =
                    $conn->prepare(
                        $sqlInicioColeta
                    );


                if (!$stmtInicioColeta) {

                    throw new Exception(
                        "Erro ao preparar início da coleta: " .
                        $conn->error
                    );
                }


                $stmtInicioColeta->bind_param(
                    "ssis",
                    $dataInicioNovo,
                    $motoristaEmail,
                    $agendamentoId,
                    $dataInicioAnterior
                );


                if (
                    !$stmtInicioColeta->execute()
                ) {

                    throw new Exception(
                        "Erro ao registrar o início da coleta: " .
                        $stmtInicioColeta->error
                    );
                }


                if (
                    $stmtInicioColeta->affected_rows !== 1
                ) {

                    $stmtInicioColeta->close();

                    throw new Exception(
                        "A coleta não pôde ser iniciada. O registro pode ter sido alterado por outra operação."
                    );
                }


                $stmtInicioColeta->close();


                /*
                |--------------------------------------------------------------------------
                | Atualizar STATUS do AGENDAMENTO
                |--------------------------------------------------------------------------
                */

                definirUsuarioLogado(
                    $conn,
                    $motoristaEmail
                );


                $novoStatus =
                    "Em andamento";


                $sqlUpdate = "

                    UPDATE agendamento

                    SET status = ?

                    WHERE id = ?

                      AND status = 'A caminho'

                    LIMIT 1
                ";


                $stmtUpdate =
                    $conn->prepare(
                        $sqlUpdate
                    );


                if (!$stmtUpdate) {

                    throw new Exception(
                        "Erro ao preparar mudança de status: " .
                        $conn->error
                    );
                }


                $stmtUpdate->bind_param(
                    "si",
                    $novoStatus,
                    $agendamentoId
                );


                if (
                    !$stmtUpdate->execute()
                ) {

                    throw new Exception(
                        "Erro ao iniciar coleta: " .
                        $stmtUpdate->error
                    );
                }


                if (
                    $stmtUpdate->affected_rows !== 1
                ) {

                    $stmtUpdate->close();

                    throw new Exception(
                        "O status do pedido não pôde ser atualizado. Tente novamente."
                    );
                }


                $stmtUpdate->close();


                /*
                | O trigger trg_agendamento_update registra automaticamente
                | a alteração do status no agendamento_historico.
                | Evitamos inserir um segundo histórico manualmente.
                */

                $conn->commit();

                enviarEmailStatusEcoAgenda($conn, $pedido, "Em andamento");

                $mensagem =
                    "Coleta iniciada e marcada como Em andamento.";

            } catch (Throwable $e) {

                $conn->rollback();

                $mensagem =
                    $e->getMessage();

                $tipoMensagem =
                    "error";
            }
        }
    }


    /*
    |--------------------------------------------------------------------------
    | SUSPENDER COLETA
    | A ação grava o status definitivo "Suspenso".
    | A foto e a justificativa ficam registradas no agendamento_historico.
    |--------------------------------------------------------------------------
    */

    if (
        $acao === "suspender"
    ) {

        $justificativa = trim(
            $_POST["justificativa_suspensao"] ?? ""
        );

        if ($agendamentoId <= 0) {

            $mensagem = "Pedido inválido.";
            $tipoMensagem = "error";

        } elseif ($justificativa === "") {

            $mensagem = "Informe a justificativa para suspender a coleta.";
            $tipoMensagem = "error";

        } elseif (mb_strlen($justificativa, "UTF-8") > 225) {

            $mensagem = "A justificativa deve ter no máximo 225 caracteres.";
            $tipoMensagem = "error";

        } elseif (
            !isset($_FILES["foto_suspensao"]) ||
            $_FILES["foto_suspensao"]["error"] === UPLOAD_ERR_NO_FILE
        ) {

            $mensagem = "A foto do ocorrido é obrigatória para suspender a coleta.";
            $tipoMensagem = "error";

        } else {

            $conn->begin_transaction();

            $nomeFotoSuspensao = null;

            try {

                $sqlPedido = "
                    SELECT
                        a.id,
                        a.criado_por,
                        a.descricao,
                        a.data_pedido,
                        a.morador_email,
                        a.status
                    FROM agendamento a
                    INNER JOIN coleta c
                        ON c.agendamento_id = a.id
                       AND c.motorista_email = ?
                    WHERE a.id = ?
                    LIMIT 1
                ";

                $stmtPedido = $conn->prepare($sqlPedido);

                if (!$stmtPedido) {
                    throw new Exception(
                        "Erro ao buscar pedido: " . $conn->error
                    );
                }

                $stmtPedido->bind_param(
                    "si",
                    $motoristaEmail,
                    $agendamentoId
                );

                $stmtPedido->execute();
                $pedidoSuspensao = $stmtPedido
                    ->get_result()
                    ->fetch_assoc();
                $stmtPedido->close();

                if (!$pedidoSuspensao) {
                    throw new Exception(
                        "Pedido não encontrado ou não pertence a este motorista."
                    );
                }

                if (
                    mb_strtolower(
                        trim($pedidoSuspensao["status"]),
                        "UTF-8"
                    ) !== "em andamento"
                ) {
                    throw new Exception(
                        "Somente pedidos em andamento podem ser suspensos."
                    );
                }

                $arquivo = $_FILES["foto_suspensao"];

                if ($arquivo["error"] !== UPLOAD_ERR_OK) {
                    throw new Exception(
                        "Erro ao enviar a foto do ocorrido."
                    );
                }

                if ($arquivo["size"] > 5 * 1024 * 1024) {
                    throw new Exception(
                        "A foto deve ter no máximo 5 MB."
                    );
                }

                $tiposPermitidos = [
                    "image/jpeg" => "jpg",
                    "image/png" => "png",
                    "image/webp" => "webp"
                ];

                $finfo = finfo_open(FILEINFO_MIME_TYPE);
                if (!$finfo) {
                    throw new Exception("Não foi possível validar a foto.");
                }

                $tipoArquivo = finfo_file(
                    $finfo,
                    $arquivo["tmp_name"]
                );
                finfo_close($finfo);

                if (!isset($tiposPermitidos[$tipoArquivo])) {
                    throw new Exception(
                        "Formato de imagem não permitido. Use JPG, PNG ou WEBP."
                    );
                }

                $extensao = $tiposPermitidos[$tipoArquivo];
                $nomeFotoSuspensao = uniqid("suspensao_", true) . "." . $extensao;
                $pastaUpload = __DIR__ . "/../../agendamento/uploads/";

                if (!is_dir($pastaUpload)) {
                    if (!mkdir($pastaUpload, 0755, true)) {
                        throw new Exception(
                            "Não foi possível criar a pasta de uploads."
                        );
                    }
                }

                $caminhoFoto = $pastaUpload . $nomeFotoSuspensao;

                if (!move_uploaded_file(
                    $arquivo["tmp_name"],
                    $caminhoFoto
                )) {
                    throw new Exception(
                        "Não foi possível salvar a foto do ocorrido."
                    );
                }

                $caminhoBancoSuspensao = "uploads/" . $nomeFotoSuspensao;

                definirUsuarioLogado(
                    $conn,
                    $motoristaEmail
                );

                $novoStatusSuspensao = "Suspenso";

                $sqlStatus = "
                    UPDATE agendamento
                    SET status = ?
                    WHERE id = ?
                      AND status = 'Em andamento'
                    LIMIT 1
                ";

                $stmtStatus = $conn->prepare($sqlStatus);

                if (!$stmtStatus) {
                    throw new Exception(
                        "Erro ao preparar suspensão: " . $conn->error
                    );
                }

                $stmtStatus->bind_param(
                    "si",
                    $novoStatusSuspensao,
                    $agendamentoId
                );

                if (!$stmtStatus->execute()) {
                    throw new Exception(
                        "Erro ao suspender a coleta: " . $stmtStatus->error
                    );
                }

                if ($stmtStatus->affected_rows !== 1) {
                    $stmtStatus->close();
                    throw new Exception(
                        "A coleta não pôde ser suspensa. O status pode ter sido alterado."
                    );
                }

                $stmtStatus->close();

                /*
                | O trigger registra a mudança de status automaticamente.
                | Este segundo registro guarda a justificativa e a foto
                | específica da ocorrência que motivou a suspensão.
                */
                $sqlHistorico = "
                    INSERT INTO agendamento_historico
                    (
                        agendamento_id,
                        criado_por,
                        descricao,
                        data_pedido,
                        foto,
                        morador_email,
                        status,
                        comando,
                        data_comando,
                        usuario_logado
                    )
                    VALUES (?, ?, ?, ?, ?, ?, ?, 'COLETA_SUSPENSA', NOW(), ?)
                ";

                $stmtHistorico = $conn->prepare($sqlHistorico);

                if (!$stmtHistorico) {
                    throw new Exception(
                        "Erro ao preparar o histórico da suspensão: " . $conn->error
                    );
                }

                $stmtHistorico->bind_param(
                    "isssssss",
                    $agendamentoId,
                    $pedidoSuspensao["criado_por"],
                    $justificativa,
                    $pedidoSuspensao["data_pedido"],
                    $caminhoBancoSuspensao,
                    $pedidoSuspensao["morador_email"],
                    $novoStatusSuspensao,
                    $motoristaEmail
                );

                if (!$stmtHistorico->execute()) {
                    throw new Exception(
                        "Erro ao registrar a justificativa da suspensão: " . $stmtHistorico->error
                    );
                }

                $stmtHistorico->close();

                $conn->commit();

                enviarEmailStatusEcoAgenda($conn, $pedidoSuspensao, "Suspenso");

                $mensagem = "Coleta suspensa com sucesso.";

            } catch (Throwable $e) {

                $conn->rollback();

                if ($nomeFotoSuspensao !== null) {
                    $arquivo =
                        __DIR__ .
                        "/../../agendamento/uploads/" .
                        $nomeFotoSuspensao;

                    if (file_exists($arquivo)) {
                        unlink($arquivo);
                    }
                }

                $mensagem = $e->getMessage();
                $tipoMensagem = "error";
            }
        }
    }


    /*
    |--------------------------------------------------------------------------
    | CONCLUIR COLETA
    |--------------------------------------------------------------------------
    */

    if (
        $acao === "concluir"
    ) {

        if (
            $agendamentoId <= 0
        ) {

            $mensagem =
                "Pedido inválido.";

            $tipoMensagem =
                "error";

        } else {

            $conn->begin_transaction();

            $nomeFoto = null;
            $caminhoBanco = null;

            try {

                /*
                |--------------------------------------------------------------------------
                | Buscar pedido
                |--------------------------------------------------------------------------
                */

                $sqlPedido = "

                    SELECT

                        a.id,
                        a.criado_por,
                        a.descricao,
                        a.data_pedido,
                        a.foto,
                        a.morador_email,
                        a.status,

                        c.data_inicio,
                        c.data_chegada,
                        c.data_finalizacao,
                        c.foto AS foto_coleta

                    FROM agendamento a

                    INNER JOIN coleta c
                        ON c.agendamento_id = a.id
                       AND c.motorista_email = ?

                    WHERE a.id = ?

                    ORDER BY
                        c.data_inicio DESC

                    LIMIT 1
                ";


                $stmtPedido =
                    $conn->prepare(
                        $sqlPedido
                    );


                if (!$stmtPedido) {

                    throw new Exception(
                        "Erro ao buscar pedido: " .
                        $conn->error
                    );
                }


                $stmtPedido->bind_param(
                    "si",
                    $motoristaEmail,
                    $agendamentoId
                );


                $stmtPedido->execute();


                $pedido =
                    $stmtPedido
                        ->get_result()
                        ->fetch_assoc();


                $stmtPedido->close();


                if (!$pedido) {

                    throw new Exception(
                        "Pedido não encontrado ou não pertence a este motorista."
                    );
                }


                /*
                |--------------------------------------------------------------------------
                | Verificar status
                |--------------------------------------------------------------------------
                */

                if (
                    mb_strtolower(
                        trim(
                            $pedido["status"]
                        ),
                        "UTF-8"
                    ) !== "em andamento"
                ) {

                    throw new Exception(
                        "Somente pedidos em andamento podem ser concluídos."
                    );
                }


                /*
                |--------------------------------------------------------------------------
                | Buscar data_inicio da coleta
                |--------------------------------------------------------------------------
                */

                $sqlColeta = "

                    SELECT

                        motorista_email,
                        agendamento_id,
                        data_inicio,
                        data_chegada,
                        data_finalizacao,
                        foto

                    FROM coleta

                    WHERE motorista_email = ?
                      AND agendamento_id = ?

                    ORDER BY
                        data_inicio DESC

                    LIMIT 1
                ";


                $stmtColeta =
                    $conn->prepare(
                        $sqlColeta
                    );


                if (!$stmtColeta) {

                    throw new Exception(
                        "Erro ao buscar coleta: " .
                        $conn->error
                    );
                }


                $stmtColeta->bind_param(
                    "si",
                    $motoristaEmail,
                    $agendamentoId
                );


                $stmtColeta->execute();


                $coleta =
                    $stmtColeta
                        ->get_result()
                        ->fetch_assoc();


                $stmtColeta->close();


                if (!$coleta) {

                    throw new Exception(
                        "Registro de coleta não encontrado."
                    );
                }


                /*
                |--------------------------------------------------------------------------
                | FOTO DO MOTORISTA - OBRIGATÓRIA PARA CONCLUIR
                |--------------------------------------------------------------------------
                */

                if (
                    !isset($_FILES["foto_motorista"]) ||
                    $_FILES["foto_motorista"]["error"] === UPLOAD_ERR_NO_FILE
                ) {
                    throw new Exception(
                        "A foto da coleta é obrigatória para concluir o pedido."
                    );
                }

                if (
                    $_FILES["foto_motorista"]["error"] === UPLOAD_ERR_OK
                ) {

                    if (
                        $_FILES[
                            "foto_motorista"
                        ]["error"]
                        !== UPLOAD_ERR_OK
                    ) {

                        throw new Exception(
                            "Erro ao enviar a foto do motorista."
                        );
                    }


                    if (
                        $_FILES[
                            "foto_motorista"
                        ]["size"]
                        >
                        5 * 1024 * 1024
                    ) {

                        throw new Exception(
                            "A foto deve ter no máximo 5 MB."
                        );
                    }


                    $tiposPermitidos = [

                        "image/jpeg",

                        "image/png",

                        "image/webp"
                    ];


                    $tipoArquivo =
                        mime_content_type(
                            $_FILES[
                                "foto_motorista"
                            ]["tmp_name"]
                        );


                    if (
                        !in_array(
                            $tipoArquivo,
                            $tiposPermitidos,
                            true
                        )
                    ) {

                        throw new Exception(
                            "Formato de imagem não permitido."
                        );
                    }


                    $extensoes = [

                        "image/jpeg" =>
                            "jpg",

                        "image/png" =>
                            "png",

                        "image/webp" =>
                            "webp"
                    ];


                    $extensao =
                        $extensoes[
                            $tipoArquivo
                        ];


                    $nomeFoto =
                        uniqid(
                            "motorista_",
                            true
                        )
                        .
                        "."
                        .
                        $extensao;


                    $pastaUpload =
                        __DIR__ .
                        "/../../agendamento/uploads/";


                    if (
                        !is_dir(
                            $pastaUpload
                        )
                    ) {

                        if (
                            !mkdir(
                                $pastaUpload,
                                0755,
                                true
                            )
                        ) {

                            throw new Exception(
                                "Não foi possível criar a pasta de uploads."
                            );
                        }
                    }


                    $caminhoFoto =
                        $pastaUpload .
                        $nomeFoto;


                    if (
                        !move_uploaded_file(
                            $_FILES[
                                "foto_motorista"
                            ]["tmp_name"],
                            $caminhoFoto
                        )
                    ) {

                        throw new Exception(
                            "Não foi possível salvar a foto."
                        );
                    }


                    $caminhoBanco =
                        "uploads/" .
                        $nomeFoto;
                }


                /*
                |--------------------------------------------------------------------------
                | ATUALIZAR COLETA
                |--------------------------------------------------------------------------
                */

                $dataInicio =
                    $coleta[
                        "data_inicio"
                    ];


                $fotoFinal =
                    $caminhoBanco ??
                    ($coleta["foto"] ?? null);


                $sqlUpdateColeta = "

                    UPDATE coleta

                    SET

                        data_finalizacao =
                            NOW(),

                        foto = ?

                    WHERE
                        motorista_email = ?

                        AND agendamento_id = ?

                        AND data_inicio = ?

                    LIMIT 1
                ";


                $stmtUpdateColeta =
                    $conn->prepare(
                        $sqlUpdateColeta
                    );


                if (!$stmtUpdateColeta) {

                    throw new Exception(
                        "Erro ao preparar finalização da coleta: " .
                        $conn->error
                    );
                }


                $stmtUpdateColeta->bind_param(
                    "ssis",
                    $fotoFinal,
                    $motoristaEmail,
                    $agendamentoId,
                    $dataInicio
                );


                if (
                    !$stmtUpdateColeta->execute()
                ) {

                    throw new Exception(
                        "Erro ao finalizar coleta: " .
                        $stmtUpdateColeta->error
                    );
                }


                if (
                    $stmtUpdateColeta->affected_rows !== 1
                ) {

                    $stmtUpdateColeta->close();

                    throw new Exception(
                        "O registro da coleta não pôde ser finalizado."
                    );
                }


                $stmtUpdateColeta->close();


                /*
                |--------------------------------------------------------------------------
                | ATUALIZAR STATUS DO AGENDAMENTO
                |--------------------------------------------------------------------------
                */

                definirUsuarioLogado(
                    $conn,
                    $motoristaEmail
                );


                $novoStatus =
                    "Concluído";


                $sqlUpdateAgendamento = "

                    UPDATE agendamento

                    SET status = ?

                    WHERE id = ?

                      AND status = 'Em andamento'

                    LIMIT 1
                ";


                $stmtUpdateAgendamento =
                    $conn->prepare(
                        $sqlUpdateAgendamento
                    );


                if (!$stmtUpdateAgendamento) {

                    throw new Exception(
                        "Erro ao preparar conclusão: " .
                        $conn->error
                    );
                }


                $stmtUpdateAgendamento->bind_param(
                    "si",
                    $novoStatus,
                    $agendamentoId
                );


                if (
                    !$stmtUpdateAgendamento->execute()
                ) {

                    throw new Exception(
                        "Erro ao atualizar status: " .
                        $stmtUpdateAgendamento->error
                    );
                }


                $stmtUpdateAgendamento->close();


                /*
                | O trigger trg_agendamento_update registra automaticamente
                | a alteração para Concluído no histórico.
                */

                $conn->commit();

                enviarEmailStatusEcoAgenda($conn, $pedido, "Concluído");

                $mensagem =
                    "Coleta concluída com sucesso.";

            } catch (Throwable $e) {

                $conn->rollback();


                /*
                | Apagar foto caso a transação tenha falhado
                */

                if (
                    $nomeFoto !== null
                ) {

                    $arquivo =
                        __DIR__ .
                        "/../../agendamento/uploads/" .
                        $nomeFoto;

                    if (
                        file_exists(
                            $arquivo
                        )
                    ) {

                        unlink(
                            $arquivo
                        );
                    }
                }


                $mensagem =
                    $e->getMessage();

                $tipoMensagem =
                    "error";
            }
        }
    }
}


/*
|--------------------------------------------------------------------------
| BUSCAR PEDIDOS DO MOTORISTA
|--------------------------------------------------------------------------
*/

$pedidos = [];


$sqlPedidos = "

    SELECT

        a.id,

        a.criado_por,

        a.descricao,

        a.data_pedido,

        a.foto,

        a.morador_email,

        a.status,

        m.cpf AS morador_cpf,

        CASE
            WHEN LOWER(a.status) IN ('concluído', 'concluido')
                THEN NULL
            ELSE m.telefone
        END AS morador_telefone,

        u_morador.nome AS morador_nome,

        e.cep,

        e.estado,

        e.cidade,

        e.rua,

        e.bairro,

        e.numero,

        e.complemento,

        c.data_inicio,

        c.data_chegada,

        c.data_finalizacao,

        c.foto AS foto_motorista

    FROM agendamento a


    INNER JOIN coleta c
        ON c.agendamento_id = a.id
       AND c.motorista_email = ?


    LEFT JOIN morador m
        ON m.email = a.morador_email


    LEFT JOIN usuario u_morador
        ON u_morador.email = m.email


    LEFT JOIN agendamento_morador_endereco ame
        ON ame.agendamento_id = a.id
       AND ame.morador_email = a.morador_email


    LEFT JOIN morador_endereco me
        ON me.endereco_id = ame.endereco_id
       AND me.morador_email = ame.morador_email


    LEFT JOIN endereco e
        ON e.id = me.endereco_id
       AND e.email = me.morador_email


    ORDER BY

        CASE

            WHEN LOWER(a.status)
                = 'encaminhado'
            THEN 1

            WHEN LOWER(a.status)
                = 'a caminho'
            THEN 2

            WHEN LOWER(a.status)
                = 'em andamento'
            THEN 3

            WHEN LOWER(a.status)
                IN ('concluído', 'concluido')
            THEN 4

            WHEN LOWER(a.status)
                = 'suspenso'
            THEN 5

            ELSE 5

        END,

        a.id DESC,

        c.data_inicio DESC
";


$stmtPedidos =
    $conn->prepare(
        $sqlPedidos
    );


if (!$stmtPedidos) {

    die(
        "Erro ao carregar pedidos: " .
        $conn->error
    );
}


$stmtPedidos->bind_param(
    "s",
    $motoristaEmail
);


$stmtPedidos->execute();


$resultadoPedidos =
    $stmtPedidos->get_result();


while (
    $pedido =
    $resultadoPedidos->fetch_assoc()
) {

    /*
    | Montar endereço para a interface
    */

    $partesEndereco = [];

    if (
        !empty(
            $pedido["rua"]
        )
    ) {

        $partesEndereco[] =
            $pedido["rua"];
    }

    if (
        !empty(
            $pedido["numero"]
        )
    ) {

        $partesEndereco[] =
            "nº " .
            $pedido["numero"];
    }

    if (
        !empty(
            $pedido["complemento"]
        )
    ) {

        $partesEndereco[] =
            $pedido["complemento"];
    }

    if (
        !empty(
            $pedido["bairro"]
        )
    ) {

        $partesEndereco[] =
            $pedido["bairro"];
    }

    if (
        !empty(
            $pedido["cidade"]
        )
    ) {

        $partesEndereco[] =
            $pedido["cidade"];
    }

    if (
        !empty(
            $pedido["estado"]
        )
    ) {

        $partesEndereco[] =
            $pedido["estado"];
    }

    if (
        !empty(
            $pedido["cep"]
        )
    ) {

        $partesEndereco[] =
            "CEP: " .
            $pedido["cep"];
    }


    $pedido["endereco"] =
        implode(
            ", ",
            $partesEndereco
        );


    $pedidos[] =
        $pedido;
}


$stmtPedidos->close();


/*
|--------------------------------------------------------------------------
| ESTATÍSTICAS
|--------------------------------------------------------------------------
*/

$totalPedidos =
    count($pedidos);

$confirmados = 0;
$andamento   = 0;
$concluidos  = 0;
$cancelados  = 0;


foreach (
    $pedidos
    as $pedido
) {

    $statusNormalizado =
        mb_strtolower(
            trim(
                $pedido["status"]
            ),
            "UTF-8"
        );


    if (
        $statusNormalizado ===
        "encaminhado"
    ) {

        $confirmados++;

    } elseif (
        $statusNormalizado === "a caminho" ||
        $statusNormalizado === "em andamento"
    ) {

        $andamento++;

    } elseif (
        $statusNormalizado ===
        "concluído" ||
        $statusNormalizado ===
        "concluido"
    ) {

        $concluidos++;

    } elseif (
        $statusNormalizado ===
        "suspenso"
    ) {

        $cancelados++;
    }
}


$demandasMotorista = [];
foreach ($pedidos as &$pedido) {
    $pedido['prazo_motorista'] = prazoMotorista($pedido);
    if ($pedido['prazo_motorista']['ativo']) $demandasMotorista[] = $pedido;
}
unset($pedido);
usort($demandasMotorista, static function ($a, $b) {
    return [$a['prazo_motorista']['limite'] ?: '9999', (int)$a['id']] <=> [$b['prazo_motorista']['limite'] ?: '9999', (int)$b['id']];
});
$agendaMotorista = array_map(static function ($p) {
    return ['id'=>(int)$p['id'], 'local'=>trim(($p['rua'] ?? '') . ', ' . ($p['numero'] ?? '') . ' · ' . ($p['bairro'] ?? '')),
        'limite'=>$p['prazo_motorista']['limite'], 'classe'=>$p['prazo_motorista']['classe']];
}, $demandasMotorista);

/*
|--------------------------------------------------------------------------
| INICIAIS
|--------------------------------------------------------------------------
*/

$partesNome =
    preg_split(
        '/\s+/',
        trim(
            $nomeMotorista
        )
    );


$iniciais = "";


if (
    !empty(
        $partesNome[0]
    )
) {

    $iniciais .=
        strtoupper(
            substr(
                $partesNome[0],
                0,
                1
            )
        );
}


if (
    count($partesNome) > 1
) {

    $iniciais .=
        strtoupper(
            substr(
                $partesNome[
                    count($partesNome) - 1
                ],
                0,
                1
            )
        );
}


$iniciais =
    substr(
        $iniciais ?: "M",
        0,
        2
    );

?>

<!DOCTYPE html>

<html lang="pt-BR">

<head>

    <meta charset="UTF-8">

    <meta
        name="viewport"
        content="width=device-width, initial-scale=1.0">

    <title>
        EcoAgenda - Motorista
    </title>

    <link
        rel="stylesheet"
        href="motorista.css?v=20261008-planejamento">

</head>


<body>

<div class="dashboard">


    <!-- =====================================================
         SIDEBAR
    ====================================================== -->

    <aside class="sidebar">

        <div class="logo"><img src="../../assets/icons/logo-ecoagenda-branco.png" alt="EcoAgenda"></div>

        <div class="perfil-side">
            Motorista
        </div>


        <nav class="menu">

            <button
                type="button"
                class="menu-link active"
                data-section="inicio">

                <span>
                    ▦
                </span>

                Dashboard

            </button>


            <button
                type="button"
                class="menu-link"
                data-section="pedidos">

                <span>
                    ▤
                </span>

                Minhas coletas

            </button>


            <button
                type="button"
                class="menu-link"
                data-section="perfil">

                <span>
                    ♙
                </span>

                Meu perfil

            </button>

        </nav>

    </aside>



    <!-- =====================================================
         MAIN
    ====================================================== -->

    <main class="main">


        <header class="topbar">

            <div>

                <h1 id="tituloPagina">
                    Dashboard
                </h1>

                <p id="subtituloPagina">
                    Acompanhe as coletas agendadas para você.
                </p>

            </div>


            <div class="top-actions">

                <span class="motorista-nome">

                    <?= e(
                        $nomeMotorista
                    ) ?>

                </span>


                <a
                    href="../logout.php"
                    class="logout">

                    Sair

                </a>


                <div class="avatar">

                    <?= e(
                        $iniciais
                    ) ?>

                </div>

            </div>

        </header>



        <div class="content">


            <?php if (
                $mensagem !== ""
            ): ?>

                <div
                    class="alerta <?= e(
                        $tipoMensagem
                    ) ?>">

                    <?= e(
                        $mensagem
                    ) ?>

                </div>

            <?php endif; ?>



            <!-- =================================================
                 DASHBOARD
            ================================================== -->

            <section
                class="section active"
                id="section-inicio">


                <div class="mot-agenda">
                    <div class="mot-heading">
                        <div><span class="mot-eyebrow">SEU PLANEJAMENTO</span><h2>Prazo das coletas</h2>
                        <p>Veja até quando atender cada pedido. Você decide o dia e a ordem das coletas.</p></div>
                        <div class="mot-navigation"><button type="button" id="mot-prev" aria-label="Semana anterior">‹</button>
                        <button type="button" id="mot-current">Esta semana</button>
                        <button type="button" id="mot-next" aria-label="Próxima semana">›</button></div>
                    </div>
                    <div class="mot-week-heading"><strong id="mot-week-label"></strong><span>Prazo de 5 dias úteis · segunda a sexta</span></div>
                    <div id="mot-calendar" class="mot-calendar" aria-label="Calendário semanal de prazos"></div>
                    <p class="mot-calendar-help">Clique no pedido para abrir a coleta ou no dia para filtrar as demandas. <span>No celular, deslize a semana para os lados.</span></p>
                    <div class="mot-legend"><span class="valido">Dentro do prazo</span><span class="hoje">Vence hoje</span><span class="vencido">Prazo vencido</span></div>
                    <noscript>Ative o JavaScript para navegar pelo calendário. Todos os pedidos estão na lista abaixo.</noscript>
                </div>
                <div class="mot-demands">
                    <div class="mot-heading"><div><span class="mot-eyebrow">COLETAS A ATENDER</span><h2>Suas demandas</h2>
                        <p>Pedido, local e prazo em uma só visão. Abra a coleta para consultar os detalhes e atualizar o andamento.</p></div>
                        <button type="button" class="btn-primary" data-go-section="pedidos">Ver minhas coletas</button></div>
                    <div class="mot-demand-filters" role="group" aria-label="Filtrar demandas por prazo">
                        <button type="button" data-demand-filter="todos" aria-pressed="true">Todas as pendentes</button>
                        <button type="button" data-demand-filter="valido" aria-pressed="false">Dentro do prazo</button>
                        <button type="button" data-demand-filter="hoje" aria-pressed="false">Vencem hoje</button>
                        <button type="button" data-demand-filter="vencido" aria-pressed="false">Prazo vencido</button>
                    </div>
                    <p id="mot-demand-summary" aria-live="polite"></p>
                    <div class="mot-demand-grid">
                    <?php foreach ($demandasMotorista as $demanda): $prazo = $demanda['prazo_motorista']; ?>
                        <article class="mot-demand-card <?= e($prazo['classe']) ?>" data-prazo="<?= e($prazo['classe']) ?>" data-limite="<?= e($prazo['limite']) ?>">
                            <div class="mot-demand-top"><strong>Pedido #<?= (int)$demanda['id'] ?></strong><span class="mot-badge <?= e($prazo['classe']) ?>"><?= e($prazo['texto']) ?></span></div>
                            <h3><?= e($demanda['bairro'] ?: 'Bairro não informado') ?></h3>
                            <p class="mot-address"><?= e($demanda['endereco']) ?></p>
                            <div class="mot-demand-footer"><div><span>Prazo de atendimento</span><strong><?= e(dataBR($prazo['limite'])) ?></strong></div>
                                <span class="status <?= e(classeStatus($demanda['status'])) ?>"><?= e(mb_strtolower(trim($demanda['status']), 'UTF-8') === 'encaminhado' ? 'Agendado' : $demanda['status']) ?></span></div>
                            <button type="button" class="btn-small mot-open" data-open-pedido="<?= (int)$demanda['id'] ?>">Abrir coleta <span aria-hidden="true">→</span></button>
                        </article>
                    <?php endforeach; ?>
                    </div>
                    <div id="mot-demand-empty" class="sem-registros" <?= $demandasMotorista ? 'hidden' : '' ?>>Nenhuma coleta pendente neste filtro.</div>
                </div>
                <script type="application/json" id="mot-agenda-data"><?= json_encode(['hoje'=>(new DateTimeImmutable('now', new DateTimeZone('America/Sao_Paulo')))->format('Y-m-d'), 'pedidos'=>$agendaMotorista], JSON_HEX_TAG|JSON_HEX_AMP|JSON_HEX_APOS|JSON_HEX_QUOT|JSON_UNESCAPED_UNICODE) ?></script>
            </section>



            <!-- =================================================
                 MINHAS COLETAS
            ================================================== -->

            <section
                class="section"
                id="section-pedidos">


                <div class="section-top">

                    <div>

                        <h2>
                            Minhas coletas
                        </h2>

                        <p>
                            Visualize os pedidos agendados para você e atualize o andamento.
                        </p>

                    </div>


                    <div class="filtros">

                        <button
                            type="button"
                            class="filtro active"
                            data-filter="todos">

                            Todos

                        </button>


                        <button
                            type="button"
                            class="filtro"
                            data-filter="confirmado">

                            Agendados

                        </button>



                        <button
                            type="button"
                            class="filtro"
                            data-filter="a-caminho">

                            A caminho

                        </button>


                        <button
                            type="button"
                            class="filtro"
                            data-filter="andamento">

                            Em andamento

                        </button>


                        <button
                            type="button"
                            class="filtro"
                            data-filter="concluido">

                            Concluídos

                        </button>


                        <button
                            type="button"
                            class="filtro"
                            data-filter="cancelado">

                            Suspensos

                        </button>

                    </div>

                </div>



                <label class="mot-detail-filter">Prazo dos pedidos
                    <select id="mot-detail-filter"><option value="todos">Todos os prazos</option><option value="valido">Dentro do prazo (inclui hoje)</option><option value="hoje">Vencem hoje</option><option value="vencido">Prazo vencido</option></select>
                </label>
                <div class="cards-pedidos">


                    <?php foreach (
                        $pedidos
                        as $pedido
                    ): ?>


                        <?php

                        $classe = classeStatus($pedido["status"]);
                        $filtroStatus = match (mb_strtolower(trim($pedido["status"]), "UTF-8")) {
                            "encaminhado" => "confirmado",
                            "a caminho" => "a-caminho",
                            "em andamento" => "andamento",
                            "concluído", "concluido" => "concluido",
                            "suspenso" => "cancelado",
                            default => "outro"
                        };

                        ?>


                        <article
                            class="pedido-card"
                            id="mot-pedido-<?= (int)$pedido["id"] ?>"
                            data-prazo="<?= e($pedido["prazo_motorista"]["classe"]) ?>"
                            data-status="<?= e($filtroStatus) ?>">


                            <div
                                class="pedido-card-top">


                                <div>

                                    <span
                                        class="numero-pedido">

                                        Pedido #
                                        <?= e(
                                            $pedido[
                                                "id"
                                            ]
                                        ) ?>

                                    </span>


                                    <h3><?= e($pedido['bairro'] ?: 'Local de coleta') ?></h3>


                                    <p>

                                        Morador:

                                        <?= e(
                                            $pedido[
                                                "morador_nome"
                                            ]
                                            ?: "Morador"
                                        ) ?>

                                        •

                                        CPF:

                                        <?= e(
                                            $pedido[
                                                "morador_cpf"
                                            ]
                                        ) ?>

                                    </p>

                                </div>


                                <span
                                    class="status <?= e($classe) ?>">

                                    <?= e(
                                        mb_strtolower(trim($pedido["status"]), "UTF-8") === "encaminhado"
                                            ? "Agendado"
                                            : $pedido["status"]
                                    ) ?>

                                </span>


                            </div>



                            <div class="mot-waste-grid">
                                <?php foreach (explode('|', (string)$pedido['descricao']) as $parteResiduo):
                                    $camposResiduo = explode(':', trim($parteResiduo), 2); ?>
                                    <div><span><?= e(count($camposResiduo) === 2 ? $camposResiduo[0] : 'Descrição') ?></span>
                                    <strong><?= e(count($camposResiduo) === 2 ? trim($camposResiduo[1]) : $camposResiduo[0]) ?></strong></div>
                                <?php endforeach; ?>
                            </div>
                            <div class="mot-detail-deadline">
                                <span class="mot-badge <?= e($pedido['prazo_motorista']['classe']) ?>"><?= e($pedido['prazo_motorista']['texto']) ?></span>
                                <span>Prazo de atendimento: <strong><?= e(dataBR($pedido['prazo_motorista']['limite'])) ?></strong> · 5 dias úteis após o pedido</span>
                            </div>

                            <div
                                class="pedido-meta">


                                <div>

                                    <span>
                                        Endereço
                                    </span>

                                    <strong>

                                        <?= e(
                                            $pedido[
                                                "endereco"
                                            ]
                                        ) ?>

                                    </strong>

                                </div>


                                <div>

                                    <span>
                                        Início da coleta
                                    </span>

                                    <strong>

                                        <?= e(
                                            in_array($classe, ["confirmado", "a-caminho"], true)
                                                ? ($classe === "confirmado" ? "Aguardando deslocamento" : "A caminho")
                                                : dataHoraBR(
                                                    $pedido[
                                                        "data_inicio"
                                                    ]
                                                )
                                        ) ?>

                                    </strong>

                                </div>


                                <div>

                                    <span>
                                        Chegada
                                    </span>

                                    <strong>

                                        <?= e(
                                            dataHoraBR(
                                                $pedido[
                                                    "data_chegada"
                                                ]
                                            )
                                        ) ?>

                                    </strong>

                                </div>


                                <div>

                                    <span>
                                        Finalização
                                    </span>

                                    <strong>

                                        <?= e(
                                            dataHoraBR(
                                                $pedido[
                                                    "data_finalizacao"
                                                ]
                                            )
                                        ) ?>

                                    </strong>

                                </div>


                                <div>

                                    <span>
                                        Telefone do morador
                                    </span>

                                    <strong>

                                        <?= e(
                                            in_array(
                                                mb_strtolower(trim($pedido["status"]), "UTF-8"),
                                                ["concluído", "concluido"],
                                                true
                                            )
                                                ? "Restrito"
                                                : ($pedido["morador_telefone"] ?? "")
                                        ) ?>

                                    </strong>

                                </div>

                            </div>



                            <div
                                class="pedido-actions">


                                <button
                                    type="button"
                                    class="btn-small btn-detalhes"
                                    data-id="<?= (int)$pedido["id"] ?>">

                                    Ver detalhes

                                </button>


                                <?php if (mb_strtolower(trim($pedido["status"]), "UTF-8") === "encaminhado"): ?>

                                    <form method="POST" class="inline-form">
                                        <input type="hidden" name="acao" value="ir_local">
                                        <input type="hidden" name="agendamento_id" value="<?= (int)$pedido["id"] ?>">
                                        <button type="submit" class="btn-small btn-iniciar">
                                            Ir até o local
                                        </button>
                                    </form>

                                <?php elseif (mb_strtolower(trim($pedido["status"]), "UTF-8") === "a caminho"): ?>

                                    <form method="POST" class="inline-form">
                                        <input type="hidden" name="acao" value="iniciar">
                                        <input type="hidden" name="agendamento_id" value="<?= (int)$pedido["id"] ?>">
                                        <button type="submit" class="btn-small btn-iniciar">
                                            Iniciar coleta
                                        </button>
                                    </form>

                                <?php endif; ?>


                                <?php if (
                                    $classe === "andamento"
                                ): ?>

                                    <button
                                        type="button"
                                        class="btn-small btn-concluir"
                                        data-id="<?= (int)$pedido["id"] ?>">

                                        Concluir coleta

                                    </button>

                                    <button
                                        type="button"
                                        class="btn-small btn-suspender"
                                        data-id="<?= (int)$pedido["id"] ?>">

                                        Suspender coleta

                                    </button>

                                <?php endif; ?>


                            </div>



                            <!-- DADOS PARA O JS -->

                            <div
                                class="dados-pedido"

                                id="dados-<?= (int)$pedido["id"] ?>"

                                data-id="<?= (int)$pedido["id"] ?>"

                                data-descricao="<?= e(
                                    $pedido["descricao"]
                                ) ?>"

                                data-status="<?= e(
                                    mb_strtolower(trim($pedido["status"]), "UTF-8") === "encaminhado"
                                        ? "Agendado"
                                        : $pedido["status"]
                                ) ?>"

                                data-morador="<?= e(
                                    $pedido[
                                        "morador_nome"
                                    ] ?? ""
                                ) ?>"

                                data-cpf="<?= e(
                                    $pedido[
                                        "morador_cpf"
                                    ] ?? ""
                                ) ?>"

                                data-telefone="<?= e($pedido["morador_telefone"] ?? "") ?>"

                                data-endereco="<?= e(
                                    $pedido[
                                        "endereco"
                                    ] ?? ""
                                ) ?>"

                                data-data="<?= e(
                                    in_array($classe, ["confirmado", "a-caminho"], true)
                                        ? ""
                                        : ($pedido[
                                            "data_inicio"
                                        ] ?? "")
                                ) ?>"

                                data-hora="<?= e(
                                    in_array($classe, ["confirmado", "a-caminho"], true)
                                        ? ""
                                        : horaBR(
                                            $pedido[
                                                "data_inicio"
                                            ] ?? ""
                                        )
                                ) ?>"

                                data-foto="<?= e(
                                    $pedido[
                                        "foto"
                                    ] ?? ""
                                ) ?>"

                                data-foto-motorista="<?= e(
                                    $pedido[
                                        "foto_motorista"
                                    ] ?? ""
                                ) ?>"

                            ></div>


                        </article>


                    <?php endforeach; ?>


                    <?php if (
                        empty($pedidos)
                    ): ?>

                        <div class="sem-registros">

                            Ainda não existem coletas agendadas para você.

                        </div>

                    <?php endif; ?>


                </div>



                <div
                    id="semResultadoFiltro"
                    class="sem-registros"
                    hidden>

                    Nenhuma coleta encontrada para este filtro.

                </div>


            </section>



            <!-- =================================================
                 PERFIL
            ================================================== -->

            <section
                class="section"
                id="section-perfil">


                <div
                    class="painel perfil-card">


                    <div
                        class="profile-header">


                        <div
                            class="big-avatar">

                            <?= e(
                                $iniciais
                            ) ?>

                        </div>


                        <div>

                            <h2>

                                <?= e(
                                    $nomeMotorista
                                ) ?>

                            </h2>


                            <p>
                                Motorista cadastrado no EcoAgenda.
                            </p>

                        </div>

                    </div>



                    <div
                        class="perfil-grid">


                        <div>

                            <span>
                                E-mail
                            </span>

                            <strong>

                                <?= e(
                                    $dadosMotorista[
                                        "email"
                                    ]
                                ) ?>

                            </strong>

                        </div>


                        <div>

                            <span>
                                CPF
                            </span>

                            <strong>

                                <?= e(
                                    $dadosMotorista[
                                        "cpf"
                                    ]
                                ) ?>

                            </strong>

                        </div>


                        <div>

                            <span>
                                Telefone
                            </span>

                            <strong>

                                <?= e(
                                    $dadosMotorista[
                                        "telefone"
                                    ]
                                ) ?>

                            </strong>

                        </div>


                        <div>

                            <span>
                                CNH
                            </span>

                            <strong>

                                <?= e(
                                    $dadosMotorista[
                                        "cnh"
                                    ]
                                ) ?>

                            </strong>

                        </div>


                        <div>

                            <span>
                                Situação
                            </span>

                            <strong>

                                <?= (
                                    (int)
                                    $dadosMotorista[
                                        "ativo"
                                    ] === 1
                                )
                                ? "Ativo"
                                : "Inativo"
                                ?>

                            </strong>

                        </div>


                    </div>



                    <div
                        class="info-box">

                        Para alterar seus dados cadastrais,
                        procure a administração responsável pelo sistema.

                    </div>


                </div>

            </section>


        </div>

    </main>

</div>



<!-- =========================================================
     MODAL DETALHES
========================================================= -->

<div
    class="modal"
    id="modalDetalhes"
    hidden>


    <div class="modal-box">


        <div class="modal-header">


            <div>

                <span
                    id="modalPedidoId">

                    Pedido

                </span>


                <h2
                    id="modalTitulo">

                    Detalhes da coleta

                </h2>

            </div>


            <button
                type="button"
                class="modal-close"
                data-close-modal>

                ×

            </button>

        </div>



        <div class="modal-body">


            <div
                class="modal-status">

                <span>
                    Status
                </span>

                <strong
                    id="modalStatus">

                    —

                </strong>

            </div>



            <div
                class="detalhes-grid">


                <div>

                    <span>
                        Morador
                    </span>

                    <strong
                        id="modalMorador">

                        —

                    </strong>

                </div>


                <div>

                    <span>
                        CPF
                    </span>

                    <strong
                        id="modalCpf">

                        —

                    </strong>

                </div>


                <div id="blocoTelefoneMorador">

                    <span>
                        Telefone
                    </span>

                    <strong
                        id="modalTelefone">

                        —

                    </strong>

                </div>


                <div>

                    <span>
                        Início da coleta
                    </span>

                    <strong
                        id="modalData">

                        —

                    </strong>

                </div>


                <div>

                    <span>
                        Horário
                    </span>

                    <strong
                        id="modalHora">

                        —

                    </strong>

                </div>


                <div class="full">

                    <span>
                        Endereço
                    </span>

                    <strong
                        id="modalEndereco">

                        —

                    </strong>

                </div>


                <div class="full">

                    <span>
                        Descrição
                    </span>

                    <strong
                        id="modalDescricao">

                        —

                    </strong>

                </div>


            </div>



            <div
                id="modalFotoMotoristaAtual"
                class="foto-modal"
                hidden>

                <span>
                    Foto registrada pelo motorista
                </span>


                <img
                    id="modalFotoMotorista"
                    src=""
                    alt="Foto da coleta">

            </div>

        </div>



        <div
            class="modal-footer">


            <button
                type="button"
                class="btn-secondary"
                data-close-modal>

                Fechar

            </button>


        </div>

    </div>

</div>



<!-- =========================================================
     MODAL CONCLUIR
========================================================= -->

<div
    class="modal"
    id="modalConcluir"
    hidden>


    <div
        class="modal-box small">


        <div class="modal-header">


            <div>

                <span>
                    Finalizar coleta
                </span>

                <h2>
                    Concluir pedido
                </h2>

            </div>


            <button
                type="button"
                class="modal-close"
                data-close-modal>

                ×

            </button>

        </div>



        <form
            method="POST"
            enctype="multipart/form-data"
            class="modal-form">


            <input
                type="hidden"
                name="acao"
                value="concluir">


            <input
                type="hidden"
                name="agendamento_id"
                id="concluirId">


            <div class="info-box">

                Confirme a conclusão da coleta.
                A foto do material coletado é obrigatória para finalizar o pedido.

            </div>


            <div class="campo">

                <label
                    for="foto_motorista">

                    Foto da coleta

                    <span>
                        obrigatória
                    </span>

                </label>


                <input
                    type="file"
                    id="foto_motorista"
                    name="foto_motorista"
                    accept="image/jpeg,image/png,image/webp"
                    capture="environment"
                    required>

            </div>


            <div
                id="previewFoto"
                class="preview"
                hidden>


                <img
                    id="previewImagem"
                    src=""
                    alt="Pré-visualização">

            </div>



            <div
                class="form-actions">


                <button
                    type="button"
                    class="btn-secondary"
                    data-close-modal>

                    Cancelar

                </button>


                <button
                    type="submit"
                    class="btn-primary">

                    Concluir coleta

                </button>

            </div>


        </form>

    </div>

</div>




<!-- =========================================================
     MODAL SUSPENDER COLETA
========================================================= -->

<div
    class="modal"
    id="modalSuspender"
    hidden>

    <div
        class="modal-box small">

        <div class="modal-header">

            <div>

                <span>
                    Suspensão da coleta
                </span>

                <h2>
                    Suspender coleta
                </h2>

            </div>

            <button
                type="button"
                class="modal-close"
                data-close-modal>

                ×

            </button>

        </div>

        <form
            method="POST"
            enctype="multipart/form-data"
            class="modal-form">

            <input
                type="hidden"
                name="acao"
                value="suspender">

            <input
                type="hidden"
                name="agendamento_id"
                id="suspenderId">

            <div class="warning-box">
                Registre a foto do ocorrido e descreva o motivo da suspensão. O pedido será registrado com status <strong>Suspenso</strong>.
            </div>

            <div class="campo">

                <label
                    for="foto_suspensao">

                    Foto do ocorrido

                    <span>
                        obrigatória
                    </span>

                </label>

                <input
                    type="file"
                    id="foto_suspensao"
                    name="foto_suspensao"
                    accept="image/jpeg,image/png,image/webp"
                    capture="environment"
                    required>

            </div>

            <div
                id="previewFotoSuspensao"
                class="preview"
                hidden>

                <img
                    id="previewImagemSuspensao"
                    src=""
                    alt="Pré-visualização da foto do ocorrido">

            </div>

            <div class="campo">

                <label
                    for="justificativaSuspensao">

                    Justificativa

                    <span>
                        obrigatória
                    </span>

                </label>

                <textarea
                    id="justificativaSuspensao"
                    name="justificativa_suspensao"
                    maxlength="225"
                    rows="5"
                    placeholder="Descreva o que foi encontrado no local e por que a coleta não pôde ser realizada."
                    required></textarea>

                <small class="contador-caracteres">
                    Máximo de 225 caracteres.
                </small>

            </div>

            <div class="form-actions">

                <button
                    type="button"
                    class="btn-secondary"
                    data-close-modal>

                    Voltar

                </button>

                <button
                    type="submit"
                    class="btn-danger">

                    Confirmar suspensão

                </button>

            </div>

        </form>

    </div>

</div>


<script
    src="motorista.js?v=20261008-planejamento">
</script>


</body>

</html>