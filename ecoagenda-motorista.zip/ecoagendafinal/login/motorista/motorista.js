document.addEventListener("DOMContentLoaded", () => {

    const menuLinks =
        document.querySelectorAll(".menu-link");

    const sections =
        document.querySelectorAll(".section");

    const titulo =
        document.getElementById("tituloPagina");

    const subtitulo =
        document.getElementById("subtituloPagina");


    const textos = {

        inicio: {
            titulo: "Dashboard",
            subtitulo:
                "Acompanhe as coletas encaminhadas para você."
        },

        pedidos: {
            titulo: "Minhas coletas",
            subtitulo:
                "Visualize os pedidos encaminhados para você e atualize o andamento."
        },

        historico: {
            titulo: "Histórico",
            subtitulo:
                "Consulte as atualizações realizadas por você."
        },

        perfil: {
            titulo: "Meu perfil",
            subtitulo:
                "Confira seus dados cadastrados."
        }

    };


    /* =====================================================
       NAVEGAÇÃO
    ====================================================== */

    function abrirSecao(nome) {

        sections.forEach((section) => {

            section.classList.toggle(
                "active",
                section.id ===
                `section-${nome}`
            );

        });


        menuLinks.forEach((link) => {

            link.classList.toggle(
                "active",
                link.dataset.section === nome
            );

        });


        if (textos[nome]) {

            titulo.textContent =
                textos[nome].titulo;

            subtitulo.textContent =
                textos[nome].subtitulo;
        }


        window.scrollTo({
            top: 0,
            behavior: "smooth"
        });

    }


    menuLinks.forEach((link) => {

        link.addEventListener(
            "click",
            () => {

                abrirSecao(
                    link.dataset.section
                );

            }
        );

    });


    document
        .querySelectorAll("[data-go-section]")
        .forEach((botao) => {

            botao.addEventListener(
                "click",
                () => {

                    abrirSecao(
                        botao.dataset.goSection
                    );

                }
            );

        });


    /* =====================================================
       FILTROS
    ====================================================== */

    const filtroStatus = document.getElementById('mot-status-filter');

    const cards =
        document.querySelectorAll(".pedido-card");

    const semResultado =
        document.getElementById(
            "semResultadoFiltro"
        );


    const filtroPrazo = document.getElementById('mot-detail-filter');
    function filtrarDetalhes() {
        const status = filtroStatus?.value || 'todos';
        const prazo = filtroPrazo?.value || 'todos';
        let encontrados=0;
        cards.forEach(card => {
            const atendePrazo = prazo==='todos' || card.dataset.prazo===prazo || (prazo==='valido' && card.dataset.prazo==='hoje');
            card.hidden = !((status==='todos' || card.dataset.status===status) && atendePrazo);
            if (!card.hidden) encontrados++;
        });
        if (semResultado) semResultado.hidden=encontrados>0;
    }
    filtroStatus?.addEventListener('change', filtrarDetalhes);
    filtroPrazo?.addEventListener('change', filtrarDetalhes);
    function abrirColeta(id) {
        document.querySelector(`#mot-pedido-${id} .btn-detalhes`)?.click();
    }
    const agendaElement=document.getElementById('mot-agenda-data');
    if (agendaElement) {
        const agenda=JSON.parse(agendaElement.textContent);
        const toDate=value => {const [y,m,d]=value.split('-').map(Number); return new Date(y,m-1,d,12);};
        const iso=date => `${date.getFullYear()}-${String(date.getMonth()+1).padStart(2,'0')}-${String(date.getDate()).padStart(2,'0')}`;
        const hoje=toDate(agenda.hoje);
        let semana=new Date(hoje); semana.setDate(semana.getDate()-((semana.getDay()+6)%7));
        const inicioAtual=new Date(semana);
        const container=document.getElementById('mot-calendar');
        const demandCards=[...document.querySelectorAll('.mot-demand-card')];
        const demandStatus=document.getElementById('mot-demand-status');
        const demandPrazo=document.getElementById('mot-demand-prazo');
        const clearDay=document.getElementById('mot-clear-day');
        let diaSelecionado='';
        function filtrarDemandas(dia) {
            if (typeof dia==='string') diaSelecionado=dia;
            const filtro=demandPrazo.value, status=demandStatus.value;
            let count=0;
            demandCards.forEach(card => {
                const prazo=filtro==='todos' || card.dataset.prazo===filtro || (filtro==='valido' && card.dataset.prazo==='hoje');
                const match=prazo && (status==='todos' || card.dataset.status===status) && (!diaSelecionado || card.dataset.limite===diaSelecionado);
                card.hidden=!match; if(match) count++;
            });
            clearDay.hidden=!diaSelecionado;
            document.getElementById('mot-demand-empty').hidden=count>0;
            const atrasados=agenda.pedidos.filter(p=>p.classe==='vencido').length;
            document.getElementById('mot-demand-summary').textContent=diaSelecionado ? `${count} pedido(s) com prazo em ${toDate(diaSelecionado).toLocaleDateString('pt-BR')}.` : `${count} coleta(s) neste filtro · ${atrasados} com prazo vencido no total.`;
        }
        [demandStatus,demandPrazo].forEach(select=>select.addEventListener('change',()=>filtrarDemandas()));
        clearDay.addEventListener('click',()=>filtrarDemandas(''));
        function renderSemana() {
            container.replaceChildren();
            const fim=new Date(semana);fim.setDate(fim.getDate()+6);
            document.getElementById('mot-week-label').textContent=`${semana.toLocaleDateString('pt-BR')} — ${fim.toLocaleDateString('pt-BR')}`;
            for(let i=0;i<7;i++) {
                const dia=new Date(semana);dia.setDate(dia.getDate()+i); const key=iso(dia);
                const col=document.createElement('div');col.className=`mot-day${i>4?' mot-weekend':''}${key===agenda.hoje?' mot-today':''}`;
                const heading=document.createElement('button');heading.type='button';heading.className='mot-day-heading';
                heading.textContent=`${['Seg','Ter','Qua','Qui','Sex','Sáb','Dom'][i]} ${String(dia.getDate()).padStart(2,'0')}`;
                heading.setAttribute('aria-label',`Ver pedidos com prazo em ${dia.toLocaleDateString('pt-BR')}`);
                heading.addEventListener('click',()=>filtrarDemandas(key)); col.append(heading);
                const pedidos=agenda.pedidos.filter(p=>p.limite===key);
                pedidos.forEach(p=>{
                    const button=document.createElement('button');button.type='button';button.className=`mot-calendar-order ${p.classe}`;
                    const numero=document.createElement('strong');numero.textContent=`Pedido #${p.id}`;
                    const local=document.createElement('span');local.textContent=p.local;
                    button.append(numero,local);if(p.classe==='hoje'){const aviso=document.createElement('span');aviso.textContent='VENCEM HOJE';aviso.className='mot-today-notice';button.append(aviso);}button.addEventListener('click',()=>abrirColeta(p.id));col.append(button);
                });
                if(!pedidos.length){const empty=document.createElement('p');empty.className='mot-day-empty';empty.textContent=i>4?'Fim de semana':'Sem prazo neste dia';col.append(empty);}
                container.append(col);
            }
        }
        document.getElementById('mot-prev').addEventListener('click',()=>{semana.setDate(semana.getDate()-7);renderSemana();});
        document.getElementById('mot-next').addEventListener('click',()=>{semana.setDate(semana.getDate()+7);renderSemana();});
        document.getElementById('mot-current').addEventListener('click',()=>{semana=new Date(inicioAtual);renderSemana();});
        renderSemana();filtrarDemandas();
    }

    /* =====================================================
       MODAIS
    ====================================================== */

    const modalDetalhes =
        document.getElementById(
            "modalDetalhes"
        );

    const modalConcluir =
        document.getElementById(
            "modalConcluir"
        );

    const modalSuspender =
        document.getElementById(
            "modalSuspender"
        );


    function abrirModal(modal) {

        if (!modal) {
            return;
        }

        modal.hidden = false;

        document.body.style.overflow =
            "hidden";

    }


    function fecharModais() {

        [modalDetalhes, modalConcluir, modalSuspender]
            .forEach((modal) => {

                if (modal) {
                    modal.hidden = true;
                }

            });

        document.body.style.overflow =
            "";

    }


    document
        .querySelectorAll("[data-close-modal]")
        .forEach((botao) => {

            botao.addEventListener(
                "click",
                fecharModais
            );

        });


    [modalDetalhes, modalConcluir, modalSuspender]
        .forEach((modal) => {

            if (!modal) {
                return;
            }

            modal.addEventListener(
                "click",
                (event) => {

                    if (
                        event.target === modal
                    ) {

                        fecharModais();

                    }

                }
            );

        });


    document.addEventListener(
        "keydown",
        (event) => {

            if (event.key === "Escape") {
                fecharModais();
            }

        }
    );


    /* =====================================================
       DADOS DO PEDIDO
    ====================================================== */

    function obterDados(id) {

        const elemento =
            document.getElementById(
                `dados-${id}`
            );

        if (!elemento) {
            return null;
        }


        return {

            id:
                elemento.dataset.id,

            descricao:
                elemento.dataset.descricao || "",

            status:
                elemento.dataset.status || "",

            morador:
                elemento.dataset.morador || "",

            cpf:
                elemento.dataset.cpf || "",

            telefone:
                elemento.dataset.telefone || "",

            endereco:
                elemento.dataset.endereco || "",

            data:
                elemento.dataset.data || "",

            hora:
                elemento.dataset.hora || "",

            fotoMotorista:
                elemento.dataset.fotoMotorista || ""

        };

    }


    /* =====================================================
       DETALHES DO PEDIDO
    ====================================================== */

    document
        .querySelectorAll(".btn-detalhes")
        .forEach((botao) => {

            botao.addEventListener(
                "click",
                () => {

                    const dados =
                        obterDados(
                            botao.dataset.id
                        );

                    if (!dados) {
                        return;
                    }


                    document.getElementById(
                        "modalPedidoId"
                    ).textContent =
                        `Pedido #${dados.id}`;


                    document.getElementById(
                        "modalTitulo"
                    ).textContent =
                        dados.descricao;


                    document.getElementById(
                        "modalStatus"
                    ).textContent =
                        dados.status || "—";


                    document.getElementById(
                        "modalMorador"
                    ).textContent =
                        dados.morador ||
                        "Cadastro por CPF";


                    document.getElementById(
                        "modalCpf"
                    ).textContent =
                        dados.cpf || "—";


                    document.getElementById(
                        "modalTelefone"
                    ).textContent =
                        dados.telefone || "—";


                    document.getElementById(
                        "modalData"
                    ).textContent =
                        dados.data
                        ? formatarData(
                            dados.data
                        )
                        : "Ainda não definida";


                    document.getElementById(
                        "modalHora"
                    ).textContent =
                        dados.hora ||
                        "Ainda não definido";


                    document.getElementById(
                        "modalEndereco"
                    ).textContent =
                        dados.endereco || "—";


                    document.getElementById(
                        "modalDescricao"
                    ).textContent =
                        dados.descricao || "—";


                    const elementoDados = document.getElementById(`dados-${dados.id}`);
                    document.getElementById('mot-modal-prazo').textContent=elementoDados.dataset.prazo || '—';
                    document.getElementById('mot-modal-prazo-texto').textContent=elementoDados.dataset.prazoTexto + (elementoDados.dataset.prazoHoje==='1' ? ' · VENCEM HOJE' : '');
                    document.getElementById('mot-modal-chegada').textContent=elementoDados.dataset.chegada || '—';
                    document.getElementById('mot-modal-finalizacao').textContent=elementoDados.dataset.finalizacao || '—';
                    document.getElementById('modalTitulo').textContent='Detalhes da coleta';
                    const acoes=document.getElementById('mot-modal-actions');
                    acoes.replaceChildren();
                    document.querySelectorAll(`#mot-actions-${dados.id} button`).forEach(original => {
                        const botaoAcao=document.createElement('button');
                        botaoAcao.type='button';botaoAcao.className='btn-small';botaoAcao.textContent=original.textContent.trim();
                        botaoAcao.addEventListener('click',()=>{
                            if(original.matches('.btn-concluir,.btn-suspender')) modalDetalhes.hidden=true;
                            original.click();
                        });
                        acoes.append(botaoAcao);
                    });

                    const blocoFoto =
                        document.getElementById(
                            "modalFotoMotoristaAtual"
                        );

                    const foto =
                        document.getElementById(
                            "modalFotoMotorista"
                        );


                    if (
                        dados.fotoMotorista
                    ) {

                        foto.src =
                            `../../agendamento/${dados.fotoMotorista}`;

                        blocoFoto.hidden = false;

                    } else {

                        foto.src = "";
                        blocoFoto.hidden = true;

                    }


                    abrirModal(
                        modalDetalhes
                    );

                }
            );

        });


    /* =====================================================
       SUSPENDER COLETA
    ====================================================== */

    document
        .querySelectorAll(".btn-suspender")
        .forEach((botao) => {

            botao.addEventListener(
                "click",
                () => {

                    const id =
                        botao.dataset.id || "";

                    const campoId =
                        document.getElementById(
                            "suspenderId"
                        );

                    const formulario =
                        modalSuspender?.querySelector(
                            "form"
                        );

                    const inputFoto =
                        document.getElementById(
                            "foto_suspensao"
                        );

                    const justificativa =
                        document.getElementById(
                            "justificativaSuspensao"
                        );

                    const preview =
                        document.getElementById(
                            "previewFotoSuspensao"
                        );

                    const previewImagem =
                        document.getElementById(
                            "previewImagemSuspensao"
                        );

                    if (!modalSuspender || !campoId) {
                        return;
                    }

                    if (formulario) {
                        formulario.reset();
                    }

                    campoId.value = id;

                    if (preview) {
                        preview.hidden = true;
                    }

                    if (previewImagem) {
                        previewImagem.src = "";
                    }

                    if (justificativa) {
                        justificativa.value = "";
                    }

                    if (inputFoto) {
                        inputFoto.value = "";
                    }

                    abrirModal(modalSuspender);
                }
            );

        });


    /* =====================================================
       PRÉ-VISUALIZAÇÃO DA FOTO DA SUSPENSÃO
    ====================================================== */

    const inputFotoSuspensao =
        document.getElementById(
            "foto_suspensao"
        );

    const previewSuspensao =
        document.getElementById(
            "previewFotoSuspensao"
        );

    const previewImagemSuspensao =
        document.getElementById(
            "previewImagemSuspensao"
        );

    inputFotoSuspensao?.addEventListener(
        "change",
        () => {

            const arquivo =
                inputFotoSuspensao.files[0];

            if (!arquivo) {
                if (previewSuspensao) {
                    previewSuspensao.hidden = true;
                }

                if (previewImagemSuspensao) {
                    previewImagemSuspensao.src = "";
                }

                return;
            }

            if (!arquivo.type.startsWith("image/")) {
                alert("Selecione um arquivo de imagem.");
                inputFotoSuspensao.value = "";

                if (previewSuspensao) {
                    previewSuspensao.hidden = true;
                }

                return;
            }

            if (arquivo.size > 5 * 1024 * 1024) {
                alert("A foto deve ter no máximo 5 MB.");
                inputFotoSuspensao.value = "";

                if (previewSuspensao) {
                    previewSuspensao.hidden = true;
                }

                return;
            }

            const leitor =
                new FileReader();

            leitor.onload = (event) => {

                if (previewImagemSuspensao) {
                    previewImagemSuspensao.src =
                        event.target.result;
                }

                if (previewSuspensao) {
                    previewSuspensao.hidden = false;
                }
            };

            leitor.readAsDataURL(arquivo);
        }
    );


    /* =====================================================
       ABRIR MODAL DE CONCLUSÃO
    ====================================================== */

    document
        .querySelectorAll(".btn-concluir")
        .forEach((botao) => {

            botao.addEventListener(
                "click",
                () => {

                    const campoId =
                        document.getElementById(
                            "concluirId"
                        );

                    if (!campoId || !modalConcluir) {
                        return;
                    }

                    campoId.value =
                        botao.dataset.id;

                    abrirModal(
                        modalConcluir
                    );

                }
            );

        });


    /* =====================================================
       CONFIRMAÇÃO DO INÍCIO DA COLETA
    ====================================================== */

    document
        .querySelectorAll(".btn-iniciar")
        .forEach((botao) => {

            const formulario =
                botao.closest("form");

            formulario?.addEventListener(
                "submit",
                (event) => {

                    const confirmar =
                        window.confirm(
                            "Deseja realmente iniciar esta coleta agora?"
                        );

                    if (!confirmar) {
                        event.preventDefault();
                        return;
                    }

                    botao.disabled = true;
                    botao.textContent = "Iniciando...";

                }
            );

        });


    /* =====================================================
       PRÉ-VISUALIZAÇÃO DA FOTO DA COLETA
    ====================================================== */

    const inputFoto =
        document.getElementById(
            "foto_motorista"
        );

    const preview =
        document.getElementById(
            "previewFoto"
        );

    const previewImagem =
        document.getElementById(
            "previewImagem"
        );


    inputFoto?.addEventListener(
        "change",
        () => {

            const arquivo =
                inputFoto.files[0];


            if (!arquivo) {

                if (preview) {
                    preview.hidden = true;
                }

                if (previewImagem) {
                    previewImagem.src = "";
                }

                return;

            }


            if (
                !arquivo.type.startsWith(
                    "image/"
                )
            ) {

                alert(
                    "Selecione um arquivo de imagem."
                );

                inputFoto.value = "";

                if (preview) {
                    preview.hidden = true;
                }

                return;

            }


            if (
                arquivo.size >
                5 * 1024 * 1024
            ) {

                alert(
                    "A foto deve ter no máximo 5 MB."
                );

                inputFoto.value = "";

                if (preview) {
                    preview.hidden = true;
                }

                return;

            }


            const leitor =
                new FileReader();


            leitor.onload = (event) => {

                if (previewImagem) {
                    previewImagem.src =
                        event.target.result;
                }

                if (preview) {
                    preview.hidden = false;
                }

            };


            leitor.readAsDataURL(
                arquivo
            );

        }
    );


    /* =====================================================
       PREVENIR DUPLO ENVIO DA CONCLUSÃO
    ====================================================== */

    const formularioConclusao =
        modalConcluir?.querySelector("form");

    formularioConclusao?.addEventListener(
        "submit",
        (event) => {

            const botao =
                formularioConclusao.querySelector(
                    "button[type=\"submit\"]"
                );

            if (botao) {
                botao.disabled = true;
                botao.textContent = "Concluindo...";
            }

        }
    );


    /* =====================================================
       FORMATAÇÃO DE DATA
    ====================================================== */

    function formatarData(data) {

        const texto =
            String(data || "").trim();


        if (!texto) {
            return "";
        }


        const apenasData =
            texto
                .replace("T", " ")
                .split(" ")[0];

        const partes =
            apenasData.split("-");


        if (partes.length !== 3) {
            return texto;
        }


        return (
            partes[2] +
            "/" +
            partes[1] +
            "/" +
            partes[0]
        );

    }


    /* =====================================================
       ALERTA
    ====================================================== */

    const alerta =
        document.querySelector(".alerta");


    if (alerta) {

        setTimeout(() => {

            alerta.style.opacity = "0";
            alerta.style.transition =
                "opacity .4s ease";

            setTimeout(() => {

                alerta.remove();

            }, 400);

        }, 5000);

    }

});