<?php
declare(strict_types=1);

/** Incorpora a mesma Montserrat local das telas, sem depender de fontes do leitor. */
function pdfFonteMontserrat(callable $addObject, int $peso): int {
    $base=__DIR__.'/../interface/fonts/montserrat-'.$peso;
    $meta=json_decode((string)file_get_contents($base.'.json'),true,512,JSON_THROW_ON_ERROR);
    $font=(string)file_get_contents($base.'.ttf');$compressed=gzcompress($font,9);
    $fontFile=$addObject('<< /Length '.strlen($compressed).' /Length1 '.strlen($font).' /Filter /FlateDecode >>'."\nstream\n".$compressed."\nendstream");
    $name=$meta['name'];
    $descriptor=$addObject('<< /Type /FontDescriptor /FontName /'.$name.' /Flags 32 /FontBBox ['.implode(' ',$meta['bbox']).'] /ItalicAngle 0 /Ascent '.$meta['ascent'].' /Descent '.$meta['descent'].' /CapHeight '.$meta['capHeight'].' /StemV '.($peso===700?120:80).' /FontFile2 '.$fontFile.' 0 R >>');
    $mappings=[];
    for($i=32;$i<=255;$i++){
        $unicode=@iconv('Windows-1252','UTF-16BE',chr($i));
        if($unicode!==false)$mappings[]=sprintf('<%02X> <%s>',$i,strtoupper(bin2hex($unicode)));
    }
    $cmap="/CIDInit /ProcSet findresource begin\n12 dict begin\nbegincmap\n/CIDSystemInfo << /Registry (Adobe) /Ordering (UCS) /Supplement 0 >> def\n/CMapName /MontserratUnicode def\n/CMapType 2 def\n1 begincodespacerange\n<00> <FF>\nendcodespacerange\n";
    foreach(array_chunk($mappings,90) as $chunk)$cmap.=count($chunk)." beginbfchar\n".implode("\n",$chunk)."\nendbfchar\n";
    $cmap.="endcmap\nCMapName currentdict /CMap defineresource pop\nend\nend";
    $unicodeId=$addObject('<< /Length '.strlen($cmap).' >>'."\nstream\n".$cmap."\nendstream");
    return $addObject('<< /Type /Font /Subtype /TrueType /BaseFont /'.$name.' /FirstChar 32 /LastChar 255 /Widths ['.implode(' ',$meta['widths']).'] /FontDescriptor '.$descriptor.' 0 R /Encoding /WinAnsiEncoding /ToUnicode '.$unicodeId.' 0 R >>');
}
