<?php
/** Monta MIME sem conexão de rede; a logo é incorporada, sem URL externa. */
function eaMensagemMime(string $destinatario,string $assunto,string $html,string $texto,string $remetente,string $nomeRemetente): string {
    $alt='=_EcoAgenda_alt_'.bin2hex(random_bytes(12));$related='=_EcoAgenda_related_'.bin2hex(random_bytes(12));
    $logo=__DIR__.'/../assets/icons/logo-ecoagenda-branco.png';
    $inline=str_contains($html,'cid:ecoagenda-logo') && is_readable($logo);
    $encoded='=?UTF-8?B?'.base64_encode($assunto).'?=';
    $body='From: =?UTF-8?B?'.base64_encode($nomeRemetente).'?= <'.$remetente.">\r\nTo: <".$destinatario.">\r\nSubject: ".$encoded."\r\nDate: ".date(DATE_RFC2822)."\r\nMIME-Version: 1.0\r\nContent-Type: multipart/alternative; boundary=\"".$alt."\"\r\n\r\n";
    $body.='--'.$alt."\r\nContent-Type: text/plain; charset=UTF-8\r\nContent-Transfer-Encoding: base64\r\n\r\n".chunk_split(base64_encode($texto))."\r\n";
    $body.='--'.$alt."\r\n";
    if($inline)$body.='Content-Type: multipart/related; boundary="'.$related."\"\r\n\r\n--".$related."\r\n";
    $body.="Content-Type: text/html; charset=UTF-8\r\nContent-Transfer-Encoding: base64\r\n\r\n".chunk_split(base64_encode($html))."\r\n";
    if($inline)$body.='--'.$related."\r\nContent-Type: image/png; name=\"ecoagenda.png\"\r\nContent-ID: <ecoagenda-logo>\r\nContent-Disposition: inline; filename=\"ecoagenda.png\"\r\nContent-Transfer-Encoding: base64\r\n\r\n".chunk_split(base64_encode(file_get_contents($logo)))."\r\n--".$related."--\r\n";
    return $body.'--'.$alt."--\r\n";
}
function eaConteudoStatus(string $nomeMorador,int $idPedido,string $status): array {
    $chave=mb_strtolower(trim($status),'UTF-8');
    [$rotulo,$cor,$explicacao]=match($chave){
        'agendado','encaminhado','confirmado'=>['Agendado','#FF4000','Seu pedido foi encaminhado a um motorista para organizar a coleta.'],
        'a caminho'=>['A caminho','#FFA100','O motorista está se deslocando até o local da coleta.'],
        'em andamento'=>['Em andamento','#00B330','O motorista chegou ao local e a coleta está sendo realizada.'],
        'concluído','concluido'=>['Concluído','#009161','A coleta foi finalizada pelo motorista. Obrigado por contribuir com uma cidade mais limpa.'],
        'suspenso','cancelado'=>['Suspenso','#808080','O atendimento foi interrompido. Consulte os detalhes do pedido para verificar o motivo e a orientação.'],
        default=>['Em análise','#D40035','Recebemos seu pedido. A Secretaria está conferindo as informações.']
    };
    $nome=htmlspecialchars($nomeMorador ?: 'Morador',ENT_QUOTES,'UTF-8');
    $html="<!DOCTYPE html><html lang='pt-BR'><head><meta charset='UTF-8'></head><body style='margin:0;background:#eaf3ed;font-family:Montserrat,Arial,sans-serif;color:#24583b;padding:24px 12px'><table role='presentation' style='max-width:580px;width:100%;margin:auto;border-spacing:0;background:white;border-radius:20px;overflow:hidden'><tr><td style='background:#07532d;padding:26px 30px'><img src='cid:ecoagenda-logo' alt='EcoAgenda' width='180' style='display:block;max-width:100%;height:auto;color:white'></td></tr><tr><td style='padding:30px'><p>Olá, <strong>{$nome}</strong>!</p><p style='color:#758c7d;font-size:13px;margin-bottom:5px'>Atualização da sua coleta</p><h1 style='margin:0 0 24px;font-size:28px;color:#24583b'>Pedido {$idPedido}</h1><p style='border-left:4px solid {$cor};background:#f4f8f5;padding:14px 18px;border-radius:8px;font-weight:bold'>{$rotulo}</p><p style='font-size:15px;line-height:1.8'>{$explicacao}</p><p style='font-size:13px;line-height:1.8;color:#678271'>Você pode acompanhar o pedido no EcoAgenda. Se ele foi solicitado por telefone e você ainda não tem conta, cadastre-se usando o mesmo CPF e e-mail informados à Secretaria. Seus pedidos estarão disponíveis após a confirmação do cadastro.</p><p style='font-size:11px;color:#819487;border-top:1px solid #deebe3;padding-top:18px'>Mensagem automática do EcoAgenda. Não responda a este e-mail.</p></td></tr></table></body></html>";
    return ['html'=>$html,'texto'=>"Olá, {$nomeMorador}. Pedido {$idPedido}: {$rotulo}. {$explicacao} Acompanhe no EcoAgenda. Se ainda não tem conta, cadastre-se com o mesmo CPF e e-mail informados à Secretaria."];
}
