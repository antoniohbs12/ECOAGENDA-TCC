document.addEventListener("DOMContentLoaded", () => {

    // =========================================================
    // MOSTRAR / OCULTAR SENHA
    // =========================================================

    const mostrarSenha = document.getElementById("mostrarSenha");
    const senha = document.getElementById("senha");

    if (mostrarSenha && senha) {

        mostrarSenha.addEventListener("click", () => {

            if (senha.type === "password") {
                senha.type = "text";
                mostrarSenha.textContent = "🙈";
            } else {
                senha.type = "password";
                mostrarSenha.textContent = "👁";
            }

        });

    }


    // =========================================================
    // VERIFICAR MENSAGEM DE ERRO DO login.php
    // =========================================================

    const parametros = new URLSearchParams(window.location.search);
    const erro = parametros.get("erro");

    if (erro) {

        // Mostra o alerta
        const message=document.getElementById('mensagemErro');
        if(message){message.textContent=erro;message.style.display='block';message.setAttribute('role','alert');}

        // Remove o erro da URL depois do alerta
        const novaURL =
            window.location.origin +
            window.location.pathname;

        window.history.replaceState({}, document.title, novaURL);
    }


    // =========================================================
    // BOTÃO GOV.BR
    // =========================================================

    const btnGov = document.getElementById("btnGov");

    if (btnGov) {

        btnGov.addEventListener("click", () => {

            alert(
                "O acesso pelo Gov.br será disponibilizado posteriormente."
            );

        });

    }

});