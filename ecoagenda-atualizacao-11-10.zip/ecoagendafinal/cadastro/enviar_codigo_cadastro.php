<?php
session_start();
header("Content-Type: application/json; charset=utf-8");
function responderCadastroEmail(int $status, array $dados): void {
    http_response_code($status);
    echo json_encode($dados, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);
    exit;
}
if ($_SERVER["REQUEST_METHOD"] !== "POST") responderCadastroEmail(405, ["sucesso" => false, "mensagem" => "Método não permitido."]);
$entrada = json_decode(file_get_contents("php://input"), true);
$email = strtolower(trim((string)($entrada["email"] ?? "")));
if (!filter_var($email, FILTER_VALIDATE_EMAIL)) responderCadastroEmail(422, ["sucesso" => false, "mensagem" => "Informe um e-mail válido."]);
require_once __DIR__ . "/../config.php";
$stmt = $conn->prepare("SELECT email FROM usuario WHERE email = ? AND senha <> '!ecoagenda:telefone:v1' LIMIT 1");
if (!$stmt) responderCadastroEmail(500, ["sucesso" => false, "mensagem" => "Não foi possível verificar o e-mail no banco de dados."]);
$stmt->bind_param("s", $email);
$stmt->execute();
$resultado = $stmt->get_result();
$emailExiste = $resultado && $resultado->num_rows > 0;
$stmt->close();
if ($emailExiste) responderCadastroEmail(409, ["sucesso" => false, "mensagem" => "Este e-mail já está cadastrado."]);
require_once __DIR__ . "/../login/enviar_email.php";
$codigo = (string)random_int(100000, 999999);
$codigoSeguro = htmlspecialchars($codigo, ENT_QUOTES, "UTF-8");
$htmlEmail = "<!DOCTYPE html><html lang='pt-BR'><head><meta charset='UTF-8'></head><body style='margin:0;background:#f5f7f6;font-family:Arial,sans-serif;color:#26342b;'><div style='max-width:560px;margin:40px auto;padding:32px;background:#ffffff;border-radius:16px;'><h2 style='color:#07612b;'>Confirmação de cadastro - EcoAgenda</h2><p>Use o código abaixo para confirmar seu e-mail e finalizar seu cadastro no EcoAgenda.</p><div style='padding:22px;text-align:center;background:#edf7ef;border-radius:12px;'><div style='font-size:13px;color:#5a675f;margin-bottom:8px;'>Seu código de confirmação</div><div style='font-size:36px;letter-spacing:8px;font-weight:700;color:#07612b;'>{$codigoSeguro}</div></div><p>Este código é válido por <strong>15 minutos</strong>.</p><p style='color:#777;font-size:13px;'>Se você não iniciou um cadastro no EcoAgenda, ignore este e-mail.</p></div></body></html>";
$erroEnvio = null;
$enviado = enviarEmailEcoAgenda(
    $email,
    "Código de confirmação de cadastro - EcoAgenda",
    $htmlEmail,
    "Seu código de confirmação do EcoAgenda é: {$codigo}. Ele é válido por 15 minutos.",
    $erroEnvio
);

if (!$enviado) {
    error_log("EcoAgenda SMTP cadastro: " . ($erroEnvio ?? "falha desconhecida"));
    responderCadastroEmail(502, [
        "sucesso" => false,
        "mensagem" => "Não foi possível enviar o e-mail agora. Verifique a configuração do Gmail SMTP."
    ]);
}

$_SESSION["cadastro_email_pendente"] = $email;
$_SESSION["cadastro_codigo_hash"] = hash("sha256", $codigo);
$_SESSION["cadastro_codigo_expira"] = time() + 900;
responderCadastroEmail(200, ["sucesso" => true, "mensagem" => "Código enviado para seu e-mail. Verifique também a caixa de spam; ele é válido por 15 minutos."]);
