-- EcoAgenda / MariaDB (XAMPP). Exporte o banco antes e não use o site durante a execução.
-- Remove SOMENTE o pedido 18 e seus vínculos. Preserva TODOS os usuários e endereços.
-- Se houver outro pedido, a operação é cancelada.
DELIMITER $$
BEGIN NOT ATOMIC
    DECLARE EXIT HANDLER FOR SQLEXCEPTION
    BEGIN
        ROLLBACK;
        RESIGNAL;
    END;
    IF DATABASE() IS NULL OR @@foreign_key_checks <> 1 THEN
        SIGNAL SQLSTATE '45000' SET MESSAGE_TEXT = 'Selecione o banco EcoAgenda e mantenha as chaves estrangeiras ativas.';
    END IF;
    IF (SELECT COUNT(*) FROM information_schema.TABLES WHERE TABLE_SCHEMA=DATABASE() AND ENGINE='InnoDB' AND TABLE_NAME IN ('agendamento','agendamento_historico','coleta','secretaria_agendamento','agendamento_morador_endereco')) <> 5 THEN
        SIGNAL SQLSTATE '45000' SET MESSAGE_TEXT = 'Estrutura diferente da verificada. Operacao cancelada.';
    END IF;
    IF EXISTS(SELECT 1 FROM information_schema.TRIGGERS WHERE TRIGGER_SCHEMA=DATABASE() AND EVENT_MANIPULATION='DELETE') THEN
        SIGNAL SQLSTATE '45000' SET MESSAGE_TEXT = 'Existe um trigger de exclusao nao previsto. Operacao cancelada.';
    END IF;
    START TRANSACTION;
    IF (SELECT COUNT(*) FROM agendamento) <> 1 OR NOT EXISTS(SELECT 1 FROM agendamento WHERE id=18) THEN
        SIGNAL SQLSTATE '45000' SET MESSAGE_TEXT = 'Operacao cancelada: era esperado somente o pedido 18. Nenhum pedido foi apagado.';
    END IF;
    DELETE FROM agendamento_historico WHERE agendamento_id=18;
    DELETE FROM secretaria_agendamento WHERE agendamento_id=18;
    DELETE FROM coleta WHERE agendamento_id=18;
    DELETE FROM agendamento_morador_endereco WHERE agendamento_id=18;
    DELETE FROM agendamento WHERE id=18;
    COMMIT;
    -- ALTER faz commit implicito: por isso vem somente depois da exclusao confirmada.
    -- Apenas reinicia o contador; nao altera colunas, relacionamentos ou triggers.
    ALTER TABLE agendamento AUTO_INCREMENT=1;
END$$
DELIMITER ;
