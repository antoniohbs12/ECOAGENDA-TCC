(() => {
 const dialog=document.createElement('dialog');dialog.className='ea-address-dialog';
 const close=document.createElement('button');close.type='button';close.className='ea-address-close';close.textContent='Fechar ×';
 const frame=document.createElement('iframe');frame.title='Corrigir endereço da coleta';dialog.setAttribute('aria-label',frame.title);dialog.append(close,frame);document.body.append(dialog);
 let trigger=null;
 const finish=()=>{dialog.close();frame.src='about:blank';trigger?.focus();};
 close.addEventListener('click',finish);dialog.addEventListener('cancel',e=>{e.preventDefault();finish();});
 document.addEventListener('click',e=>{const b=e.target.closest('[data-edit-address]');if(!b)return;e.preventDefault();trigger=b;frame.src=b.href;dialog.showModal();close.focus();if(!matchMedia('(prefers-reduced-motion: reduce)').matches)dialog.animate([{opacity:0,transform:'translateY(16px)'},{opacity:1,transform:'translateY(0)'}],{duration:240,easing:'ease-out'});});
 window.addEventListener('message',e=>{if(e.origin!==location.origin||e.source!==frame.contentWindow||e.data?.type!=='ea-address-saved')return;location.reload();});
})();
