/* Confirmação explícita; o servidor valida e registra o motivo no histórico. */
(() => {
    const dialog = document.createElement('dialog');
    dialog.setAttribute('aria-labelledby', 'suspensao-titulo');
    dialog.style.cssText = 'width:min(560px,calc(100% - 32px));max-height:90vh;overflow:auto;border:1px solid #d5e6dc;border-radius:24px;padding:28px;color:#174b32;background:white;box-sizing:border-box;font:inherit;box-shadow:0 24px 80px #123b3240';
    dialog.innerHTML = `<form method="dialog"><h2 id="suspensao-titulo">Suspender pedido</h2><p>Confirme a suspensão somente após conferir o pedido. Comunique ao morador o motivo da suspensão.</p><label for="suspensao-motivo">Motivo da suspensão</label><textarea id="suspensao-motivo" required maxlength="225" rows="4" style="display:block;width:100%;box-sizing:border-box;margin:12px 0 20px;padding:12px;border:1px solid #abcdb9;border-radius:12px;font:inherit"></textarea><div style="display:flex;gap:12px;justify-content:flex-end;flex-wrap:wrap"><button type="button" class="btn-small" data-voltar>Voltar</button><button type="submit" class="btn-small">Confirmar suspensão</button></div></form>`;
    document.body.append(dialog);
    let original;
    const motivo = dialog.querySelector('textarea');
    dialog.querySelector('[data-voltar]').onclick = () => dialog.close();
    document.addEventListener('submit', event => {
        if (!event.target.matches('form[data-confirmar-suspensao]')) return;
        if (event.target.dataset.confirmado === '1') return;
        event.preventDefault();
        original = event.target;
        motivo.value = ''; motivo.setCustomValidity('');
        const id = original.querySelector('[name="agendamento_id"]').value;
        dialog.querySelector('h2').textContent = `Suspender pedido ${id}`;
        dialog.showModal(); motivo.focus();
    }, true);
    motivo.addEventListener('input', () => motivo.setCustomValidity(''));
    dialog.querySelector('form').addEventListener('submit', event => {
        event.preventDefault();
        if (!motivo.value.trim()) { motivo.setCustomValidity('Informe o motivo da suspensão.'); motivo.reportValidity(); return; }
        for (const [name,value] of Object.entries({justificativa_suspensao:motivo.value.trim(),confirmar_suspensao:'1'})) {
            let input=original.querySelector(`[name="${name}"]`);
            if (!input) { input=document.createElement('input'); input.type='hidden';input.name=name;original.append(input); }
            input.value=value;
        }
        original.dataset.confirmado='1';dialog.close();original.requestSubmit();
    });
})();
