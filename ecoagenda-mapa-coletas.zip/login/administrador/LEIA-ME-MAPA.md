# Mapas de coletas e relatório mensal — versão 2

Este pacote atualiza os arquivos da pasta `login/administrador` do RAR atual enviado em 08/10/2026. O restante do site permanece no projeto original. Aplique copiando os arquivos para a pasta existente, sem apagar os outros arquivos.

## O que mudou

- O dashboard tem duas seções independentes: **Locais das coletas realizadas**, com ruas e marcadores, e **Demanda de coletas por bairro**, com apenas as fronteiras e a intensidade dos pedidos.
- Ambos aceitam zoom pelo scroll, botões, busca e retorno à visão geral.
- Os marcadores consideram `coleta.data_finalizacao` no mês selecionado. O mapa colorido considera `agendamento.data_pedido`, ou seja, todos os pedidos criados no mês. A interface identifica essa diferença.
- Coletas no mesmo endereço ou na mesma posição aproximada ficam agrupadas; o número no ícone informa quantas coletas representa. O popup lista os endereços representados. Pontos próximos usam agrupamento visual para evitar sobreposição.
- O PDF passa a mostrar o mapa colorido, uma lista dos 15 bairros e o gráfico de total de pedidos nos últimos seis meses. A mesma consulta, paleta e geometria são usadas no mapa de demanda e no PDF.

## Instalação no XAMPP

1. Faça backup de `administrador.php`, `gerar_relatorio.php` e dos arquivos anteriores do mapa.
2. Extraia o ZIP dentro de `ecoagendafinal`, mesclando `login/administrador` e substituindo os arquivos fornecidos.
3. PHP precisa de `mysqli`, `mbstring`, `iconv` e **curl**, com acesso HTTPS à internet para localizar endereços. Mantenha a conexão MySQLi existente. Não há migração, novas colunas ou alterações no banco.
4. Reinicie Apache se tiver habilitado alguma extensão no `php.ini`, entre como Administrador e faça recarga forçada do navegador.
5. Se os endereços não forem encontrados por indisponibilidade do serviço, a interface informa isso e oferece nova tentativa. Os bairros e os dados continuam disponíveis.

## Localização dos endereços, sem alterar o banco

`mapa_localizar.php` consulta Nominatim/OpenStreetMap no servidor, após validar sessão administrativa e token CSRF. Apenas rua/número/cidade são enviados ao serviço; nomes, telefones e e-mails de moradores não são enviados.

A consulta respeita o limite de uma requisição por segundo, com trava entre processos e cache persistente. Resultados são guardados em `localizacoes.json` numa pasta própria dentro do diretório temporário do PHP, fora da pasta pública do site. As chaves do cache derivam do endereço; mudanças no endereço invalidam naturalmente a posição anterior. Não são feitas gravações no banco.

É possível definir `ECOAGENDA_MAP_DATA_DIR` no ambiente do Apache/PHP para escolher uma pasta persistente **fora de htdocs**, com permissão de escrita para o servidor. `ECOAGENDA_GEOCODER_URL` permite escolher outro endpoint HTTPS compatível com a busca estruturada Nominatim; não é necessário configurá-lo para usar o padrão.

Um resultado com número correspondente é identificado como endereço localizado. Quando só a rua é encontrada, o ponto é **aproximado e explicitamente identificado**. Se nenhum resultado compatível for encontrado, não há marcador fictício. Não são usados centros de bairros nem deslocamentos artificiais para simular casas. No SQL enviado, os três endereços das coletas de outubro foram encontrados apenas no nível da rua: a API não confirmou os números.

Pedidos com endereços conflitantes ou bairro não reconhecido não são somados duas vezes na demanda. Endereços incompatíveis com Pinhais não são posicionados no mapa. Coletas sem endereço válido continuam no total e aparecem no aviso de localização pendente.

## Arquivos necessários

- `administrador.php` e `gerar_relatorio.php`: integração das duas seções e novo PDF.
- `mapa_pinhais.php`, `.css`, `.js`: interface compartilhada dos dois mapas.
- `mapa_dados.php`: consultas e paleta comuns.
- `mapa_localizar.php`, `mapa_geocodificar.php`: serviço de localização com cache externo ao banco.
- `pinhais_bairros_wgs84.geojson`: fronteiras preservadas do arquivo GeoPinhais enviado.
- `pinhais_base.geojson`: ruas, caminhos, áreas verdes, edifícios, rios e lagos locais, sem nomes de ruas. Só é carregado na seção de marcadores; edifícios ficam visíveis com maior zoom.
- `vendor/leaflet` (1.9.4, BSD-2-Clause) e `vendor/markercluster` (1.5.3, MIT): bibliotecas locais e licenças.

Nenhuma chave de API é necessária. O mapa colorido e a base de ruas são locais; a consulta inicial dos endereços requer internet. A base de ruas é um snapshot e não é atualizada automaticamente. Os arquivos originais `BAIRROS.*` e `pinhais_bairros.geojson` não são usados em execução; guarde-os como arquivo de referência.

## Cartografia e atribuição

Os 15 bairros do WGS84 correspondem exatamente aos polígonos de `BAIRROS.shp` do RAR. O CRS original é SIRGAS 2000 / UTM 22S, EPSG:31982; a reprojeção foi conferida. A base informa Prefeitura Municipal de Pinhais / GeoPinhais, **referência 2012**. Preservar essa geometria não certifica alterações municipais posteriores.

A base local de ruas foi obtida em 08/10/2026 a partir dos tiles vetoriais públicos CARTO/OpenStreetMap de nível 14, recortados pelos bairros fornecidos. Foram mantidas as camadas `landcover`, `landuse`, `park`, `water`, `waterway`, `building` e `transportation`, sem rótulos. Fonte: `https://basemaps.cartocdn.com/vectortiles/carto.streets/v1/{z}/{x}/{y}.mvt`. As atribuições permanecem visíveis; mantenha a atribuição CARTO e OpenStreetMap e respeite a licença ODbL na redistribuição dos dados.

## Validação

- PHP e JavaScript: sintaxe verificada; endpoints protegidos por sessão; POST de localização também verifica CSRF.
- API real consultada com TLS verificado: 3 endereços localizados, todos com precisão aproximada na rua. O cache foi reutilizado sem outra consulta.
- SQL enviado: outubro/2026, 3 coletas finalizadas e 6 pedidos (5 Jardim Amélia e 1 Jardim Karla). Nenhuma alteração de esquema ou conteúdo é necessária.
- Chromium: duas seções integradas, zoom por scroll, busca sem acentos, seleção, pins/agrupamento, mapa de ruas sem preenchimentos por demanda, tooltips de bairros, retorno à visão geral, telas de 390 a 1400 px e mês vazio.
- Falha da geocodificação mantém os endereços listados, sem pontos fictícios. Falha da atualização mantém os últimos dados.
- PDF A4 em paisagem: geometria vetorial, 15 bairros, paleta compartilhada e gráfico mensal; estrutura do arquivo e texto extraído conferidos.

Os testes de interface e falhas estão em `tests/mapa` no repositório. A execução local usou MariaDB 11.8 com o SQL enviado, cuja origem também informa MariaDB. O código mantém MySQLi e SQL compatível com MySQL; não foi realizado um teste separado em Oracle MySQL.
