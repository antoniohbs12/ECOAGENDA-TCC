<?php
declare(strict_types=1);
session_start();
header('Content-Type: application/json; charset=UTF-8');
header('Cache-Control: private, no-store');
function respostaLocalizar(int $status, array $data): never { http_response_code($status); echo json_encode($data, JSON_UNESCAPED_UNICODE | JSON_HEX_TAG); exit; }
if (($_SESSION['perfil'] ?? '') !== 'administrador' || empty($_SESSION['email'])) respostaLocalizar(403, ['erro' => 'Acesso negado.']);
if ($_SERVER['REQUEST_METHOD'] !== 'POST') respostaLocalizar(405, ['erro' => 'Use POST.']);
if (!isset($_SESSION['mapa_csrf']) || !hash_equals($_SESSION['mapa_csrf'], (string)($_SERVER['HTTP_X_MAPA_CSRF'] ?? ''))) respostaLocalizar(403, ['erro' => 'Sessão inválida. Atualize a página.']);
session_write_close();
require_once '../../config.php';
require_once __DIR__ . '/mapa_dados.php';
require_once __DIR__ . '/mapa_geocodificar.php';
$payload = json_decode((string)file_get_contents('php://input'), true);
$id = filter_var($payload['enderecoId'] ?? null, FILTER_VALIDATE_INT);
if (!$id || $id < 1) respostaLocalizar(400, ['erro' => 'Endereço inválido.']);
$stmt = $conn->prepare('SELECT id, rua, numero, bairro, cep, cidade, estado FROM endereco WHERE id = ? LIMIT 1');
$stmt->bind_param('i', $id); $stmt->execute(); $e = $stmt->get_result()->fetch_assoc(); $stmt->close();
if (!$e) respostaLocalizar(404, ['erro' => 'Endereço não encontrado.']);
try {
    $result = geocodificarEnderecoMapa($e);
    if (($result['precisao'] ?? '') === 'temporariamente_indisponivel') respostaLocalizar(503, ['erro' => 'Serviço temporariamente indisponível. Tente novamente em alguns minutos.']);
    respostaLocalizar(200, ['chave' => chaveEnderecoMapa($e)] + $result);
} catch (Throwable $error) {
    respostaLocalizar(503, ['erro' => 'Não foi possível consultar a localização. Tente novamente mais tarde.']);
}
