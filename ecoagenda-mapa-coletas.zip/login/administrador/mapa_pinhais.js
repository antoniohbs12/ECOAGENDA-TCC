(() => {
  'use strict';
  const cfg = window.EcoAgendaMapa;
  const $ = id => document.getElementById(id);
  const canvas = $('mapCanvas');
  const state = $('mapState');
  if (!canvas || !cfg) return;
  if (!window.L || !cfg.geojson?.features?.length) {
    state.hidden = false;
    state.textContent = 'Não foi possível carregar o mapa. Recarregue a página ou confira os arquivos do módulo.';
    return;
  }
  const normalize = value => String(value ?? '').normalize('NFD').replace(/[\u0300-\u036f]/g, '').toLowerCase().replace(/\s+/g, ' ').trim();
  const number = value => Number(value || 0).toLocaleString('pt-BR');
  const percent = value => `${Number(value || 0).toLocaleString('pt-BR', {maximumFractionDigits: 1})}%`;
  const thematic = cfg.modo !== 'locais';
  let data = cfg.data;
  let selectedLocal = null;
  let locating = false;
  const attempted = new Set();
  const markers = new Map();
  let selected = null;
  let busy = false;
  let initialized = false;
  let resizeFrame;
  const layers = new Map();
  const palette = cfg.palette;
  const safeValue = name => thematic ? Math.max(0, Number(data.dados?.[name] || 0)) : (data.locais || []).filter(l => normalize(l.bairro) === normalize(name)).reduce((sum, l) => sum + Number(l.total), 0);
  const share = count => Number(data.total) > 0 ? count / Number(data.total) * 100 : 0;
  const color = count => palette[count === 0 ? 0 : Math.min(4, Math.max(1, Math.ceil(count / Math.max(1, Number(data.max)) * 4)))];

  const map = L.map(canvas, {zoomControl: false, scrollWheelZoom: true, zoomAnimation: false, minZoom: 11, maxZoom: 18, zoomSnap: 0.25, attributionControl: true});
  map.attributionControl.setPrefix(false);
  map.createPane('neighborhoods');
  map.getPane('neighborhoods').style.zIndex = 410;
  // Base vetorial local: ruas e hidrografia sem rótulos, sem chave de API
  // e sem depender de um serviço de tiles em cada abertura do dashboard.
  if (!thematic) map.createPane('geography');
  if (!thematic) { map.getPane('geography').style.zIndex = 200; map.getPane('geography').style.pointerEvents = 'none'; }
  const baseRenderer = L.canvas({pane: 'geography', padding: 0.3});
  if (!thematic) map.attributionControl.addAttribution('Base: &copy; <a href="https://www.openstreetmap.org/copyright" target="_blank" rel="noopener">OpenStreetMap</a> / <a href="https://carto.com/attributions" target="_blank" rel="noopener">CARTO</a>');
  let geography;
  function geographyStyle(feature) {
    const {layer, class: category} = feature.properties;
    const scale = Math.min(2.8, Math.pow(2, Math.max(0, map.getZoom() - 13) * 0.4));
    if (layer === 'transportation') {
      const main = ['motorway', 'trunk', 'primary'].includes(category);
      return {color: main ? '#c5c9c4' : '#ffffff', weight: (main ? 2.4 : 1.1) * scale, opacity: 0.92, fill: false};
    }
    if (layer === 'waterway') return {color: '#a9cbd6', weight: 1.1 * scale, opacity: 0.9, fill: false};
    if (layer === 'building') return {color: '#d6dcd6', weight: 0.4, fillColor: '#e0e5de', fillOpacity: map.getZoom() >= 14 ? 0.72 : 0, opacity: map.getZoom() >= 14 ? 0.6 : 0};
    const colors = {landcover: '#e0e9df', landuse: category === 'industrial' ? '#e5e8e5' : '#eef0ec', park: '#d6e3d3', water: '#b9d3dc'};
    return {stroke: false, fillColor: colors[layer] || '#edf1ed', fillOpacity: 1};
  }
  async function loadGeography() {
    try {
      const response = await fetch('pinhais_base.geojson?v=20261008-1');
      if (!response.ok) throw new Error('Base indisponível');
      const base = await response.json();
      if (base.type !== 'FeatureCollection' || !base.features?.length) throw new Error('Base inválida');
      geography = L.geoJSON(base, {pane: 'geography', renderer: baseRenderer, interactive: false, style: geographyStyle}).addTo(map);
      $('tileNotice').hidden = true;
    } catch {
      $('tileNotice').hidden = false;
    }
  }
  map.on('zoomend', () => { if (geography) geography.setStyle(geographyStyle); });

  function layerStyle(name, hover = false) {
    const active = name === selected;
    return {color: active ? '#054e31' : hover ? '#167347' : '#fafdfa', weight: active ? 3 : hover ? 2.5 : 1.4,
      fillColor: thematic ? color(safeValue(name)) : 'transparent', fillOpacity: thematic ? 1 : 0, opacity: thematic ? 1 : 0.4, dashArray: thematic ? null : '4 5'};
  }
  function tooltip(name) {
    const node = document.createElement('div');
    const title = document.createElement('strong'); title.textContent = name;
    const text = document.createElement('span'); text.textContent = `${number(safeValue(name))} pedidos de coleta · ${percent(share(safeValue(name)))} do período`;
    node.append(title, text); return node;
  }
  const districts = L.geoJSON(cfg.geojson, {
    pane: 'neighborhoods', interactive: thematic, style: feature => layerStyle(feature.properties.bairro),
    onEachFeature(feature, layer) {
      const name = feature.properties.bairro;
      layers.set(name, layer);
      if (!thematic) return;
      layer.bindTooltip(tooltip(name), {sticky: true, className: 'district-tooltip', direction: 'top'});
      layer.on({mouseover: () => { layer.setStyle(layerStyle(name, true)); layer.bringToFront(); },
        mouseout: () => { layer.setStyle(layerStyle(name)); if (selected) layers.get(selected)?.bringToFront(); },
        click: () => select(name, true)});
    }
  }).addTo(map);
  const bounds = districts.getBounds();
  map.setMaxBounds(bounds.pad(0.45));
  function zoomReadout() {
    if (!initialized) return;
    const fitZoom = map.getBoundsZoom(bounds, false, L.point(64, 146));
    $('zoomLevel').textContent = `${Math.round(100 * 2 ** (map.getZoom() - fitZoom))}%`;
    $('zoomIn').disabled = map.getZoom() >= map.getMaxZoom();
    $('zoomOut').disabled = map.getZoom() <= map.getMinZoom();
  }
  function home() {
    map.stop();
    map.closePopup();
    selected = null;
    selectedLocal = null;
    updateSelection();
    map.fitBounds(bounds, {paddingTopLeft: [32, 46], paddingBottomRight: [32, 100], animate: false});
    initialized = true;
    zoomReadout();
  }
  function updateSelection() {
    if (!thematic && selectedLocal) {
      const local = (data.locais || []).find(l => l.chave === selectedLocal);
      if (local) {
        $('selectedName').textContent = local.endereco;
        $('selectedHint').hidden = false; $('selectedHint').textContent = local.bairro;
        $('selectedTotal').textContent = number(local.total);
        $('selectedShare').textContent = local.precisao === 'rua_aproximada' ? 'Posição aproximada na rua, sem confirmação do número.' : local.lat !== null ? 'Endereço localizado pela API.' : 'A localização ainda não está disponível.';
        $('clearSelection').hidden = false;
        return;
      }
    }

    $('selectedHint').textContent = thematic ? 'Clique em um bairro ou use a busca.' : 'Clique em um marcador ou busque um endereço.';
    $('selectedName').textContent = selected || 'Explore o mapa';
    $('selectedHint').hidden = Boolean(selected);
    $('selectedTotal').textContent = selected ? number(safeValue(selected)) : '—';
    $('selectedShare').textContent = selected ? `${percent(share(safeValue(selected)))} dos pedidos do período` : (thematic ? 'Selecione um bairro para ver os detalhes' : 'Selecione um local para ver os detalhes');
    $('clearSelection').hidden = !selected;
    for (const [name, layer] of layers) layer.setStyle(layerStyle(name));
    if (selected) layers.get(selected)?.bringToFront();
    document.querySelectorAll('.ranking-item').forEach(button => {
      const active = button.dataset.bairro === selected;
      button.classList.toggle('is-selected', active);
      button.setAttribute('aria-pressed', String(active));
    });
  }
  function select(name, focus) {
    const layer = layers.get(name);
    if (!layer) return;
    selected = name;
    updateSelection();
    if (focus) map.fitBounds(layer.getBounds(), {padding: [52, 70], maxZoom: 15, animate: true});
  }
  function renderRanking() {
    if (!thematic) { renderLocations(); return; }
    const q = normalize($('bairroSearch').value);
    const fragment = document.createDocumentFragment();
    const ranking = [...layers.keys()].map(bairro => ({bairro, total: safeValue(bairro)})).sort((a, b) => b.total - a.total || a.bairro.localeCompare(b.bairro, 'pt-BR'));
    for (const item of ranking.filter(item => normalize(item.bairro).includes(q))) {
      const button = document.createElement('button'); button.type = 'button'; button.className = 'ranking-item'; button.dataset.bairro = item.bairro;
      const main = document.createElement('span'); main.className = 'ranking-main';
      const name = document.createElement('span'); name.className = 'ranking-name'; name.textContent = item.bairro;
      const track = document.createElement('span'); track.className = 'ranking-bar';
      const bar = document.createElement('i'); bar.style.width = `${data.max ? item.total / data.max * 100 : 0}%`; track.append(bar);
      main.append(name, track);
      const values = document.createElement('span'); values.className = 'ranking-values';
      const pct = document.createElement('strong'); pct.textContent = percent(share(item.total));
      const count = document.createElement('small'); count.textContent = `${number(item.total)} ${item.total === 1 ? 'pedido' : 'pedidos'}`;
      values.append(pct, count); button.append(main, values);
      button.addEventListener('click', () => select(item.bairro, true)); fragment.append(button);
    }
    $('searchEmpty').hidden = Boolean(fragment.childElementCount);
    $('rankingList').replaceChildren(fragment);
    updateSelection();
  }
  const clusters = !thematic && L.markerClusterGroup ? L.markerClusterGroup({
    maxClusterRadius: 38, disableClusteringAtZoom: 16, showCoverageOnHover: false,
    iconCreateFunction(cluster) {
      const count = cluster.getAllChildMarkers().reduce((sum, marker) => sum + marker.options.coletas, 0);
      return L.divIcon({className: 'coleta-cluster', html: `<span>${number(count)}</span>`, iconSize: [40, 40]});
    }
  }).addTo(map) : !thematic ? L.layerGroup().addTo(map) : null;
  function pinIcon(count) {
    return L.divIcon({className: 'coleta-pin', iconSize: [32, 42], iconAnchor: [16, 42], popupAnchor: [0, -40],
      html: `<svg width="32" height="42" viewBox="0 0 32 42" aria-hidden="true"><path d="M16 41C12 34 1 25 1 16a15 15 0 1 1 30 0c0 9-11 18-15 25Z" fill="#15784b" stroke="white" stroke-width="2"/><circle cx="16" cy="16" r="9" fill="white"/><text x="16" y="20" text-anchor="middle" fill="#15784b" font-size="12" font-family="Arial" font-weight="bold">${number(count)}</text></svg>`});
  }
  function locationPopup(local) {
    const node = document.createElement('div'); node.className = 'coleta-popup';
    const name = document.createElement('strong'); name.textContent = local.endereco;
    const area = document.createElement('span'); area.textContent = local.bairro;
    const count = document.createElement('p'); count.textContent = `${number(local.total)} ${local.total === 1 ? 'coleta concluída' : 'coletas concluídas'} neste endereço`;
    const accuracy = document.createElement('small'); accuracy.textContent = local.precisao === 'rua_aproximada' ? 'Posição aproximada na rua. O número não foi confirmado pela API.' : 'Endereço localizado por Nominatim / OpenStreetMap.';
    node.append(name, area, count, accuracy); return node;
  }
  function drawMarkers() {
    clusters.clearLayers(); markers.clear();
    // A API pode retornar o mesmo ponto aproximado para vários números da rua.
    // Agrupamos sem deslocar artificialmente as casas para posições inventadas.
    const positions = new Map();
    for (const local of data.locais || []) {
      if (!Number.isFinite(local.lat) || !Number.isFinite(local.lng)) continue;
      const key = `${local.lat.toFixed(7)}|${local.lng.toFixed(7)}`;
      if (!positions.has(key)) positions.set(key, []);
      positions.get(key).push(local);
    }
    for (const group of positions.values()) {
      const first = group[0];
      const count = group.reduce((sum, local) => sum + local.total, 0);
      const marker = L.marker([first.lat, first.lng], {icon: pinIcon(count), title: `${number(count)} coletas neste ponto`, coletas: count});
      const popup = document.createElement('div');
      for (const local of group) popup.append(locationPopup(local));
      marker.bindPopup(popup, {maxHeight: 220, maxWidth: 280, autoPanPadding: [20, 30], keepInView: true});
      marker.on('click', () => { selectedLocal = first.chave; updateSelection(); });
      clusters.addLayer(marker);
      for (const local of group) markers.set(local.chave, marker);
    }
  }
  function focusLocation(local) {
    selectedLocal = local.chave; updateSelection();
    const marker = markers.get(local.chave);
    if (!marker) return;
    if (clusters.zoomToShowLayer) clusters.zoomToShowLayer(marker, () => { map.setView(marker.getLatLng(), 16, {animate: false}); marker.openPopup(); });
    else { map.setView(marker.getLatLng(), 16); marker.openPopup(); }
  }
  function renderLocations() {
    const q = normalize($('bairroSearch').value);
    const fragment = document.createDocumentFragment();
    for (const local of data.locais || []) {
      if (!normalize(`${local.endereco} ${local.bairro}`).includes(q)) continue;
      const button = document.createElement('button'); button.type = 'button'; button.className = 'ranking-item location-item';
      const main = document.createElement('span'); main.className = 'ranking-main';
      const name = document.createElement('span'); name.className = 'ranking-name'; name.textContent = local.endereco;
      const area = document.createElement('small'); area.textContent = local.bairro;
      const status = document.createElement('small'); status.className = 'location-status'; status.textContent = local.lat !== null ? (local.precisao === 'rua_aproximada' ? 'Localização aproximada' : 'Endereço localizado') : attempted.has(local.chave) ? 'Localização indisponível' : 'Aguardando localização';
      main.append(name, area, status);
      const count = document.createElement('strong'); count.className = 'location-count'; count.textContent = number(local.total);
      button.append(main, count); button.addEventListener('click', () => focusLocation(local)); fragment.append(button);
    }
    $('searchEmpty').hidden = Boolean(fragment.childElementCount);
    $('rankingList').replaceChildren(fragment);
    updateSelection();
  }
  async function locatePending(force = false) {
    if (locating || document.hidden) return;
    const pending = (data.locais || []).filter(l => l.lat === null && (force || !attempted.has(l.chave)));
    if (!pending.length) return;
    locating = true;
    $('retryLocations').disabled = true;
    for (const [index, local] of pending.entries()) {
      attempted.add(local.chave);
      $('mapUpdated').textContent = `Localizando endereços · ${index + 1}/${pending.length}`;
      const controller = new AbortController(); const timeout = setTimeout(() => controller.abort(), 45000);
      try {
        const response = await fetch('mapa_localizar.php', {method: 'POST', headers: {'Content-Type': 'application/json', 'X-Mapa-CSRF': cfg.csrf}, body: JSON.stringify({enderecoId: local.enderecoId}), signal: controller.signal});
        if (!response.ok) throw new Error('Consulta indisponível');
        const result = await response.json();
        if (result.chave === local.chave && Number.isFinite(result.lat) && Number.isFinite(result.lng)) Object.assign(local, result);
      } catch { /* O endereço segue listado, sem marcador fictício. */ }
      finally { clearTimeout(timeout); }
    }
    applyData(data);
    const unresolved = (data.locais || []).some(l => l.lat === null);
    if (unresolved) $('mapUpdated').textContent = 'Alguns endereços ainda não foram localizados';
    locating = false;
    $('retryLocations').disabled = false;
    $('retryLocations').hidden = !unresolved;
  }
  if (!thematic) $('retryLocations').addEventListener('click', () => locatePending(true));
  function applyData(next) {
    data = next;
    $('mapTotal').querySelector('strong').textContent = number(data.total);
    $('mapUpdated').textContent = data.total === 0 ? (thematic ? 'Nenhum pedido neste período' : 'Nenhuma coleta concluída neste período') : `Atualizado às ${data.atualizadoEm || '—'}`;
    $('legendMax').textContent = percent(share(data.max));
    $('legendMid').textContent = percent(share(data.max) / 2);
    $('unmappedNotice').hidden = !data.semBairro;
    $('unmappedNotice').textContent = `${number(data.semBairro)} ${data.semBairro === 1 ? 'pedido sem bairro identificável' : 'pedidos sem bairro identificável'} — incluídos no total, fora do mapa.`;
    if (thematic) for (const [name, layer] of layers) layer.setTooltipContent(tooltip(name));
    if (!thematic) {
      drawMarkers();
      const missing = (data.locais || []).filter(l => l.lat === null).reduce((sum, l) => sum + l.total, 0);
      $('unmappedNotice').hidden = !missing && !data.semEndereco;
      $('unmappedNotice').textContent = `${number(missing)} coletas aguardam localização do endereço${data.semEndereco ? `; ${number(data.semEndereco)} sem endereço válido` : ''}. Nenhum ponto foi inventado.`;
    }
    renderRanking();
    window.parent.postMessage({type: 'ecoagenda:map-update', modo: cfg.modo, total: Number(data.total)}, window.location.origin);
  }
  async function refresh() {
    if (busy || document.hidden) return;
    busy = true;
    const controller = new AbortController();
    const timeout = setTimeout(() => controller.abort(), 10000);
    try {
      const params = new URLSearchParams({dados: '1', modo: cfg.modo, mes: cfg.mes, ano: cfg.ano, _: Date.now()});
      const response = await fetch(`mapa_pinhais.php?${params}`, {cache: 'no-store', headers: {Accept: 'application/json'}, signal: controller.signal});
      if (!response.ok) throw new Error('Resposta indisponível');
      const next = await response.json();
      if (!next || !Number.isFinite(next.total) || (thematic ? typeof next.dados !== 'object' || next.dados === null || !Number.isFinite(next.max) : !Array.isArray(next.locais))) throw new Error('Dados inválidos');
      applyData(next);
      if (!thematic) locatePending();
    } catch {
      $('mapUpdated').textContent = 'Atualização indisponível · últimos dados mantidos';
    } finally { clearTimeout(timeout); busy = false; }
  }
  $('bairroSearch').addEventListener('input', renderRanking);
  $('bairroSearch').addEventListener('keydown', event => {
    if (event.key === 'Enter') { event.preventDefault(); const first = $('rankingList').querySelector('button'); if (first) first.click(); }
    if (event.key === 'Escape') { $('bairroSearch').value = ''; renderRanking(); home(); }
  });
  $('zoomIn').addEventListener('click', () => map.zoomIn(0.5));
  $('zoomOut').addEventListener('click', () => map.zoomOut(0.5));
  $('zoomHome').addEventListener('click', home);
  $('clearSelection').addEventListener('click', home);
  map.on('zoomend resize', zoomReadout);
  // Um único observer e um único conjunto de listeners, mesmo após redimensionar
  // o iframe ou abrir a seção inicialmente escondida do dashboard.
  const observer = new ResizeObserver(() => {
    cancelAnimationFrame(resizeFrame);
    resizeFrame = requestAnimationFrame(() => {
      if (!canvas.clientWidth || !canvas.clientHeight) return;
      map.invalidateSize({pan: false});
      if (!initialized) home();
      else zoomReadout();
    });
  });
  observer.observe(canvas);
  if (canvas.clientWidth && canvas.clientHeight) home();
  applyData(data);
  if (!thematic) { loadGeography(); locatePending(); }
  const interval = setInterval(refresh, 60000);
  document.addEventListener('visibilitychange', () => { if (!document.hidden) refresh(); });
  window.addEventListener('pagehide', () => { clearInterval(interval); observer.disconnect(); }, {once: true});
})();
