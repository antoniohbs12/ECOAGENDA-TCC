<?php
session_start();
require_once "../../config.php";

if (
    !isset($_SESSION["email"]) ||
    !isset($_SESSION["perfil"]) ||
    $_SESSION["perfil"] !== "administrador"
) {
    http_response_code(403);
    exit("Acesso negado.");
}

session_write_close();
require_once __DIR__ . "/mapa_dados.php";

function pdfTextEncode(string $text): string
{
    $converted = @iconv("UTF-8", "Windows-1252//TRANSLIT", $text);
    if ($converted === false) {
        $converted = $text;
    }
    return str_replace(
        ["\\", "(", ")", "\r", "\n"],
        ["\\\\", "\\(", "\\)", " ", " "],
        $converted
    );
}

function pdfNum(float $number): string
{
    $value = round($number, 2);
    return rtrim(rtrim(sprintf("%.2f", $value), "0"), ".");
}

function pdfRgb(float $r, float $g, float $b): string
{
    return pdfNum($r) . " " . pdfNum($g) . " " . pdfNum($b);
}

function pdfBuild(array $pages): string
{
    $objects = [];
    $addObject = static function (string $body) use (&$objects): int {
        $objects[] = $body;
        return count($objects);
    };

    $fontRegular = $addObject("<< /Type /Font /Subtype /Type1 /BaseFont /Helvetica /Encoding /WinAnsiEncoding >>");
    $fontBold = $addObject("<< /Type /Font /Subtype /Type1 /BaseFont /Helvetica-Bold /Encoding /WinAnsiEncoding >>");

    $pageRefs = [];
    foreach ($pages as $page) {
        $content = $page["content"];
        $contentId = $addObject(
            "<< /Length " . strlen($content) . " >>\nstream\n" . $content . "\nendstream"
        );
        $pageId = $addObject("PAGE_PLACEHOLDER");
        $pageRefs[] = [$pageId, $contentId];
    }

    $pagesId = $addObject("PAGES_PLACEHOLDER");
    $catalogId = $addObject("<< /Type /Catalog /Pages " . $pagesId . " 0 R >>");

    foreach ($pageRefs as [$pageId, $contentId]) {
        $objects[$pageId - 1] =
            "<< /Type /Page /Parent " . $pagesId . " 0 R " .
            "/MediaBox [0 0 841.89 595.28] " .
            "/Resources << /Font << /F1 " . $fontRegular . " 0 R /F2 " . $fontBold . " 0 R >> >> " .
            "/Contents " . $contentId . " 0 R >>";
    }

    $kids = implode(" ", array_map(static fn($pair) => $pair[0] . " 0 R", $pageRefs));
    $objects[$pagesId - 1] =
        "<< /Type /Pages /Count " . count($pageRefs) . " /Kids [" . $kids . "] >>";

    $pdf = "%PDF-1.4\n%\xE2\xE3\xCF\xD3\n";
    $offsets = [0];
    foreach ($objects as $index => $body) {
        $offsets[$index + 1] = strlen($pdf);
        $pdf .= ($index + 1) . " 0 obj\n" . $body . "\nendobj\n";
    }

    $xrefOffset = strlen($pdf);
    $pdf .= "xref\n0 " . (count($objects) + 1) . "\n";
    $pdf .= "0000000000 65535 f \n";
    for ($i = 1; $i <= count($objects); $i++) {
        $pdf .= sprintf("%010d 00000 n \n", $offsets[$i]);
    }
    $pdf .= "trailer\n<< /Size " . (count($objects) + 1) . " /Root " . $catalogId . " 0 R >>\n";
    $pdf .= "startxref\n" . $xrefOffset . "\n%%EOF";

    return $pdf;
}

function pdfTextCmd(float $x, float $y, string $text, float $size = 10, bool $bold = false, string $color = "0.18 0.24 0.20"): string
{
    $font = $bold ? "/F2" : "/F1";
    return "BT {$color} rg {$font} " . pdfNum($size) . " Tf 1 0 0 1 " . pdfNum($x) . " " . pdfNum($y) . " Tm (" . pdfTextEncode($text) . ") Tj ET\n";
}

function pdfRect(float $x, float $y, float $w, float $h, string $fill, ?string $stroke = null, float $lineWidth = 1): string
{
    $cmd = "q " . $fill . " rg " . pdfNum($x) . " " . pdfNum($y) . " " . pdfNum($w) . " " . pdfNum($h) . " re f ";
    if ($stroke !== null) {
        $cmd .= $stroke . " RG " . pdfNum($lineWidth) . " w " . pdfNum($x) . " " . pdfNum($y) . " " . pdfNum($w) . " " . pdfNum($h) . " re S ";
    }
    return $cmd . "Q\n";
}

function pdfLine(float $x1, float $y1, float $x2, float $y2, string $color, float $width = 1): string
{
    return "q {$color} RG " . pdfNum($width) . " w " . pdfNum($x1) . " " . pdfNum($y1) . " m " . pdfNum($x2) . " " . pdfNum($y2) . " l S Q\n";
}

function pdfCircle(float $cx, float $cy, float $r, string $fill): string
{
    // Circle using four cubic Bézier segments.
    $k = 0.5522847498;
    $c = $r * $k;
    $cmd = "q {$fill} rg ";
    $cmd .= pdfNum($cx + $r) . " " . pdfNum($cy) . " m ";
    $cmd .= pdfNum($cx + $r) . " " . pdfNum($cy + $c) . " " . pdfNum($cx + $c) . " " . pdfNum($cy + $r) . " " . pdfNum($cx) . " " . pdfNum($cy + $r) . " c ";
    $cmd .= pdfNum($cx - $c) . " " . pdfNum($cy + $r) . " " . pdfNum($cx - $r) . " " . pdfNum($cy + $c) . " " . pdfNum($cx - $r) . " " . pdfNum($cy) . " c ";
    $cmd .= pdfNum($cx - $r) . " " . pdfNum($cy - $c) . " " . pdfNum($cx - $c) . " " . pdfNum($cy - $r) . " " . pdfNum($cx) . " " . pdfNum($cy - $r) . " c ";
    $cmd .= pdfNum($cx + $c) . " " . pdfNum($cy - $r) . " " . pdfNum($cx + $r) . " " . pdfNum($cy - $c) . " " . pdfNum($cx + $r) . " " . pdfNum($cy) . " c f Q\n";
    return $cmd;
}

function pdfPolyline(array $points, string $color, float $width = 2): string
{
    if (count($points) < 2) return "";
    $cmd = "q {$color} RG " . pdfNum($width) . " w " . pdfNum($points[0][0]) . " " . pdfNum($points[0][1]) . " m ";
    for ($i = 1, $n = count($points); $i < $n; $i++) {
        $cmd .= pdfNum($points[$i][0]) . " " . pdfNum($points[$i][1]) . " l ";
    }
    return $cmd . "S Q\n";
}

function pdfCorMapa(string $hex): string
{
    return pdfRgb(hexdec(substr($hex, 1, 2)) / 255, hexdec(substr($hex, 3, 2)) / 255, hexdec(substr($hex, 5, 2)) / 255);
}
function pdfMapaDemanda(array $geo, array $dados, float $x, float $y, float $width, float $height): string
{
    $project = static function (array $point): array {
        return [deg2rad((float)$point[0]), log(tan(M_PI / 4 + deg2rad((float)$point[1]) / 2))];
    };
    $features = []; $xs = []; $ys = [];
    foreach ($geo['features'] as $feature) {
        $geometry = $feature['geometry'];
        $polygons = $geometry['type'] === 'Polygon' ? [$geometry['coordinates']] : $geometry['coordinates'];
        $projected = [];
        foreach ($polygons as $rings) {
            $pRings = [];
            foreach ($rings as $ring) {
                $pRing = [];
                foreach ($ring as $point) { $p = $project($point); $pRing[] = $p; $xs[] = $p[0]; $ys[] = $p[1]; }
                $pRings[] = $pRing;
            }
            $projected[] = $pRings;
        }
        $features[] = ['bairro' => $feature['properties']['bairro'], 'polygons' => $projected];
    }
    if (!$xs || !$ys) throw new RuntimeException('Mapa sem geometria.');
    $minX = min($xs); $maxX = max($xs); $minY = min($ys); $maxY = max($ys);
    $scale = min($width / ($maxX - $minX), $height / ($maxY - $minY));
    $offsetX = $x + ($width - ($maxX - $minX) * $scale) / 2;
    $offsetY = $y + ($height - ($maxY - $minY) * $scale) / 2;
    $content = '';
    foreach ($features as $feature) {
        $value = (int)($dados['dados'][$feature['bairro']] ?? 0);
        $content .= 'q ' . pdfCorMapa(corDemandaMapa($value, (int)$dados['max'])) . " rg 1 1 1 RG 0.65 w ";
        foreach ($feature['polygons'] as $rings) {
            foreach ($rings as $ring) {
                foreach ($ring as $index => [$px, $py]) {
                    $content .= pdfNum($offsetX + ($px - $minX) * $scale) . ' ' . pdfNum($offsetY + ($py - $minY) * $scale) . ($index === 0 ? ' m ' : ' l ');
                }
                $content .= 'h ';
            }
        }
        $content .= "B* Q\n"; // Preenchimento par/ímpar mantém eventuais buracos dos polígonos.
    }
    return $content;
}

function evolucaoRelatorioMapa(mysqli $conn, int $mes, int $ano): array
{
    $evolucao = [];
    $periodo = new DateTime(sprintf("%04d-%02d-01", $ano, $mes));
    $periodo->modify("-5 months");
    $nomes = [1=>'Jan',2=>'Fev',3=>'Mar',4=>'Abr',5=>'Mai',6=>'Jun',7=>'Jul',8=>'Ago',9=>'Set',10=>'Out',11=>'Nov',12=>'Dez'];
    for ($i = 0; $i < 6; $i++) {
        $ini = $periodo->format("Y-m-01 00:00:00");
        $fimObj = clone $periodo;
        $fimObj->modify("+1 month");
        $fimMes = $fimObj->format("Y-m-01 00:00:00");
        $total = 0;
        $stmt = $conn->prepare("SELECT COUNT(*) AS total FROM agendamento WHERE data_pedido >= ? AND data_pedido < ?");
        if ($stmt) {
            $stmt->bind_param("ss", $ini, $fimMes);
            $stmt->execute();
            $row = $stmt->get_result()->fetch_assoc();
            $total = (int)($row["total"] ?? 0);
            $stmt->close();
        }
        $evolucao[] = ["label" => $nomes[(int)$periodo->format("n")] . "/" . $periodo->format("Y"), "valor" => $total];
        $periodo->modify("+1 month");
    }

    return $evolucao;
}

$mes = isset($_GET["mes"]) ? (int)$_GET["mes"] : (int)date("n");
$ano = isset($_GET["ano"]) ? (int)$_GET["ano"] : (int)date("Y");
if ($mes < 1 || $mes > 12) $mes = (int)date("n");
if ($ano < 2020 || $ano > 2100) $ano = (int)date("Y");

$demanda = buscarDadosMapa($conn, $mes, $ano, BAIRROS_MAPA);
$evolucao = evolucaoRelatorioMapa($conn, $mes, $ano);
$geo = carregarGeoMapa();
$meses = [1=>'Janeiro',2=>'Fevereiro',3=>'Março',4=>'Abril',5=>'Maio',6=>'Junho',7=>'Julho',8=>'Agosto',9=>'Setembro',10=>'Outubro',11=>'Novembro',12=>'Dezembro'];
$nomeMes = $meses[$mes];

$w = 841.89;
$h = 595.28;
$content = "1 1 1 rg 0 0 {$w} {$h} re f\n";

// Header
$content .= pdfRect(0, 515, $w, 80, "0.07 0.38 0.18");
$content .= pdfTextCmd(38, 554, "EcoAgenda", 24, true, "1 1 1");
$content .= pdfTextCmd(38, 534, "Relatório mensal de coleta", 12, true, "0.86 0.95 0.88");
$content .= pdfTextCmd(650, 548, $nomeMes . "/" . $ano, 12, true, "1 1 1");

// Mapa vetorial, com as mesmas geometrias e classes de cor do dashboard.
$content .= pdfRect(38, 244, 765, 253, "0.995 0.998 0.996", "0.89 0.92 0.90", 0.8);
$content .= pdfTextCmd(52, 477, "Demanda de coletas por bairro", 14, true);
$content .= pdfTextCmd(52, 462, $demanda['total'] . " pedidos criados no período · limites GeoPinhais (base 2012)", 8.5, false, "0.43 0.49 0.45");
$content .= pdfMapaDemanda($geo, $demanda, 52, 267, 422, 185);
$content .= pdfTextCmd(490, 443, "Bairro", 9, true);
$content .= pdfTextCmd(755, 443, "Pedidos", 9, true);
$y = 426;
foreach ($demanda['ranking'] as $row) {
    $hex = corDemandaMapa((int)$row['total'], (int)$demanda['max']);
    $content .= pdfRect(490, $y - 1, 7, 7, pdfCorMapa($hex));
    $content .= pdfTextCmd(505, $y, $row['bairro'], 8.5);
    $content .= pdfTextCmd(764, $y, (string)$row['total'], 8.5, true);
    $y -= 11;
}
$content .= pdfTextCmd(52, 252, $demanda['semBairro'] ? $demanda['semBairro'] . " pedidos sem bairro identificável: incluídos no total, fora do mapa." : "Intensidade relativa à quantidade de pedidos por bairro.", 7.3, false, "0.55 0.60 0.57");
// Legenda de intensidade, idêntica à paleta usada no mapa interativo.
foreach (CORES_MAPA as $index => $hex) $content .= pdfRect(60 + 24 * $index, 264, 24, 5, pdfCorMapa($hex));
$content .= pdfTextCmd(60, 274, "Menor", 6.5, false, "0.43 0.49 0.45");
$content .= pdfTextCmd(162, 274, "Maior", 6.5, false, "0.43 0.49 0.45");

// Evolution chart
$content .= pdfRect(38, 42, 765, 188, "1 1 1", "0.89 0.92 0.90", 0.8);
$content .= pdfTextCmd(52, 206, "Total de pedidos no mês", 14, true);
$content .= pdfTextCmd(52, 190, "Evolução dos últimos seis meses.", 8.5, false, "0.43 0.49 0.45");

$chartX = 75;
$chartY = 78;
$chartW = 680;
$chartH = 86;
$maxVal = 1;
foreach ($evolucao as $p) $maxVal = max($maxVal, $p["valor"]);
for ($i = 0; $i < 5; $i++) {
    $gy = $chartY + ($chartH * $i / 4);
    $content .= pdfLine($chartX, $gy, $chartX + $chartW, $gy, "0.92 0.94 0.93", 0.6);
}
$points = [];
foreach ($evolucao as $idx => $p) {
    $px = $chartX + ($chartW * ($idx / max(1, count($evolucao) - 1)));
    $py = $chartY + ($p["valor"] / $maxVal) * $chartH;
    $points[] = [$px, $py];
}
$content .= pdfPolyline($points, "0.14 0.50 0.29", 2.6);
foreach ($evolucao as $idx => $p) {
    [$px, $py] = $points[$idx];
    $content .= pdfCircle($px, $py, 3.5, "0.14 0.50 0.29");
    $content .= pdfTextCmd($px - 7, $py + 8, (string)$p["valor"], 8.5, true, "0.20 0.25 0.22");
    $content .= pdfTextCmd($px - 20, 62, $p["label"], 7.5, false, "0.42 0.47 0.44");
}
$content .= pdfTextCmd(52, 52, "Dados gerados pelo EcoAgenda para o período selecionado.", 7.3, false, "0.55 0.60 0.57");

$pages = [["content" => $content]];
$pdf = pdfBuild($pages);

$filename = "EcoAgenda_Relatorio_" . $nomeMes . "_" . $ano . ".pdf";
header("Content-Type: application/pdf");
header("Content-Disposition: attachment; filename=\"" . preg_replace('/[^A-Za-z0-9_\-\.]/', '_', $filename) . "\"");
header("Content-Length: " . strlen($pdf));
header("Cache-Control: private, max-age=0, must-revalidate");
header("Pragma: public");
echo $pdf;
exit;
