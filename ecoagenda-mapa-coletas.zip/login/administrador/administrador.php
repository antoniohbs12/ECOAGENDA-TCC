<?php

session_start();
require_once "../../config.php";

/* =========================================================
   PROTEÇÃO
========================================================= */
if (
    !isset($_SESSION["email"]) ||
    !isset($_SESSION["perfil"]) ||
    $_SESSION["perfil"] !== "administrador"
) {
    header("Location: ../login.html");
    exit();
}

$adminEmail = $_SESSION["email"];
$adminNome = $_SESSION["nome"] ?? "Administrador";
$mensagem = "";
$tipoMensagem = "success";


/* =========================================================
   MAPA DE PINHAIS — PROXY SVG
   Mantém o SVG do mapa na mesma origem do EcoAgenda.
========================================================= */
if (isset($_GET["mapa_svg"]) && $_GET["mapa_svg"] === "1") {
    $urlMapa = "https://upload.wikimedia.org/wikipedia/commons/4/42/Mapa_dos_bairros_de_Pinhais_%28SVG%29.svg";
    $svgMapa = false;

    if (function_exists("curl_init")) {
        $chMapa = curl_init($urlMapa);
        curl_setopt_array($chMapa, [
            CURLOPT_RETURNTRANSFER => true,
            CURLOPT_FOLLOWLOCATION => true,
            CURLOPT_CONNECTTIMEOUT => 8,
            CURLOPT_TIMEOUT => 18,
            CURLOPT_USERAGENT => "EcoAgenda/1.0 Dashboard",
            CURLOPT_HTTPHEADER => ["Accept: image/svg+xml,text/xml;q=0.9,*/*;q=0.8"],
        ]);
        $svgMapa = curl_exec($chMapa);
        $httpMapa = (int)curl_getinfo($chMapa, CURLINFO_HTTP_CODE);
        curl_close($chMapa);
        if ($httpMapa !== 200 || !is_string($svgMapa) || stripos($svgMapa, "<svg") === false) {
            $svgMapa = false;
        }
    }

    if ($svgMapa === false) {
        $svgMapa = @file_get_contents($urlMapa);
    }

    if (!is_string($svgMapa) || stripos($svgMapa, "<svg") === false) {
        http_response_code(503);
        header("Content-Type: text/plain; charset=UTF-8");
        exit("Mapa indisponível no momento.");
    }

    header("Content-Type: image/svg+xml; charset=UTF-8");
    header("Cache-Control: public, max-age=86400");
    echo $svgMapa;
    exit();
}

/* =========================================================
   FUNÇÕES
========================================================= */
function e($valor): string
{
    return htmlspecialchars((string)$valor, ENT_QUOTES, "UTF-8");
}

function dataBR(?string $data): string
{
    if (empty($data)) return "—";
    $timestamp = strtotime($data);
    return $timestamp ? date("d/m/Y", $timestamp) : "—";
}

function normalizarStatusAdmin(string $status): string
{
    $status = mb_strtolower(trim($status), "UTF-8");
    return strtr($status, ["á" => "a", "ã" => "a", "â" => "a", "é" => "e", "ê" => "e", "í" => "i", "ó" => "o", "ô" => "o", "õ" => "o", "ú" => "u", "ç" => "c"]);
}

function classeStatus(string $status): string
{
    $status = normalizarStatusAdmin($status);

    switch ($status) {
        case "pendente":
        case "em analise":
            return "pendente";
        case "confirmado":
        case "encaminhado":
        case "agendado":
            return "confirmado";
        case "a caminho":
        case "em andamento":
            return "andamento";
        case "concluido":
            return "concluido";
        case "cancelado":
        case "suspenso":
            return "cancelado";
        default:
            return "outro";
    }
}

function statusExibicaoAdmin(string $status): string
{
    $normalizado = normalizarStatusAdmin($status);
    if (in_array($normalizado, ["encaminhado", "agendado", "confirmado"], true)) {
        return "Agendado";
    }
    if ($normalizado === "em analise") {
        return "Em análise";
    }
    if ($normalizado === "suspenso") {
        return "Suspenso";
    }
    return $status;
}

function dataComCincoDiasUteisAdmin(string $dataBase): string
{
    $data = new DateTime($dataBase);
    $dias = 0;
    while ($dias < 5) {
        $data->modify("+1 day");
        if ((int)$data->format("N") <= 5) {
            $dias++;
        }
    }
    return $data->format("Y-m-d");
}

function diasUteisRestantesAdmin(string $dataLimite, ?string $dataReferencia = null): int
{
    $inicio = new DateTime(($dataReferencia ?: date("Y-m-d")) . " 00:00:00");
    $fim = new DateTime($dataLimite . " 00:00:00");
    if ($inicio >= $fim) return 0;

    $dias = 0;
    $cursor = clone $inicio;
    while ($cursor < $fim) {
        $cursor->modify("+1 day");
        if ((int)$cursor->format("N") <= 5 && $cursor <= $fim) {
            $dias++;
        }
    }
    return $dias;
}

function statusAtivoDashboardAdmin(string $status): bool
{
    return !in_array(normalizarStatusAdmin($status), [
        "concluido", "cancelado", "suspenso"
    ], true);
}

function prazoDashboardAdmin(array $pedido): array
{
    $status = normalizarStatusAdmin((string)($pedido["status"] ?? ""));

    if ($status === "concluido") {
        return ["data" => !empty($pedido["data_finalizacao"]) ? dataBR($pedido["data_finalizacao"]) : "Concluída", "classe" => "concluido", "texto" => "Concluída"];
    }
    if (in_array($status, ["cancelado", "suspenso"], true)) {
        return ["data" => "—", "classe" => "cancelado", "texto" => "Suspenso"];
    }

    $base = substr((string)($pedido["data_pedido"] ?? ""), 0, 10);
    if ($base === "") {
        return ["data" => "—", "classe" => "outro", "texto" => "Sem prazo"];
    }

    $limite = dataComCincoDiasUteisAdmin($base);
    $restantes = diasUteisRestantesAdmin($limite);
    $hoje = date("Y-m-d");

    if ($limite < $hoje) {
        return ["data" => dataBR($limite), "classe" => "cancelado", "texto" => "Prazo vencido"];
    }
    if ($limite === $hoje) {
        return ["data" => dataBR($limite), "classe" => "proximo", "texto" => "Prazo hoje"];
    }
    if ($restantes <= 2) {
        return ["data" => dataBR($limite), "classe" => "proximo", "texto" => $restantes . ($restantes === 1 ? " dia útil" : " dias úteis")];
    }
    return ["data" => dataBR($limite), "classe" => "normal", "texto" => "Dentro do prazo"];
}

function definirUsuarioLogado(mysqli $conn, string $email): void
{
    $emailSeguro = $conn->real_escape_string($email);
    if (!$conn->query("SET @usuario_logado = '" . $emailSeguro . "'")) {
        throw new Exception("Erro ao definir usuário da operação: " . $conn->error);
    }
}

function buscarStatus(mysqli $conn, string $status): bool
{
    $stmt = $conn->prepare("SELECT status FROM status_agendamento WHERE status = ? LIMIT 1");
    if (!$stmt) {
        throw new Exception("Erro ao validar status: " . $conn->error);
    }
    $stmt->bind_param("s", $status);
    $stmt->execute();
    $ok = (bool)$stmt->get_result()->fetch_assoc();
    $stmt->close();
    return $ok;
}

/* =========================================================
   AÇÕES DO ADMINISTRADOR
========================================================= */
if ($_SERVER["REQUEST_METHOD"] === "POST") {
    $acao = $_POST["acao"] ?? "";

    /* CADASTRAR MOTORISTA */
    if ($acao === "cadastrar_motorista") {
        $nome = trim($_POST["nome"] ?? "");
        $email = trim($_POST["email"] ?? "");
        $senha = $_POST["senha"] ?? "";
        $cnh = preg_replace('/\D+/', '', trim($_POST["cnh"] ?? ""));
        $cpf = preg_replace('/\D+/', '', trim($_POST["cpf"] ?? ""));
        $telefone = trim($_POST["telefone"] ?? "");

        if ($nome === "" || $email === "" || $senha === "" || $cnh === "" || $cpf === "") {
            $mensagem = "Nome, e-mail, senha, CNH e CPF são obrigatórios.";
            $tipoMensagem = "error";
        } elseif (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
            $mensagem = "Informe um e-mail válido.";
            $tipoMensagem = "error";
        } elseif (strlen($senha) < 6) {
            $mensagem = "A senha do motorista deve ter pelo menos 6 caracteres.";
            $tipoMensagem = "error";
        } elseif (strlen($cnh) !== 11) {
            $mensagem = "A CNH deve conter 11 dígitos.";
            $tipoMensagem = "error";
        } elseif (strlen($cpf) !== 11) {
            $mensagem = "O CPF deve conter 11 dígitos.";
            $tipoMensagem = "error";
        } else {
            $conn->begin_transaction();
            try {
                $stmt = $conn->prepare("SELECT email FROM usuario WHERE email = ? LIMIT 1");
                if (!$stmt) throw new Exception("Erro ao verificar e-mail: " . $conn->error);
                $stmt->bind_param("s", $email);
                $stmt->execute();
                $existeUsuario = (bool)$stmt->get_result()->fetch_assoc();
                $stmt->close();
                if ($existeUsuario) throw new Exception("Este e-mail já está cadastrado no sistema.");

                $stmt = $conn->prepare("SELECT email FROM motorista WHERE cnh = ? OR cpf = ? LIMIT 1");
                if (!$stmt) throw new Exception("Erro ao verificar CNH/CPF: " . $conn->error);
                $stmt->bind_param("ss", $cnh, $cpf);
                $stmt->execute();
                $duplicado = $stmt->get_result()->fetch_assoc();
                $stmt->close();
                if ($duplicado) throw new Exception("A CNH ou o CPF informado já pertence a um motorista.");

                $senhaHash = password_hash($senha, PASSWORD_DEFAULT);
                $stmt = $conn->prepare("INSERT INTO usuario (email, senha, nome) VALUES (?, ?, ?)");
                if (!$stmt) throw new Exception("Erro ao preparar usuário do motorista: " . $conn->error);
                $stmt->bind_param("sss", $email, $senhaHash, $nome);
                if (!$stmt->execute()) throw new Exception("Erro ao cadastrar usuário do motorista: " . $stmt->error);
                $stmt->close();

                $stmt = $conn->prepare("INSERT INTO motorista (email, cnh, cpf, telefone, ativo) VALUES (?, ?, ?, ?, 1)");
                if (!$stmt) throw new Exception("Erro ao preparar motorista: " . $conn->error);
                $stmt->bind_param("ssss", $email, $cnh, $cpf, $telefone);
                if (!$stmt->execute()) throw new Exception("Erro ao cadastrar motorista: " . $stmt->error);
                $stmt->close();

                $conn->commit();
                $mensagem = "Motorista cadastrado com sucesso.";
            } catch (Throwable $e) {
                $conn->rollback();
                $mensagem = $e->getMessage();
                $tipoMensagem = "error";
            }
        }
    }

    /* EDITAR MOTORISTA */
    if ($acao === "editar_motorista") {
        $emailAtual = trim($_POST["id"] ?? "");
        $emailInformado = trim($_POST["email"] ?? "");
        $nome = trim($_POST["nome"] ?? "");
        $cnh = preg_replace('/\D+/', '', trim($_POST["cnh"] ?? ""));
        $cpf = preg_replace('/\D+/', '', trim($_POST["cpf"] ?? ""));
        $telefone = trim($_POST["telefone"] ?? "");
        $novaSenha = $_POST["senha"] ?? "";
        $ativo = isset($_POST["ativo"]) ? 1 : 0;

        if ($emailAtual === "" || $emailInformado === "" || $nome === "" || $cnh === "" || $cpf === "") {
            $mensagem = "Nome, e-mail, CNH e CPF do motorista são obrigatórios.";
            $tipoMensagem = "error";
        } elseif ($emailInformado !== $emailAtual) {
            $mensagem = "O e-mail do motorista é a chave de acesso e não pode ser alterado por esta tela.";
            $tipoMensagem = "error";
        } elseif (strlen($cnh) !== 11 || strlen($cpf) !== 11) {
            $mensagem = "CNH e CPF devem conter 11 dígitos.";
            $tipoMensagem = "error";
        } elseif ($novaSenha !== "" && strlen($novaSenha) < 6) {
            $mensagem = "A nova senha deve ter pelo menos 6 caracteres.";
            $tipoMensagem = "error";
        } else {
            $conn->begin_transaction();
            try {
                $stmt = $conn->prepare("SELECT email FROM motorista WHERE (cnh = ? OR cpf = ?) AND email <> ? LIMIT 1");
                if (!$stmt) throw new Exception("Erro ao verificar CNH/CPF: " . $conn->error);
                $stmt->bind_param("sss", $cnh, $cpf, $emailAtual);
                $stmt->execute();
                $duplicado = $stmt->get_result()->fetch_assoc();
                $stmt->close();
                if ($duplicado) throw new Exception("A CNH ou o CPF informado já pertence a outro motorista.");

                $stmt = $conn->prepare("UPDATE usuario SET nome = ? WHERE email = ? LIMIT 1");
                if (!$stmt) throw new Exception("Erro ao preparar nome do motorista: " . $conn->error);
                $stmt->bind_param("ss", $nome, $emailAtual);
                if (!$stmt->execute()) throw new Exception("Erro ao atualizar nome do motorista: " . $stmt->error);
                $stmt->close();

                if ($novaSenha !== "") {
                    $senhaHash = password_hash($novaSenha, PASSWORD_DEFAULT);
                    $stmt = $conn->prepare("UPDATE usuario SET senha = ? WHERE email = ? LIMIT 1");
                    if (!$stmt) throw new Exception("Erro ao preparar senha do motorista: " . $conn->error);
                    $stmt->bind_param("ss", $senhaHash, $emailAtual);
                    if (!$stmt->execute()) throw new Exception("Erro ao atualizar senha do motorista: " . $stmt->error);
                    $stmt->close();
                }

                $stmt = $conn->prepare("UPDATE motorista SET cnh = ?, cpf = ?, telefone = ?, ativo = ? WHERE email = ? LIMIT 1");
                if (!$stmt) throw new Exception("Erro ao preparar motorista: " . $conn->error);
                $stmt->bind_param("sssis", $cnh, $cpf, $telefone, $ativo, $emailAtual);
                if (!$stmt->execute()) throw new Exception("Erro ao atualizar motorista: " . $stmt->error);
                $stmt->close();

                $conn->commit();
                $mensagem = "Motorista atualizado com sucesso.";
            } catch (Throwable $e) {
                $conn->rollback();
                $mensagem = $e->getMessage();
                $tipoMensagem = "error";
            }
        }
    }

    /* ATIVAR / DESATIVAR MOTORISTA */
    if ($acao === "toggle_motorista") {
        $emailMotorista = trim($_POST["id"] ?? "");

        if ($emailMotorista === "") {
            $mensagem = "Motorista inválido.";
            $tipoMensagem = "error";
        } else {
            $stmt = $conn->prepare("UPDATE motorista SET ativo = IF(ativo = 1, 0, 1) WHERE email = ? LIMIT 1");
            if (!$stmt) {
                $mensagem = "Erro: " . $conn->error;
                $tipoMensagem = "error";
            } else {
                $stmt->bind_param("s", $emailMotorista);
                if ($stmt->execute()) {
                    $mensagem = "Situação do motorista atualizada.";
                } else {
                    $mensagem = "Erro ao atualizar motorista: " . $stmt->error;
                    $tipoMensagem = "error";
                }
                $stmt->close();
            }
        }
    }

    /* CADASTRAR SECRETARIA */
    if ($acao === "cadastrar_secretaria") {
        $nome = trim($_POST["nome"] ?? "");
        $email = trim($_POST["email"] ?? "");
        $senha = $_POST["senha"] ?? "";

        if ($nome === "" || $email === "" || $senha === "") {
            $mensagem = "Nome, e-mail e senha são obrigatórios.";
            $tipoMensagem = "error";
        } elseif (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
            $mensagem = "Informe um e-mail válido.";
            $tipoMensagem = "error";
        } elseif (strlen($senha) < 6) {
            $mensagem = "A senha da Secretaria deve ter pelo menos 6 caracteres.";
            $tipoMensagem = "error";
        } else {
            $conn->begin_transaction();
            try {
                $stmt = $conn->prepare("SELECT email FROM usuario WHERE email = ? LIMIT 1");
                if (!$stmt) {
                    throw new Exception("Erro ao verificar e-mail: " . $conn->error);
                }
                $stmt->bind_param("s", $email);
                $stmt->execute();
                $existeUsuario = (bool)$stmt->get_result()->fetch_assoc();
                $stmt->close();

                if ($existeUsuario) {
                    throw new Exception("Este e-mail já está cadastrado no sistema.");
                }

                $senhaHash = password_hash($senha, PASSWORD_DEFAULT);

                $stmt = $conn->prepare("INSERT INTO usuario (email, senha, nome) VALUES (?, ?, ?)");
                if (!$stmt) {
                    throw new Exception("Erro ao preparar usuário da Secretaria: " . $conn->error);
                }
                $stmt->bind_param("sss", $email, $senhaHash, $nome);
                if (!$stmt->execute()) {
                    throw new Exception("Erro ao cadastrar usuário da Secretaria: " . $stmt->error);
                }
                $stmt->close();

                $stmt = $conn->prepare("INSERT INTO secretaria (email, ativo) VALUES (?, 1)");
                if (!$stmt) {
                    throw new Exception("Erro ao preparar Secretaria: " . $conn->error);
                }
                $stmt->bind_param("s", $email);
                if (!$stmt->execute()) {
                    throw new Exception("Erro ao cadastrar Secretaria: " . $stmt->error);
                }
                $stmt->close();

                $conn->commit();
                $mensagem = "Secretaria cadastrada com sucesso.";
            } catch (Throwable $e) {
                $conn->rollback();
                $mensagem = $e->getMessage();
                $tipoMensagem = "error";
            }
        }
    }

    /* EDITAR SECRETARIA */
    if ($acao === "editar_secretaria") {
        $emailAtual = trim($_POST["email_atual"] ?? "");
        $emailNovo = trim($_POST["email"] ?? "");
        $nome = trim($_POST["nome"] ?? "");
        $novaSenha = $_POST["senha"] ?? "";
        $ativo = isset($_POST["ativo"]) ? 1 : 0;

        if ($emailAtual === "" || $emailNovo === "" || $nome === "") {
            $mensagem = "Nome e e-mail são obrigatórios.";
            $tipoMensagem = "error";
        } elseif ($emailNovo !== $emailAtual) {
            $mensagem = "O e-mail da Secretaria não pode ser alterado por esta tela.";
            $tipoMensagem = "error";
        } else {
            try {
                if ($novaSenha !== "") {
                    $senhaHash = password_hash($novaSenha, PASSWORD_DEFAULT);
                    $stmt = $conn->prepare("UPDATE usuario SET nome = ?, senha = ? WHERE email = ? LIMIT 1");
                    if (!$stmt) throw new Exception("Erro ao preparar Secretaria: " . $conn->error);
                    $stmt->bind_param("sss", $nome, $senhaHash, $emailAtual);
                } else {
                    $stmt = $conn->prepare("UPDATE usuario SET nome = ? WHERE email = ? LIMIT 1");
                    if (!$stmt) throw new Exception("Erro ao preparar Secretaria: " . $conn->error);
                    $stmt->bind_param("ss", $nome, $emailAtual);
                }

                if (!$stmt->execute()) throw new Exception("Erro ao atualizar Secretaria: " . $stmt->error);
                $stmt->close();

                $stmt = $conn->prepare("UPDATE secretaria SET ativo = ? WHERE email = ? LIMIT 1");
                if (!$stmt) throw new Exception("Erro ao preparar situação da Secretaria: " . $conn->error);
                $stmt->bind_param("is", $ativo, $emailAtual);
                if (!$stmt->execute()) throw new Exception("Erro ao atualizar situação da Secretaria: " . $stmt->error);
                $stmt->close();

                $mensagem = "Secretaria atualizada com sucesso.";
            } catch (Throwable $e) {
                $mensagem = $e->getMessage();
                $tipoMensagem = "error";
            }
        }
    }

    /* ATIVAR / DESATIVAR SECRETARIA */
    if ($acao === "toggle_secretaria") {
        $emailSecretaria = trim($_POST["id"] ?? "");

        if ($emailSecretaria === "") {
            $mensagem = "Secretaria inválida.";
            $tipoMensagem = "error";
        } else {
            $stmt = $conn->prepare("UPDATE secretaria SET ativo = IF(ativo = 1, 0, 1) WHERE email = ? LIMIT 1");
            if (!$stmt) {
                $mensagem = "Erro: " . $conn->error;
                $tipoMensagem = "error";
            } else {
                $stmt->bind_param("s", $emailSecretaria);
                if ($stmt->execute()) {
                    $mensagem = "Situação da Secretaria atualizada.";
                } else {
                    $mensagem = "Erro ao atualizar Secretaria: " . $stmt->error;
                    $tipoMensagem = "error";
                }
                $stmt->close();
            }
        }
    }

    /* ALTERAR STATUS */
    if ($acao === "alterar_status") {
        $agendamentoId = (int)($_POST["agendamento_id"] ?? 0);
        $novoStatus = trim($_POST["status"] ?? "");

        if ($agendamentoId <= 0 || $novoStatus === "") {
            $mensagem = "Pedido ou status inválido.";
            $tipoMensagem = "error";
        } else {
            try {
                if (!buscarStatus($conn, $novoStatus)) {
                    throw new Exception("O status informado não existe no banco.");
                }

                definirUsuarioLogado($conn, $adminEmail);

                $stmt = $conn->prepare("UPDATE agendamento SET status = ? WHERE id = ? LIMIT 1");
                if (!$stmt) throw new Exception("Erro ao preparar status: " . $conn->error);
                $stmt->bind_param("si", $novoStatus, $agendamentoId);
                if (!$stmt->execute()) throw new Exception("Erro ao atualizar status: " . $stmt->error);
                $stmt->close();

                $mensagem = "Status do pedido atualizado.";
            } catch (Throwable $e) {
                $mensagem = $e->getMessage();
                $tipoMensagem = "error";
            }
        }
    }
}

/* =========================================================
   ESTATÍSTICAS
========================================================= */
$stats = [
    "total" => 0,
    "pendente" => 0,
    "confirmado" => 0,
    "a_caminho" => 0,
    "andamento" => 0,
    "concluido" => 0,
    "cancelado" => 0
];

$sqlStats = "
    SELECT
        COUNT(*) AS total,
        SUM(status IN ('Pendente', 'Em análise')) AS pendente,
        SUM(status IN ('Confirmado', 'Encaminhado', 'Agendado')) AS confirmado,
        SUM(status = 'A caminho') AS a_caminho,
        SUM(status = 'Em andamento') AS andamento,
        SUM(status IN ('Concluído', 'Concluido')) AS concluido,
        SUM(status IN ('Cancelado', 'Suspenso')) AS cancelado
    FROM agendamento
";

$resultStats = $conn->query($sqlStats);
if ($resultStats) {
    $row = $resultStats->fetch_assoc();
    foreach ($stats as $chave => $valor) {
        $stats[$chave] = (int)($row[$chave] ?? 0);
    }
}

/* =========================================================
   PEDIDOS
========================================================= */
$pedidos = [];
$sqlPedidos = "
    SELECT
        a.id,
        a.descricao,
        a.data_pedido,
        DATE(c.data_inicio) AS data_realizacao,
        TIME(c.data_inicio) AS horario_realizacao,
        a.foto,
        c.foto AS foto_motorista,
        a.morador_email,
        m.cpf AS morador_cpf,
        m.telefone AS morador_telefone,
        u.nome AS morador_nome,
        c.motorista_email,
        c.data_inicio,
        c.data_chegada,
        c.data_finalizacao,
        a.criado_por,
        a.status,
        CONCAT_WS(', ',
            e.rua,
            CASE WHEN e.numero IS NOT NULL AND e.numero <> '' THEN CONCAT('nº ', e.numero) END,
            e.complemento,
            e.bairro,
            e.cidade,
            e.estado,
            CASE WHEN e.cep IS NOT NULL AND e.cep <> '' THEN CONCAT('CEP: ', e.cep) END
        ) AS endereco
    FROM agendamento a
    LEFT JOIN morador m ON m.email = a.morador_email
    LEFT JOIN usuario u ON u.email = m.email
    LEFT JOIN agendamento_morador_endereco ame
        ON ame.agendamento_id = a.id
       AND ame.morador_email = a.morador_email
    LEFT JOIN morador_endereco me
        ON me.endereco_id = ame.endereco_id
       AND me.morador_email = ame.morador_email
    LEFT JOIN endereco e
        ON e.id = me.endereco_id
       AND e.email = me.morador_email
    LEFT JOIN coleta c
        ON c.agendamento_id = a.id
       AND c.data_inicio = (
            SELECT MAX(c2.data_inicio)
            FROM coleta c2
            WHERE c2.agendamento_id = a.id
       )
    ORDER BY a.id DESC
    LIMIT 250
";

$resultPedidos = $conn->query($sqlPedidos);
if ($resultPedidos) {
    while ($pedido = $resultPedidos->fetch_assoc()) {
        $pedidos[] = $pedido;
    }
}

/* =========================================================
   MOTORISTAS
========================================================= */
$motoristas = [];
$sqlMotoristas = "
    SELECT m.email, m.cnh, m.cpf, m.telefone, m.ativo, u.nome
    FROM motorista m
    INNER JOIN usuario u ON u.email = m.email
    ORDER BY u.nome, m.email
";
$resultMotoristas = $conn->query($sqlMotoristas);
if ($resultMotoristas) {
    while ($motorista = $resultMotoristas->fetch_assoc()) {
        $motoristas[] = $motorista;
    }
}

/* =========================================================
   MORADORES
========================================================= */
$moradores = [];
$sqlMoradores = "
    SELECT m.cpf, m.email, m.telefone, m.nascimento, u.nome
    FROM morador m
    LEFT JOIN usuario u ON u.email = m.email
    ORDER BY u.nome, m.cpf
    LIMIT 250
";
$resultMoradores = $conn->query($sqlMoradores);
if ($resultMoradores) {
    while ($morador = $resultMoradores->fetch_assoc()) {
        $moradores[] = $morador;
    }
}

/* =========================================================
   SECRETARIAS
========================================================= */
$secretarias = [];
$sqlSecretarias = "
    SELECT s.email, s.ativo, u.nome
    FROM secretaria s
    LEFT JOIN usuario u ON u.email = s.email
    ORDER BY u.nome, s.email
";
$resultSecretarias = $conn->query($sqlSecretarias);
if ($resultSecretarias) {
    while ($secretaria = $resultSecretarias->fetch_assoc()) {
        $secretarias[] = $secretaria;
    }
}

/* =========================================================
   HISTÓRICO COMPLETO DOS PEDIDOS
   O histórico continua sendo lido diretamente da tabela
   agendamento_historico. A interface mostrará somente o
   histórico do pedido que foi pesquisado.
========================================================= */
$historico = [];
$sqlHistorico = "
    SELECT
        h.id,
        h.agendamento_id,
        h.criado_por,
        h.descricao,
        h.data_pedido,
        h.foto,
        h.morador_email,
        h.status,
        h.comando,
        h.data_comando,
        h.usuario_logado,
        u.nome AS usuario_nome,
        CASE
            WHEN ad.email IS NOT NULL THEN 'Administrador'
            WHEN se.email IS NOT NULL THEN 'Secretaria'
            WHEN mo.email IS NOT NULL THEN 'Motorista'
            WHEN mr.email IS NOT NULL THEN 'Morador'
            WHEN UPPER(COALESCE(h.usuario_logado, '')) LIKE 'MIGRACAO%' THEN 'Administrador'
            WHEN UPPER(COALESCE(h.usuario_logado, '')) LIKE 'SISTEMA%' THEN 'Administrador'
            ELSE 'Administrador'
        END AS perfil_usuario
    FROM agendamento_historico h
    LEFT JOIN usuario u ON u.email = h.usuario_logado
    LEFT JOIN administrador ad ON ad.email = h.usuario_logado
    LEFT JOIN secretaria se ON se.email = h.usuario_logado
    LEFT JOIN motorista mo ON mo.email = h.usuario_logado
    LEFT JOIN morador mr ON mr.email = h.usuario_logado
    ORDER BY h.agendamento_id ASC, h.data_comando ASC, h.id ASC
    LIMIT 1000
";
$resultHistorico = $conn->query($sqlHistorico);
if ($resultHistorico) {
    while ($registro = $resultHistorico->fetch_assoc()) {
        $historico[] = $registro;
    }
}

/* =========================================================
   INDICADORES DE FOTOS
========================================================= */
$fotosMorador = 0;
$fotosMotorista = 0;
foreach ($pedidos as $pedido) {
    if (!empty($pedido["foto"])) $fotosMorador++;
    if (!empty($pedido["foto_motorista"])) $fotosMotorista++;
}


/* =========================================================
   RELATÓRIO MENSAL — DADOS
   Tela visual e operacional inicial. A geração do PDF ficará
   para uma etapa posterior, sem alterar o banco.
========================================================= */
$relatorioMes = isset($_GET['relatorio_mes']) ? (int)$_GET['relatorio_mes'] : (int)date('n');
$relatorioAno = isset($_GET['relatorio_ano']) ? (int)$_GET['relatorio_ano'] : (int)date('Y');
if ($relatorioMes < 1 || $relatorioMes > 12) $relatorioMes = (int)date('n');
if ($relatorioAno < 2020 || $relatorioAno > 2100) $relatorioAno = (int)date('Y');

$relatorioInicio = sprintf('%04d-%02d-01 00:00:00', $relatorioAno, $relatorioMes);
$relatorioFim = date('Y-m-d H:i:s', strtotime($relatorioInicio . ' +1 month'));
$mesesRelatorio = [1=>'Janeiro',2=>'Fevereiro',3=>'Março',4=>'Abril',5=>'Maio',6=>'Junho',7=>'Julho',8=>'Agosto',9=>'Setembro',10=>'Outubro',11=>'Novembro',12=>'Dezembro'];

$relatorio = [
    'coletas' => 0,
    'concluidos' => 0,
    'suspensos' => 0,
    'fotos' => 0,
    'recebidos' => 0,
    'analise' => 0,
    'andamento' => 0,
    'cancelados' => 0,
];
$locaisColeta = [];

$stmtRel = $conn->prepare("SELECT COUNT(*) AS total FROM agendamento WHERE data_pedido >= ? AND data_pedido < ?");
if ($stmtRel) {
    $stmtRel->bind_param('ss', $relatorioInicio, $relatorioFim);
    $stmtRel->execute();
    $rowRel = $stmtRel->get_result()->fetch_assoc();
    $relatorio['recebidos'] = (int)($rowRel['total'] ?? 0);
    $stmtRel->close();
}

$stmtRel = $conn->prepare("SELECT COUNT(*) AS total FROM coleta WHERE data_finalizacao >= ? AND data_finalizacao < ?");
if ($stmtRel) {
    $stmtRel->bind_param('ss', $relatorioInicio, $relatorioFim);
    $stmtRel->execute();
    $rowRel = $stmtRel->get_result()->fetch_assoc();
    $relatorio['coletas'] = (int)($rowRel['total'] ?? 0);
    $relatorio['concluidos'] = $relatorio['coletas'];
    $stmtRel->close();
}

$stmtRel = $conn->prepare("SELECT COUNT(*) AS total FROM coleta WHERE data_finalizacao >= ? AND data_finalizacao < ? AND foto IS NOT NULL AND foto <> ''");
if ($stmtRel) {
    $stmtRel->bind_param('ss', $relatorioInicio, $relatorioFim);
    $stmtRel->execute();
    $rowRel = $stmtRel->get_result()->fetch_assoc();
    $relatorio['fotos'] = (int)($rowRel['total'] ?? 0);
    $stmtRel->close();
}

$stmtRel = $conn->prepare("SELECT COUNT(DISTINCT h.agendamento_id) AS total FROM agendamento_historico h WHERE (h.status = 'Cancelado' OR h.comando = 'COLETA_SUSPENSA') AND h.data_comando >= ? AND h.data_comando < ?");
if ($stmtRel) {
    $stmtRel->bind_param('ss', $relatorioInicio, $relatorioFim);
    $stmtRel->execute();
    $rowRel = $stmtRel->get_result()->fetch_assoc();
    $relatorio['suspensos'] = (int)($rowRel['total'] ?? 0);
    $relatorio['cancelados'] = $relatorio['suspensos'];
    $stmtRel->close();
}

$stmtRel = $conn->prepare("SELECT COUNT(*) AS total FROM agendamento WHERE status = 'Em análise' AND data_pedido >= ? AND data_pedido < ?");
if ($stmtRel) {
    $stmtRel->bind_param('ss', $relatorioInicio, $relatorioFim);
    $stmtRel->execute();
    $rowRel = $stmtRel->get_result()->fetch_assoc();
    $relatorio['analise'] = (int)($rowRel['total'] ?? 0);
    $stmtRel->close();
}

$stmtRel = $conn->prepare("SELECT COUNT(*) AS total FROM agendamento WHERE status = 'Em andamento' AND data_pedido >= ? AND data_pedido < ?");
if ($stmtRel) {
    $stmtRel->bind_param('ss', $relatorioInicio, $relatorioFim);
    $stmtRel->execute();
    $rowRel = $stmtRel->get_result()->fetch_assoc();
    $relatorio['andamento'] = (int)($rowRel['total'] ?? 0);
    $stmtRel->close();
}

$sqlLocais = "
    SELECT
        COALESCE(NULLIF(TRIM(e.bairro), ''), 'Sem bairro informado') AS bairro,
        COUNT(*) AS total
    FROM coleta c
    INNER JOIN agendamento a ON a.id = c.agendamento_id
    LEFT JOIN agendamento_morador_endereco ame ON ame.agendamento_id = a.id AND ame.morador_email = a.morador_email
    LEFT JOIN morador_endereco me ON me.endereco_id = ame.endereco_id AND me.morador_email = ame.morador_email
    LEFT JOIN endereco e ON e.id = me.endereco_id AND e.email = me.morador_email
    WHERE c.data_finalizacao >= ? AND c.data_finalizacao < ?
    GROUP BY bairro
    ORDER BY total DESC, bairro ASC
    LIMIT 5
";
$stmtRel = $conn->prepare($sqlLocais);
if ($stmtRel) {
    $stmtRel->bind_param('ss', $relatorioInicio, $relatorioFim);
    $stmtRel->execute();
    $resultLocais = $stmtRel->get_result();
    while ($local = $resultLocais->fetch_assoc()) {
        $locaisColeta[] = [
            'bairro' => $local['bairro'],
            'total' => (int)$local['total']
        ];
    }
    $stmtRel->close();
}

$maiorLocal = 1;
foreach ($locaisColeta as $local) {
    $maiorLocal = max($maiorLocal, (int)$local['total']);
}


/* =========================================================
   MAPA TEMÁTICO DE PINHAIS
========================================================= */
$bairrosPinhais = [
    "Alphaville Graciosa", "Alto Tarumã", "Atuba", "Centro",
    "Emiliano Perneta", "Estância Pinhais", "Jardim Amélia",
    "Jardim Cláudia", "Jardim Karla", "Jardim das Nascentes",
    "Maria Antonieta", "Parque das Águas", "Pineville",
    "Vargem Grande", "Weissópolis"
];

$normalizarBairroMapa = static function (string $valor): string {
    $valor = trim(mb_strtolower($valor, "UTF-8"));
    $transliterado = @iconv("UTF-8", "ASCII//TRANSLIT//IGNORE", $valor);
    if ($transliterado !== false) $valor = strtolower($transliterado);
    $valor = preg_replace('/[^a-z0-9]+/', ' ', $valor);
    return trim(preg_replace('/\s+/', ' ', $valor));
};

$mapaColetasPinhais = array_fill_keys($bairrosPinhais, 0);

$sqlMapaPinhais = "
    SELECT COALESCE(NULLIF(TRIM(e.bairro), ''), 'Sem bairro informado') AS bairro, COUNT(DISTINCT a.id) AS total
    FROM agendamento a
    LEFT JOIN agendamento_morador_endereco ame
        ON ame.agendamento_id = a.id AND ame.morador_email = a.morador_email
    LEFT JOIN morador_endereco me
        ON me.endereco_id = ame.endereco_id AND me.morador_email = ame.morador_email
    LEFT JOIN endereco e
        ON e.id = me.endereco_id AND e.email = me.morador_email
    WHERE a.data_pedido >= ? AND a.data_pedido < ?
    GROUP BY bairro
    ORDER BY total DESC, bairro ASC
";

$stmtMapaPinhais = $conn->prepare($sqlMapaPinhais);
if ($stmtMapaPinhais) {
    $stmtMapaPinhais->bind_param('ss', $relatorioInicio, $relatorioFim);
    $stmtMapaPinhais->execute();
    $resultMapaPinhais = $stmtMapaPinhais->get_result();
    while ($linhaMapa = $resultMapaPinhais->fetch_assoc()) {
        $chaveLinha = $normalizarBairroMapa((string)$linhaMapa['bairro']);
        foreach ($bairrosPinhais as $bairroPinhais) {
            if ($normalizarBairroMapa($bairroPinhais) === $chaveLinha) {
                $mapaColetasPinhais[$bairroPinhais] += (int)$linhaMapa['total'];
                break;
            }
        }
    }
    $stmtMapaPinhais->close();
}

$mapaRankingPinhais = [];
foreach ($mapaColetasPinhais as $bairro => $total) {
    $mapaRankingPinhais[] = ["bairro" => $bairro, "total" => (int)$total];
}
usort($mapaRankingPinhais, static function ($a, $b) {
    if ($a['total'] === $b['total']) return strcasecmp($a['bairro'], $b['bairro']);
    return $b['total'] <=> $a['total'];
});

$maiorMapaPinhais = 0;
foreach ($mapaRankingPinhais as $itemMapa) $maiorMapaPinhais = max($maiorMapaPinhais, (int)$itemMapa['total']);
$totalColetasMapaPinhais = array_sum($mapaColetasPinhais);


/* =========================================================
   EVOLUÇÃO DOS PEDIDOS — ÚLTIMOS 6 MESES
   Mesmo conceito do gráfico exibido no Dashboard ADM,
   reaproveitado dentro do relatório mensal.
========================================================= */
$evolucaoPedidos = [];
$periodoGrafico = new DateTime(sprintf('%04d-%02d-01', $relatorioAno, $relatorioMes));
$periodoGrafico->modify('-5 months');

for ($i = 0; $i < 6; $i++) {
    $inicioMesGrafico = $periodoGrafico->format('Y-m-01 00:00:00');
    $fimMesObj = clone $periodoGrafico;
    $fimMesObj->modify('+1 month');
    $fimMesGrafico = $fimMesObj->format('Y-m-01 00:00:00');

    $totalMesGrafico = 0;
    $stmtGrafico = $conn->prepare("SELECT COUNT(*) AS total FROM agendamento WHERE data_pedido >= ? AND data_pedido < ?");
    if ($stmtGrafico) {
        $stmtGrafico->bind_param('ss', $inicioMesGrafico, $fimMesGrafico);
        $stmtGrafico->execute();
        $rowGrafico = $stmtGrafico->get_result()->fetch_assoc();
        $totalMesGrafico = (int)($rowGrafico['total'] ?? 0);
        $stmtGrafico->close();
    }

    $nomeMesCurto = [
        1 => 'Jan', 2 => 'Fev', 3 => 'Mar', 4 => 'Abr',
        5 => 'Mai', 6 => 'Jun', 7 => 'Jul', 8 => 'Ago',
        9 => 'Set', 10 => 'Out', 11 => 'Nov', 12 => 'Dez'
    ];

    $evolucaoPedidos[] = [
        'label' => $nomeMesCurto[(int)$periodoGrafico->format('n')] . '/' . $periodoGrafico->format('Y'),
        'valor' => $totalMesGrafico
    ];

    $periodoGrafico->modify('+1 month');
}

$maiorEvolucao = 1;
foreach ($evolucaoPedidos as $ponto) {
    $maiorEvolucao = max($maiorEvolucao, (int)$ponto['valor']);
}

/* =========================================================
   DADOS DA NOVA DASHBOARD
========================================================= */
$hojeDashboard = new DateTime("today");
$inicioSemanaDashboard = (clone $hojeDashboard)->modify("monday this week");
$fimSemanaDashboard = (clone $inicioSemanaDashboard)->modify("+6 days");

$equipeAtiva = [];
foreach ($motoristas as $motorista) {
    if ((int)$motorista["ativo"] === 1) {
        $equipeAtiva[] = [
            "tipo" => "Motorista",
            "nome" => $motorista["nome"] ?: $motorista["email"],
            "email" => $motorista["email"],
            "icone" => "../../assets/icons/motorista-verde.png"
        ];
    }
}
foreach ($secretarias as $secretaria) {
    if ((int)($secretaria["ativo"] ?? 1) === 1) {
        $equipeAtiva[] = [
            "tipo" => "Secretaria",
            "nome" => $secretaria["nome"] ?: $secretaria["email"],
            "email" => $secretaria["email"],
            "icone" => "../../assets/icons/secretaria-verde.png"
        ];
    }
}
usort($equipeAtiva, fn($a, $b) => strcasecmp($a["nome"], $b["nome"]));
$equipeAtivaTotal = count($equipeAtiva);
$equipeAtivaLista = array_slice($equipeAtiva, 0, 7);

$pedidosValidosHoje = [];
$pedidosProximosPrazo = [];
$pedidosForaPrazo = [];
$pedidosSemana = [];
$pedidosPorDiaCalendario = [1 => [], 2 => [], 3 => [], 4 => [], 5 => [], 6 => [], 7 => []];
$coletasConcluidasSemana = 0;

foreach ($pedidos as $pedido) {
    $statusNormalizado = normalizarStatusAdmin((string)($pedido["status"] ?? ""));
    $dataPedido = substr((string)($pedido["data_pedido"] ?? ""), 0, 10);
    if ($dataPedido === "") continue;

    $limite = dataComCincoDiasUteisAdmin($dataPedido);
    $limiteDate = new DateTime($limite);
    $prazoAtivo = statusAtivoDashboardAdmin((string)$pedido["status"]);

    if ($prazoAtivo) {
        if ($limite >= $hojeDashboard->format("Y-m-d")) {
            $pedido["prazo_calculado"] = $limite;
            $pedido["prazo_info"] = prazoDashboardAdmin($pedido);
            $pedidosValidosHoje[] = $pedido;

            $diasRestantes = diasUteisRestantesAdmin($limite);
            if ($diasRestantes <= 2) {
                $pedido["prazo_calculado"] = $limite;
                $pedido["prazo_info"] = prazoDashboardAdmin($pedido);
                $pedidosProximosPrazo[] = $pedido;
            }
        } else {
            $pedido["prazo_calculado"] = $limite;
            $pedido["prazo_info"] = prazoDashboardAdmin($pedido);
            $pedidosForaPrazo[] = $pedido;
        }
    }

    $finalizacao = !empty($pedido["data_finalizacao"]) ? substr((string)$pedido["data_finalizacao"], 0, 10) : "";
    $estaNaSemanaPorPrazo = $limiteDate >= $inicioSemanaDashboard && $limiteDate <= $fimSemanaDashboard;
    $estaConcluidoNaSemana = $finalizacao !== "" && $finalizacao >= $inicioSemanaDashboard->format("Y-m-d") && $finalizacao <= $fimSemanaDashboard->format("Y-m-d");

    if ($estaNaSemanaPorPrazo || $estaConcluidoNaSemana) {
        $pedido["prazo_calculado"] = $limite;
        $pedido["prazo_info"] = prazoDashboardAdmin($pedido);
        $pedidosSemana[] = $pedido;
    }

    $dataSemana = new DateTime($limite);
    if ($dataSemana >= $inicioSemanaDashboard && $dataSemana <= $fimSemanaDashboard && $prazoAtivo) {
        $indiceDia = (int)$dataSemana->format("N");
        $pedido["prazo_calculado"] = $limite;
        $pedido["prazo_info"] = prazoDashboardAdmin($pedido);
        $pedidosPorDiaCalendario[$indiceDia][] = $pedido;
    }

    if ($estaConcluidoNaSemana) {
        $coletasConcluidasSemana++;
    }
}

$totalValidosSemana = count($pedidosSemana);
$percentualSemana = $totalValidosSemana > 0 ? (int)round(($coletasConcluidasSemana / $totalValidosSemana) * 100) : 0;

$weeklyStatus = [
    "analise" => 0,
    "agendado" => 0,
    "caminho" => 0,
    "andamento" => 0,
    "concluido" => 0
];
foreach ($pedidosSemana as $pedidoSemana) {
    $status = normalizarStatusAdmin((string)$pedidoSemana["status"]);
    if ($status === "em analise" || $status === "pendente") $weeklyStatus["analise"]++;
    elseif (in_array($status, ["confirmado", "encaminhado", "agendado"], true)) $weeklyStatus["agendado"]++;
    elseif ($status === "a caminho") $weeklyStatus["caminho"]++;
    elseif ($status === "em andamento") $weeklyStatus["andamento"]++;
    elseif ($status === "concluido") $weeklyStatus["concluido"]++;
}

$weeklyTotal = array_sum($weeklyStatus);
$weeklyAngle = 0.0;
$weeklySegments = [];
$weeklyColors = [
    "analise" => "#FF6200",
    "agendado" => "#FFAA00",
    "caminho" => "#FFFB00",
    "andamento" => "#00B330",
    "concluido" => "#009150"
];
foreach ($weeklyStatus as $keyWeekly => $valorWeekly) {
    $graus = $weeklyTotal > 0 ? ((int)$valorWeekly / $weeklyTotal) * 360 : 0;
    $weeklySegments[] = $weeklyColors[$keyWeekly] . " " . round($weeklyAngle, 2) . "deg " . round($weeklyAngle + $graus, 2) . "deg";
    $weeklyAngle += $graus;
}
$weeklyPieStyle = $weeklyTotal > 0
    ? "conic-gradient(" . implode(", ", $weeklySegments) . ")"
    : "conic-gradient(#e4eae6 0deg 360deg)";
$weeklyConcluidaPct = $weeklyTotal > 0 ? (int)round(($weeklyStatus['concluido'] / $weeklyTotal) * 100) : 0;

$coletasHojeDashboard = 0;
$pedidosAnaliseDashboard = 0;
foreach ($pedidos as $pedido) {
    $status = normalizarStatusAdmin((string)$pedido["status"]);
    if (in_array($status, ["concluido", "cancelado", "suspenso"], true)) continue;
    $limite = dataComCincoDiasUteisAdmin(substr((string)$pedido["data_pedido"], 0, 10));
    if ($limite === $hojeDashboard->format("Y-m-d")) $coletasHojeDashboard++;
    if (in_array($status, ["pendente", "em analise"], true)) $pedidosAnaliseDashboard++;
}

$pedidosProximosPrazoCount = count($pedidosProximosPrazo);

/* =========================================================
   INICIAIS
========================================================= */
$partesNome = preg_split('/\s+/', trim($adminNome));
$iniciais = "";
if (!empty($partesNome[0])) $iniciais .= strtoupper(substr($partesNome[0], 0, 1));
if (count($partesNome) > 1) $iniciais .= strtoupper(substr($partesNome[count($partesNome) - 1], 0, 1));
$iniciais = substr($iniciais ?: "AD", 0, 2);

/* =========================================================
   GRÁFICO
========================================================= */
$totalGrafico = max(1, $stats["total"]);
$anguloPendente = ($stats["pendente"] / $totalGrafico) * 360;
$anguloConfirmado = $anguloPendente + ($stats["confirmado"] / $totalGrafico) * 360;
$anguloAndamento = $anguloConfirmado + ($stats["andamento"] / $totalGrafico) * 360;
$anguloConcluido = $anguloAndamento + ($stats["concluido"] / $totalGrafico) * 360;
$graficoStyle = "
    conic-gradient(
        #f3a51b 0deg {$anguloPendente}deg,
        #318ddd {$anguloPendente}deg {$anguloConfirmado}deg,
        #0edc8b {$anguloConfirmado}deg {$anguloAndamento}deg,
        #3ca0ea {$anguloAndamento}deg {$anguloConcluido}deg,
        #db4b4b {$anguloConcluido}deg 360deg
    )
";
?>


<!DOCTYPE html>
<html lang="pt-BR">

<head>

    <meta charset="UTF-8">

    <meta
        name="viewport"
        content="width=device-width, initial-scale=1.0">

    <title>
        EcoAgenda - Administrador
    </title>

    <link
        rel="stylesheet"
        href="administrador.css">


    <style>
        .tipo-busca-admin {
            display: flex;
            gap: 8px;
            margin: 0 0 14px;
        }

        .tipo-busca-admin-btn {
            border: 1px solid #d6ded8;
            background: #fff;
            color: #26352c;
            border-radius: 7px;
            padding: 9px 16px;
            font-weight: 700;
            cursor: pointer;
        }

        .tipo-busca-admin-btn.active {
            background: #0f6b31;
            border-color: #0f6b31;
            color: #fff;
        }
    </style>

</head>

<body>

<div class="dashboard">


    <!-- =====================================================
         SIDEBAR
    ====================================================== -->

    <aside class="sidebar">

        <div class="logo">
            <img
                src="../../ECO AGENDA LOGO FINAL HORIZONTAL BRANCO.png"
                alt="EcoAgenda"
                class="logo-img">
        </div>

        <div class="perfil-side">
            Administrador
        </div>

        <nav class="menu">

            <button
                type="button"
                class="menu-link active"
                data-section="inicio">

                <span>▦</span>
                Dashboard

            </button>

            <button
                type="button"
                class="menu-link"
                data-section="pedidos">

                <span>▤</span>
                Pedidos

            </button>

            <button
                type="button"
                class="menu-link"
                data-section="buscar">

                <span>⌕</span>
                Buscar pedido

            </button>

            <button
                type="button"
                class="menu-link"
                data-section="motoristas">

                <img
                    src="../../assets/icons/motorista-branco.png"
                    alt=""
                    aria-hidden="true"
                    class="menu-icon-image motorista-icon-sidebar">
                <span>Motoristas</span>

            </button>

            <button
                type="button"
                class="menu-link"
                data-section="secretarias">

                <img
                    src="../../assets/icons/secretaria-branco.png"
                    alt=""
                    aria-hidden="true"
                    class="menu-icon-image secretaria-icon-sidebar">

                <span>Secretarias</span>

            </button>

            <button
                type="button"
                class="menu-link"
                data-section="moradores">

                <img
                    src="../../assets/icons/perfil-branco.png"
                    alt=""
                    aria-hidden="true"
                    class="menu-icon-image morador-icon-sidebar">

                <span>Moradores</span>

            </button>
</nav>

    </aside>


    <!-- =====================================================
         MAIN
    ====================================================== -->

    <main class="main">


        <!-- TOPBAR -->

        <header class="topbar">

            <div>

                <h1 id="tituloPagina">
                    Dashboard - ADM
                </h1>

                <p id="subtituloPagina">
                    Visão geral dos seus pedidos de coleta.
                </p>

            </div>


            <div class="top-actions">

                <a
                    href="../logout.php"
                    class="logout">

                    Sair

                </a>

                <div class="avatar">

                    <?= e($iniciais) ?>

                </div>

            </div>

        </header>


        <div class="content">


            <?php if ($mensagem !== ""): ?>

                <div
                    class="alerta <?= e($tipoMensagem) ?>">

                    <?= e($mensagem) ?>

                </div>

            <?php endif; ?>


            <!-- =================================================
                 DASHBOARD
            ================================================== -->

            <section
                class="section active"
                id="section-inicio">

                <div class="adm-dashboard-topo">
                    <div>
                        <h2>Visão geral</h2>
                        <p>Acompanhe pedidos, equipe e prazos em um só lugar.</p>
                    </div>
                    <span class="adm-data-atual"><?= e($hojeDashboard->format("d/m/Y")) ?></span>
                </div>

                <!-- RESUMO GERAL -->
                <div class="adm-resumo-grid">
                    <div class="adm-resumo-card total">
                        <span class="adm-resumo-label">Total de pedidos</span>
                        <strong><?= $stats["total"] ?></strong>
                        <small>Todos os pedidos registrados</small>
                    </div>
                    <div class="adm-resumo-card analise">
                        <span class="adm-resumo-label">Em análise</span>
                        <strong><?= $stats["pendente"] ?></strong>
                        <small>Aguardando validação</small>
                    </div>
                    <div class="adm-resumo-card agendado">
                        <span class="adm-resumo-label">Agendados</span>
                        <strong><?= $stats["confirmado"] ?></strong>
                        <small>Encaminhados ao motorista</small>
                    </div>
                    <div class="adm-resumo-card caminho">
                        <span class="adm-resumo-label">A caminho</span>
                        <strong><?= $stats["a_caminho"] ?></strong>
                        <small>Motorista em deslocamento</small>
                    </div>
                    <div class="adm-resumo-card andamento">
                        <span class="adm-resumo-label">Em andamento</span>
                        <strong><?= $stats["andamento"] ?></strong>
                        <small>Coletas em execução</small>
                    </div>
                    <div class="adm-resumo-card concluido">
                        <span class="adm-resumo-label">Concluídos</span>
                        <strong><?= $stats["concluido"] ?></strong>
                        <small>Coletas finalizadas</small>
                    </div>
                    <div class="adm-resumo-card cancelado">
                        <span class="adm-resumo-label">Suspensos</span>
                        <strong><?= $stats["cancelado"] ?></strong>
                        <small>Pedidos interrompidos</small>
                    </div>
                </div>

                <!-- EQUIPE + CALENDÁRIO -->
                <div class="adm-grid-duplo">
                    <div class="adm-card adm-equipe-card">
                        <div class="adm-card-header">
                            <div>
                                <h3>Equipe online</h3>
                                <p><?= $equipeAtivaTotal ?> cadastro(s) ativo(s)</p>
                            </div>
                            <span class="adm-online-total"><i></i><?= $equipeAtivaTotal ?></span>
                        </div>

                        <div class="adm-equipe-lista">
                            <?php if (!$equipeAtivaLista): ?>
                                <div class="adm-vazio-pequeno">Nenhum motorista ou secretaria ativo.</div>
                            <?php else: ?>
                                <?php foreach ($equipeAtivaLista as $membro): ?>
                                    <div class="adm-equipe-item">
                                        <div class="adm-equipe-avatar">
                                            <img src="<?= e($membro["icone"]) ?>" alt="">
                                        </div>
                                        <div class="adm-equipe-info">
                                            <strong><?= e($membro["nome"]) ?></strong>
                                            <span><?= e($membro["tipo"]) ?></span>
                                        </div>
                                        <span class="adm-online-pill"><i></i>Ativo</span>
                                    </div>
                                <?php endforeach; ?>
                            <?php endif; ?>
                        </div>
                    </div>

                    <div class="adm-card adm-calendario-card">
                        <div class="adm-card-header">
                            <div>
                                <h3>Prazo das coletas</h3>
                                <p>Semana atual · 5 dias úteis</p>
                            </div>
                            <span class="adm-semana-label"><?= e($inicioSemanaDashboard->format("d/m")) ?> — <?= e($fimSemanaDashboard->format("d/m")) ?></span>
                        </div>

                        <div class="adm-calendario-semana">
                            <?php
                            $nomesDias = [1 => 'Seg', 2 => 'Ter', 3 => 'Qua', 4 => 'Qui', 5 => 'Sex', 6 => 'Sáb', 7 => 'Dom'];
                            foreach ($nomesDias as $numeroDia => $nomeDia):
                                $isWeekend = $numeroDia >= 6;
                            ?>
                                <div class="adm-dia <?= $isWeekend ? 'fim-semana' : '' ?>">
                                    <div class="adm-dia-cabecalho">
                                        <strong><?= $nomeDia ?></strong>
                                        <span><?= (clone $inicioSemanaDashboard)->modify('+' . ($numeroDia - 1) . ' days')->format('d') ?></span>
                                    </div>
                                    <div class="adm-dia-itens">
                                        <?php if ($isWeekend): ?>
                                            <span class="adm-dia-sem-coleta">Sem coleta</span>
                                        <?php elseif (empty($pedidosPorDiaCalendario[$numeroDia])): ?>
                                            <span class="adm-dia-sem-coleta">Sem prazo</span>
                                        <?php else: ?>
                                            <?php foreach (array_slice($pedidosPorDiaCalendario[$numeroDia], 0, 4) as $pedidoCalendario): ?>
                                                <?php $pInfo = $pedidoCalendario["prazo_info"]; ?>
                                                <button type="button" class="adm-prazo-item <?= e($pInfo["classe"]) ?> btn-detalhes" data-id="<?= (int)$pedidoCalendario["id"] ?>">
                                                    <span>#<?= (int)$pedidoCalendario["id"] ?></span>
                                                    <small><?= e($pInfo["texto"]) ?></small>
                                                </button>
                                            <?php endforeach; ?>
                                            <?php if (count($pedidosPorDiaCalendario[$numeroDia]) > 4): ?>
                                                <span class="adm-mais-itens">+ <?= count($pedidosPorDiaCalendario[$numeroDia]) - 4 ?> pedidos</span>
                                            <?php endif; ?>
                                        <?php endif; ?>
                                    </div>
                                </div>
                            <?php endforeach; ?>
                        </div>
                    </div>
                </div>

                <!-- PLANO SEMANAL + HOJE -->
                <div class="adm-grid-duplo adm-grid-meio">
                    <div class="adm-card adm-weekly-card">
                        <div class="adm-card-header">
                            <div>
                                <h3>Coletas desta semana</h3>
                                <p>Somente pedidos dentro do prazo de 5 dias úteis.</p>
                            </div>
                        </div>

                        <div class="adm-weekly-content">
                            <div class="adm-weekly-pie-shell">
                                <div class="adm-weekly-pie" style="background: <?= e($weeklyPieStyle) ?>;" role="img" aria-label="Distribuição dos pedidos válidos desta semana por status">
                                    <div class="adm-weekly-pie-center">
                                        <strong><?= (int)$weeklyTotal ?></strong>
                                        <span>coletas válidas</span>
                                        <small><?= (int)$weeklyConcluidaPct ?>% concluídas</small>
                                    </div>
                                </div>
                            </div>
                            <div class="adm-weekly-legenda">
                                <?php
                                $weeklyLabels = [
                                    "analise" => "Em análise", "agendado" => "Agendado", "caminho" => "A caminho",
                                    "andamento" => "Em andamento", "concluido" => "Concluído"
                                ];
                                foreach ($weeklyLabels as $weeklyKey => $weeklyLabel):
                                    $weeklyValue = (int)$weeklyStatus[$weeklyKey];
                                    $weeklyPct = $weeklyTotal > 0 ? (int)round(($weeklyValue / $weeklyTotal) * 100) : 0;
                                ?>
                                    <div class="adm-weekly-item">
                                        <div class="adm-weekly-item-label"><i class="<?= e($weeklyKey) ?>"></i><span><?= e($weeklyLabel) ?></span></div>
                                        <div class="adm-weekly-item-value"><strong><?= $weeklyValue ?></strong><small><?= $weeklyPct ?>%</small></div>
                                    </div>
                                <?php endforeach; ?>
                            </div>
                        </div>
                    </div>

                    <div class="adm-card adm-hoje-card">
                        <div class="adm-card-header">
                            <div>
                                <h3>O que precisa ser feito hoje</h3>
                                <p>Atalhos e tarefas prioritárias.</p>
                            </div>
                        </div>

                        <div class="adm-tarefas-lista">
                            <div class="adm-tarefa <?= $coletasHojeDashboard > 0 ? 'destaque' : '' ?>">
                                <span class="adm-tarefa-icone verde">✓</span>
                                <div><strong><?= $coletasHojeDashboard ?> coleta(s) com prazo hoje</strong><small>Verifique os pedidos com vencimento nesta data.</small></div>
                                <button type="button" class="btn-small" data-go-section="pedidos">Ver</button>
                            </div>
                            <div class="adm-tarefa <?= $pedidosProximosPrazoCount > 0 ? 'destaque' : '' ?>">
                                <span class="adm-tarefa-icone amarelo">!</span>
                                <div><strong><?= $pedidosProximosPrazoCount ?> pedido(s) próximos do prazo</strong><small>Até 2 dias úteis restantes.</small></div>
                                <button type="button" class="btn-small" data-go-section="pedidos">Ver</button>
                            </div>
                            <div class="adm-tarefa">
                                <span class="adm-tarefa-icone azul">+</span>
                                <div><strong>Cadastrar motorista</strong><small>Adicione um novo profissional ao sistema.</small></div>
                                <button type="button" class="btn-small" data-go-section="motoristas">Abrir</button>
                            </div>
                            <div class="adm-tarefa">
                                <span class="adm-tarefa-icone roxo">+</span>
                                <div><strong>Cadastrar secretaria</strong><small>Adicione um novo acesso administrativo.</small></div>
                                <button type="button" class="btn-small" data-go-section="secretarias">Abrir</button>
                            </div>
                        </div>
                    </div>
                </div>

                <!-- GRÁFICO MENSAL + PDF -->
                <div class="adm-card adm-relatorio-card">
                    <div class="adm-card-header adm-relatorio-header">
                        <div>
                            <h3>Pedidos por mês</h3>
                            <p>Acompanhe a evolução e gere o relatório do período escolhido.</p>
                        </div>
                        <form method="GET" class="adm-relatorio-filtros">
                            <select name="relatorio_mes" aria-label="Mês do relatório">
                                <?php foreach ($mesesRelatorio as $numeroMes => $nomeMes): ?>
                                    <option value="<?= (int)$numeroMes ?>" <?= $numeroMes === $relatorioMes ? 'selected' : '' ?>><?= e($nomeMes) ?></option>
                                <?php endforeach; ?>
                            </select>
                            <select name="relatorio_ano" aria-label="Ano do relatório">
                                <?php $anoAtualDashboard = (int)date('Y'); for ($ano = max(2024, $anoAtualDashboard - 2); $ano <= $anoAtualDashboard + 1; $ano++): ?>
                                    <option value="<?= $ano ?>" <?= $ano === $relatorioAno ? 'selected' : '' ?>><?= $ano ?></option>
                                <?php endfor; ?>
                            </select>
                            <button type="submit" class="btn-secondary">Filtrar</button>
                            <a class="btn-primary" href="gerar_relatorio.php?mes=<?= (int)$relatorioMes ?>&ano=<?= (int)$relatorioAno ?>" target="_blank" rel="noopener">Gerar PDF</a>
                        </form>
                    </div>

                    <div class="adm-relatorio-resumo">
                        <div><strong><?= (int)$relatorio['recebidos'] ?></strong><span>Pedidos em <?= e($mesesRelatorio[$relatorioMes]) ?></span></div>
                        <div><strong><?= (int)$relatorio['concluidos'] ?></strong><span>Concluídos no mês</span></div>
                        <div><strong><?= (int)$relatorio['cancelados'] ?></strong><span>Suspensos no mês</span></div>
                    </div>

                    <div class="adm-chart-wrap">
                        <?php
                        $chartWidthDash = 1000;
                        $chartHeightDash = 250;
                        $leftPadDash = 28;
                        $rightPadDash = 28;
                        $topPadDash = 34;
                        $bottomPadDash = 48;
                        $innerWDash = $chartWidthDash - $leftPadDash - $rightPadDash;
                        $innerHDash = $chartHeightDash - $topPadDash - $bottomPadDash;
                        $pointsDash = [];
                        foreach ($evolucaoPedidos as $idxDash => $pontoDash) {
                            $xDash = $leftPadDash + ($innerWDash * ($idxDash / max(1, count($evolucaoPedidos) - 1)));
                            $yDash = $topPadDash + ($innerHDash * (1 - ((int)$pontoDash['valor'] / max(1, $maiorEvolucao))));
                            $pointsDash[] = [$xDash, $yDash, (int)$pontoDash['valor'], $pontoDash['label']];
                        }
                        $polylineDash = implode(' ', array_map(fn($p) => round($p[0], 2) . ',' . round($p[1], 2), $pointsDash));
                        $areaDash = $polylineDash . ' ' . ($leftPadDash + $innerWDash) . ',' . ($topPadDash + $innerHDash) . ' ' . $leftPadDash . ',' . ($topPadDash + $innerHDash);
                        ?>
                        <svg class="adm-chart-svg" viewBox="0 0 <?= $chartWidthDash ?> <?= $chartHeightDash ?>" role="img" aria-label="Evolução dos pedidos dos últimos seis meses">
                            <defs>
                                <linearGradient id="admAreaChart" x1="0" y1="0" x2="0" y2="1">
                                    <stop offset="0%" stop-color="#8ccda4" stop-opacity=".42"/>
                                    <stop offset="100%" stop-color="#8ccda4" stop-opacity=".05"/>
                                </linearGradient>
                            </defs>
                            <g class="adm-chart-grid">
                                <line x1="28" y1="34" x2="972" y2="34"/>
                                <line x1="28" y1="76" x2="972" y2="76"/>
                                <line x1="28" y1="118" x2="972" y2="118"/>
                                <line x1="28" y1="160" x2="972" y2="160"/>
                                <line x1="28" y1="202" x2="972" y2="202"/>
                            </g>
                            <polygon points="<?= e($areaDash) ?>" fill="url(#admAreaChart)"/>
                            <polyline points="<?= e($polylineDash) ?>" fill="none" stroke="#23804a" stroke-width="4" stroke-linecap="round" stroke-linejoin="round"/>
                            <?php foreach ($pointsDash as $pDash): ?>
                                <circle cx="<?= round($pDash[0], 2) ?>" cy="<?= round($pDash[1], 2) ?>" r="6" fill="#23804a" stroke="#fff" stroke-width="3"/>
                                <text x="<?= round($pDash[0], 2) ?>" y="<?= round($pDash[1] - 14, 2) ?>" text-anchor="middle" class="adm-chart-valor"><?= $pDash[2] ?></text>
                                <text x="<?= round($pDash[0], 2) ?>" y="228" text-anchor="middle" class="adm-chart-label"><?= e($pDash[3]) ?></text>
                            <?php endforeach; ?>
                        </svg>
                    </div>
                </div>



                <!-- MAPA TEMÁTICO DE PINHAIS
                     Módulo isolado para não interferir nas demais telas do ADM.
                -->
                <div class="adm-card adm-mapa-card" data-map-mode="locais">
                    <div class="adm-card-header adm-mapa-header">
                        <div>
                            <span class="adm-mapa-eyebrow">DISTRIBUIÇÃO TERRITORIAL</span>
                            <h3>Locais das coletas realizadas</h3>
                            <p>Ruas detalhadas e marcadores dos endereços com coletas finalizadas no mês.</p>
                        </div>
                        <div class="adm-mapa-total">
                            <strong><?= (int)$relatorio['coletas'] ?></strong>
                            <span>coletas realizadas</span>
                        </div>
                    </div>

                    <div class="adm-mapa-iframe-shell">
                        <iframe
                            class="adm-mapa-iframe"
                            title="Mapa interativo de coletas em Pinhais"
                            src="mapa_pinhais.php?modo=locais&mes=<?= (int)$relatorioMes ?>&ano=<?= (int)$relatorioAno ?>"
                            loading="eager"
                            referrerpolicy="strict-origin-when-cross-origin">
                        </iframe>
                    </div>


                </div>
                <div class="adm-card adm-mapa-card" data-map-mode="demanda">
                    <div class="adm-card-header adm-mapa-header">
                        <div>
                            <span class="adm-mapa-eyebrow">DISTRIBUIÇÃO TERRITORIAL</span>
                            <h3>Demanda de coletas por bairro</h3>
                            <p>Bairros coloridos pela quantidade de pedidos do mês. Passe o mouse para ver os dados.</p>
                        </div>
                        <div class="adm-mapa-total">
                            <strong><?= (int)$totalColetasMapaPinhais ?></strong>
                            <span>pedidos no mês</span>
                        </div>
                    </div>

                    <div class="adm-mapa-iframe-shell">
                        <iframe
                            class="adm-mapa-iframe"
                            title="Mapa interativo de coletas em Pinhais"
                            src="mapa_pinhais.php?modo=demanda&mes=<?= (int)$relatorioMes ?>&ano=<?= (int)$relatorioAno ?>"
                            loading="eager"
                            referrerpolicy="strict-origin-when-cross-origin">
                        </iframe>
                    </div>


                </div>
                    <script>
                    window.addEventListener("message", function (event) {
                        if (event.origin !== window.location.origin || !event.data || event.data.type !== "ecoagenda:map-update") return;
                        document.querySelectorAll(".adm-mapa-card[data-map-mode]").forEach(function (card) {
                            const iframe = card.querySelector("iframe");
                            if (event.source !== iframe.contentWindow || event.data.modo !== card.dataset.mapMode) return;
                            const total = Number(event.data.total);
                            if (Number.isFinite(total)) card.querySelector(".adm-mapa-total strong").textContent = total.toLocaleString("pt-BR");
                        });
                    });
                    </script>
            </section>


            <!-- =================================================
                 PEDIDOS
            ================================================== -->

            <section
                class="section"
                id="section-pedidos">


                <div class="section-top">

                    <div>

                        <h2>
                            Todos os pedidos
                        </h2>

                        <p>
                            Visualize pedidos, responsáveis, status e fotos.
                        </p>

                    </div>

                </div>


                <div class="tabela-wrapper">

                    <table class="data-table">

                        <thead>

                            <tr>

                                <th>
                                    Pedido
                                </th>

                                <th>
                                    Morador
                                </th>

                                <th>
                                    Status
                                </th>

                                <th>
                                    Motorista
                                </th>

                                <th>
                                    Data da coleta
                                </th>

                                <th>
                                    Fotos
                                </th>

                                <th>
                                    Ações
                                </th>

                            </tr>

                        </thead>

                        <tbody>

                        <?php foreach ($pedidos as $pedido): ?>

                            <tr class="pedido-admin-row"
                                data-id="<?= (int)$pedido["id"] ?>"
                                data-cpf="<?= e($pedido["morador_cpf"] ?? "") ?>">

                                <td>

                                    <strong>
                                        #<?= e($pedido["id"]) ?>
                                    </strong>

                                    <small>
                                        <?= e(
                                            mb_strimwidth(
                                                $pedido["descricao"],
                                                0,
                                                55,
                                                "..."
                                            )
                                        ) ?>
                                    </small>

                                </td>


                                <td>

                                    <strong>
                                        <?= e(
                                            $pedido["morador_nome"]
                                            ?: "Morador"
                                        ) ?>
                                    </strong>

                                    <small>
                                        CPF:
                                        <?= e(
                                            $pedido["morador_cpf"]
                                        ) ?>
                                    </small>

                                </td>


                                <td>

                                    <span
                                        class="status <?= e(
                                            classeStatus(
                                                $pedido["status"]
                                            )
                                        ) ?>">

                                        <?= e(
                                            $pedido["status"]
                                        ) ?>

                                    </span>

                                </td>


                                <td>

                                    <?= e(
                                        $pedido["motorista_email"]
                                        ?: "Não atribuído"
                                    ) ?>

                                </td>


                                <td>

                                    <?= e(
                                        dataBR(
                                            $pedido[
                                                "data_realizacao"
                                            ]
                                        )
                                    ) ?>

                                </td>


                                <td>

                                    <?php if (
                                        !empty(
                                            $pedido["foto"]
                                        )
                                    ): ?>

                                        <a
                                            href="../../agendamento/<?= e(
                                                $pedido["foto"]
                                            ) ?>"
                                            target="_blank"
                                            class="foto-link">

                                            Morador

                                        </a>

                                    <?php endif; ?>


                                    <?php if (
                                        !empty(
                                            $pedido["foto_motorista"]
                                        )
                                    ): ?>

                                        <a
                                            href="../../agendamento/<?= e(
                                                $pedido["foto_motorista"]
                                            ) ?>"
                                            target="_blank"
                                            class="foto-link">

                                            Coleta

                                        </a>

                                    <?php endif; ?>


                                    <?php if (
                                        empty($pedido["foto"]) &&
                                        empty(
                                            $pedido["foto_motorista"]
                                        )
                                    ): ?>

                                        <span class="sem-foto">
                                            —

                                        </span>

                                    <?php endif; ?>

                                </td>


                                <td>

                                    <button
                                        type="button"
                                        class="btn-small btn-detalhes"
                                        data-id="<?= (int)$pedido["id"] ?>">

                                        Detalhes

                                    </button>

                                </td>

                            </tr>


                            <tr class="dados-pedido">

                                <td colspan="7">

                                    <div
                                        id="dados-<?= (int)$pedido["id"] ?>"

                                        data-id="<?= (int)$pedido["id"] ?>"
                                        data-descricao="<?= e($pedido["descricao"]) ?>"
                                        data-status="<?= e($pedido["status"]) ?>"
                                        data-morador="<?= e($pedido["morador_nome"] ?? "") ?>"
                                        data-cpf="<?= e($pedido["morador_cpf"]) ?>"
                                        data-telefone="<?= e($pedido["morador_telefone"] ?? "") ?>"
                                        data-endereco="<?= e($pedido["endereco"]) ?>"
                                        data-data="<?= e($pedido["data_realizacao"] ?? "") ?>"
                                        data-hora="<?= e($pedido["horario_realizacao"] ?? "") ?>"
                                        data-motorista="<?= e($pedido["motorista_email"] ?? "") ?>"

                                    ></div>

                                </td>

                            </tr>

                        <?php endforeach; ?>

                        </tbody>

                    </table>

                </div>

            </section>




            <!-- =================================================
                 BUSCAR PEDIDO
            ================================================== -->

            <section class="section" id="section-buscar">
                <div class="painel">
                    <div class="section-top">
                        <div>
                            <h2>Buscar pedido</h2>
                            <p>Localize um pedido por CPF do morador ou pelo ID do pedido.</p>
                        </div>
                    </div>

                    <div class="busca-form busca-tipos">
                        <button type="button" id="tipoBuscaCpf" class="btn-primary">Buscar por CPF</button>
                        <button type="button" id="tipoBuscaId" class="btn-secondary">Buscar por ID</button>
                    </div>

                    <div class="busca-form">
                        <input type="text" id="campoBuscaPedido" placeholder="Digite o CPF" autocomplete="off">
                        <button type="button" id="buscarPedido" class="btn-primary">Buscar</button>
                    </div>

                    <div id="resultadoBuscaPedido" class="resultado-busca"></div>

                    <div id="resultadoPedidosBusca" class="cards-pedidos"></div>

                    <div id="fontePedidosBusca" class="cards-pedidos busca-fonte" hidden>
                        <?php foreach ($pedidos as $pedido): ?>
                            <?php $classeBusca = classeStatus($pedido["status"]); ?>
                            <article
                                class="pedido-card"
                                data-status="<?= e($classeBusca) ?>"
                                data-id="<?= (int)$pedido["id"] ?>"
                                data-cpf="<?= e($pedido["morador_cpf"]) ?>">

                                <div class="pedido-card-top">
                                    <div>
                                        <span class="numero-pedido">Pedido #<?= e($pedido["id"]) ?></span>
                                        <h3><?= e(mb_strimwidth($pedido["descricao"], 0, 90, "...")) ?></h3>
                                        <p>CPF: <?= e($pedido["morador_cpf"]) ?> • Pedido em <?= e(dataBR($pedido["data_pedido"])) ?></p>
                                    </div>
                                    <span class="status <?= e($classeBusca) ?>"><?= e($pedido["status"]) ?></span>
                                </div>

                                <div class="pedido-meta">
                                    <div>
                                        <span>Morador</span>
                                        <strong><?= e($pedido["morador_nome"] ?: "Morador") ?></strong>
                                    </div>
                                    <div>
                                        <span>Motorista</span>
                                        <strong><?= e($pedido["motorista_email"] ?: "Ainda não atribuído") ?></strong>
                                    </div>
                                    <div>
                                        <span>Endereço</span>
                                        <strong><?= e($pedido["endereco"] ?: "Não informado") ?></strong>
                                    </div>
                                </div>

                                <div class="pedido-actions">
                                    <button type="button" class="btn-small btn-detalhes" data-id="<?= (int)$pedido["id"] ?>">Ver detalhes</button>
                                    <button type="button" class="btn-small btn-historico-pedido" data-id="<?= (int)$pedido["id"] ?>">Mostrar histórico</button>
                                </div>
                            </article>
                        <?php endforeach; ?>
                    </div>
                </div>
            </section>

            <script type="application/json" id="historicoPedidosAdmin"><?= json_encode($historico, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES | JSON_HEX_TAG | JSON_HEX_APOS | JSON_HEX_AMP | JSON_HEX_QUOT) ?></script>


            <!-- =================================================
                 MOTORISTAS
            ================================================== -->

            <section
                class="section"
                id="section-motoristas">


                <div class="section-top">

                    <div>

                        <h2>
                            Gerenciar motoristas
                        </h2>

                        <p>
                            Controle os motoristas cadastrados e sua situação.
                        </p>

                    </div>

                    <button
                        type="button"
                        class="btn-primary"
                        id="btnNovoMotorista">

                        + Cadastrar motorista

                    </button>

                </div>


                <div class="cards-equipe">


                    <?php foreach (
                        $motoristas
                        as $motorista
                    ): ?>

                        <article class="equipe-card">

                            <div class="equipe-avatar">
                                <img
                                    src="../../assets/icons/motorista-verde.png"
                                    alt="Motorista"
                                    class="motorista-icon-card">
                            </div>

                            <div class="equipe-info">

                                <span>
                                    Motorista
                                </span>

                                <h3>
                                    <?= e(
                                        $motorista["nome"] ?: $motorista["email"]
                                    ) ?>
                                </h3>

                                <p>
                                    E-mail:
                                    <?= e($motorista["email"]) ?>
                                </p>

                                <p>
                                    CNH:
                                    <?= e($motorista["cnh"]) ?>
                                </p>

                                <p>
                                    CPF:
                                    <?= e($motorista["cpf"]) ?>
                                </p>

                                <p>
                                    Telefone:
                                    <?= e($motorista["telefone"]) ?>
                                </p>

                            </div>


                            <div class="equipe-actions">

                                <span
                                    class="situacao <?= (
                                        (int)$motorista["ativo"] === 1
                                    )
                                    ? "ativo"
                                    : "inativo"
                                    ?>">

                                    <?= (
                                        (int)$motorista["ativo"] === 1
                                    )
                                    ? "Ativo"
                                    : "Inativo"
                                    ?>

                                </span>


                                <button
                                    type="button"
                                    class="btn-small btn-editar-motorista"
                                    data-id="<?= e($motorista["email"]) ?>"
                                    data-email="<?= e($motorista["email"]) ?>"
                                    data-nome="<?= e($motorista["nome"] ?? "") ?>"
                                    data-cnh="<?= e($motorista["cnh"]) ?>"
                                    data-cpf="<?= e($motorista["cpf"]) ?>"
                                    data-telefone="<?= e($motorista["telefone"]) ?>"
                                    data-ativo="<?= (int)$motorista["ativo"] ?>">

                                    Editar

                                </button>


                                <form
                                    method="POST"
                                    class="inline-form">

                                    <input
                                        type="hidden"
                                        name="acao"
                                        value="toggle_motorista">

                                    <input
                                        type="hidden"
                                        name="id"
                                        value="<?= e($motorista["email"]) ?>">

                                    <button
                                        type="submit"
                                        class="btn-small">

                                        <?= (
                                            (int)$motorista["ativo"] === 1
                                        )
                                        ? "Desativar"
                                        : "Ativar"
                                        ?>

                                    </button>

                                </form>

                            </div>

                        </article>

                    <?php endforeach; ?>


                    <?php if (empty($motoristas)): ?>

                        <div class="sem-registros">
                            Nenhum motorista cadastrado.
                        </div>

                    <?php endif; ?>

                </div>

            </section>


            <!-- =================================================
                 SECRETARIAS
            ================================================== -->

            <section
                class="section"
                id="section-secretarias">


                <div class="section-top">

                    <div>

                        <h2>
                            Gerenciar secretarias
                        </h2>

                        <p>
                            Controle os dados de acesso das secretarias cadastradas.
                        </p>

                    </div>

                    <button
                        type="button"
                        class="btn-primary"
                        id="btnNovaSecretaria">

                        + Cadastrar secretaria

                    </button>

                </div>


                <div class="cards-equipe">


                    <?php foreach (
                        $secretarias
                        as $secretaria
                    ): ?>

                        <article class="equipe-card">

                            <div class="equipe-avatar">
                                <img
                                    src="../../assets/icons/secretaria-verde.png"
                                    alt="Secretaria"
                                    class="secretaria-icon-card">
                            </div>

                            <div class="equipe-info">

                                <span>
                                    Secretaria
                                </span>

                                <h3>
                                    <?= e(
                                        $secretaria["nome"]
                                        ?: "Sem nome"
                                    ) ?>
                                </h3>

                                <p>
                                    <?= e(
                                        $secretaria["email"]
                                    ) ?>
                                </p>

                            </div>


                            <div class="equipe-actions">

                                <span
                                    class="situacao <?= (
                                        (int)$secretaria["ativo"] === 1
                                    )
                                    ? "ativo"
                                    : "inativo"
                                    ?>">

                                    <?= (
                                        (int)$secretaria["ativo"] === 1
                                    )
                                    ? "Ativo"
                                    : "Inativo"
                                    ?>

                                </span>

                                <button
                                    type="button"
                                    class="btn-small btn-editar-secretaria"
                                    data-email="<?= e($secretaria["email"]) ?>"
                                    data-nome="<?= e($secretaria["nome"] ?? "") ?>"
                                    data-ativo="<?= (int)$secretaria["ativo"] ?>">

                                    Editar

                                </button>

                                <form
                                    method="POST"
                                    class="inline-form">

                                    <input
                                        type="hidden"
                                        name="acao"
                                        value="toggle_secretaria">

                                    <input
                                        type="hidden"
                                        name="id"
                                        value="<?= e($secretaria["email"]) ?>">

                                    <button
                                        type="submit"
                                        class="btn-small">

                                        <?= (
                                            (int)$secretaria["ativo"] === 1
                                        )
                                        ? "Desativar"
                                        : "Ativar"
                                        ?>

                                    </button>

                                </form>

                            </div>

                        </article>

                    <?php endforeach; ?>


                    <?php if (empty($secretarias)): ?>

                        <div class="sem-registros">
                            Nenhuma Secretaria cadastrada.
                        </div>

                    <?php endif; ?>

                </div>

            </section>


            <!-- =================================================
                 MORADORES
            ================================================== -->

            <section
                class="section"
                id="section-moradores">


                <div class="section-top">

                    <div>

                        <h2>
                            Gerenciar moradores
                        </h2>

                        <p>
                            Consulte os dados dos moradores cadastrados.
                        </p>

                    </div>

                </div>


                <div class="tabela-wrapper">

                    <table class="data-table">

                        <thead>

                            <tr>

                                <th>
                                    Nome
                                </th>

                                <th>
                                    CPF
                                </th>

                                <th>
                                    E-mail
                                </th>

                                <th>
                                    Telefone
                                </th>

                                <th>
                                    Nascimento
                                </th>

                            </tr>

                        </thead>

                        <tbody>

                        <?php foreach (
                            $moradores
                            as $morador
                        ): ?>

                            <tr>

                                <td>
                                    <?= e(
                                        $morador["nome"]
                                        ?: "Sem nome"
                                    ) ?>
                                </td>

                                <td>
                                    <?= e(
                                        $morador["cpf"]
                                    ) ?>
                                </td>

                                <td>
                                    <?= e(
                                        $morador["email"]
                                    ) ?>
                                </td>

                                <td>
                                    <?= e(
                                        $morador["telefone"]
                                    ) ?>
                                </td>

                                <td>
                                    <?= e(
                                        dataBR(
                                            $morador["nascimento"]
                                        )
                                    ) ?>
                                </td>

                            </tr>

                        <?php endforeach; ?>

                        </tbody>

                    </table>

                </div>

            </section>

            <!-- =================================================
                 RELATÓRIOS MENSAIS
            ================================================== -->

            <section
                class="section"
                id="section-relatorios">

                <div class="relatorio-topo">
                    <div>
                        <h2>Relatórios mensais</h2>
                        <p>Indicadores de coleta por período.</p>
                    </div>

                </div>

                <form class="relatorio-filtros" method="get" action="administrador.php">
                    <input type="hidden" name="secao" value="relatorios">

                    <div class="relatorio-filtro">
                        <label for="relatorioMes">Mês</label>
                        <select id="relatorioMes" name="relatorio_mes">
                            <?php foreach ($mesesRelatorio as $numeroMes => $nomeMes): ?>
                                <option value="<?= $numeroMes ?>" <?= $numeroMes === $relatorioMes ? 'selected' : '' ?>>
                                    <?= e($nomeMes) ?>
                                </option>
                            <?php endforeach; ?>
                        </select>
                    </div>

                    <div class="relatorio-filtro">
                        <label for="relatorioAno">Ano</label>
                        <select id="relatorioAno" name="relatorio_ano">
                            <?php
                            $anoAtual = (int)date('Y');
                            for ($ano = max(2024, $anoAtual - 2); $ano <= $anoAtual + 1; $ano++):
                            ?>
                                <option value="<?= $ano ?>" <?= $ano === $relatorioAno ? 'selected' : '' ?>>
                                    <?= $ano ?>
                                </option>
                            <?php endfor; ?>
                        </select>
                    </div>

                    <button type="submit" class="btn-secondary relatorio-aplicar">
                        Atualizar relatório
                    </button>
                </form>

                <div class="relatorio-metricas">
                    <div class="relatorio-metrica">
                        <div class="metrica-topo verde"><strong><?= $relatorio['coletas'] ?></strong><span>▣</span></div>
                        <span>Coletas realizadas</span>
                    </div>
                    <div class="relatorio-metrica">
                        <div class="metrica-topo azul"><strong><?= $relatorio['concluidos'] ?></strong><span>✓</span></div>
                        <span>Pedidos concluídos</span>
                    </div>
                    <div class="relatorio-metrica">
                        <div class="metrica-topo vermelho"><strong><?= $relatorio['suspensos'] ?></strong><span>Ⅱ</span></div>
                        <span>Pedidos suspensos</span>
                    </div>
                    <div class="relatorio-metrica">
                        <div class="metrica-topo roxo"><strong><?= $relatorio['fotos'] ?></strong><span>◉</span></div>
                        <span>Com foto de coleta</span>
                    </div>
                </div>

                <div class="relatorio-grid-principal">
                    <div class="painel relatorio-locais">
                        <div class="painel-header">
                            <div>
                                <h2>Locais com mais coletas</h2>
                                <p>Bairros com maior número de coletas no período selecionado.</p>
                            </div>
                        </div>

                        <?php if (!$locaisColeta): ?>
                            <div class="sem-registros relatorio-sem-dados">
                                Nenhuma coleta concluída no período selecionado.
                            </div>
                        <?php else: ?>
                            <div class="relatorio-barras-horizontais">
                                <?php foreach ($locaisColeta as $local):
                                    $largura = max(3, ($local['total'] / $maiorLocal) * 100);
                                ?>
                                    <div class="local-linha">
                                        <div class="local-nome"><?= e($local['bairro']) ?></div>
                                        <div class="local-barra-area">
                                            <div class="local-barra" style="width: <?= $largura ?>%"></div>
                                        </div>
                                        <strong><?= (int)$local['total'] ?></strong>
                                    </div>
                                <?php endforeach; ?>
                            </div>
                        <?php endif; ?>

                        <div class="relatorio-rodape-dado">
                            Dados referentes a <?= e($mesesRelatorio[$relatorioMes]) ?>/<?= $relatorioAno ?>.
                        </div>
                    </div>
                </div>

                <div class="painel relatorio-evolucao">
                    <div class="painel-header">
                        <div>
                            <h2>Total de pedidos no mês</h2>
                            <p>Evolução dos últimos seis meses.</p>
                        </div>
                        <div class="relatorio-evolucao-selecao">
                            <span>Mês/Ano</span>
                            <strong><?= e($relatorioAno) ?></strong>
                        </div>
                    </div>

                    <div class="relatorio-linha-chart">
                        <div class="relatorio-y-axis">
                            <span><?= $maiorEvolucao ?></span>
                            <span><?= (int)round($maiorEvolucao * .75) ?></span>
                            <span><?= (int)round($maiorEvolucao * .5) ?></span>
                            <span><?= (int)round($maiorEvolucao * .25) ?></span>
                            <span>0</span>
                        </div>
                        <div class="relatorio-chart-area">
                            <div class="relatorio-grid-lines">
                                <span></span><span></span><span></span><span></span><span></span>
                            </div>
                            <?php
                            $chartWidth = 1000;
                            $chartHeight = 220;
                            $leftPad = 18;
                            $rightPad = 18;
                            $topPad = 28;
                            $bottomPad = 42;
                            $innerW = $chartWidth - $leftPad - $rightPad;
                            $innerH = $chartHeight - $topPad - $bottomPad;
                            $points = [];
                            foreach ($evolucaoPedidos as $idx => $ponto) {
                                $x = $leftPad + ($innerW * ($idx / max(1, count($evolucaoPedidos) - 1)));
                                $y = $topPad + ($innerH * (1 - ((int)$ponto['valor'] / max(1, $maiorEvolucao))));
                                $points[] = [$x, $y, (int)$ponto['valor'], $ponto['label']];
                            }
                            $polyline = implode(' ', array_map(fn($p) => round($p[0], 2) . ',' . round($p[1], 2), $points));
                            $area = $polyline . ' ' . ($leftPad + $innerW) . ',' . ($topPad + $innerH) . ' ' . $leftPad . ',' . ($topPad + $innerH);
                            ?>
                            <svg class="relatorio-svg" viewBox="0 0 <?= $chartWidth ?> <?= $chartHeight ?>" role="img" aria-label="Evolução dos pedidos dos últimos seis meses">
                                <defs>
                                    <linearGradient id="areaRelatorio" x1="0" y1="0" x2="0" y2="1">
                                        <stop offset="0%" stop-color="#8ccda4" stop-opacity=".42"/>
                                        <stop offset="100%" stop-color="#8ccda4" stop-opacity=".08"/>
                                    </linearGradient>
                                </defs>
                                <polygon points="<?= e($area) ?>" fill="url(#areaRelatorio)"/>
                                <polyline points="<?= e($polyline) ?>" fill="none" stroke="#23804a" stroke-width="4" stroke-linecap="round" stroke-linejoin="round"/>
                                <?php foreach ($points as $p): ?>
                                    <circle cx="<?= round($p[0],2) ?>" cy="<?= round($p[1],2) ?>" r="6" fill="#23804a" stroke="#fff" stroke-width="3"/>
                                    <text x="<?= round($p[0],2) ?>" y="<?= round($p[1]-14,2) ?>" text-anchor="middle" class="relatorio-ponto-valor"><?= $p[2] ?></text>
                                    <text x="<?= round($p[0],2) ?>" y="<?= $chartHeight-10 ?>" text-anchor="middle" class="relatorio-ponto-label"><?= e($p[3]) ?></text>
                                <?php endforeach; ?>
                            </svg>
                        </div>
                    </div>

                    <div class="relatorio-rodape-dado">
                        Comparativo mensal considerando os pedidos registrados no sistema.
                    </div>
                </div>

                <div class="relatorio-pdf-card">
                    <div class="relatorio-pdf-icon">▤</div>
                    <div class="relatorio-pdf-texto">
                        <h3>Relatório mensal</h3>
                        <p>PDF referente ao período selecionado.</p>
                        <span>Gera um relatório com os principais indicadores, gráficos e lista de coletas do mês.</span>
                    </div>
                    <a
                        class="btn-primary relatorio-pdf-link"
                        href="gerar_relatorio.php?mes=<?= (int)$relatorioMes ?>&ano=<?= (int)$relatorioAno ?>"
                        target="_blank"
                        rel="noopener">
                        <span>▣</span>
                        Gerar PDF do mês
                    </a>
                </div>

            </section>
</div>

    </main>

</div>


<!-- =========================================================
     MODAL HISTÓRICO DO PEDIDO
========================================================= -->
<div class="modal" id="modalHistoricoPedido" hidden>
    <div class="modal-box modal-box-historico-pedido">
        <div class="modal-header">
            <div>
                <span id="historicoPedidoNumero">Histórico</span>
                <h2>Histórico do pedido</h2>
            </div>
            <button type="button" class="modal-close" data-close-modal>×</button>
        </div>

        <div class="modal-body historico-pedido-body">
            <div class="historico-intro">
                <strong id="historicoPedidoTitulo">Alterações registradas neste pedido.</strong>
                <span>Informações registradas em agendamento_historico.</span>
            </div>
            <div id="historicoPedidoLista" class="historico-pedido-lista"></div>
            <div id="historicoPedidoVazio" class="historico-vazio" hidden>Nenhum histórico registrado para este pedido.</div>
        </div>

        <div class="modal-footer">
            <button type="button" class="btn-secondary" data-close-modal>Fechar</button>
        </div>
    </div>
</div>


<!-- =========================================================
     MODAL DETALHES DO PEDIDO
========================================================= -->

<div
    class="modal"
    id="modalDetalhes"
    hidden>

    <div class="modal-box">

        <div class="modal-header">

            <div>

                <span id="modalPedidoId">
                    Pedido
                </span>

                <h2 id="modalTitulo">
                    Detalhes do pedido
                </h2>

            </div>

            <button
                type="button"
                class="modal-close"
                data-close-modal>

                ×

            </button>

        </div>


        <div class="modal-body">

            <div class="modal-status">

                <span>
                    Status
                </span>

                <strong id="modalStatus">
                    —
                </strong>

            </div>


            <div class="detalhes-grid">

                <div>
                    <span>Morador</span>
                    <strong id="modalMorador">—</strong>
                </div>

                <div>
                    <span>CPF</span>
                    <strong id="modalCpf">—</strong>
                </div>

                <div>
                    <span>Telefone</span>
                    <strong id="modalTelefone">—</strong>
                </div>

                <div>
                    <span>Motorista</span>
                    <strong id="modalMotoristaDetalhes">—</strong>
                </div>

                <div>
                    <span>Data da coleta</span>
                    <strong id="modalData">—</strong>
                </div>

                <div>
                    <span>Horário</span>
                    <strong id="modalHora">—</strong>
                </div>

                <div class="full">
                    <span>Endereço</span>
                    <strong id="modalEndereco">—</strong>
                </div>

                <div class="full">
                    <span>Descrição</span>
                    <strong id="modalDescricao">—</strong>
                </div>

            </div>

        </div>


        <div class="modal-footer">

            <button
                type="button"
                class="btn-secondary"
                data-close-modal>

                Fechar

            </button>

        </div>

    </div>

</div>


<!-- =========================================================
     MODAL CADASTRAR MOTORISTA
========================================================= -->

<div
    class="modal"
    id="modalNovoMotorista"
    hidden>

    <div class="modal-box small">

        <div class="modal-header">
            <div>
                <span>Gerenciar motoristas</span>
                <h2>Cadastrar motorista</h2>
            </div>
            <button
                type="button"
                class="modal-close"
                data-close-modal>×</button>
        </div>

        <form method="POST" class="modal-form" id="formNovoMotorista">
            <input type="hidden" name="acao" value="cadastrar_motorista">

            <div class="campo">
                <label>Nome*</label>
                <input type="text" name="nome" required>
            </div>

            <div class="campo">
                <label>E-mail*</label>
                <input type="email" name="email" required>
            </div>

            <div class="campo">
                <label>Senha*</label>
                <input type="password" name="senha" minlength="6" required>
            </div>

            <div class="campo">
                <label>CNH*</label>
                <input type="text" name="cnh" maxlength="11" inputmode="numeric" required>
            </div>

            <div class="campo">
                <label>CPF*</label>
                <input type="text" name="cpf" maxlength="14" inputmode="numeric" required>
            </div>

            <div class="campo">
                <label>Telefone</label>
                <input type="text" name="telefone">
            </div>

            <div class="form-actions">
                <button type="button" class="btn-secondary" data-close-modal>Cancelar</button>
                <button type="submit" class="btn-primary">Cadastrar</button>
            </div>
        </form>

    </div>
</div>


<!-- =========================================================
     MODAL MOTORISTA
========================================================= -->

<div
    class="modal"
    id="modalMotorista"
    hidden>

    <div class="modal-box small">

        <div class="modal-header">

            <div>

                <span>
                    Gerenciar motorista
                </span>

                <h2>
                    Editar motorista
                </h2>

            </div>

            <button
                type="button"
                class="modal-close"
                data-close-modal>

                ×

            </button>

        </div>


        <form
            method="POST"
            class="modal-form">

            <input
                type="hidden"
                name="acao"
                value="editar_motorista">

            <input
                type="hidden"
                name="id"
                id="motoristaId">


            <div class="campo">

                <label>
                    Nome*
                </label>

                <input
                    type="text"
                    name="nome"
                    id="motoristaNome"
                    required>

            </div>


            <div class="campo">

                <label>
                    E-mail*
                </label>

                <input
                    type="email"
                    name="email"
                    id="motoristaEmail" readonly
                    required>

            </div>


            <div class="campo">

                <label>
                    CNH*
                </label>

                <input
                    type="text"
                    name="cnh"
                    id="motoristaCnh"
                    maxlength="11"
                    inputmode="numeric"
                    required>

            </div>


            <div class="campo">

                <label>
                    CPF*
                </label>

                <input
                    type="text"
                    name="cpf"
                    id="motoristaCpf"
                    required>

            </div>


            <div class="campo">

                <label>
                    Telefone
                </label>

                <input
                    type="text"
                    name="telefone"
                    id="motoristaTelefone">

            </div>


            <div class="campo">

                <label>
                    Nova senha
                    <span>deixe vazio para manter</span>
                </label>

                <input
                    type="password"
                    name="senha"
                    minlength="6">

            </div>


            <label class="check-label">

                <input
                    type="checkbox"
                    name="ativo"
                    id="motoristaAtivo">

                Motorista ativo

            </label>


            <div class="form-actions">

                <button
                    type="button"
                    class="btn-secondary"
                    data-close-modal>

                    Cancelar

                </button>

                <button
                    type="submit"
                    class="btn-primary">

                    Salvar

                </button>

            </div>

        </form>

    </div>

</div>


<!-- =========================================================
     MODAL CADASTRAR SECRETARIA
========================================================= -->

<div
    class="modal"
    id="modalNovaSecretaria"
    hidden>

    <div class="modal-box small">

        <div class="modal-header">

            <div>
                <span>Gerenciar secretarias</span>
                <h2>Cadastrar secretaria</h2>
            </div>

            <button
                type="button"
                class="modal-close"
                data-close-modal>
                ×
            </button>

        </div>

        <form
            method="POST"
            class="modal-form"
            id="formNovaSecretaria">

            <input
                type="hidden"
                name="acao"
                value="cadastrar_secretaria">

            <div class="campo">
                <label>Nome*</label>
                <input
                    type="text"
                    name="nome"
                    id="novaSecretariaNome"
                    required>
            </div>

            <div class="campo">
                <label>E-mail*</label>
                <input
                    type="email"
                    name="email"
                    id="novaSecretariaEmail"
                    required>
            </div>

            <div class="campo">
                <label>Senha*</label>
                <input
                    type="password"
                    name="senha"
                    id="novaSecretariaSenha"
                    minlength="6"
                    required>
            </div>

            <div class="form-actions">
                <button
                    type="button"
                    class="btn-secondary"
                    data-close-modal>
                    Cancelar
                </button>

                <button
                    type="submit"
                    class="btn-primary">
                    Cadastrar
                </button>
            </div>

        </form>

    </div>

</div>

<!-- =========================================================
     MODAL SECRETARIA
========================================================= -->

<div
    class="modal"
    id="modalSecretaria"
    hidden>

    <div class="modal-box small">

        <div class="modal-header">

            <div>

                <span>
                    Gerenciar Secretaria
                </span>

                <h2>
                    Editar Secretaria
                </h2>

            </div>

            <button
                type="button"
                class="modal-close"
                data-close-modal>

                ×

            </button>

        </div>


        <form
            method="POST"
            class="modal-form">

            <input
                type="hidden"
                name="acao"
                value="editar_secretaria">

            <input
                type="hidden"
                name="email_atual"
                id="secretariaEmailAtual">


            <div class="campo">

                <label>
                    Nome*
                </label>

                <input
                    type="text"
                    name="nome"
                    id="secretariaNome"
                    required>

            </div>


            <div class="campo">

                <label>
                    E-mail*
                </label>

                <input
                    type="email"
                    name="email"
                    id="secretariaEmail" readonly
                    required>

            </div>


            <div class="campo">

                <label>
                    Nova senha
                    <span>deixe vazio para manter</span>
                </label>

                <input
                    type="password"
                    name="senha">

            </div>

            <label class="check-label">

                <input
                    type="checkbox"
                    name="ativo"
                    id="secretariaAtivo">

                Secretaria ativa

            </label>


            <div class="form-actions">

                <button
                    type="button"
                    class="btn-secondary"
                    data-close-modal>

                    Cancelar

                </button>

                <button
                    type="submit"
                    class="btn-primary">

                    Salvar

                </button>

            </div>

        </form>

    </div>

</div>


<script src="administrador.js?v=20260929-historico-fix"></script>

</body>

</html>
