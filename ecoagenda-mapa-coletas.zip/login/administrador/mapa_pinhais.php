<?php
declare(strict_types=1);

session_start();
require_once "../../config.php";

if (
    !isset($_SESSION["email"]) ||
    !isset($_SESSION["perfil"]) ||
    $_SESSION["perfil"] !== "administrador"
) {
    http_response_code(403);
    exit("Acesso negado.");
}

if (empty($_SESSION['mapa_csrf'])) $_SESSION['mapa_csrf'] = bin2hex(random_bytes(32));
$mapaCSRF = $_SESSION['mapa_csrf'];
session_write_close();

$mes = isset($_GET["mes"]) ? (int)$_GET["mes"] : (int)date("n");
$ano = isset($_GET["ano"]) ? (int)$_GET["ano"] : (int)date("Y");
if ($mes < 1 || $mes > 12) $mes = (int)date("n");
if ($ano < 2020 || $ano > 2100) $ano = (int)date("Y");

$meses = [
    1 => "Janeiro", 2 => "Fevereiro", 3 => "Março", 4 => "Abril",
    5 => "Maio", 6 => "Junho", 7 => "Julho", 8 => "Agosto",
    9 => "Setembro", 10 => "Outubro", 11 => "Novembro", 12 => "Dezembro"
];

require_once __DIR__ . "/mapa_dados.php";
$bairros = BAIRROS_MAPA;
$modo = ($_GET["modo"] ?? "demanda") === "locais" ? "locais" : "demanda";

if (isset($_GET["dados"]) && $_GET["dados"] === "1") {
    header("Content-Type: application/json; charset=UTF-8");
    header("Cache-Control: no-store, no-cache, must-revalidate, max-age=0");
    echo json_encode(
        ($modo === "locais" ? buscarColetasMapa($conn, $mes, $ano) : buscarDadosMapa($conn, $mes, $ano, $bairros)),
        JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES
    );
    exit;
}

/* GeoJSON carregado pelo próprio PHP e entregue ao D3 no HTML.
 * Isso evita que o navegador tente abrir um arquivo .geojson por uma rota
 * que possa devolver uma página HTML/erro do servidor.
 */
$geoJsonPath = __DIR__ . DIRECTORY_SEPARATOR . "pinhais_bairros_wgs84.geojson";
$geoJsonRaw = is_file($geoJsonPath) ? file_get_contents($geoJsonPath) : false;
$geoJsonData = is_string($geoJsonRaw) ? json_decode($geoJsonRaw, true) : null;
if (!is_array($geoJsonData) || ($geoJsonData["type"] ?? null) !== "FeatureCollection") {
    $geoJsonData = ["type" => "FeatureCollection", "features" => []];
}
$geoJsonInline = json_encode(
    $geoJsonData,
    JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES | JSON_INVALID_UTF8_SUBSTITUTE | JSON_HEX_TAG | JSON_HEX_AMP | JSON_HEX_APOS | JSON_HEX_QUOT
);
if ($geoJsonInline === false) {
    $geoJsonInline = '{"type":"FeatureCollection","features":[]}';
}

// Dados iniciais dos pedidos já são enviados no HTML para que o mapa
// apareça sem depender de uma chamada AJAX no primeiro carregamento.
$dadosMapaInicial = $modo === "locais" ? buscarColetasMapa($conn, $mes, $ano) : buscarDadosMapa($conn, $mes, $ano, $bairros);
$dadosMapaInicialInline = json_encode(
    $dadosMapaInicial,
    JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES | JSON_INVALID_UTF8_SUBSTITUTE | JSON_HEX_TAG | JSON_HEX_AMP | JSON_HEX_APOS | JSON_HEX_QUOT
);
if ($dadosMapaInicialInline === false) {
    $dadosMapaInicialInline = '{"mes":' . (int)$mes . ',"ano":' . (int)$ano . ',"dados":{},"ranking":[],"total":0,"max":0,"atualizadoEm":""}';
}

?>
<!doctype html>
<html lang="pt-BR">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Mapa de coletas — EcoAgenda</title>
<link rel="stylesheet" href="vendor/leaflet/leaflet.css">
<link rel="stylesheet" href="mapa_pinhais.css?v=20261008-2">
<script defer src="vendor/leaflet/leaflet.js"></script>
<?php if ($modo === 'locais'): ?><link rel="stylesheet" href="vendor/markercluster/MarkerCluster.css"><script defer src="vendor/markercluster/leaflet.markercluster.js"></script><?php endif; ?>
<script defer src="mapa_pinhais.js?v=20261008-2"></script>
</head>
<body class="modo-<?= $modo ?>">
<div class="map-app">
    <header class="map-top">
        <div class="map-heading">
            <span class="map-eyebrow">DISTRIBUIÇÃO TERRITORIAL</span>
            <h2><?= $modo === "locais" ? "Locais das coletas realizadas" : "Demanda por bairro em Pinhais" ?></h2>
            <p><?= htmlspecialchars($meses[$mes], ENT_QUOTES, "UTF-8") ?> de <?= $ano ?> · <?= $modo === "locais" ? "coletas finalizadas no período" : "pedidos de coleta criados no período" ?></p>
        </div>
        <div class="map-total" id="mapTotal"><strong><?= (int)$dadosMapaInicial['total'] ?></strong><span><?= $modo === "locais" ? "coletas realizadas" : "pedidos no período" ?></span><small id="mapUpdated" role="status">Dados do período</small></div>
    </header>
    <div class="map-toolbar">
        <label class="map-search"><span class="sr-only">Pesquisar bairro</span><span aria-hidden="true">⌕</span><input type="search" id="bairroSearch" placeholder="<?= $modo === 'locais' ? 'Buscar endereço ou bairro' : 'Buscar bairro de Pinhais' ?>" autocomplete="off" aria-controls="rankingList"></label>
        <div class="map-controls" aria-label="Controles do mapa">
            <button type="button" id="zoomOut" aria-label="Diminuir zoom" title="Diminuir zoom">−</button>
            <output id="zoomLevel" aria-label="Nível de zoom">100%</output>
            <button type="button" id="zoomIn" aria-label="Aumentar zoom" title="Aumentar zoom">+</button>
            <button type="button" id="zoomHome" class="map-home" title="Ver todos os bairros">↺ <span>Pinhais</span></button>
        </div>
    </div>
    <main class="map-workspace">
        <section class="map-panel" aria-label="Mapa dos bairros">
            <div id="mapCanvas" tabindex="0" aria-label="Mapa interativo de Pinhais. Use os botões para ampliar e a lista para selecionar um bairro."></div>
            <div class="map-caption"><span class="map-dot"></span> <?= $modo === "locais" ? "Ruas e locais de coleta · use o scroll para ampliar" : "Limites dos bairros · use o scroll para ampliar" ?></div>
            <div id="mapState" class="map-state" role="status" hidden></div>
            <div class="map-legend" <?= $modo === "locais" ? "hidden" : "" ?>><span>Participação nos pedidos do período</span><div class="legend-gradient"></div><div class="legend-ticks"><span>0%</span><span id="legendMid">0%</span><span id="legendMax">0%</span></div></div>
            <p id="tileNotice" class="tile-notice" role="status" hidden>Fundo cartográfico indisponível. Os bairros e os pedidos continuam disponíveis.</p>
        </section>
        <aside class="map-sidebar">
            <div class="map-side-head"><span class="map-side-label"><?= $modo === "locais" ? "LOCAL SELECIONADO" : "BAIRRO SELECIONADO" ?></span><div class="map-selected"><h3 id="selectedName">Explore o mapa</h3><p id="selectedHint">Clique em um bairro ou use a busca.</p><div class="selected-line"><strong id="selectedTotal">—</strong><span><?= $modo === "locais" ? "coletas realizadas" : "pedidos no período" ?></span></div><span id="selectedShare" class="selected-share">—</span><button id="clearSelection" type="button" hidden>Limpar seleção ×</button></div></div>
            <div class="map-ranking"><div class="ranking-heading"><h3><?= $modo === "locais" ? "Locais de coleta" : "Onde mais há pedidos" ?></h3><span><?= $modo === "locais" ? "Um marcador por endereço · coletas agrupadas" : "Participação no período selecionado" ?></span></div><div id="rankingList"></div><p id="searchEmpty" hidden><?= $modo === "locais" ? "Nenhum local encontrado neste período ou nesta busca." : "Nenhum bairro encontrado. Tente outro nome." ?></p></div>
            <div class="map-footer"><?php if ($modo === "locais"): ?><button type="button" id="retryLocations" hidden>Tentar localizar endereços</button><?php endif; ?><p id="unmappedNotice" hidden></p><span>Limites: GeoPinhais · base 2012</span><span>Pedidos: EcoAgenda · atualização a cada minuto</span></div>
        </aside>
    </main>
</div>
<script>window.EcoAgendaMapa = {geojson: <?= $geoJsonInline ?>, data: <?= $dadosMapaInicialInline ?>, mes: <?= $mes ?>, ano: <?= $ano ?>, modo: <?= json_encode($modo) ?>, palette: <?= json_encode(CORES_MAPA) ?>, csrf: <?= json_encode($mapaCSRF) ?>};</script>
</body>
</html>
