# EcoAgenda — roteiro de capturas e texto para Resultados e Discussão

Este roteiro foi elaborado a partir dos arquivos do projeto ecoagendafinal.rar enviados em 21/10/2026. A conferência foi realizada no código das páginas e dos componentes JavaScript; não houve execução do sistema com o banco de dados local do usuário. Os parágrafos descrevem o comportamento implementado e devem ser associados às capturas e aos testes efetivamente realizados. Não representam comprovação de aprovação de todos os fluxos.

Os títulos 4, 4.1 e seguintes são uma sugestão de organização. Ajustar à numeração do TCC. Os identificadores F01, F02 etc. são referências de planejamento, não a numeração definitiva das figuras. Um item pode exigir duas ou três capturas. Os blocos “Texto para o TCC” são o conteúdo acadêmico; os demais blocos são instruções de produção e não precisam ser colados no trabalho.

## Como marcar e legendar as imagens

1. Usar retângulos sem preenchimento, com contorno verde-escuro de 2 a 3 px, e pequenos círculos numerados ao lado. Evitar cobrir o texto do botão.
2. Reiniciar a numeração em cada figura. O número da legenda deve corresponder ao retângulo realmente desenhado. As tabelas deste roteiro fornecem um inventário por função: quando dividir a captura, renumerar os itens em cada imagem.
3. Preferir até cinco ou seis marcações por captura. Para páginas extensas, usar duas figuras ou painéis (a) e (b). A lista completa de controles não deve ser comprimida em uma única imagem.
4. Marcar cada botão visível, inclusive Fechar, Cancelar e Voltar. O menu lateral pode ser explicado uma vez por perfil e referenciado nas figuras seguintes; não é necessário repetir todos os retângulos a cada captura.
5. Distinguir botão, campo, filtro e informação. Datas, quantidade de pedidos, status e etapas não são comandos de execução. Os selos de status podem exibir explicação ao passar o mouse, receber foco ou clicar; isso não muda a etapa do pedido.
6. Controles repetidos em vários cartões têm a mesma função: marcar um exemplo e informar que se aplica aos demais. Botões condicionais só recebem legenda na imagem em que aparecem.
7. Remover dados pessoais das imagens com tarjas sólidas ou utilizar dados de demonstração autorizados. Ocultar senhas, códigos válidos, e-mails pessoais, CPF e telefones. Preservar a legibilidade dos rótulos e o número do pedido usado na narrativa.
8. Acima da imagem, escrever “Figura X – [título da função]”. Abaixo, inserir “Fonte: Captura de tela do EcoAgenda, com marcações elaboradas pelos autores (2026).”. Depois, apresentar “Legenda: 1 – ...; 2 – ...”. Adequar ao manual da instituição e ao ano de apresentação.
9. Referenciar a figura no texto: “A Figura X apresenta ...”. Não deixar imagens sem explicação. Os parágrafos deste roteiro podem receber essa referência quando a numeração final estiver definida.
10. No Word/Google Docs, manter a figura e a fonte próximas. Não incluir a barra de favoritos e abas pessoais do navegador. Usar a mesma escala de captura para telas semelhantes.
11. Mensagens temporárias podem ter × para dispensar o aviso: esse botão fecha apenas a mensagem. Botões nativos de confirmação do navegador devem ser descritos como controles do navegador, caso apareçam, e não como parte do layout desenvolvido.
12. Imagens e balões cartográficos podem abrir outra aba ou janela. O × do balão fecha apenas a informação do ponto; o × da janela do mapa fecha a visualização inteira. Manter essa diferença nas legendas.

## Preparação e sequência da demonstração

Preparação: manter pelo menos uma conta de morador, uma da Secretaria, um motorista ativo e uma de administrador. Anotar os acessos fora do documento. Utilizar perfis de navegador separados para evitar que o login de um perfil substitua a sessão do outro.

Fluxo principal A: página inicial → cadastro e confirmação → login do morador → criação do pedido A → acompanhamento Em análise → conferência pela Secretaria → correção de endereço, se usada na demonstração → histórico → encaminhamento automático → motorista atribuído → A caminho → Em andamento → foto e conclusão → retorno do morador → consulta administrativa, relatório e mapas.

Fluxos alternativos: pedido B para suspensão pela Secretaria; pedido C para suspensão pelo motorista; pedido D para atendimento registrado pela Secretaria. Recuperação de senha e alterações de perfil devem ser capturadas separadamente. Não é necessário criar quatro registros se algumas demonstrações forem apenas formulários sem envio, mas indicar isso no texto e não alegar um resultado não executado.

Preparar as fotos e verificar os endereços de demonstração antes de capturar. Para os mapas, manter pedidos com localização disponível e usar o período correspondente às datas dos registros. Se não houver dados, registrar e explicar o estado vazio em vez de inserir dados fictícios em uma captura do sistema.

Registrar o ID do pedido A e reutilizá-lo nas figuras de todos os perfis. O calendário usa a data de emissão, não a data de execução. Capturar a correção de endereço antes de A caminho. Após a conclusão, o pedido deixa de integrar o mapa de coletas pendentes do motorista.

## 4 Resultados e discussão

### 4.1 Apresentação dos resultados

A apresentação dos resultados do EcoAgenda é organizada pelas funções disponibilizadas aos diferentes perfis de usuário. A sequência inicia-se na página pública e nos procedimentos de acesso, prossegue pelo registro e acompanhamento das solicitações pelo morador e apresenta as atividades de validação da Secretaria, execução do motorista e supervisão do administrador. Essa organização permite relacionar as interfaces às etapas do atendimento de uma solicitação de coleta.

As figuras apresentam as telas associadas a cada função, acompanhadas de marcações numeradas para identificar seus principais controles. O acompanhamento de um mesmo pedido ao longo das áreas permite compreender a continuidade do fluxo de informações. Os procedimentos de recuperação de acesso, manutenção cadastral e suspensão são apresentados separadamente, por constituírem operações complementares ou alternativas ao atendimento concluído.

## 4.2 Apresentação das telas por função

## 4.2.1 Página inicial e acesso

### F01 — Página inicial: apresentação e acesso

**Como acessar:** Abrir index.html, sem sessão autenticada.

**Captura sugerida:** Capturar o topo da página com o menu e a chamada principal. Em uma segunda captura, mostrar a área de apresentação e o botão Criar pedido.

**Texto para o TCC:** A página inicial apresenta a finalidade do EcoAgenda e organiza os acessos às funcionalidades públicas. O visitante pode consultar informações sobre o serviço, acessar o contato e iniciar o cadastro ou a autenticação. A opção de criação de pedido conduz o morador ao fluxo de solicitação; quando não há sessão autenticada, o sistema solicita o acesso à conta.

Figura X – Página inicial: apresentação e acesso

Fonte: Captura de tela do EcoAgenda, com marcações elaboradas pelos autores (2026).

**Legenda dos controles:**

| Marcador | Controle | Explicação |
|---|---|---|

| 1 | Logomarca | Retorna ao início da página. |

| 2 | Sobre | Desloca a página até a apresentação do serviço. |

| 3 | Contato | Desloca a página até a área de contato. |

| 4 | Cadastre-se | Abre o formulário de criação da conta do morador. |

| 5 | Entrar (menu) | Abre a autenticação. |

| 6 | Entrar (destaque principal) | Oferece outro acesso à mesma autenticação. |

| 7 | Criar pedido | Encaminha ao fluxo de solicitação, condicionado à autenticação e ao perfil de morador. |

| 8 | Abrir menu (celular) | Expande ou recolhe as opções de navegação em telas estreitas. |

**Orientação de produção:** Fotografar a versão pública. Com uma sessão ativa, podem aparecer Meus pedidos (abre a área do perfil autenticado) e Sair (encerra a sessão); se mostrar essa variação, acrescentar esses dois marcadores. Não desenhar botões ausentes do print.

### F02 — Contato com a Prefeitura

**Como acessar:** Página inicial → Contato.

**Captura sugerida:** Capturar o campo de nome, o botão de WhatsApp e, em uma segunda imagem se necessário, os links do rodapé.

**Texto para o TCC:** A área de contato disponibiliza o encaminhamento ao WhatsApp pelo número (41) 98707-5000. Após informar o nome, o visitante pode abrir uma conversa com uma mensagem previamente preenchida. O envio efetivo da mensagem é realizado pelo usuário no WhatsApp. Os links do rodapé permitem acessar os perfis institucionais nas redes sociais.

Figura X – Contato com a Prefeitura

Fonte: Captura de tela do EcoAgenda, com marcações elaboradas pelos autores (2026).

**Legenda dos controles:**

| Marcador | Controle | Explicação |
|---|---|---|

| 1 | Nome (campo) | Identifica o solicitante no texto preparado para o contato. |

| 2 | Enviar via WhatsApp | Abre a conversa com o número configurado e o texto preenchido. |

| 3 | Facebook | Abre o perfil institucional indicado no rodapé. |

| 4 | Instagram | Abre o perfil institucional indicado no rodapé. |

**Orientação de produção:** O número foi fornecido para este ajuste; não houve verificação externa de titularidade nem envio de mensagem. Para a figura do TCC, basta a página do sistema; o WhatsApp é um serviço externo.

### F03 — Cadastro: dados pessoais

**Como acessar:** Página inicial → Cadastre-se → primeira etapa.

**Captura sugerida:** Mostrar o formulário de identificação e as ações inferiores. Usar dados de demonstração e ocultar CPF, telefone e e-mail pessoais.

**Texto para o TCC:** O cadastro do morador inicia-se pelo preenchimento dos dados pessoais e das credenciais de acesso. O formulário reúne as informações necessárias à identificação da conta e realiza verificações antes do avanço. A consulta relacionada ao CPF auxilia a conferência cadastral, sem constituir, isoladamente, comprovação da identidade de quem preenche o formulário.

Figura X – Cadastro: dados pessoais

Fonte: Captura de tela do EcoAgenda, com marcações elaboradas pelos autores (2026).

**Legenda dos controles:**

| Marcador | Controle | Explicação |
|---|---|---|

| 1 | Olho da senha | Alterna a exibição da senha digitada. |

| 2 | Olho da confirmação | Alterna a exibição da confirmação da senha. |

| 3 | Continuar | Valida a etapa e permite avançar para o endereço. |

| 4 | Voltar | Retorna à página inicial. |

**Orientação de produção:** Não utilizar CPF inventado para demonstrar aprovação da API. Utilizar uma conta de teste autorizada e anonimizar a captura. Não afirmar que o CPF é validado diretamente pela Receita Federal.

### F04 — Cadastro: endereço

**Como acessar:** Cadastro → segunda etapa.

**Captura sugerida:** Capturar endereço após a consulta de um CEP e antes de avançar; destacar CEP, número e os botões.

**Texto para o TCC:** Na segunda etapa, o morador informa o endereço associado à conta. A consulta ao ViaCEP auxilia o preenchimento dos dados disponíveis para o CEP, enquanto o número do imóvel e o complemento são informados pelo usuário. Essa organização reduz a repetição de dados e permite conferir o endereço antes de prosseguir.

Figura X – Cadastro: endereço

Fonte: Captura de tela do EcoAgenda, com marcações elaboradas pelos autores (2026).

**Legenda dos controles:**

| Marcador | Controle | Explicação |
|---|---|---|

| 1 | CEP (campo) | Inicia a consulta de endereço durante o preenchimento. |

| 2 | Número e complemento (campos) | Permitem detalhar a localização do imóvel. |

| 3 | Continuar | Prossegue para a confirmação por e-mail, após as verificações do cadastro. |

| 4 | Voltar | Retorna aos dados pessoais para conferência. |

### F05 — Cadastro: confirmação de e-mail

**Como acessar:** Cadastro → etapa Verifique seu e-mail.

**Captura sugerida:** Capturar os campos do código e os controles de reenvio e conclusão, sem um código válido visível.

**Texto para o TCC:** A confirmação de e-mail complementa o cadastro por meio de um código enviado ao endereço informado. O usuário insere o código recebido para concluir a criação da conta. O mecanismo verifica o acesso à caixa de e-mail indicada e disponibiliza uma opção de reenvio quando necessário.

Figura X – Cadastro: confirmação de e-mail

Fonte: Captura de tela do EcoAgenda, com marcações elaboradas pelos autores (2026).

**Legenda dos controles:**

| Marcador | Controle | Explicação |
|---|---|---|

| 1 | Código (campos) | Recebe os dígitos enviados por e-mail. |

| 2 | Envie novamente | Solicita o reenvio do código de confirmação. |

| 3 | Voltar | Retorna à etapa anterior do cadastro. |

| 4 | Finalizar Cadastro | Submete os dados e a confirmação para concluir o cadastro. |

**Orientação de produção:** Consultar o e-mail no mesmo navegador de trabalho e usar o código mais recente. A figura pode mostrar campos vazios.

### F06 — Autenticação e direcionamento por perfil

**Como acessar:** Página inicial → Entrar.

**Captura sugerida:** Capturar o formulário completo, com a senha oculta.

**Texto para o TCC:** A autenticação permite o acesso às áreas restritas do EcoAgenda por e-mail ou CPF e senha. Após a verificação das credenciais, o sistema direciona o usuário à área correspondente ao seu perfil. Essa separação organiza as funcionalidades disponíveis para morador, Secretaria, motorista e administrador.

Figura X – Autenticação e direcionamento por perfil

Fonte: Captura de tela do EcoAgenda, com marcações elaboradas pelos autores (2026).

**Legenda dos controles:**

| Marcador | Controle | Explicação |
|---|---|---|

| 1 | E-mail ou CPF (campo) | Recebe o identificador da conta. |

| 2 | Olho da senha | Exibe ou oculta o conteúdo digitado. |

| 3 | Entrar | Envia as credenciais para autenticação. |

| 4 | Esqueci minha senha | Abre a recuperação de acesso. |

| 5 | Voltar à página inicial | Retorna à página pública. |

### F07 — Recuperação: solicitação de código

**Como acessar:** Login → Esqueci minha senha.

**Captura sugerida:** Capturar o formulário e, em outra figura, a mensagem apresentada após uma solicitação bem-sucedida.

**Texto para o TCC:** A recuperação de acesso permite solicitar um código para o e-mail associado à conta. Após o processamento da solicitação, o usuário pode seguir para a etapa de definição de uma nova senha. O procedimento oferece uma alternativa para recuperar o acesso sem a criação de outro cadastro.

Figura X – Recuperação: solicitação de código

Fonte: Captura de tela do EcoAgenda, com marcações elaboradas pelos autores (2026).

**Legenda dos controles:**

| Marcador | Controle | Explicação |
|---|---|---|

| 1 | E-mail (campo) | Informa o endereço associado à conta. |

| 2 | Continuar | Solicita o envio do código de recuperação. |

| 3 | Voltar para o login | Retorna à autenticação. |

| 4 | Informar código (após envio) | Abre a etapa de redefinição. |

| 5 | Voltar (página de resposta, quando exibido) | Retorna à solicitação de recuperação. |

**Orientação de produção:** Os controles das páginas de formulário e de resposta devem ser numerados em suas respectivas figuras. Não reunir em uma mesma imagem botões que aparecem em momentos diferentes.

### F08 — Recuperação: definição da nova senha

**Como acessar:** Após solicitar o código → Informar código.

**Captura sugerida:** Mostrar código, nova senha, confirmação e ações, com dados sensíveis ocultos.

**Texto para o TCC:** A redefinição da senha depende da conferência do código enviado por e-mail e do preenchimento da nova senha com sua confirmação. O código possui prazo de validade, e o procedimento deve ser concluído no contexto da sessão em que foi solicitado. Após a alteração, o acesso à conta passa a utilizar a nova credencial.

Figura X – Recuperação: definição da nova senha

Fonte: Captura de tela do EcoAgenda, com marcações elaboradas pelos autores (2026).

**Legenda dos controles:**

| Marcador | Controle | Explicação |
|---|---|---|

| 1 | Código (campo) | Recebe o código de recuperação. |

| 2 | Nova senha e confirmação (campos) | Definem a nova credencial. |

| 3 | Alterar senha | Submete o código e a nova senha para validação e gravação. |

| 4 | Voltar para o login | Retorna à autenticação. |

**Orientação de produção:** Prazo definido no código analisado: 15 minutos. Uma nova solicitação pode substituir o código anterior. Não mostrar o código real nem alegar sucesso antes de efetuar o teste.

## 4.2.2 Área do morador

### F09 — Painel inicial do morador

**Como acessar:** Entrar com o perfil de morador → Dashboard.

**Captura sugerida:** Capturar o resumo e os pedidos recentes. Produzir uma imagem complementar com uma conta sem pedidos, se desejar explicar o estado inicial.

**Texto para o TCC:** O painel do morador reúne indicadores e solicitações recentes, permitindo acompanhar a situação dos pedidos vinculados à conta. Os atalhos conduzem à criação de uma solicitação, à listagem de acompanhamento e à manutenção dos dados cadastrais. Quando não há pedidos, a interface apresenta uma orientação para iniciar a primeira solicitação.

Figura X – Painel inicial do morador

Fonte: Captura de tela do EcoAgenda, com marcações elaboradas pelos autores (2026).

**Legenda dos controles:**

| Marcador | Controle | Explicação |
|---|---|---|

| 1 | Dashboard | Abre o resumo da conta. |

| 2 | Novo Pedido (menu) | Abre o formulário de solicitação. |

| 3 | Acompanhar | Abre a listagem dos pedidos do morador. |

| 4 | Perfil | Abre as opções de dados pessoais, endereço e senha. |

| 5 | Sair | Encerra a sessão. |

| 6 | Indicadores de status | Abrem a relação correspondente ao indicador selecionado. |

| 7 | Ver todos | Abre a listagem de acompanhamento. |

| 8 | Ver detalhes | Abre as informações do pedido escolhido. |

| 9 | Novo Pedido (estado vazio) | Inicia a primeira solicitação. |

**Orientação de produção:** Nos indicadores, identificar separadamente Total de pedidos, Em análise, Agendados, A caminho, Em andamento, Concluídos e Suspensos quando visíveis. Os indicadores são clicáveis; os selos de status dentro dos pedidos são apenas informativos.

### F10 — Criação de pedido: material e endereço

**Como acessar:** Morador → Novo Pedido.

**Captura sugerida:** Primeira figura: material, quantidade e escolha de endereço. Segunda: endereço alternativo expandido.

**Texto para o TCC:** A solicitação de coleta é registrada pelo morador com a identificação do material, a quantidade aproximada e a localização. O formulário permite reutilizar o endereço cadastrado ou informar outro local para a coleta. A descrição complementa os dados estruturados e fornece informações para a análise e o atendimento.

Figura X – Criação de pedido: material e endereço

Fonte: Captura de tela do EcoAgenda, com marcações elaboradas pelos autores (2026).

**Legenda dos controles:**

| Marcador | Controle | Explicação |
|---|---|---|

| 1 | Material (campo) | Identifica o resíduo a ser recolhido. |

| 2 | Quantidade aproximada (seleção) | Indica a estimativa em carrinhos de mão. |

| 3 | Sim, usar este endereço | Utiliza o endereço apresentado a partir do cadastro. |

| 4 | Não, informar outro | Exibe os campos de outro endereço de coleta. |

| 5 | CEP (endereço alternativo) | Auxilia o preenchimento pela consulta de endereço. |

| 6 | Descrição (campo) | Registra as informações complementares do pedido. |

**Orientação de produção:** Quantidade: opções de 1 a 3, 4 a 8, 9 a 12 e 13 a 15 carrinhos de mão. Quando o endereço cadastrado não é de Pinhais, o controle pode aparecer como Informar endereço de Pinhais; explicar essa variação somente se capturada.

### F11 — Criação de pedido: fotografia e envio

**Como acessar:** Continuar no formulário de Novo Pedido, na parte inferior.

**Captura sugerida:** Mostrar a foto de demonstração, sua prévia e as ações finais. Após enviar, capturar o pedido criado na listagem.

**Texto para o TCC:** A fotografia complementa a descrição do material e auxilia a análise da solicitação. Após conferir os dados, o morador envia o pedido, que passa a ser identificado por um número e disponibilizado para acompanhamento. O registro inicial integra o fluxo de análise da Secretaria.

Figura X – Criação de pedido: fotografia e envio

Fonte: Captura de tela do EcoAgenda, com marcações elaboradas pelos autores (2026).

**Legenda dos controles:**

| Marcador | Controle | Explicação |
|---|---|---|

| 1 | Área de fotografia / Escolher arquivo | Permite selecionar uma imagem do material. |

| 2 | Remover foto | Retira a imagem selecionada antes do envio. |

| 3 | Voltar | Retorna à navegação anterior do morador. |

| 4 | Enviar pedido | Submete a solicitação para registro. |

**Orientação de produção:** O texto do seletor de arquivo pode variar conforme o navegador. Não inventar um botão de confirmação após o envio: o JavaScript apresenta uma mensagem e redireciona automaticamente. Registrar o número do pedido para reutilizá-lo nas próximas figuras.

### F12 — Acompanhamento de pedidos

**Como acessar:** Morador → Acompanhar.

**Captura sugerida:** Mostrar um pedido de demonstração, os dois filtros e o botão de detalhes.

**Texto para o TCC:** A tela de acompanhamento apresenta as solicitações do morador com informações resumidas sobre local, material, status e prazo. Os filtros permitem restringir a listagem por etapa de atendimento e situação do prazo. A consulta detalhada preserva o vínculo entre a solicitação e suas informações de execução.

Figura X – Acompanhamento de pedidos

Fonte: Captura de tela do EcoAgenda, com marcações elaboradas pelos autores (2026).

**Legenda dos controles:**

| Marcador | Controle | Explicação |
|---|---|---|

| 1 | Status dos pedidos (seleção) | Filtra a listagem pela etapa de atendimento. |

| 2 | Prazo dos pedidos (seleção) | Filtra por todos os prazos, dentro do prazo ou prazo vencido. |

| 3 | Ver detalhes | Abre os dados completos da solicitação. |

| 4 | Novo Pedido (quando não há pedidos) | Abre o formulário de solicitação. |

**Orientação de produção:** Os controles do menu lateral seguem a legenda do painel do morador. A seleção de um filtro não altera o status do pedido.

### F13 — Detalhes e evolução da solicitação

**Como acessar:** Acompanhar → Ver detalhes.

**Captura sugerida:** Capturar a parte superior com as etapas; depois, a parte inferior com fotos e informações complementares.

**Texto para o TCC:** Os detalhes da solicitação apresentam a data do pedido, o prazo e a etapa atual do atendimento, acompanhados de uma explicação do status. O morador pode consultar o endereço, o material e os registros visuais disponíveis. A sequência de etapas permite compreender a evolução da solicitação, desde a análise até a conclusão, sem permitir ao morador modificar os status de execução.

Figura X – Detalhes e evolução da solicitação

Fonte: Captura de tela do EcoAgenda, com marcações elaboradas pelos autores (2026).

**Legenda dos controles:**

| Marcador | Controle | Explicação |
|---|---|---|

| 1 | Editar endereço (quando disponível) | Abre a correção exclusiva do local de coleta. |

| 2 | Fotografia / Abrir foto (quando disponível) | Permite consultar o registro visual. |

| 3 | × | Fecha a janela de detalhes. |

| 4 | Fechar | Retorna à listagem. |

**Orientação de produção:** As etapas Em análise, Agendado, A caminho, Em andamento e Concluído são informações de progresso, não botões de mudança de status. Pedidos suspensos devem ser apresentados como um caso alternativo.

### F14 — Correção do endereço da coleta

**Como acessar:** Pedido em análise ou agendado → Editar endereço.

**Captura sugerida:** Capturar a janela de correção e, em outra imagem, a orientação do botão ao receber foco ou passar o mouse.

**Texto para o TCC:** A correção do endereço permite ajustar o local informado incorretamente sem alterar as demais características do pedido. Essa ação fica disponível ao morador e à Secretaria somente antes de a coleta atingir o status A caminho. A alteração é registrada no histórico, permitindo acompanhar a correção efetuada.

Figura X – Correção do endereço da coleta

Fonte: Captura de tela do EcoAgenda, com marcações elaboradas pelos autores (2026).

**Legenda dos controles:**

| Marcador | Controle | Explicação |
|---|---|---|

| 1 | CEP e demais campos de endereço | Permitem conferir e corrigir o local da coleta. |

| 2 | Salvar endereço | Grava a correção permitida e seu registro no histórico. |

| 3 | Fechar × | Fecha a janela de edição. |

| 4 | Voltar ao pedido (após sucesso) | Retorna à consulta da solicitação. |

**Orientação de produção:** Após a passagem para A caminho, fazer uma captura complementar dos detalhes sem a opção de edição. Não confundir esta correção com a alteração do endereço do perfil. Confirmar visualmente o resultado antes de fechar a janela.

### F15 — Perfil: alteração dos dados pessoais

**Como acessar:** Morador → Perfil → Geral.

**Captura sugerida:** Mostrar as abas e as ações do formulário; capturar separadamente a confirmação por código.

**Texto para o TCC:** O perfil reúne as opções de manutenção dos dados associados à conta. Na aba Geral, o morador pode solicitar a alteração das informações pessoais disponíveis no formulário. A confirmação por código de e-mail acrescenta uma etapa de verificação antes da efetivação das mudanças.

Figura X – Perfil: alteração dos dados pessoais

Fonte: Captura de tela do EcoAgenda, com marcações elaboradas pelos autores (2026).

**Legenda dos controles:**

| Marcador | Controle | Explicação |
|---|---|---|

| 1 | Geral | Exibe os dados pessoais. |

| 2 | Endereço | Abre a manutenção do endereço cadastral. |

| 3 | Senha | Abre a alteração da credencial. |

| 4 | Voltar (formulário inicial) | Retorna ao painel. |

| 5 | Alterar dados | Solicita a confirmação das alterações. |

| 6 | Confirmar alterações (etapa do código) | Confirma os dados após a conferência do código. |

| 7 | Enviar outro código | Solicita um novo código. |

| 8 | Voltar (etapa do código) | Retorna ao formulário e cancela a confirmação pendente. |

**Orientação de produção:** Não expor códigos, CPF, e-mail ou telefone reais. Na figura da confirmação, reiniciar a numeração dos marcadores.

### F16 — Perfil: endereço cadastral

**Como acessar:** Perfil → Endereço.

**Captura sugerida:** Mostrar os campos de endereço e os controles inferiores.

**Texto para o TCC:** A aba Endereço permite manter a localização associada ao cadastro do morador. Os dados podem ser utilizados como referência no preenchimento de novas solicitações. A manutenção cadastral deve ser distinguida da correção de um pedido já registrado, que possui ação própria e restrição conforme o status da coleta.

Figura X – Perfil: endereço cadastral

Fonte: Captura de tela do EcoAgenda, com marcações elaboradas pelos autores (2026).

**Legenda dos controles:**

| Marcador | Controle | Explicação |
|---|---|---|

| 1 | Geral / Endereço / Senha | Alternam as categorias do perfil. |

| 2 | CEP (campo) | Auxilia a consulta e o preenchimento do endereço. |

| 3 | Salvar endereço | Grava o endereço cadastral informado. |

| 4 | Voltar | Retorna ao painel do morador. |

### F17 — Perfil: alteração de senha

**Como acessar:** Perfil → Senha.

**Captura sugerida:** Capturar a etapa inicial e a confirmação por código em figuras separadas.

**Texto para o TCC:** A alteração de senha dentro do perfil permite ao morador atualizar sua credencial mediante verificação por e-mail. O procedimento apresenta uma etapa de solicitação do código e outra de confirmação da mudança. Essa função diferencia-se da recuperação de acesso por ser iniciada em uma sessão autenticada.

Figura X – Perfil: alteração de senha

Fonte: Captura de tela do EcoAgenda, com marcações elaboradas pelos autores (2026).

**Legenda dos controles:**

| Marcador | Controle | Explicação |
|---|---|---|

| 1 | Geral / Endereço / Senha | Alternam as categorias do perfil. |

| 2 | Enviar código por e-mail | Solicita o código de confirmação da alteração. |

| 3 | Confirmar e alterar senha | Valida o código e efetiva a nova senha. |

| 4 | Enviar outro código | Solicita o reenvio. |

| 5 | Voltar (etapa inicial) | Retorna ao painel. |

| 6 | Voltar (etapa de confirmação) | Retorna à etapa inicial da alteração de senha. |

## 4.2.3 Área da Secretaria

### F18 — Painel da Secretaria e triagem

**Como acessar:** Entrar com perfil de Secretaria → Dashboard.

**Captura sugerida:** Mostrar indicadores, pedidos aguardando validação e um pedido recente.

**Texto para o TCC:** A área da Secretaria organiza o atendimento das solicitações e a etapa de validação. O painel reúne indicadores e pedidos que aguardam análise, permitindo acessar os detalhes necessários à conferência. A partir desse ponto, a equipe pode consultar solicitações, corrigir endereços permitidos e encaminhar o atendimento aos motoristas.

Figura X – Painel da Secretaria e triagem

Fonte: Captura de tela do EcoAgenda, com marcações elaboradas pelos autores (2026).

**Legenda dos controles:**

| Marcador | Controle | Explicação |
|---|---|---|

| 1 | Dashboard | Abre o resumo do atendimento. |

| 2 | Pedidos | Exibe as solicitações. |

| 3 | Buscar pedido | Abre a consulta por CPF ou identificador. |

| 4 | Novo Pedido | Abre o registro realizado pela Secretaria. |

| 5 | Sair | Encerra a sessão. |

| 6 | Indicadores de status | Abrem a listagem correspondente à situação selecionada. |

| 7 | Ver pedidos | Abre a relação de solicitações. |

| 8 | Ver detalhes | Abre a consulta do pedido escolhido. |

**Orientação de produção:** Identificar os indicadores individualmente conforme a figura: Total, Em análise, Agendados, A caminho, Em andamento, Concluídos e Suspensos. Não afirmar que são indicadores de desempenho medido em testes.

### F19 — Consulta e análise de um pedido

**Como acessar:** Secretaria → Pedidos → Ver detalhes.

**Captura sugerida:** Primeira captura: listagem e filtros. Segunda: detalhes com a barra de ações visível.

**Texto para o TCC:** A consulta de pedidos disponibiliza os dados necessários à análise do atendimento, incluindo a identificação do morador, o local, a descrição e os registros apresentados. As ações disponíveis dependem da situação da solicitação. Essa organização permite consultar o histórico e executar as operações pertinentes à etapa atual.

Figura X – Consulta e análise de um pedido

Fonte: Captura de tela do EcoAgenda, com marcações elaboradas pelos autores (2026).

**Legenda dos controles:**

| Marcador | Controle | Explicação |
|---|---|---|

| 1 | Status dos pedidos | Filtra a listagem por status. |

| 2 | Prazo dos pedidos | Restringe os registros pela situação do prazo. |

| 3 | Ver detalhes | Abre as informações do pedido. |

| 4 | Mostrar histórico | Apresenta os registros de alteração. |

| 5 | Editar endereço | Permite corrigir o endereço antes de A caminho. |

| 6 | Encaminhar | Abre a confirmação da validação e distribuição ao motorista. |

| 7 | Suspender | Abre a confirmação de suspensão, quando permitida. |

| 8 | × | Fecha a janela de detalhes. |

| 9 | Fechar | Retorna à listagem. |

**Orientação de produção:** Nem todas as ações aparecem em todos os status. Usar um pedido em análise para apresentar a triagem; não incluir o antigo formulário de edição geral que não integra o fluxo atual. A fotografia, quando clicável, abre o registro visual.

### F20 — Histórico e rastreabilidade

**Como acessar:** Secretaria → detalhes → Mostrar histórico.

**Captura sugerida:** Capturar um registro após corrigir o endereço do pedido de demonstração. Se necessário, capturar registros adicionais em outra figura.

**Texto para o TCC:** O histórico permite consultar as alterações registradas para a solicitação. Os registros apresentam informações temporais, a ação e os dados disponíveis sobre sua realização, possibilitando acompanhar mudanças no atendimento. A consulta contribui para a rastreabilidade do pedido e para a conferência de correções, como a alteração do endereço de coleta.

Figura X – Histórico e rastreabilidade

Fonte: Captura de tela do EcoAgenda, com marcações elaboradas pelos autores (2026).

**Legenda dos controles:**

| Marcador | Controle | Explicação |
|---|---|---|

| 1 | Abrir foto (quando disponível) | Abre a imagem vinculada ao registro. |

| 2 | × | Fecha a janela do histórico. |

| 3 | Fechar | Retorna à consulta anterior. |

**Orientação de produção:** Data, comando, responsável, status e descrição são informações, não botões. Não interpretar UPDATE como “coleta concluída”: é a operação registrada. Descrever o conteúdo realmente mostrado; o histórico não deve ser apresentado como auditoria de toda ação possível do sistema.

### F21 — Encaminhamento automático ao motorista

**Como acessar:** Pedido em análise → Encaminhar. Deve existir motorista ativo.

**Captura sugerida:** Mostrar a janela com a explicação da distribuição. Depois, registrar a confirmação e o pedido agendado.

**Texto para o TCC:** Após conferir a solicitação, a Secretaria confirma a validação e o encaminhamento. A distribuição é realizada automaticamente entre os motoristas ativos, considerando as coletas pendentes e o prazo de atendimento. O pedido passa a integrar as atividades do profissional atribuído, permitindo a continuidade do fluxo operacional.

Figura X – Encaminhamento automático ao motorista

Fonte: Captura de tela do EcoAgenda, com marcações elaboradas pelos autores (2026).

**Legenda dos controles:**

| Marcador | Controle | Explicação |
|---|---|---|

| 1 | Validar e agendar | Confirma a validação e executa a distribuição automática. |

| 2 | Cancelar | Fecha a confirmação sem encaminhar. |

| 3 | × | Fecha a janela. |

| 4 | OK (mensagem de sucesso) | Fecha a notificação de encaminhamento. |

**Orientação de produção:** Não inserir um marcador de seleção manual de motorista: essa escolha não existe no fluxo analisado. Sem motoristas ativos, a confirmação fica indisponível. “Agendado” não significa que a Secretaria escolheu data e horário específicos; a interface trabalha com prazo.

### F22 — Busca por CPF ou número do pedido

**Como acessar:** Secretaria → Buscar pedido.

**Captura sugerida:** Capturar a escolha do tipo de busca e o resultado usando o ID do pedido de demonstração.

**Texto para o TCC:** A busca permite localizar solicitações por CPF do morador ou pelo identificador do pedido. A consulta por CPF apoia o atendimento relacionado a um usuário, enquanto a busca pelo identificador permite acessar uma solicitação específica. Os resultados preservam o acesso aos detalhes e às ações disponíveis para cada situação.

Figura X – Busca por CPF ou número do pedido

Fonte: Captura de tela do EcoAgenda, com marcações elaboradas pelos autores (2026).

**Legenda dos controles:**

| Marcador | Controle | Explicação |
|---|---|---|

| 1 | Buscar por CPF | Seleciona a consulta vinculada ao CPF. |

| 2 | Buscar por ID | Seleciona a consulta pelo número do pedido. |

| 3 | Campo de busca | Recebe o identificador correspondente ao modo selecionado. |

| 4 | Buscar | Executa a consulta. |

| 5 | Ver detalhes (resultado) | Abre a solicitação encontrada. |

**Orientação de produção:** Se as ações de histórico, endereço, encaminhamento ou suspensão aparecerem no resultado/detalhes, usar as mesmas explicações da consulta de pedidos, numeradas na própria figura.

### F23 — Registro de solicitação pelo atendimento

**Como acessar:** Secretaria → Novo Pedido.

**Captura sugerida:** Dividir a captura entre identificação do morador e endereço/descrição/ações.

**Texto para o TCC:** A Secretaria pode registrar uma solicitação durante o atendimento ao morador, incluindo demandas recebidas por outros canais. O formulário reúne identificação, contato, endereço e descrição do resíduo. Dessa forma, o pedido passa a integrar o acompanhamento do sistema mesmo quando o registro não é realizado diretamente pelo morador na interface pública.

Figura X – Registro de solicitação pelo atendimento

Fonte: Captura de tela do EcoAgenda, com marcações elaboradas pelos autores (2026).

**Legenda dos controles:**

| Marcador | Controle | Explicação |
|---|---|---|

| 1 | CPF do morador (campo) | Identifica o morador relacionado à solicitação. |

| 2 | CEP (campo) | Auxilia o preenchimento do local de coleta. |

| 3 | Limpar | Restaura os campos do formulário. |

| 4 | Criar pedido | Submete o registro realizado pela Secretaria. |

**Orientação de produção:** O formulário desta versão possui descrição livre do resíduo; não atribuir a ele os mesmos controles de quantidade e foto do formulário do morador. Para uma demonstração mais simples, utilizar um morador de teste já cadastrado.

### F24 — Suspensão pela Secretaria: fluxo alternativo

**Como acessar:** Em um segundo pedido que permita a ação → Suspender.

**Captura sugerida:** Capturar a janela de motivo antes da confirmação; depois, o status Suspenso.

**Texto para o TCC:** A suspensão constitui um fluxo alternativo ao encaminhamento normal da solicitação. A Secretaria informa o motivo e confirma a interrupção do atendimento, permitindo que a situação fique registrada no sistema. O procedimento exige atenção ao pedido selecionado e a comunicação do motivo ao morador.

Figura X – Suspensão pela Secretaria: fluxo alternativo

Fonte: Captura de tela do EcoAgenda, com marcações elaboradas pelos autores (2026).

**Legenda dos controles:**

| Marcador | Controle | Explicação |
|---|---|---|

| 1 | Motivo da suspensão | Registra a justificativa, limitada a 225 caracteres. |

| 2 | Voltar | Fecha a confirmação sem suspender. |

| 3 | Confirmar suspensão | Efetiva a suspensão com a justificativa. |

**Orientação de produção:** Usar outro pedido para não interromper a narrativa principal. Nesta janela da Secretaria não há campo de foto; não confundir com a suspensão realizada pelo motorista.

## 4.2.4 Área do motorista

### F25 — Painel e calendário de emissão

**Como acessar:** Entrar com o motorista atribuído ao pedido → Dashboard.

**Captura sugerida:** Mostrar o calendário e, em uma segunda captura, a janela de um dia com pedidos.

**Texto para o TCC:** O painel do motorista organiza as solicitações atribuídas ao profissional. O calendário permite consultar os pedidos por data de emissão, oferecendo uma visão temporal dos registros. A seleção de um dia abre a relação correspondente, da qual é possível acessar os detalhes necessários ao atendimento.

Figura X – Painel e calendário de emissão

Fonte: Captura de tela do EcoAgenda, com marcações elaboradas pelos autores (2026).

**Legenda dos controles:**

| Marcador | Controle | Explicação |
|---|---|---|

| 1 | Dashboard | Abre o painel do motorista. |

| 2 | Minhas coletas | Abre a listagem das coletas atribuídas. |

| 3 | Meu perfil | Exibe os dados cadastrais do profissional. |

| 4 | Sair | Encerra a sessão. |

| 5 | ‹ | Exibe a semana anterior. |

| 6 | Esta semana | Retorna à semana atual. |

| 7 | › | Exibe a próxima semana. |

| 8 | Dia do calendário | Abre os pedidos emitidos naquela data. |

| 9 | Pedido na janela do dia | Abre os detalhes da solicitação. |

| 10 | Fechar × | Fecha a janela dos pedidos do dia. |

| 11 | Ver semana do pedido mais urgente (quando exibido) | Leva à semana correspondente ao pedido indicado. |

**Orientação de produção:** O calendário não representa horários de coleta nem comprova que a execução ocorrerá no dia da emissão. Se mostrar um dia vazio, explicar a ausência de registros nessa data.

### F26 — Coletas atribuídas e detalhes

**Como acessar:** Motorista → Minhas coletas → Ver detalhes.

**Captura sugerida:** Capturar filtros e um pedido Agendado; em outra figura, os detalhes.

**Texto para o TCC:** A listagem de coletas apresenta as solicitações atribuídas ao motorista, com local, material, status e informações de prazo. Os filtros auxiliam a consulta dos atendimentos, enquanto os detalhes reúnem as informações operacionais e os dados do morador. As ações de execução são disponibilizadas conforme a etapa do pedido.

Figura X – Coletas atribuídas e detalhes

Fonte: Captura de tela do EcoAgenda, com marcações elaboradas pelos autores (2026).

**Legenda dos controles:**

| Marcador | Controle | Explicação |
|---|---|---|

| 1 | Status dos pedidos | Filtra as coletas por status. |

| 2 | Prazo dos pedidos | Filtra pela situação do prazo. |

| 3 | Visualizar mapa | Abre a localização das coletas disponíveis no mapa. |

| 4 | Ver detalhes | Exibe os dados completos do pedido. |

| 5 | Ir até o local | Registra o início do deslocamento e muda o status para A caminho. |

| 6 | Iniciar coleta | Registra o início da execução e muda o status para Em andamento. |

| 7 | Concluir coleta | Abre o registro de conclusão com fotografia. |

| 8 | Suspender coleta | Abre o registro de impedimento do atendimento. |

| 9 | × / Fechar (detalhes) | Encerram a consulta dos detalhes. |

**Orientação de produção:** Não apresentar todas as ações como simultaneamente disponíveis: capturar Agendado, A caminho e Em andamento em momentos diferentes. Usar as seções seguintes para mostrar cada transição.

### F27 — Mapa de apoio à localização

**Como acessar:** Minhas coletas → Visualizar mapa.

**Captura sugerida:** Mostrar a busca, os botões superiores, a lista lateral e um marcador selecionado. Usar outra captura para a opção de tentar novamente, se surgir naturalmente.

**Texto para o TCC:** O mapa do motorista apresenta as coletas atribuídas ao profissional, exceto as concluídas, e permite relacionar os pedidos aos locais disponíveis. A busca e a seleção na lista auxiliam a identificação de uma solicitação. O recurso oferece apoio à localização, cabendo ao motorista decidir o percurso; não corresponde a rastreamento ao vivo nem à geração automática de uma rota.

Figura X – Mapa de apoio à localização

Fonte: Captura de tela do EcoAgenda, com marcações elaboradas pelos autores (2026).

**Legenda dos controles:**

| Marcador | Controle | Explicação |
|---|---|---|

| 1 | Buscar coleta | Filtra por pedido, endereço ou material. |

| 2 | Ver todos os locais | Ajusta o enquadramento aos locais disponíveis. |

| 3 | Atualizar | Solicita novamente os dados das coletas. |

| 4 | + | Aproxima a visualização do mapa. |

| 5 | − | Afasta a visualização do mapa. |

| 6 | Pedido na lista lateral | Seleciona o marcador correspondente, quando localizado. |

| 7 | Marcador | Abre as informações do pedido. |

| 8 | Agrupamento de marcadores | Permite explorar locais próximos ao ampliar a área. |

| 9 | × do balão | Fecha as informações do marcador. |

| 10 | Tentar localizar novamente (condicional) | Repete a tentativa de geocodificação dos endereços pendentes. |

| 11 | × da janela | Fecha o mapa e retorna à listagem. |

**Orientação de produção:** Localização aproximada da rua não garante precisão no número do imóvel. Manter os créditos cartográficos visíveis; eles são links externos de atribuição, não ações operacionais do pedido.

### F28 — Deslocamento: A caminho

**Como acessar:** Pedido Agendado → Ir até o local.

**Captura sugerida:** Capturar o pedido antes da ação e, depois, o status A caminho. Reabrir o mesmo pedido como morador para a imagem complementar.

**Texto para o TCC:** O início do deslocamento é registrado pela ação Ir até o local, que atualiza o pedido para A caminho. Essa mudança informa ao acompanhamento que o motorista iniciou o deslocamento para o atendimento. A partir desse status, a edição do endereço deixa de estar disponível ao morador e à Secretaria, preservando o local utilizado na execução.

Figura X – Deslocamento: A caminho

Fonte: Captura de tela do EcoAgenda, com marcações elaboradas pelos autores (2026).

**Legenda dos controles:**

| Marcador | Controle | Explicação |
|---|---|---|

| 1 | Ir até o local (antes da transição) | Registra o início do deslocamento. |

| 2 | Ver detalhes | Permite conferir o pedido antes ou após a ação. |

| 3 | Iniciar coleta (após a transição) | Permite registrar a etapa seguinte, quando o atendimento for iniciado. |

**Orientação de produção:** O botão não abre um navegador de GPS: sua função no fluxo é alterar o status. Verificar o endereço antes de acioná-lo.

### F29 — Execução: Em andamento

**Como acessar:** Pedido A caminho → Iniciar coleta.

**Captura sugerida:** Capturar o status Em andamento e as ações de conclusão e suspensão.

**Texto para o TCC:** A ação Iniciar coleta registra a passagem do deslocamento para a execução do atendimento. O status Em andamento permite distinguir uma coleta em realização de um pedido ainda em deslocamento. Nessa etapa, o motorista pode registrar a conclusão ou uma situação que impeça a continuidade.

Figura X – Execução: Em andamento

Fonte: Captura de tela do EcoAgenda, com marcações elaboradas pelos autores (2026).

**Legenda dos controles:**

| Marcador | Controle | Explicação |
|---|---|---|

| 1 | Iniciar coleta (antes da transição) | Registra o início da execução. |

| 2 | Concluir coleta | Abre o formulário de finalização. |

| 3 | Suspender coleta | Abre o registro de impedimento. |

| 4 | Ver detalhes | Permite consultar as informações da solicitação. |

### F30 — Conclusão com registro fotográfico

**Como acessar:** Pedido Em andamento → Concluir coleta.

**Captura sugerida:** Capturar a janela com uma fotografia de demonstração e, após confirmar, o pedido Concluído.

**Texto para o TCC:** A conclusão da coleta exige o registro de uma fotografia do atendimento. A imagem complementa a informação de finalização e fica associada à solicitação. Após a confirmação, o pedido passa ao status Concluído e pode ser consultado nas áreas de acompanhamento e gestão.

Figura X – Conclusão com registro fotográfico

Fonte: Captura de tela do EcoAgenda, com marcações elaboradas pelos autores (2026).

**Legenda dos controles:**

| Marcador | Controle | Explicação |
|---|---|---|

| 1 | Escolher arquivo / Foto da coleta | Seleciona a fotografia obrigatória. |

| 2 | Concluir coleta | Confirma a finalização após a validação dos dados. |

| 3 | Cancelar | Fecha a janela sem concluir. |

| 4 | × | Fecha a janela de conclusão. |

**Orientação de produção:** Não incluir um campo de observação inexistente. A fotografia é obrigatória nesta etapa; utilizar uma imagem autorizada e coerente com o material demonstrado.

### F31 — Suspensão com fotografia e justificativa

**Como acessar:** Em outro pedido elegível → Suspender coleta.

**Captura sugerida:** Capturar a janela com os campos de foto, justificativa e ações.

**Texto para o TCC:** Quando há impedimento para realizar o atendimento, o motorista pode registrar a suspensão da coleta. O procedimento exige uma fotografia do ocorrido e uma justificativa, permitindo documentar a situação encontrada. A confirmação atualiza o pedido para Suspenso e preserva os elementos informados para consulta.

Figura X – Suspensão com fotografia e justificativa

Fonte: Captura de tela do EcoAgenda, com marcações elaboradas pelos autores (2026).

**Legenda dos controles:**

| Marcador | Controle | Explicação |
|---|---|---|

| 1 | Foto do ocorrido | Seleciona a fotografia obrigatória do impedimento. |

| 2 | Justificativa | Registra o motivo, com limite de 225 caracteres. |

| 3 | Voltar | Fecha a janela sem confirmar a suspensão. |

| 4 | Confirmar suspensão | Grava o impedimento e altera o status. |

| 5 | × | Fecha a janela. |

**Orientação de produção:** Apresentar como caso alternativo. Não suspender o pedido já utilizado para demonstrar a conclusão; usar outro registro.

### F32 — Consulta do perfil profissional

**Como acessar:** Motorista → Meu perfil.

**Captura sugerida:** Capturar os dados com informações pessoais anonimizadas.

**Texto para o TCC:** A consulta do perfil permite ao motorista visualizar os dados cadastrais associados à sua conta. A manutenção desses dados é realizada na área administrativa. A tela, portanto, oferece conferência das informações sem disponibilizar um formulário de edição ao motorista.

Figura X – Consulta do perfil profissional

Fonte: Captura de tela do EcoAgenda, com marcações elaboradas pelos autores (2026).

**Legenda dos controles:**

| Marcador | Controle | Explicação |
|---|---|---|

| 1 | Meu perfil | Abre a consulta cadastral. |

| 2 | Dashboard | Retorna ao painel. |

| 3 | Minhas coletas | Retorna às solicitações atribuídas. |

| 4 | Sair | Encerra a sessão. |

**Orientação de produção:** Não criar legenda para Editar ou Salvar: não são ações deste perfil nesta tela.

## 4.2.5 Área do administrador

### F33 — Visão administrativa e indicadores

**Como acessar:** Entrar com perfil de administrador → Dashboard.

**Captura sugerida:** Capturar o topo com indicadores e equipe; separar os demais blocos em outras figuras.

**Texto para o TCC:** O painel administrativo reúne informações gerais sobre as solicitações e oferece acesso às funções de gestão. Os indicadores permitem consultar os pedidos por situação, enquanto a área de equipe oferece atalhos para os cadastros correspondentes. Essa organização centraliza o acompanhamento operacional e a manutenção das contas de trabalho.

Figura X – Visão administrativa e indicadores

Fonte: Captura de tela do EcoAgenda, com marcações elaboradas pelos autores (2026).

**Legenda dos controles:**

| Marcador | Controle | Explicação |
|---|---|---|

| 1 | Dashboard | Exibe o painel geral. |

| 2 | Pedidos | Abre a listagem administrativa. |

| 3 | Buscar pedido | Abre a consulta por CPF ou ID. |

| 4 | Motoristas | Abre a gestão dos motoristas. |

| 5 | Secretarias | Abre a gestão das contas da Secretaria. |

| 6 | Moradores | Exibe a relação de moradores. |

| 7 | Sair | Encerra a sessão. |

| 8 | Visualizar todos os pedidos | Abre a listagem geral. |

| 9 | Visualizar pedidos: status | Abre a listagem correspondente ao indicador. |

| 10 | Cartão da equipe | Abre a gestão de motoristas ou secretarias, conforme o cartão. |

| 11 | Ver pedidos | Abre a relação de solicitações do painel. |

| 12 | Abrir motoristas | Abre a gestão de motoristas. |

| 13 | Abrir secretarias | Abre a gestão de secretarias. |

**Orientação de produção:** Distribuir os marcadores por recortes; não colocar 13 retângulos em uma única figura. A informação de equipe online deve ser descrita como apresentada pelo sistema, sem afirmar rastreamento contínuo dos profissionais.

### F34 — Calendário e acompanhamento semanal

**Como acessar:** Administrador → Dashboard → calendário e coletas da semana.

**Captura sugerida:** Uma captura do calendário, outra da janela de um dia e outra do detalhamento por status semanal.

**Texto para o TCC:** O acompanhamento semanal permite explorar a distribuição dos pedidos e consultar registros associados a cada situação. O calendário organiza a visualização pela data de emissão. A seleção de um status no resumo semanal apresenta os pedidos correspondentes e oferece um atalho para localizá-los no calendário.

Figura X – Calendário e acompanhamento semanal

Fonte: Captura de tela do EcoAgenda, com marcações elaboradas pelos autores (2026).

**Legenda dos controles:**

| Marcador | Controle | Explicação |
|---|---|---|

| 1 | ‹ | Navega para a semana anterior. |

| 2 | Esta semana | Retorna à semana atual. |

| 3 | › | Navega para a semana seguinte. |

| 4 | Dia do calendário | Abre os pedidos emitidos na data. |

| 5 | Pedido na janela do dia | Abre os detalhes da solicitação. |

| 6 | Fechar × | Fecha a janela do dia. |

| 7 | Status no resumo semanal | Exibe os pedidos daquela situação. |

| 8 | Voltar às coletas da semana | Retorna ao resumo semanal. |

| 9 | Visualizar o pedido no calendário | Localiza a data e o pedido indicado. |

| 10 | Ver semana do pedido mais urgente (quando exibido) | Abre a semana do pedido indicado. |

**Orientação de produção:** Não denominar esta figura como agenda de horários marcados. Não afirmar que um dia sem emissões é um dia sem execução de coletas.

### F35 — Consulta administrativa e histórico

**Como acessar:** Administrador → Pedidos → Ver detalhes / Mostrar histórico.

**Captura sugerida:** Capturar a listagem, os detalhes do pedido concluído e o histórico em figuras diferentes.

**Texto para o TCC:** A consulta administrativa permite acompanhar as solicitações e conferir os registros disponíveis sobre o atendimento. Os detalhes reúnem informações do pedido e os registros visuais, enquanto o histórico possibilita examinar alterações. A apresentação do mesmo pedido utilizado no fluxo do morador e do motorista evidencia a integração das áreas.

Figura X – Consulta administrativa e histórico

Fonte: Captura de tela do EcoAgenda, com marcações elaboradas pelos autores (2026).

**Legenda dos controles:**

| Marcador | Controle | Explicação |
|---|---|---|

| 1 | Status dos pedidos | Filtra a relação por etapa. |

| 2 | Prazo dos pedidos | Filtra pela situação do prazo. |

| 3 | Ver detalhes | Abre a consulta completa do pedido. |

| 4 | Mostrar histórico | Abre os registros de alteração. |

| 5 | Fotografia / Abrir foto | Abre o registro visual disponível. |

| 6 | × | Fecha a janela aberta. |

| 7 | Fechar | Retorna à consulta anterior. |

**Orientação de produção:** Não atribuir ao administrador botões de execução próprios do motorista nem ações de encaminhamento exclusivas da Secretaria.

### F36 — Busca administrativa

**Como acessar:** Administrador → Buscar pedido.

**Captura sugerida:** Mostrar consulta por ID com resultado do pedido utilizado na narrativa.

**Texto para o TCC:** A busca administrativa oferece localização direta de solicitações pelo CPF do morador ou pelo número do pedido. O recurso complementa a navegação pela listagem e permite acessar registros específicos para conferência. Os resultados conduzem à consulta dos dados e do histórico disponível.

Figura X – Busca administrativa

Fonte: Captura de tela do EcoAgenda, com marcações elaboradas pelos autores (2026).

**Legenda dos controles:**

| Marcador | Controle | Explicação |
|---|---|---|

| 1 | Buscar por CPF | Seleciona o modo de busca pelo CPF. |

| 2 | Buscar por ID | Seleciona o modo de busca pelo pedido. |

| 3 | Buscar | Executa a consulta do valor informado. |

| 4 | Ver detalhes | Abre o resultado selecionado. |

| 5 | Mostrar histórico (na consulta) | Abre as alterações registradas. |

### F37 — Período do relatório e exportação

**Como acessar:** Administrador → Dashboard → Pedidos por mês.

**Captura sugerida:** Capturar os seletores de período e o gráfico; em outra figura, mostrar o relatório gerado, se necessário.

**Texto para o TCC:** O painel apresenta informações dos pedidos por período e disponibiliza a geração de um relatório em PDF. A seleção de mês e ano permite consultar o recorte desejado e atualizar os componentes relacionados do painel. O documento gerado oferece uma forma de registrar e compartilhar as informações administrativas do período.

Figura X – Período do relatório e exportação

Fonte: Captura de tela do EcoAgenda, com marcações elaboradas pelos autores (2026).

**Legenda dos controles:**

| Marcador | Controle | Explicação |
|---|---|---|

| 1 | Mês | Seleciona o mês de referência. |

| 2 | Ano | Seleciona o ano de referência. |

| 3 | Filtrar | Aplica o período selecionado. |

| 4 | Gerar PDF | Abre a geração do relatório do período. |

**Orientação de produção:** Utilizar o rótulo efetivamente visível na página. Baixar e Imprimir, quando aparecerem no visualizador de PDF, pertencem ao navegador e não à interface desenvolvida do EcoAgenda. Conferir os valores do relatório antes de discutir resultados quantitativos.

### F38 — Mapa de locais das coletas realizadas

**Como acessar:** Dashboard → Locais das coletas realizadas, após selecionar o período.

**Captura sugerida:** Mostrar busca, controles de zoom, locais e um marcador selecionado.

**Texto para o TCC:** O mapa de locais permite consultar os endereços associados às coletas realizadas no período selecionado. Os registros são agrupados por endereço e apresentados com os dados disponíveis de localização. A busca e a seleção de locais apoiam a exploração territorial dos atendimentos concluídos.

Figura X – Mapa de locais das coletas realizadas

Fonte: Captura de tela do EcoAgenda, com marcações elaboradas pelos autores (2026).

**Legenda dos controles:**

| Marcador | Controle | Explicação |
|---|---|---|

| 1 | Buscar endereço ou bairro | Restringe os locais apresentados na busca. |

| 2 | + | Aproxima o mapa. |

| 3 | − | Afasta o mapa. |

| 4 | Pinhais | Restaura o enquadramento geral. |

| 5 | Local na lista | Seleciona o local correspondente. |

| 6 | Marcador | Apresenta as informações do local. |

| 7 | Agrupamento (quando exibido) | Permite explorar marcadores próximos. |

| 8 | Limpar seleção × | Remove a seleção corrente. |

| 9 | Tentar localizar endereços (condicional) | Solicita nova tentativa para locais pendentes. |

| 10 | × do balão (quando exibido) | Fecha as informações do marcador. |

**Orientação de produção:** Não confundir com o mapa de pedidos pendentes do motorista. Um endereço não localizado não deve ser apresentado como coleta inexistente; a falha diz respeito à localização cartográfica.

### F39 — Mapa de demanda por bairro

**Como acessar:** Dashboard → Demanda de coletas por bairro.

**Captura sugerida:** Capturar um bairro selecionado, a legenda de intensidade, a busca e a lista lateral.

**Texto para o TCC:** O mapa de demanda apresenta a distribuição dos pedidos por bairro no período consultado. A representação territorial e a relação lateral permitem observar a concentração dos registros e consultar a participação de uma área. A visualização corresponde aos pedidos registrados no EcoAgenda, sem representar necessariamente toda a geração de resíduos do município.

Figura X – Mapa de demanda por bairro

Fonte: Captura de tela do EcoAgenda, com marcações elaboradas pelos autores (2026).

**Legenda dos controles:**

| Marcador | Controle | Explicação |
|---|---|---|

| 1 | Buscar bairro de Pinhais | Localiza bairros na relação apresentada. |

| 2 | + | Aproxima o mapa. |

| 3 | − | Afasta o mapa. |

| 4 | Pinhais | Retorna ao enquadramento geral. |

| 5 | Bairro no mapa | Seleciona a área para consultar seus dados. |

| 6 | Bairro na lista | Seleciona a área correspondente. |

| 7 | Limpar seleção × | Retira a seleção corrente. |

**Orientação de produção:** Manter os créditos da base cartográfica. Não interpretar maior número de pedidos como maior volume de resíduos: essas variáveis são diferentes. No texto final, discutir somente os valores efetivamente capturados.

### F40 — Gestão e cadastro de motoristas

**Como acessar:** Administrador → Motoristas → Cadastrar motorista.

**Captura sugerida:** Primeira figura: cartões e ações; segunda: formulário de cadastro.

**Texto para o TCC:** A gestão de motoristas permite cadastrar os profissionais que participarão do atendimento e controlar a situação de suas contas. O cadastro reúne identificação, contato, credenciais e CNH. A disponibilidade de motoristas ativos também se relaciona ao encaminhamento automático das solicitações realizado pela Secretaria.

Figura X – Gestão e cadastro de motoristas

Fonte: Captura de tela do EcoAgenda, com marcações elaboradas pelos autores (2026).

**Legenda dos controles:**

| Marcador | Controle | Explicação |
|---|---|---|

| 1 | Cadastrar motorista | Abre o formulário de inclusão. |

| 2 | Editar | Abre a manutenção do motorista selecionado. |

| 3 | Desativar | Altera a situação da conta para inativa. |

| 4 | Ativar | Reativa uma conta inativa. |

| 5 | Cadastrar (formulário) | Submete os dados do novo motorista. |

| 6 | Cancelar | Fecha o formulário sem cadastrar. |

| 7 | × | Fecha a janela de cadastro. |

**Orientação de produção:** Ativar e Desativar são alternativas conforme a situação atual, não precisam estar no mesmo cartão. Não testar desativação no motorista do fluxo principal antes de concluir sua demonstração.

### F41 — Edição de motorista

**Como acessar:** Motoristas → Editar.

**Captura sugerida:** Mostrar campos editáveis, opção de atividade e ações, mantendo as credenciais ocultas.

**Texto para o TCC:** A edição permite atualizar os dados do profissional e controlar sua situação cadastral. A manutenção é realizada pelo administrador, centralizando o gerenciamento das contas operacionais. A opção de nova senha permite atualizar a credencial quando necessário, conforme as condições apresentadas no formulário.

Figura X – Edição de motorista

Fonte: Captura de tela do EcoAgenda, com marcações elaboradas pelos autores (2026).

**Legenda dos controles:**

| Marcador | Controle | Explicação |
|---|---|---|

| 1 | Motorista ativo (caixa de seleção) | Define a situação cadastral da conta. |

| 2 | Salvar | Grava as alterações do motorista. |

| 3 | Cancelar | Fecha a edição sem salvar. |

| 4 | × | Fecha a janela. |

**Orientação de produção:** O campo de nova senha é opcional na edição: conferir a orientação exibida e não preencher apenas para produzir a captura. Campos de dados não são botões; podem receber marcadores próprios quando úteis.

### F42 — Gestão e cadastro de secretarias

**Como acessar:** Administrador → Secretarias → Cadastrar secretaria.

**Captura sugerida:** Capturar a listagem e o formulário em figuras separadas.

**Texto para o TCC:** A gestão de secretarias organiza as contas responsáveis pelo atendimento e pela validação dos pedidos. O administrador pode incluir novas contas, atualizar informações e controlar sua situação. Essa manutenção permite definir os usuários que atuarão nas atividades de atendimento do sistema.

Figura X – Gestão e cadastro de secretarias

Fonte: Captura de tela do EcoAgenda, com marcações elaboradas pelos autores (2026).

**Legenda dos controles:**

| Marcador | Controle | Explicação |
|---|---|---|

| 1 | Cadastrar secretaria | Abre a inclusão de uma conta de atendimento. |

| 2 | Editar | Abre a manutenção da conta selecionada. |

| 3 | Desativar | Altera a conta para inativa. |

| 4 | Ativar | Reativa a conta. |

| 5 | Cadastrar (formulário) | Registra a nova conta com os dados informados. |

| 6 | Cancelar | Fecha o formulário sem cadastrar. |

| 7 | × | Fecha a janela. |

**Orientação de produção:** O formulário de cadastro de secretaria reúne nome, e-mail e senha; não inserir legendas para CNH ou CPF que não pertencem a este formulário.

### F43 — Edição de secretaria

**Como acessar:** Secretarias → Editar.

**Captura sugerida:** Capturar os dados, a opção de atividade e as ações inferiores.

**Texto para o TCC:** A edição das contas da Secretaria permite atualizar as informações de acesso e controlar sua situação. O administrador realiza essas operações em um formulário próprio, mantendo a separação entre o gerenciamento de usuários e o atendimento das solicitações.

Figura X – Edição de secretaria

Fonte: Captura de tela do EcoAgenda, com marcações elaboradas pelos autores (2026).

**Legenda dos controles:**

| Marcador | Controle | Explicação |
|---|---|---|

| 1 | Ativo (caixa de seleção) | Define a situação cadastral da conta. |

| 2 | Salvar | Grava as alterações. |

| 3 | Cancelar | Fecha a edição sem salvar. |

| 4 | × | Fecha a janela. |

**Orientação de produção:** Não expor senhas em capturas. A alteração de senha é opcional na edição, conforme indicado no formulário.

### F44 — Consulta de moradores

**Como acessar:** Administrador → Moradores.

**Captura sugerida:** Capturar o cabeçalho e algumas linhas anonimizadas da relação.

**Texto para o TCC:** A relação de moradores permite ao administrador consultar os usuários cadastrados e as informações disponibilizadas nessa área. A tela complementa a visão de gestão das contas, sem apresentar as mesmas ações de manutenção destinadas aos profissionais da equipe.

Figura X – Consulta de moradores

Fonte: Captura de tela do EcoAgenda, com marcações elaboradas pelos autores (2026).

**Legenda dos controles:**

| Marcador | Controle | Explicação |
|---|---|---|

| 1 | Moradores | Abre a relação de usuários desse perfil. |

| 2 | Dashboard | Retorna ao painel administrativo. |

| 3 | Sair | Encerra a sessão. |

**Orientação de produção:** A relação não deve receber legendas de Editar, Excluir ou Desativar quando esses controles não existem na interface. Anonimizar os dados pessoais exibidos.

## 4.2.6 Encerramento do fluxo

### F45 — Retorno do morador ao pedido concluído

**Como acessar:** Após concluir como motorista, entrar como morador → Acompanhar → mesmo pedido.

**Captura sugerida:** Mostrar o status Concluído e, se necessário, a fotografia enviada originalmente no pedido. A foto de execução do motorista deve ser ilustrada na consulta administrativa ou operacional que a disponibiliza.

**Texto para o TCC:** O encerramento do fluxo é apresentado pelo retorno à consulta do morador. O mesmo identificador utilizado na criação permite reconhecer a solicitação e verificar sua situação final e os registros disponíveis. Essa sequência evidencia a articulação entre o registro pelo morador, a validação pela Secretaria e a execução pelo motorista.

Figura X – Retorno do morador ao pedido concluído

Fonte: Captura de tela do EcoAgenda, com marcações elaboradas pelos autores (2026).

**Legenda dos controles:**

| Marcador | Controle | Explicação |
|---|---|---|

| 1 | Ver detalhes | Abre a solicitação concluída. |

| 2 | Fotografia disponível | Permite consultar o registro visual do atendimento, quando clicável. |

| 3 | × | Fecha a janela de detalhes. |

| 4 | Fechar | Retorna ao acompanhamento. |

**Orientação de produção:** Este parágrafo pressupõe que a demonstração foi efetivamente concluída. Se não houver conclusão no ambiente de testes, manter como roteiro de captura e não como resultado já observado. Na versão examinada, os detalhes do morador exibem a foto enviada no pedido; não afirmar que ali aparece a fotografia final do motorista.

## 4.3 Mensagens eletrônicas

### F46 — E-mail de confirmação de cadastro

**Como acessar:** Solicitar cadastro de teste e abrir a mensagem recebida.

**Captura sugerida:** Capturar remetente, identidade visual, finalidade e prazo; ocultar o código e o endereço pessoal.

**Texto para o TCC:** A mensagem de confirmação de cadastro orienta o usuário a verificar o e-mail informado na criação da conta. O conteúdo identifica a finalidade da comunicação e apresenta o código e sua validade. A confirmação é concluída no formulário do EcoAgenda, mediante o preenchimento do código recebido.

Figura X – E-mail de confirmação de cadastro

Fonte: Captura de tela do EcoAgenda, com marcações elaboradas pelos autores (2026).

**Legenda dos controles:**

| Marcador | Controle | Explicação |
|---|---|---|

| 1 | Código e prazo (conteúdo informativo) | Orientam a confirmação na tela de cadastro. |

**Orientação de produção:** Não há necessidade de inventar um botão no e-mail. Responder, Encaminhar, Excluir e outros controles da caixa de entrada pertencem ao provedor. Se o layout efetivamente incluir um link do sistema, descrevê-lo pelo destino real.

### F47 — E-mail de recuperação de acesso

**Como acessar:** Solicitar recuperação de uma conta de teste e abrir o e-mail.

**Captura sugerida:** Mostrar o título, a orientação de recuperação e a validade, ocultando o código.

**Texto para o TCC:** A mensagem de recuperação apresenta as orientações e o código necessário à redefinição da senha. O usuário retorna ao formulário do sistema para informar o código e estabelecer a nova credencial. O recebimento do e-mail integra o procedimento de recuperação, mas a alteração somente é efetivada após a validação no EcoAgenda.

Figura X – E-mail de recuperação de acesso

Fonte: Captura de tela do EcoAgenda, com marcações elaboradas pelos autores (2026).

**Legenda dos controles:**

| Marcador | Controle | Explicação |
|---|---|---|

| 1 | Código e validade (conteúdo informativo) | Identificam os dados a serem utilizados na recuperação. |

**Orientação de produção:** Não apresentar o simples envio como prova de recuperação bem-sucedida: registrar também o retorno ao login com a nova senha, após teste.

### F48 — E-mails de confirmação de alterações do perfil

**Como acessar:** Solicitar alteração de dados ou senha no perfil.

**Captura sugerida:** Capturar um exemplo de cada finalidade, caso os títulos sejam diferentes.

**Texto para o TCC:** As mensagens de confirmação de alterações apoiam a verificação das operações realizadas no perfil do morador. O conteúdo informa a finalidade do código, que deve ser utilizado na etapa correspondente do sistema. Esse procedimento associa a efetivação das mudanças à confirmação por e-mail.

Figura X – E-mails de confirmação de alterações do perfil

Fonte: Captura de tela do EcoAgenda, com marcações elaboradas pelos autores (2026).

**Legenda dos controles:**

| Marcador | Controle | Explicação |
|---|---|---|

| 1 | Código de confirmação (conteúdo informativo) | Deve ser utilizado na operação do perfil que o solicitou. |

**Orientação de produção:** Não reutilizar o código de recuperação de acesso para confirmar alteração cadastral: são fluxos distintos. Anonimizar o conteúdo sensível das figuras.

### F49 — Notificação de atualização da coleta

**Como acessar:** Após uma transição que gere notificação, consultar o e-mail do morador.

**Captura sugerida:** Mostrar número do pedido, status e texto de orientação. Se houver várias mensagens, escolher as que demonstrem etapas distintas.

**Texto para o TCC:** As notificações de coleta comunicam atualizações relacionadas à solicitação e orientam o morador a consultar o sistema. A identificação do pedido e a indicação do status permitem relacionar a mensagem ao atendimento acompanhado nas telas. O e-mail complementa a consulta no EcoAgenda, sem substituir o registro mantido na aplicação.

Figura X – Notificação de atualização da coleta

Fonte: Captura de tela do EcoAgenda, com marcações elaboradas pelos autores (2026).

**Legenda dos controles:**

| Marcador | Controle | Explicação |
|---|---|---|

| 1 | Número do pedido e status (conteúdo informativo) | Identificam a solicitação e a atualização comunicada. |

**Orientação de produção:** Usar mensagens realmente recebidas. Não afirmar recebimento garantido ou instantâneo: a entrega depende do serviço de e-mail. Não numerar logomarca como botão. Caso haja link clicável, verificar seu destino antes de incluí-lo na legenda.

## 4.4 Testes e resultados observados

Os testes funcionais devem relacionar cada operação ao comportamento esperado e ao resultado efetivamente observado. Para cada caso, registrar a data, o perfil utilizado, os passos executados e a evidência correspondente. As divergências e limitações também devem ser apresentadas, incluindo eventuais falhas de serviços externos ou endereços sem localização cartográfica.

Modelo para preencher após o teste: “No teste [identificação], realizado em [data], executou-se [procedimento] com o perfil [perfil]. Observou-se [resultado real], conforme a Figura [número]. O comportamento [correspondeu/não correspondeu] ao esperado, pois [evidência].”

Na discussão, relacionar a continuidade do mesmo pedido entre os perfis, as restrições de edição, a documentação fotográfica e a consulta do histórico às funções do sistema. Não afirmar melhoria de produtividade, redução percentual de tempo, satisfação dos usuários, segurança absoluta ou atendimento em prazo garantido sem uma avaliação específica que sustente essas conclusões.

| Caso | Procedimento | Resultado esperado | Resultado observado / evidência |
|---|---|---|---|

| Acesso público | Abrir os links Sobre, Contato, Entrar e Cadastre-se. | Navegação para as áreas e páginas correspondentes. | Preencher após execução. |

| WhatsApp | Informar nome e clicar em Enviar via WhatsApp; depois repetir sem nome. | Conversa preparada para 5541987075000; sem nome, orientação de preenchimento e nenhuma abertura. | Preencher após execução. |

| Cadastro | Preencher as etapas e confirmar o código válido recebido. | Conta criada e disponível para autenticação. | Preencher após execução. |

| CPF | Conferir um caso autorizado válido e um formato inválido, sem expor os dados. | Mensagens coerentes com o caso; distinguir indisponibilidade do serviço de CPF inválido. | Preencher após execução. |

| CEP | Consultar um CEP existente e conferir os campos retornados. | Preenchimento dos dados disponíveis; número e complemento permanecem sob conferência do usuário. | Preencher após execução. |

| Login | Entrar com cada perfil e tentar uma senha incorreta. | Direcionamento ao perfil correto; rejeição das credenciais incorretas. | Preencher após execução. |

| Recuperação | Solicitar código e redefinir a senha; testar código incorreto em outra tentativa. | Código correto permite alteração; código incorreto não altera a senha. | Preencher após execução. |

| Pedido | Criar solicitação e consultar o ID em Acompanhar. | Registro exibido com os dados informados e situação inicial. | Preencher após execução. |

| Correção de endereço | Corrigir antes de A caminho e consultar o histórico. | Endereço atualizado e alteração registrada. | Preencher após execução. |

| Bloqueio da edição | Passar para A caminho e consultar como morador e Secretaria. | Opção de edição indisponível; nenhuma alteração tardia autorizada. | Preencher após execução. |

| Encaminhamento | Validar com motorista ativo e conferir o destinatário no sistema. | Distribuição automática e pedido disponível ao motorista atribuído. | Preencher após execução. |

| Calendário | Abrir o dia de emissão do pedido e navegar entre semanas. | Relação coerente com a data de emissão e acesso aos detalhes. | Preencher após execução. |

| Execução | Executar Ir até o local, Iniciar coleta e Concluir coleta com foto. | Transições A caminho, Em andamento e Concluído registradas. | Preencher após execução. |

| Foto obrigatória | Tentar concluir sem foto e depois com arquivo permitido. | Bloqueio sem fotografia; conclusão após preenchimento válido. | Preencher após execução. |

| Suspensão | Executar os casos alternativos da Secretaria e motorista. | Justificativa exigida; no motorista, fotografia também exigida; status Suspenso após confirmação. | Preencher após execução. |

| Busca e filtros | Buscar por ID/CPF e aplicar filtros de status e prazo. | Resultados coerentes com os dados e critérios selecionados. | Preencher após execução. |

| Mapa do motorista | Abrir mapa, selecionar pedido, buscar e atualizar. | Coletas atribuídas disponíveis, exceto concluídas; informações coerentes e aviso quando localização pendente. | Preencher após execução. |

| Mapas administrativos | Selecionar período e comparar registros do mapa de locais e de demanda. | Coletas realizadas e pedidos por bairro apresentados conforme o modo e o período. | Preencher após execução. |

| Gestão de equipe | Cadastrar, editar, desativar e reativar uma conta de teste. | Persistência dos dados e situação cadastral correspondente. | Preencher após execução. |

| Perfil | Alterar dados, endereço e senha pelos fluxos correspondentes. | Mudanças persistidas após as verificações exigidas. | Preencher após execução. |

| E-mails | Conferir mensagens de cadastro, recuperação, alterações e coleta. | Finalidade, destinatário e dados coerentes com a operação; registrar também eventuais falhas. | Preencher após execução. |

| Relatório | Gerar PDF e comparar os totais com os registros do período. | Valores e período coerentes; documento acessível. | Preencher após execução. |

| Sessão | Sair e tentar retornar a uma área restrita. | Acesso condicionado a nova autenticação. | Preencher após execução. |

## Conferência antes de inserir no TCC

Conferência editorial: manter somente os parágrafos associados às telas realmente capturadas; inserir referências Figura X; revisar nomes de perfis; numerar figuras na ordem do TCC; conservar as fontes; conferir se cada retângulo tem uma legenda; preencher os resultados dos testes; retirar estas instruções de produção da versão final do trabalho.

Base de conferência: index.html e js/contato.js; cadastro/cadastro.html; páginas de login e recuperação; login/dashboard_morador (dashboard, novo pedido e perfil); login/secretaria (painel e suspensão); login/motorista (painel e mapa); login/administrador (painel, mapa e relatório); componentes login/interface (pedidos, calendário, identidade e edição de endereço). A leitura de código não substitui a revisão visual no ambiente em execução.