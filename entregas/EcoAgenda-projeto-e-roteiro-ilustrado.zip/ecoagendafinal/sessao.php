<?php

session_start();
header("Content-Type: application/json; charset=utf-8");
header("Cache-Control: no-store, private");

if (isset($_SESSION["email"])) {
    echo json_encode([
        "logado" => true,
        "nome" => $_SESSION["nome"],
        "perfil" => $_SESSION["perfil"],
    ]);
} else {
    echo json_encode([
        "logado" => false,
    ]);
}

?>
