# Onde encontrar cada parte

- `configuracoes/banco.php`: conexão com MySQL; valores preservados.
- `configuracoes/email.php`: configuração do envio de e-mail.
- `configuracoes/cpf.php`: configuração da consulta de CPF.
- `recursos/scripts/`: JavaScript organizado por perfil ou função.
- `recursos/estilos/`: CSS organizado pelos mesmos grupos.
- `cadastro/`: cadastro e confirmação.
- `agendamento/`: criação das solicitações e arquivos enviados.
- `login/`: entrada, saída e recuperação de acesso.
- `login/dashboard_morador/`: painel e funções do morador.
- `login/secretaria/`: análise e encaminhamento.
- `login/motorista/`: execução das coletas.
- `login/administrador/`: indicadores, relatórios e gestão.
- `login/interface/`: código compartilhado entre as telas.
- `assets/icons/`: imagens de ícones existentes.
- `login/administrador/vendor/`: bibliotecas externas usadas pelos mapas. Não é código próprio do projeto; seus arquivos e licenças devem ser preservados.
- `documentacao/`: instruções e verificações.

Os nomes das pastas que fazem parte das URLs das páginas foram mantidos para preservar formulários, links e redirecionamentos existentes. Os três arquivos antigos de configuração continuam como encaminhadores; não os remova.

Para o escopo atualizado da limpeza e os testes realizados, consulte REVISAO_FINAL.md.
