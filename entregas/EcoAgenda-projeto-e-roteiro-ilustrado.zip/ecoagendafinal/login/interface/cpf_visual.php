<?php

function eaCpfVisual($valor): string
{
    $cpf = preg_replace("/\D+/", "", (string) ($valor ?? ""));
    return strlen($cpf) === 11 ? substr($cpf, 0, 3) . ".***.***-" . substr($cpf, -2) : "—";
}
