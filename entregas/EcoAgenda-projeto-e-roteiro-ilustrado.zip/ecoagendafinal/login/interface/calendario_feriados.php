<?php
require_once __DIR__ . "/feriados.php";
header("Content-Type: application/json; charset=utf-8");
$ano = filter_input(INPUT_GET, "ano", FILTER_VALIDATE_INT);
if (!$ano || $ano < 1900 || $ano > 2200) {
    http_response_code(400);
    echo '{"erro":"Ano inválido"}';
    exit();
}
echo json_encode(
    eaFeriados($ano - 1) + eaFeriados($ano) + eaFeriados($ano + 1),
    JSON_UNESCAPED_UNICODE,
);
