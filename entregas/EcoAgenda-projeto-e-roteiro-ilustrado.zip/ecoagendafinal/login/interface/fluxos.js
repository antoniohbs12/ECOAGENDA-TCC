(() => {
    const reduced = matchMedia("(prefers-reduced-motion: reduce)");
    const key = "ecoagenda:retorno:" + location.pathname;
    const storage = {
        get(k) {
            try {
                return JSON.parse(sessionStorage.getItem(k));
            } catch {
                return null;
            }
        },
        set(k, v) {
            try {
                sessionStorage.setItem(k, JSON.stringify(v));
            } catch {}
        },
        remove(k) {
            try {
                sessionStorage.removeItem(k);
            } catch {}
        }
    };
    function animate(el, frames, duration = 240) {
        if (el?.animate && !reduced.matches) el.animate(frames, { duration, easing: "ease-out" });
    }
    function toast(message, { error = false, center = false } = {}) {
        document.querySelector(".ea-toast")?.remove();
        const el = document.createElement("div");
        el.className = `ea-toast${error ? " error" : ""}${center ? " center" : ""}`;
        el.setAttribute("role", error ? "alert" : "status");
        const text = document.createElement("span");
        text.textContent = message;
        const close = document.createElement("button");
        close.type = "button";
        close.textContent = "×";
        close.setAttribute("aria-label", "Fechar mensagem");
        close.addEventListener("click", () => el.remove());
        el.append(text, close);
        document.body.append(el);
        animate(el, [{ opacity: 0 }, { opacity: 1 }]);
        if (!error) setTimeout(() => el.remove(), 5500);
    }
    function busy(message = "Salvando alterações…") {
        document.querySelector(".ea-busy")?.remove();
        if (!message) return;
        const box = document.createElement("div");
        box.className = "ea-busy";
        box.setAttribute("role", "status");
        const card = document.createElement("div"),
            spinner = document.createElement("span");
        spinner.className = "ea-spinner";
        spinner.setAttribute("aria-hidden", "true");
        card.append(spinner, document.createTextNode(message));
        box.append(card);
        document.body.append(box);
        animate(box, [{ opacity: 0 }, { opacity: 1 }], 160);
    }
    const filterSelector =
        "select[data-ea-status],select[data-ea-prazo],#mot-status-filter,#mot-detail-filter";
    function snapshot() {
        return {
            time: Date.now(),
            section: document.querySelector(".section.active")?.id,
            scroll: window.scrollY,
            mainScroll: document.querySelector(".main-content")?.scrollTop || 0,
            tab: document.querySelector(".tab.active")?.dataset.tab,
            filters: [...document.querySelectorAll(filterSelector)].map((el) => el.value),
            weeks: [...document.querySelectorAll("[data-calendar]")].map((el) => ({
                source: el.dataset.calendar,
                date: el.dataset.week
            }))
        };
    }
    function restore(state) {
        if (!state) return;
        if (state.section)
            document
                .querySelector(
                    `.menu-link[data-section="${state.section.replace("section-", "")}"]`
                )
                ?.click();
        if (state.tab) document.querySelector(`.tab[data-tab="${state.tab}"]`)?.click();
        document.querySelectorAll(filterSelector).forEach((el, i) => {
            if (state.filters?.[i] !== undefined) {
                el.value = state.filters[i];
                el.dispatchEvent(new Event("change", { bubbles: true }));
            }
        });
        state.weeks?.forEach((w) => {
            if (w.date) document.dispatchEvent(new CustomEvent("ea-calendar-go", { detail: w }));
        });
        requestAnimationFrame(() => {
            window.scrollTo({ top: state.scroll || 0, behavior: "instant" });
            const main = document.querySelector(".main-content");
            if (main) main.scrollTop = state.mainScroll || 0;
        });
    }
    window.EcoFlow = { toast, busy, animate, snapshot, restore };
    function init() {
        const saved = storage.get(key);
        storage.remove(key);
        if (saved && Date.now() - saved.time < 180000) {
            restore(saved);
            const message = document.querySelector(
                ".alerta,.mensagem.sucesso,.mensagem.erro,.mensagem.success,.mensagem.error,.alert-success,.alert-danger"
            );
            if (message?.textContent.trim())
                toast(message.textContent.trim(), {
                    error: /erro|error|danger/.test(message.className)
                });
        }
        const result = storage.get("ecoagenda:resultado");
        if (result && Date.now() - result.time < 30000) {
            storage.remove("ecoagenda:resultado");
            toast(result.text);
        }
        document.addEventListener("submit", (event) => {
            const form = event.target;
            if (
                event.defaultPrevented ||
                form.method.toLowerCase() !== "post" ||
                form.target === "_blank" ||
                document.body.classList.contains("ea-access")
            )
                return;
            storage.set(key, snapshot());
            busy();
        });
        document.addEventListener("click", (event) => {
            const menu = event.target.closest(".menu-link");
            if (menu) {
                const section = document.querySelector(".section.active");
                animate(section, [
                    { opacity: 0, transform: "translateY(8px)" },
                    { opacity: 1, transform: "none" }
                ]);
            }
            const address = event.target.closest("#btnUsarEndereco");
            if (address?.classList.contains("selected"))
                toast("Endereço confirmado. Você já pode informar os materiais da coleta.", {
                    center: true
                });
            const link = event.target.closest("a[href]");
            if (
                link &&
                /novo_pedido/.test(link.getAttribute("href")) &&
                !/novo_pedido/.test(location.pathname)
            ) {
                storage.set("ecoagenda:origem-pedido", {
                    path: location.pathname + location.search,
                    context: snapshot()
                });
            }
        });
        const origin = storage.get("ecoagenda:restaurar-origem");
        if (origin && origin.path === location.pathname + location.search) {
            storage.remove("ecoagenda:restaurar-origem");
            restore(origin.context);
        }
    }
    window.addEventListener("pageshow", () => busy(false));
    if (document.readyState === "complete") init();
    else document.addEventListener("DOMContentLoaded", () => queueMicrotask(init), { once: true });
})();
