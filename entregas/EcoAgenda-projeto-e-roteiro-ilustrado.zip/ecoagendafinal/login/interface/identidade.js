(() => {
    const base = new URL(".", document.currentScript.src);
    const norm = (s) =>
        String(s || "")
            .normalize("NFD")
            .replace(/[\u0300-\u036f]/g, "")
            .toLowerCase()
            .replace(/\s+/g, " ")
            .trim();
    function status(s) {
        s = norm(s);
        if (/conclu/.test(s)) return "concluido";
        if (/suspens|cancelad/.test(s)) return "suspenso";
        if (/a caminho/.test(s)) return "caminho";
        if (/andamento/.test(s)) return "andamento";
        if (/agendad|encaminhad|confirmad/.test(s)) return "agendado";
        if (/analise|pendente/.test(s)) return "analise";
        return "";
    }
    const explicacoes = {
        analise: "Recebemos seu pedido. A Secretaria está conferindo as informações.",
        agendado: "Seu pedido foi encaminhado a um motorista para organizar a coleta.",
        caminho: "O motorista está se deslocando até o local da coleta.",
        andamento: "O motorista chegou ao local e a coleta está sendo realizada.",
        concluido: "A coleta foi finalizada pelo motorista.",
        suspenso:
            "O atendimento foi interrompido. Consulte os detalhes para verificar o motivo e a orientação."
    };
    const nomes = {
        analise: "Em análise",
        agendado: "Agendado",
        caminho: "A caminho",
        andamento: "Em andamento",
        concluido: "Concluído",
        suspenso: "Suspenso"
    };
    window.EcoStatus = {
        key: status,
        nomes,
        badge(value) {
            const e = document.createElement("span");
            e.className = "ea-status-token";
            e.dataset.statusKey = status(value);
            e.textContent = nomes[status(value)] || value;
            return e;
        }
    };
    function decorate() {
        document
            .querySelectorAll(".status,.historico-status,#modalStatus,.ea-status-token")
            .forEach((el) => {
                if (el.id === "modalStatus" && !el.classList.contains("status"))
                    el.classList.add("status");
                const key = status(el.textContent);
                if (key && el.dataset.statusKey !== key) el.dataset.statusKey = key;
                if (key && !el.closest("button,a") && !el.hasAttribute("tabindex")) {
                    el.tabIndex = 0;
                    el.setAttribute("aria-label", nomes[key] + ". Explicação do status.");
                }
            });
        document.querySelectorAll(".stat-card,.adm-resumo-card").forEach((el) => {
            const key = status(
                el.querySelector(".stat-label,.adm-resumo-label")?.textContent || el.textContent
            );
            if (key && el.dataset.statusKey !== key) el.dataset.statusKey = key;
        });
        document.querySelectorAll(".ea-progress-step").forEach((el) => {
            const key = status(el.querySelector(".ea-progress-label")?.firstChild?.textContent);
            if (key && el.dataset.statusKey !== key) el.dataset.statusKey = key;
        });
        document.querySelectorAll(".adm-weekly-item i").forEach((el) => {
            const key = status(el.parentElement.textContent);
            if (key && el.dataset.statusKey !== key) el.dataset.statusKey = key;
        });
        document.querySelectorAll(".menu-link").forEach((link) => {
            const icon = link.querySelector(".ea-nav-icon,.menu-icon");
            if (!icon) return;
            if (norm(link.textContent).includes("secretaria")) {
                if (!icon.querySelector("[data-secretaria]")) {
                    const img = document.createElement("img");
                    img.dataset.secretaria = "1";
                    img.className = "ea-img-icon";
                    img.alt = "";
                    icon.replaceChildren(img);
                }
                const img = icon.firstElementChild;
                const url = new URL(
                    "icones/secretaria" +
                        (link.classList.contains("active") ? "-verde" : "") +
                        ".png",
                    base
                ).href;
                if (img.src !== url) img.src = url;
            }
        });
        document.querySelectorAll(".ea-password-control").forEach((button) => {
            const input = document.getElementById(button.dataset.passwordFor);
            if (!input) return;
            const open = input.type === "text",
                white = button.matches(":focus-visible") || open;
            button.setAttribute("aria-pressed", String(open));
            button.setAttribute("aria-label", open ? "Ocultar senha" : "Visualizar senha");
            const src = new URL(
                `icones/${open ? "ocultar" : "visualizar"}-senha${white ? "" : "-verde"}.png`,
                base
            ).href;
            if (button.firstElementChild?.src !== src) {
                const img = document.createElement("img");
                img.alt = "";
                img.src = src;
                button.replaceChildren(img);
            }
        });
    }
    function passwords() {
        document.querySelectorAll("#mostrarSenha,.btn-toggle-pass").forEach((button) => {
            if (button.dataset.passwordFor) return;
            const input = button.closest(".senha,.senha-container")?.querySelector("input");
            if (!input) return;
            button.classList.add("ea-password-control");
            button.dataset.passwordFor = input.id;

            button.addEventListener("click", () => queueMicrotask(decorate));
            button.addEventListener("focus", decorate);
            button.addEventListener("blur", decorate);
        });
    }

    function metrics() {
        function filter(key) {
            const form = document.querySelector(".ea-order-filters");
            if (!form) return;
            const status = form.querySelector("select[data-ea-status]"),
                prazo = form.querySelector("select[data-ea-prazo]");
            status.value = key;
            prazo.value = "todos";
            status.dispatchEvent(new Event("change"));
            prazo.dispatchEvent(new Event("change"));
        }
        document.querySelectorAll("[data-ea-metric]").forEach((button) =>
            button.addEventListener("click", () => {
                document.querySelector('.menu-link[data-section="pedidos"]')?.click();
                filter(button.dataset.eaMetric);
                window.EcoFlow?.animate(document.getElementById("section-pedidos"), [
                    { opacity: 0, transform: "translateY(10px)" },
                    { opacity: 1, transform: "none" }
                ]);
                document.querySelector("select[data-ea-status]")?.focus({ preventScroll: true });
            })
        );
        const key = new URL(location.href).searchParams.get("status");
        if (key === "todos" || Object.hasOwn(nomes, key)) filter(key);
    }
    function statusHelp() {
        const tip = document.createElement("div");
        tip.id = "ea-status-help";
        tip.className = "ea-status-help";
        tip.setAttribute("role", "tooltip");
        tip.hidden = true;
        document.body.append(tip);
        let active = null,
            timer;
        const selector =
            ".status[data-status-key],.ea-status-token[data-status-key],.historico-status[data-status-key]";
        function close() {
            clearTimeout(timer);
            if (active) active.removeAttribute("aria-describedby");
            active = null;
            tip.hidden = true;
        }
        function show(el) {
            if (!el || !explicacoes[el.dataset.statusKey]) return;
            clearTimeout(timer);
            if (active && active !== el) active.removeAttribute("aria-describedby");
            active = el;
            tip.textContent = explicacoes[el.dataset.statusKey];
            tip.hidden = false;
            el.setAttribute("aria-describedby", tip.id);
            const box = el.getBoundingClientRect();
            tip.style.left =
                Math.max(12, Math.min(box.left, innerWidth - tip.offsetWidth - 12)) + "px";
            tip.style.top = Math.max(12, box.top - tip.offsetHeight - 10) + "px";
        }
        document.addEventListener("pointerover", (e) => {
            const el = e.target.closest(selector);
            if (el) show(el);
            else if (!tip.contains(e.target)) timer = setTimeout(close, 120);
        });
        document.addEventListener("focusin", (e) => {
            const el = e.target.closest(selector);
            if (el) show(el);
            else close();
        });
        document.addEventListener("click", (e) => {
            const el = e.target.closest(selector);
            if (el && !el.closest("button,a")) {
                show(el);
            } else if (!tip.contains(e.target)) close();
        });
        document.addEventListener("keydown", (e) => {
            if (e.key === "Escape") close();
            else if (["Enter", " "].includes(e.key) && e.target.matches(selector)) {
                e.preventDefault();
                show(e.target);
            }
        });
        document.addEventListener("pointerout", (e) => {
            if (e.target.closest?.(selector) && !tip.contains(e.relatedTarget))
                timer = setTimeout(close, 160);
        });
        tip.addEventListener("pointerenter", () => clearTimeout(timer));
        tip.addEventListener("pointerleave", close);
        window.addEventListener("scroll", close, true);
        window.addEventListener("resize", close);
    }
    let queued = false;
    const observer = new MutationObserver(() => {
        if (queued) return;
        queued = true;
        requestAnimationFrame(() => {
            queued = false;
            decorate();
        });
    });
    function init() {
        passwords();
        decorate();
        statusHelp();
        metrics();
        observer.observe(document.body, {
            subtree: true,
            childList: true,
            characterData: true,
            attributes: true,
            attributeFilter: ["class", "type"]
        });
    }
    if (document.readyState === "loading") document.addEventListener("DOMContentLoaded", init);
    else init();
})();
