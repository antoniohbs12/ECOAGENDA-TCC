<?php

require_once __DIR__ . "/enviar_email.php";

$mensagem = "";
$sucesso = false;

if ($_SERVER["REQUEST_METHOD"] === "POST") {
    $destino = trim((string) ($_POST["destino"] ?? ""));

    if (!filter_var($destino, FILTER_VALIDATE_EMAIL)) {
        $mensagem = "Digite um e-mail válido.";
    } else {
        $erro = null;
        $sucesso = enviarEmailEcoAgenda(
            $destino,
            "Teste de e-mail - EcoAgenda",
            '<!DOCTYPE html><html lang="pt-BR"><body style="font-family:Arial,sans-serif;background:#f5f7f6;padding:24px;"><div style="max-width:520px;margin:auto;background:#fff;padding:28px;border-radius:14px;"><h2 style="color:#08752f;">EcoAgenda</h2><p>Este é um teste de envio pelo Gmail SMTP.</p><p>Se você recebeu esta mensagem, a integração SMTP está funcionando.</p></div></body></html>',
            "Este é um teste de envio pelo Gmail SMTP do EcoAgenda.",
            $erro,
        );

        if ($sucesso) {
            $mensagem = "E-mail de teste enviado. Confira a caixa de entrada e o spam.";
        } else {
            error_log("EcoAgenda SMTP teste: " . ($erro ?? "falha desconhecida"));
            $mensagem = "Falha no envio. Consulte o log do PHP para o detalhe técnico.";
        }
    }
}
?>
<!DOCTYPE html>
<html lang="pt-BR">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>EcoAgenda - Teste Gmail SMTP</title>
    <style>
        body{font-family:Arial,sans-serif;background:#f5f7f6;margin:0;padding:40px;color:#26342b}
        .card{max-width:520px;margin:auto;background:#fff;padding:30px;border-radius:16px;box-shadow:0 8px 30px rgba(0,0,0,.08)}
        h1{color:#08752f}
        input,button{width:100%;padding:12px;margin-top:8px;box-sizing:border-box}
        button{background:#2d8d48;color:#fff;border:0;border-radius:8px;font-weight:700;cursor:pointer}
        .msg{margin-top:18px;padding:12px;border-radius:8px;background:#edf7ef}
    </style>
</head>
<body>
<div class="card">
    <h1>Teste Gmail SMTP</h1>
    <p>Use esta tela apenas durante a configuração local do TCC.</p>
    <form method="POST">
        <label for="destino">E-mail de destino</label>
        <input type="email" id="destino" name="destino" placeholder="seuemail@gmail.com" required>
        <button type="submit">Enviar e-mail de teste</button>
    </form>
    <?php if ($mensagem !== ""): ?>
        <div class="msg"><?= htmlspecialchars($mensagem, ENT_QUOTES, "UTF-8") ?></div>
    <?php endif; ?>
</div>
</body>
</html>
