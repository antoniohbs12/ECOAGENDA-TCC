<?php

return require __DIR__ . "/../configuracoes/email.php";
