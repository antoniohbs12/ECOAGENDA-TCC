
<?php
session_start();

require_once __DIR__ . "/../config.php";
require_once __DIR__ . "/enviar_email.php";

if ($_SERVER["REQUEST_METHOD"] !== "POST") {
    header("Location: esqueci_senha.html");

    exit();
}

$email = trim($_POST["email"] ?? "");

if ($email === "") {
    echo "
    <script>

        alert('Digite seu e-mail.');

        history.back();

    </script>
    ";

    exit();
}

if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
    echo "
    <script>

        alert('Digite um e-mail válido.');

        history.back();

    </script>
    ";

    exit();
}

$sql = "
    SELECT
        email,
        nome
    FROM usuario
    WHERE email = ? AND senha <> '!ecoagenda:telefone:v1'
    LIMIT 1
";

$stmt = $conn->prepare($sql);

if (!$stmt) {
    die("Erro ao preparar consulta: " . $conn->error);
}

$stmt->bind_param("s", $email);

if (!$stmt->execute()) {
    $stmt->close();

    die("Erro ao consultar usuário.");
}

$resultado = $stmt->get_result();

if ($resultado->num_rows === 0) {
    $stmt->close();

    echo "
    <script>

        alert(
            'Não encontramos um usuário cadastrado com esse e-mail.'
        );

        history.back();

    </script>
    ";

    exit();
}

$usuario = $resultado->fetch_assoc();

$stmt->close();

$codigo = (string) random_int(100000, 999999);

$_SESSION["recuperacao_email"] = $usuario["email"];

$_SESSION["recuperacao_codigo"] = $codigo;

$_SESSION["recuperacao_expira"] = time() + 900;

$nomeUsuario = trim((string) ($usuario["nome"] ?? "Morador"));

if ($nomeUsuario === "") {
    $nomeUsuario = "Morador";
}

$nomeSeguro = htmlspecialchars($nomeUsuario, ENT_QUOTES, "UTF-8");

$codigoSeguro = htmlspecialchars($codigo, ENT_QUOTES, "UTF-8");

$htmlEmail = eaConteudoCodigo("recuperacao", $codigo, $nomeUsuario);

$erroEnvio = null;
$enviado = enviarEmailEcoAgenda(
    $usuario["email"],
    "Código de recuperação de senha - EcoAgenda",
    $htmlEmail,
    "Seu código de recuperação do EcoAgenda é: {$codigo}. Ele é válido por 15 minutos.",
    $erroEnvio,
);

if (!$enviado) {
    unset(
        $_SESSION["recuperacao_email"],
        $_SESSION["recuperacao_codigo"],
        $_SESSION["recuperacao_expira"],
    );

    error_log("EcoAgenda SMTP recuperação de senha: " . ($erroEnvio ?? "falha desconhecida"));

    echo "
    <script>
        alert('Não foi possível enviar o código por e-mail. Verifique a configuração do Gmail SMTP e tente novamente.');
        window.location.href = 'esqueci_senha.html';
    </script>
    ";
    exit();
}

$parteEmail = explode("@", $usuario["email"], 2);

$emailMascarado = $usuario["email"];

if (count($parteEmail) === 2) {
    $local = $parteEmail[0];

    $dominio = $parteEmail[1];

    if (strlen($local) > 2) {
        $localMascara = substr($local, 0, 2) . str_repeat("*", max(1, strlen($local) - 2));
    } else {
        $localMascara = "***";
    }

    $emailMascarado = $localMascara . "@" . $dominio;
}
?>


<!DOCTYPE html>

<html lang="pt-BR">

<head>

    <meta charset="UTF-8">

    <meta
        name="viewport"
        content="width=device-width, initial-scale=1.0"
    >

    <title>
        EcoAgenda - E-mail enviado
    </title>


    

<link rel="stylesheet" href="interface/acesso.css?v=20261011-1">
<link rel="stylesheet" href="interface/identidade.css?v=20261011-1">
<script defer src="interface/identidade.js?v=20261011-1"></script>
<script defer src="interface/fluxos.js?v=20261011-1"></script>
</head>


<body class="ea-access">


<div class="card">
<div class="ea-access-brand"><img src="../ECO AGENDA LOGO FINAL HORIZONTAL BRANCO.png" alt="EcoAgenda"></div>


    <div class="icone">

        ✓

    </div>


    <h1>

        Código enviado!

    </h1>


    <p>

        Enviamos o código de recuperação
        para o e-mail cadastrado abaixo.

    </p>


    <div class="email">

        <?= htmlspecialchars($emailMascarado, ENT_QUOTES, "UTF-8") ?>

    </div>


    <p>

        O código é válido por
        <strong>15 minutos</strong>.

        Verifique também a caixa de spam
        ou lixo eletrônico.

    </p>


    <a
        href="nova_senha.html"
        class="btn"
    >

        Informar código

    </a>


    <a
        href="esqueci_senha.html"
        class="voltar"
    >

        Voltar

    </a>


</div>


</body>

</html>