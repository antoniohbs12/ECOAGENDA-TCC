            <div class="form-card">

                

                <div class="field">

                    <label for="tipo_residuo">
                        Tipo de resíduo
                        <span>(somente materiais à base de madeira)*</span>
                    </label>

                    <input
                        type="text"
                        id="tipo_residuo"
                        aria-describedby="orientacao-madeira"
                        placeholder="Ex.: portas de madeira, tábuas, móveis de madeira..."
                        maxlength="100"
                    >
                    <div id="orientacao-madeira" class="ea-wood-notice" hidden role="note"><strong>Separe somente madeira</strong><p>Esta coleta é destinada a materiais à base de madeira. Não misture plástico, metal, vidro, entulho de construção ou outros resíduos. Não realizamos coleta de colchões.</p></div>

                </div>


                

                <div class="field">

                    <label for="quantidade">
                        Quantidade aproximada
                    </label>

                    <select id="quantidade" aria-describedby="orientacao-volume">
                        <option value="">Selecione a quantidade aproximada</option>
                        <option value="1 a 3 carrinhos de mão">1 a 3 carrinhos de mão</option>
                        <option value="4 a 8 carrinhos de mão">4 a 8 carrinhos de mão</option>
                        <option value="9 a 12 carrinhos de mão">9 a 12 carrinhos de mão</option>
                        <option value="13 a 15 carrinhos de mão">13 a 15 carrinhos de mão</option>
                    </select>
                    <div id="orientacao-volume" class="ea-wood-notice"><strong>Limite por pedido: 1 m³ de madeira</strong><p>Como referência aproximada, esse volume pode corresponder a cerca de 12 a 15 carrinhos de mão. A capacidade do carrinho e a disposição das peças variam: a comparação não substitui o limite de 1 m³.</p></div>

                </div>


                

                <div
                    id="enderecoCadastrado"
                    class="address-card"
                >

                    <div class="address-title">
                        📍 <strong>Seu endereço cadastrado</strong>
                    </div>

                    <div
                        id="textoEndereco"
                        class="address-text"
                    >
                        Carregando endereço...
                    </div>

                    <p class="address-question">
                        <strong>O endereço da coleta é este?</strong>
                    </p>

                    <div class="address-actions">

                        <button
                            type="button"
                            class="btn green-btn"
                            id="btnUsarEndereco"
                        >
                            Sim, usar este endereço
                        </button>

                        <button
                            type="button"
                            class="btn outline-btn"
                            id="btnOutroEndereco"
                        >
                            Não, informar outro
                        </button>

                    </div>

                </div>


                

                <div
                    id="outroEndereco"
                    class="other-address"
                    hidden
                >

                    <div class="address-title">
                        📍 <strong>Endereço da coleta</strong>
                    </div>

                    <p class="address-help">
                        A coleta deve ser realizada somente em
                        <strong>Pinhais/PR</strong>.
                    </p>


                    <div class="field">

                        <label for="cep">
                            CEP*
                        </label>

                        <input
                            type="text"
                            id="cep"
                            placeholder="XXXXX-XXX"
                            maxlength="9"
                            inputmode="numeric"
                        >

                    </div>


                    <div class="grid-2">

                        <div class="field">

                            <label for="estado">
                                Estado
                            </label>

                            <input
                                type="text"
                                id="estado"
                                readonly
                            >

                        </div>

                        <div class="field">

                            <label for="cidade">
                                Cidade
                            </label>

                            <input
                                type="text"
                                id="cidade"
                                readonly
                            >

                        </div>

                    </div>


                    <div class="field">

                        <label for="rua">
                            Logradouro
                        </label>

                        <input
                            type="text"
                            id="rua"
                            readonly
                        >

                    </div>


                    <div class="field">

                        <label for="bairro">
                            Bairro
                        </label>

                        <input
                            type="text"
                            id="bairro"
                            readonly
                        >

                    </div>


                    <div class="grid-2">

                        <div class="field">

                            <label for="numero">
                                Número*
                            </label>

                            <input
                                type="text"
                                id="numero"
                                placeholder="Ex.: 123"
                                maxlength="20"
                            >

                        </div>

                        <div class="field">

                            <label for="complemento">
                                Complemento
                                <span class="optional">(opcional)</span>
                            </label>

                            <input
                                type="text"
                                id="complemento"
                                placeholder="Ex.: casa, bloco, apto."
                                maxlength="100"
                            >

                        </div>

                    </div>

                </div>


                

                <div class="field">

                    <label for="descricao">
                        Descrição do material*
                    </label>

                    <textarea
                        id="descricao"
                        rows="5"
                        maxlength="1000"
                        placeholder="Descreva o estado dos materiais, tamanho, condição..."
                    ></textarea>

                </div>


                

                <div class="field">

                    <label for="foto">
                        📷 Foto do resíduo
                    </label>

                    <div
                        class="upload-box"
                        id="uploadBox"
                    >

                        <input
                            type="file"
                            id="foto"
                            accept="image/jpeg,image/png,image/webp"
                        >

                        <div class="upload-icon">
                            📷
                        </div>

                        <div class="upload-main">
                            Arraste fotos aqui ou clique para enviar
                        </div>

                        <div class="upload-help">
                            JPG, PNG ou WEBP • até 5 MB
                        </div>

                    </div>


                    <div
                        id="previewContainer"
                        class="preview-container"
                        hidden
                    >

                        <img
                            id="previewFoto"
                            src=""
                            alt="Pré-visualização da foto"
                        >

                        <button
                            type="button"
                            id="removerFoto"
                            class="remove-photo"
                        >
                            Remover foto
                        </button>

                    </div>

                </div>


                

                <div class="actions">

                    <a
                        href="dashboard_morador.php"
                        class="btn back-btn"
                    >
                        Voltar
                    </a>

                    <button
                        type="button"
                        id="enviarPedido"
                        class="btn submit-btn"
                    >
                        Enviar pedido
                    </button>

                </div>


                <div
                    id="mensagem"
                    class="message"
                    hidden
                ></div>

            </div>
