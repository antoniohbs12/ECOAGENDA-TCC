<?php

require_once __DIR__ . "/enviar_email.php";
require_once __DIR__ . "/email_mensagem.php";

function notificarMoradorStatus(
    string $emailMorador,
    string $nomeMorador,
    int $idPedido,
    string $status,
): bool {
    if (!filter_var($emailMorador, FILTER_VALIDATE_EMAIL) || $idPedido <= 0) {
        return false;
    }

    $assunto = "Atualização do pedido #{$idPedido} - EcoAgenda";
    $conteudo = eaConteudoStatus($nomeMorador, $idPedido, $status);
    $html = $conteudo["html"];

    $erro = null;

    $enviado = enviarEmailEcoAgenda($emailMorador, $assunto, $html, $conteudo["texto"], $erro);

    if (!$enviado && $erro !== null) {
        error_log("EcoAgenda SMTP - status pedido #{$idPedido}: {$erro}");
    }

    return $enviado;
}
