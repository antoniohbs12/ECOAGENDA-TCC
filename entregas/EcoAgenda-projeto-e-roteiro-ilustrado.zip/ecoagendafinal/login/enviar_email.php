<?php

require_once __DIR__ . "/email_config.php";
require_once __DIR__ . "/email_mensagem.php";

function enviarEmailEcoAgenda(
    string $destinatario,
    string $assunto,
    string $html,
    string $textoAlternativo = "",
    ?string &$erro = null,
): bool {
    $erro = null;

    if (!filter_var($destinatario, FILTER_VALIDATE_EMAIL)) {
        $erro = "Destinatário inválido.";
        return false;
    }

    foreach (
        [
            "SMTP_HOST",
            "SMTP_PORT",
            "SMTP_USERNAME",
            "SMTP_PASSWORD",
            "SMTP_FROM_EMAIL",
            "SMTP_FROM_NAME",
        ]
        as $constante
    ) {
        if (!defined($constante) || constant($constante) === "") {
            $erro = "Configuração SMTP ausente: {$constante}.";
            return false;
        }
    }

    if (!function_exists("stream_socket_client")) {
        $erro = "A função stream_socket_client do PHP não está disponível.";
        return false;
    }

    $contexto = stream_context_create([
        "ssl" => [
            "verify_peer" => true,
            "verify_peer_name" => true,
            "allow_self_signed" => false,
        ],
    ]);

    $errno = 0;
    $errstr = "";

    $socket = @stream_socket_client(
        "ssl://" . SMTP_HOST . ":" . SMTP_PORT,
        $errno,
        $errstr,
        (int) (defined("SMTP_TIMEOUT") ? SMTP_TIMEOUT : 20),
        STREAM_CLIENT_CONNECT,
        $contexto,
    );

    if ($socket === false) {
        $erro = "Não foi possível conectar ao Gmail SMTP ({$errno}): {$errstr}";
        return false;
    }

    stream_set_timeout($socket, (int) (defined("SMTP_TIMEOUT") ? SMTP_TIMEOUT : 20));

    try {
        smtpEsperarCodigo($socket, [220]);

        smtpEnviarComando($socket, "EHLO localhost", [250]);
        smtpEnviarComando($socket, "AUTH LOGIN", [334]);
        smtpEnviarComando($socket, base64_encode(SMTP_USERNAME), [334]);
        smtpEnviarComando($socket, base64_encode(SMTP_PASSWORD), [235]);
        smtpEnviarComando($socket, "MAIL FROM:<" . SMTP_FROM_EMAIL . ">", [250]);
        smtpEnviarComando($socket, "RCPT TO:<" . $destinatario . ">", [250, 251]);
        smtpEnviarComando($socket, "DATA", [354]);

        $textoAlternativo =
            $textoAlternativo !== ""
                ? $textoAlternativo
                : trim(html_entity_decode(strip_tags($html), ENT_QUOTES, "UTF-8"));

        $corpo = eaMensagemMime(
            $destinatario,
            $assunto,
            $html,
            $textoAlternativo,
            SMTP_FROM_EMAIL,
            SMTP_FROM_NAME,
        );

        $corpo = preg_replace("/^\./m", "..", $corpo);

        if (fwrite($socket, $corpo . "\r\n.\r\n") === false) {
            throw new RuntimeException("Falha ao transmitir o conteúdo do e-mail.");
        }

        smtpEsperarCodigo($socket, [250]);

        @fwrite($socket, "QUIT\r\n");
        @fgets($socket, 515);

        fclose($socket);
        return true;
    } catch (Throwable $e) {
        $erro = $e->getMessage();
        fclose($socket);
        return false;
    }
}

function smtpLerResposta($socket): string
{
    $resposta = "";

    while (($linha = fgets($socket, 515)) !== false) {
        $resposta .= $linha;

        if (preg_match("/^\d{3}\s/", $linha)) {
            break;
        }
    }

    return trim($resposta);
}

function smtpEsperarCodigo($socket, array $esperados): string
{
    $resposta = smtpLerResposta($socket);

    if (!preg_match("/^(\d{3})\b/", $resposta, $m)) {
        throw new RuntimeException("Resposta SMTP inválida.");
    }

    $codigo = (int) $m[1];

    if (!in_array($codigo, $esperados, true)) {
        throw new RuntimeException("Gmail SMTP respondeu: " . $resposta);
    }

    return $resposta;
}

function smtpEnviarComando($socket, string $comando, array $esperados): string
{
    if (fwrite($socket, $comando . "\r\n") === false) {
        throw new RuntimeException("Falha ao enviar comando SMTP.");
    }

    return smtpEsperarCodigo($socket, $esperados);
}
