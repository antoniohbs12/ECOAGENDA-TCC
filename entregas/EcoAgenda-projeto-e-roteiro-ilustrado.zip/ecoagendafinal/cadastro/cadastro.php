<?php

session_start();

require_once "../config.php";
require_once "../login/morador_provisorio.php";

$mensagem = "";
$tipoMensagem = "erro";

if ($_SERVER["REQUEST_METHOD"] === "POST") {
    $primeiroNome = trim($_POST["primeiro_nome"] ?? "");
    $sobrenome = trim($_POST["sobrenome"] ?? "");
    $nascimento = trim($_POST["nascimento"] ?? "");
    $cpf = trim($_POST["cpf"] ?? "");
    $email = trim($_POST["email"] ?? "");
    $telefone = trim($_POST["telefone"] ?? "");
    $senha = $_POST["senha"] ?? "";
    $confirmarSenha = $_POST["confirmar_senha"] ?? "";

    $cep = trim($_POST["cep"] ?? "");
    $estado = trim($_POST["estado"] ?? "");
    $cidade = trim($_POST["cidade"] ?? "");
    $rua = trim($_POST["rua"] ?? "");
    $bairro = trim($_POST["bairro"] ?? "");
    $numero = trim($_POST["numero"] ?? "");
    $complemento = trim($_POST["complemento"] ?? "");

    $pin =
        ($_POST["pin1"] ?? "") .
        ($_POST["pin2"] ?? "") .
        ($_POST["pin3"] ?? "") .
        ($_POST["pin4"] ?? "") .
        ($_POST["pin5"] ?? "") .
        ($_POST["pin6"] ?? "");

    if (
        $primeiroNome === "" ||
        $sobrenome === "" ||
        $nascimento === "" ||
        $cpf === "" ||
        $email === "" ||
        $telefone === "" ||
        $senha === "" ||
        $confirmarSenha === ""
    ) {
        $mensagem = "Preencha todos os dados pessoais obrigatórios.";
    } elseif (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
        $mensagem = "Informe um e-mail válido.";
    } elseif ($senha !== $confirmarSenha) {
        $mensagem = "As senhas não coincidem.";
    } elseif (strlen($senha) < 6) {
        $mensagem = "A senha deve possuir pelo menos 6 caracteres.";
    } elseif ($nascimento > date("Y-m-d")) {
        $mensagem = "A data de nascimento é inválida.";
    } elseif (
        !($dataNascimento = DateTime::createFromFormat("Y-m-d", $nascimento)) ||
        $dataNascimento->format("Y-m-d") !== $nascimento
    ) {
        $mensagem = "A data de nascimento é inválida.";
    } elseif ($dataNascimento->modify("+16 years") > new DateTime("today")) {
        $mensagem = "Para se cadastrar, é necessário ter pelo menos 16 anos completos.";
    } elseif ($cep === "" || $numero === "") {
        $mensagem = "CEP e número do endereço são obrigatórios.";
    } else {
        $cpf = preg_replace("/\D/", "", $cpf);
        $telefone = preg_replace("/\D/", "", $telefone);
        $cep = preg_replace("/\D/", "", $cep);

        $cpfValidadoSessao = $_SESSION["cpf_validado"] ?? "";

        if ($cpfValidadoSessao !== hash("sha256", $cpf)) {
            $mensagem = "Valide o CPF pela consulta antes de finalizar o cadastro.";
        }

        $email = strtolower($email);

        $emailPendente = $_SESSION["cadastro_email_pendente"] ?? "";
        $codigoHashSessao = $_SESSION["cadastro_codigo_hash"] ?? "";
        $codigoExpira = (int) ($_SESSION["cadastro_codigo_expira"] ?? 0);

        if (!preg_match("/^\d{6}$/", $pin)) {
            $mensagem = "Digite os 6 dígitos do código enviado para seu e-mail.";
        } elseif ($emailPendente !== $email || $codigoHashSessao === "") {
            $mensagem = "Solicite um novo código de confirmação para este e-mail.";
        } elseif ($codigoExpira < time()) {
            $mensagem = "O código expirou. Solicite um novo código por e-mail.";
        } elseif (!hash_equals($codigoHashSessao, hash("sha256", $pin))) {
            $mensagem = "Código de confirmação incorreto. Confira o e-mail e tente novamente.";
        }

        $nomeCompleto = trim($primeiroNome . " " . $sobrenome);

        if ($mensagem !== "") {
        } elseif (strlen($cpf) !== 11) {
            $mensagem = "CPF inválido.";
        } elseif (strlen($cep) !== 8) {
            $mensagem = "CEP inválido.";
        } else {
            $emailExiste = false;
            $cpfExiste = false;

            $sqlEmail = "
                    SELECT email
                    FROM usuario
                    WHERE email = ?
                    LIMIT 1
                ";

            $stmtEmail = $conn->prepare($sqlEmail);

            if (!$stmtEmail) {
                $mensagem = "Erro ao verificar e-mail: " . $conn->error;
            } else {
                $stmtEmail->bind_param("s", $email);

                $stmtEmail->execute();

                $resultadoEmail = $stmtEmail->get_result();

                $emailExiste = $resultadoEmail->num_rows > 0;

                $stmtEmail->close();
            }

            if ($mensagem === "") {
                $sqlCpf = "
                        SELECT cpf
                        FROM morador
                        WHERE REPLACE(REPLACE(REPLACE(cpf,'.',''),'-',''),' ','') = ?
                        LIMIT 1
                    ";

                $stmtCpf = $conn->prepare($sqlCpf);

                if (!$stmtCpf) {
                    $mensagem = "Erro ao verificar CPF: " . $conn->error;
                } else {
                    $stmtCpf->bind_param("s", $cpf);

                    $stmtCpf->execute();

                    $resultadoCpf = $stmtCpf->get_result();

                    $cpfExiste = $resultadoCpf->num_rows > 0;

                    $stmtCpf->close();
                }
            }

            $ativarProvisorio = eaMoradorProvisorio($conn, $cpf, $email);
            if ($ativarProvisorio) {
                $emailExiste = false;
                $cpfExiste = false;
            }
            if ($emailExiste) {
                $mensagem = "Este e-mail já está cadastrado.";
            } elseif ($cpfExiste) {
                $mensagem = "Este CPF já está cadastrado.";
            } else {
                $conn->begin_transaction();

                try {
                    $senhaHash = password_hash($senha, PASSWORD_DEFAULT);

                    if ($ativarProvisorio) {
                        $stmt = $conn->prepare(
                            "SELECT senha FROM usuario WHERE email=? FOR UPDATE",
                        );
                        $stmt->bind_param('s', $email);
                        $stmt->execute();
                        $atual = $stmt->get_result()->fetch_assoc();
                        $stmt->close();
                        if (!$atual || $atual['senha'] !== EA_SENHA_PROVISORIA) {
                            throw new RuntimeException(
                                'Este cadastro já foi ativado. Acesse sua conta.',
                            );
                        }
                        $stmt = $conn->prepare('UPDATE usuario SET senha=?,nome=? WHERE email=?');
                        $stmt->bind_param('sss', $senhaHash, $nomeCompleto, $email);
                        $stmt->execute();
                        $stmt->close();
                        $stmt = $conn->prepare(
                            'UPDATE morador SET telefone=?,nascimento=? WHERE email=?',
                        );
                        $stmt->bind_param('sss', $telefone, $nascimento, $email);
                        $stmt->execute();
                        $stmt->close();
                    } else {
                        $sqlUsuario = "
                            INSERT INTO usuario
                            (
                                email,
                                senha,
                                nome
                            )
                            VALUES
                            (
                                ?,
                                ?,
                                ?
                            )
                        ";

                        $stmtUsuario = $conn->prepare($sqlUsuario);

                        if (!$stmtUsuario) {
                            throw new Exception(
                                "Erro ao preparar cadastro do usuário: " . $conn->error,
                            );
                        }

                        $stmtUsuario->bind_param("sss", $email, $senhaHash, $nomeCompleto);

                        if (!$stmtUsuario->execute()) {
                            throw new Exception(
                                "Erro ao cadastrar usuário: " . $stmtUsuario->error,
                            );
                        }

                        $stmtUsuario->close();

                        $sqlMorador = "
                            INSERT INTO morador
                            (
                                email,
                                cpf,
                                telefone,
                                nascimento
                            )
                            VALUES
                            (
                                ?,
                                ?,
                                ?,
                                ?
                            )
                        ";

                        $stmtMorador = $conn->prepare($sqlMorador);

                        if (!$stmtMorador) {
                            throw new Exception(
                                "Erro ao preparar cadastro do morador: " . $conn->error,
                            );
                        }

                        $stmtMorador->bind_param("ssss", $email, $cpf, $telefone, $nascimento);

                        if (!$stmtMorador->execute()) {
                            throw new Exception(
                                "Erro ao cadastrar morador: " . $stmtMorador->error,
                            );
                        }

                        $stmtMorador->close();
                    }

                    $sqlEndereco = "
                            INSERT INTO endereco
                            (
                                email,
                                cep,
                                estado,
                                cidade,
                                rua,
                                bairro,
                                numero,
                                complemento
                            )
                            VALUES
                            (
                                ?,
                                ?,
                                ?,
                                ?,
                                ?,
                                ?,
                                ?,
                                ?
                            )
                        ";

                    $stmtEndereco = $conn->prepare($sqlEndereco);

                    if (!$stmtEndereco) {
                        throw new Exception(
                            "Erro ao preparar cadastro do endereço: " . $conn->error,
                        );
                    }

                    $stmtEndereco->bind_param(
                        "ssssssss",
                        $email,
                        $cep,
                        $estado,
                        $cidade,
                        $rua,
                        $bairro,
                        $numero,
                        $complemento,
                    );

                    if (!$stmtEndereco->execute()) {
                        throw new Exception("Erro ao cadastrar endereço: " . $stmtEndereco->error);
                    }

                    $enderecoId = $stmtEndereco->insert_id;

                    $stmtEndereco->close();

                    $sqlMoradorEndereco = "
                            INSERT INTO morador_endereco
                            (
                                endereco_id,
                                morador_email
                            )
                            VALUES
                            (
                                ?,
                                ?
                            )
                        ";

                    $stmtMoradorEndereco = $conn->prepare($sqlMoradorEndereco);

                    if (!$stmtMoradorEndereco) {
                        throw new Exception(
                            "Erro ao preparar vínculo do endereço: " . $conn->error,
                        );
                    }

                    $stmtMoradorEndereco->bind_param("is", $enderecoId, $email);

                    if (!$stmtMoradorEndereco->execute()) {
                        throw new Exception(
                            "Erro ao vincular endereço ao morador: " . $stmtMoradorEndereco->error,
                        );
                    }

                    $stmtMoradorEndereco->close();

                    $conn->commit();

                    unset(
                        $_SESSION["cpf_validado"],
                        $_SESSION["cadastro_email_pendente"],
                        $_SESSION["cadastro_codigo_hash"],
                        $_SESSION["cadastro_codigo_expira"],
                    );

                    header("Location: ../login/login.html?cadastro=sucesso");

                    exit();
                } catch (Throwable $e) {
                    $conn->rollback();

                    $mensagem = $e->getMessage();
                }
            }
        }
    }
}
?>
<!DOCTYPE html>
<html lang="pt-BR">

<head>

    <meta charset="UTF-8">

    <meta
        name="viewport"
        content="width=device-width, initial-scale=1.0">

    <title>EcoAgenda - Cadastro</title>

    <link
        rel="stylesheet"
        href="../recursos/estilos/cadastro/cadastro.css">

</head>

<body>

    <div class="mensagem-cadastro">

        <div class="mensagem-card">

            <?php if ($mensagem !== ""): ?>

                <h2>
                    Cadastro não realizado
                </h2>

                <p>
                    <?= htmlspecialchars($mensagem, ENT_QUOTES, "UTF-8") ?>
                </p>

                <a
                    href="cadastro.html"
                    class="btn-voltar">

                    Voltar ao cadastro

                </a>

            <?php endif; ?>

        </div>

    </div>

</body>

</html>