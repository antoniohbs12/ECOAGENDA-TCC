<?php

return require __DIR__ . "/../configuracoes/cpf.php";
