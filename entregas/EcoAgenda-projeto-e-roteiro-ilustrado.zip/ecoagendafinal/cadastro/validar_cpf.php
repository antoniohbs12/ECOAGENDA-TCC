<?php

session_start();
header("Content-Type: application/json; charset=UTF-8");

require_once __DIR__ . "/cpf_config.php";
require_once __DIR__ . "/../config.php";

function responderCPF(bool $sucesso, string $mensagem, int $statusHttp = 200): void
{
    http_response_code($statusHttp);
    echo json_encode(
        [
            "sucesso" => $sucesso,
            "mensagem" => $mensagem,
        ],
        JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES,
    );
    exit();
}

if ($_SERVER["REQUEST_METHOD"] !== "POST") {
    responderCPF(false, "Método de requisição não permitido.", 405);
}

$entrada = file_get_contents("php://input");
$dados = json_decode($entrada, true);

$cpf = preg_replace("/\D/", "", (string) ($dados["cpf"] ?? ""));

if (strlen($cpf) !== 11) {
    responderCPF(false, "Informe um CPF com 11 dígitos.", 422);
}

if (preg_match("/^(\d)\1{10}$/", $cpf)) {
    responderCPF(false, "CPF inválido.", 422);
}

if (!isset($conn) || !($conn instanceof mysqli)) {
    responderCPF(false, "Não foi possível verificar o cadastro do CPF.", 500);
}

$stmtCpfExiste = $conn->prepare("
    SELECT 1
    FROM morador m JOIN usuario u ON u.email=m.email
    WHERE REPLACE(REPLACE(REPLACE(m.cpf,'.',''),'-',''),' ','') = ? AND u.senha <> '!ecoagenda:telefone:v1'
    LIMIT 1
");

if (!$stmtCpfExiste) {
    responderCPF(false, "Erro ao verificar se o CPF já está cadastrado.", 500);
}

$stmtCpfExiste->bind_param("s", $cpf);

if (!$stmtCpfExiste->execute()) {
    $stmtCpfExiste->close();
    responderCPF(false, "Erro ao verificar se o CPF já está cadastrado.", 500);
}

$resultadoCpfExiste = $stmtCpfExiste->get_result();
$cpfJaCadastrado = $resultadoCpfExiste->num_rows > 0;
$stmtCpfExiste->close();

if ($cpfJaCadastrado) {
    if (isset($_SESSION["cpf_validado"]) && $_SESSION["cpf_validado"] === hash("sha256", $cpf)) {
        unset($_SESSION["cpf_validado"]);
    }

    responderCPF(false, "Este CPF já está cadastrado.", 409);
}

if (CPF_API_KEY === "" || CPF_API_KEY === "COLE_SEU_TOKEN_AQUI") {
    responderCPF(false, "A chave da API de CPF ainda não foi configurada no servidor.", 500);
}

$url = CPF_API_URL . rawurlencode($cpf);

$ch = curl_init($url);

if ($ch === false) {
    responderCPF(false, "Não foi possível iniciar a consulta do CPF.", 500);
}

curl_setopt_array($ch, [
    CURLOPT_HTTPGET => true,
    CURLOPT_HTTPHEADER => ["X-API-Key: " . CPF_API_KEY, "Accept: application/json"],
    CURLOPT_RETURNTRANSFER => true,
    CURLOPT_CONNECTTIMEOUT => 5,
    CURLOPT_TIMEOUT => 10,
    CURLOPT_SSL_VERIFYPEER => true,
    CURLOPT_SSL_VERIFYHOST => 2,
]);

$resposta = curl_exec($ch);
$erroCurl = curl_error($ch);
$httpCode = (int) curl_getinfo($ch, CURLINFO_HTTP_CODE);
curl_close($ch);

if ($resposta === false) {
    responderCPF(false, "Não foi possível consultar a API de CPF. Verifique sua conexão.", 502);
}

if ($erroCurl !== "") {
    responderCPF(false, "Erro de comunicação com a API de CPF.", 502);
}

$body = json_decode($resposta, true);

if (!is_array($body)) {
    responderCPF(false, "A API de CPF retornou uma resposta inválida.", 502);
}

if ($httpCode === 401 || $httpCode === 403) {
    responderCPF(
        false,
        "A chave da API de CPF foi recusada. Confira a configuração do token.",
        502,
    );
}

if ($httpCode === 429) {
    responderCPF(false, "O limite de consultas da API de CPF foi atingido.", 429);
}

if (($body["success"] ?? false) === true) {
    $_SESSION["cpf_validado"] = hash("sha256", $cpf);

    responderCPF(true, "CPF encontrado e validado.");
}

if ($httpCode >= 400 && $httpCode !== 404) {
    responderCPF(
        false,
        "Não foi possível concluir a validação do CPF agora. Tente novamente.",
        502,
    );
}

if (isset($_SESSION["cpf_validado"]) && $_SESSION["cpf_validado"] === hash("sha256", $cpf)) {
    unset($_SESSION["cpf_validado"]);
}

responderCPF(false, "CPF não encontrado.", 422);
