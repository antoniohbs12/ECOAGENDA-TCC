<?php

define('SMTP_HOST', 'smtp.gmail.com');

define('SMTP_PORT', 465);

define('SMTP_USERNAME', 'ecoagenda.tcc@gmail.com');

define('SMTP_PASSWORD', 'cowd ulxv kufc cttx');

define('SMTP_FROM_EMAIL', SMTP_USERNAME);

define('SMTP_FROM_NAME', 'EcoAgenda');

define('SMTP_TIMEOUT', 20);