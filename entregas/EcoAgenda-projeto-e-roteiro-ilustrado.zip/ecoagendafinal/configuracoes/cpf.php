<?php
/*
 * EcoAgenda - Configuração da API de CPF
 *
 * COLE SEU TOKEN APENAS NESTE ARQUIVO.
 * NÃO ENVIE ESTE ARQUIVO PARA NINGUÉM E NÃO COLOQUE O TOKEN NO JAVASCRIPT.
 */

define("CPF_API_KEY", "99339a30e283f8f2e025d31b25b6b40c");
define("CPF_API_URL", "https://api.cpf-brasil.org/cpf/");
