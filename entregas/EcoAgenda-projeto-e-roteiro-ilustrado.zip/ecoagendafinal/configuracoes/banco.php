<?php

$host = "127.0.0.1";
$usuario = "root";
$senha = "@Antonio2008";
$banco = "ecoagenda";
$porta = 3307;

$conn = new mysqli(
    $host,
    $usuario,
    $senha,
    $banco,
    $porta
);

if ($conn->connect_error) {
    die("Não foi possível conectar ao banco de dados.");
}

$conn->set_charset("utf8mb4");