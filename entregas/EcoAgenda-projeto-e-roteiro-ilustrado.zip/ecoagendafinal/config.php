<?php

return require __DIR__ . "/configuracoes/banco.php";
