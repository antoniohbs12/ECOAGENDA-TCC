<?php

session_start();

require_once "../config.php";

header("Content-Type: application/json; charset=UTF-8");

function responder(bool $erro, string $mensagem, array $dados = [], int $codigo = 200): void
{
    http_response_code($codigo);

    echo json_encode(
        array_merge(
            [
                "erro" => $erro,
                "mensagem" => $mensagem,
            ],
            $dados,
        ),
        JSON_UNESCAPED_UNICODE,
    );

    exit();
}

if (
    !isset($_SESSION["email"]) ||
    !isset($_SESSION["perfil"]) ||
    $_SESSION["perfil"] !== "morador"
) {
    responder(true, "Você precisa estar logado como morador.", [], 401);
}

$emailMorador = trim($_SESSION["email"]);

$sqlMorador = "
    SELECT
        email,
        cpf
    FROM morador
    WHERE email = ?
    LIMIT 1
";

$stmtMorador = $conn->prepare($sqlMorador);

if (!$stmtMorador) {
    responder(true, "Erro ao consultar o morador.");
}

$stmtMorador->bind_param("s", $emailMorador);

$stmtMorador->execute();

$resultadoMorador = $stmtMorador->get_result();

$morador = $resultadoMorador->fetch_assoc();

$stmtMorador->close();

if (!$morador) {
    responder(true, "Cadastro do morador não encontrado.", [], 404);
}

if ($_SERVER["REQUEST_METHOD"] === "GET") {
    $sqlEndereco = "
        SELECT
            e.id,
            e.email,
            e.cep,
            e.estado,
            e.cidade,
            e.rua,
            e.bairro,
            e.numero,
            e.complemento

        FROM endereco e

        INNER JOIN morador_endereco me
            ON me.endereco_id = e.id
           AND me.morador_email = e.email

        WHERE e.email = ?

        ORDER BY e.id DESC

        LIMIT 1
    ";

    $stmtEndereco = $conn->prepare($sqlEndereco);

    if (!$stmtEndereco) {
        responder(true, "Erro ao buscar endereço.");
    }

    $stmtEndereco->bind_param("s", $emailMorador);

    $stmtEndereco->execute();

    $resultadoEndereco = $stmtEndereco->get_result();

    $endereco = $resultadoEndereco->fetch_assoc();

    $stmtEndereco->close();

    if (!$endereco) {
        responder(false, "Nenhum endereço cadastrado.", [
            "endereco" => null,
        ]);
    }

    responder(false, "Endereço carregado.", [
        "endereco" => $endereco,
    ]);
}

if ($_SERVER["REQUEST_METHOD"] !== "POST") {
    responder(true, "Método de requisição inválido.", [], 405);
}

$tipoResiduo = trim($_POST["tipo_residuo"] ?? "");

$quantidade = trim($_POST["quantidade"] ?? "");

$descricao = trim($_POST["descricao"] ?? "");

$cep = trim($_POST["cep"] ?? "");

$estado = trim($_POST["estado"] ?? "");

$cidade = trim($_POST["cidade"] ?? "");

$rua = trim($_POST["rua"] ?? "");

$bairro = trim($_POST["bairro"] ?? "");

$numero = trim($_POST["numero"] ?? "");

$complemento = trim($_POST["complemento"] ?? "");

if ($tipoResiduo === "") {
    responder(true, "Informe o tipo de resíduo.");
}

if ($descricao === "") {
    responder(true, "Descreva o material que será coletado.");
}

if (
    $cep === "" ||
    $estado === "" ||
    $cidade === "" ||
    $rua === "" ||
    $bairro === "" ||
    $numero === ""
) {
    responder(true, "Preencha corretamente o endereço da coleta.");
}

$cidadeNormalizada = mb_strtolower(trim($cidade), "UTF-8");

$estadoNormalizado = mb_strtolower(trim($estado), "UTF-8");

if ($cidadeNormalizada !== "pinhais" || $estadoNormalizado !== "pr") {
    responder(true, "A coleta pode ser solicitada somente para endereços de Pinhais/PR.");
}

$cep = preg_replace("/\D/", "", $cep);

if (strlen($cep) !== 8) {
    responder(true, "CEP inválido.");
}

$descricaoCompleta = "Tipo de resíduo: " . $tipoResiduo;

if ($quantidade !== "") {
    $descricaoCompleta .= " | Quantidade aproximada: " . $quantidade;
}

$descricaoCompleta .= " | Descrição: " . $descricao;

if (mb_strlen($descricaoCompleta, "UTF-8") > 225) {
    responder(true, "A descrição do pedido ficou muito grande. Reduza o texto.");
}

$nomeFoto = null;
$caminhoBancoFoto = null;

if (isset($_FILES["foto"]) && $_FILES["foto"]["error"] !== UPLOAD_ERR_NO_FILE) {
    if ($_FILES["foto"]["error"] !== UPLOAD_ERR_OK) {
        responder(true, "Erro ao enviar a foto.");
    }

    if ($_FILES["foto"]["size"] > 5 * 1024 * 1024) {
        responder(true, "A foto deve ter no máximo 5 MB.");
    }

    $tiposPermitidos = ["image/jpeg", "image/png", "image/webp"];

    $tipoArquivo = mime_content_type($_FILES["foto"]["tmp_name"]);

    if (!in_array($tipoArquivo, $tiposPermitidos, true)) {
        responder(true, "Formato de imagem não permitido. Use JPG, PNG ou WEBP.");
    }

    $extensoes = [
        "image/jpeg" => "jpg",

        "image/png" => "png",

        "image/webp" => "webp",
    ];

    $extensao = $extensoes[$tipoArquivo];

    $nomeFoto = uniqid("morador_", true) . "." . $extensao;

    $pastaUpload = __DIR__ . "/uploads/";

    if (!is_dir($pastaUpload)) {
        if (!mkdir($pastaUpload, 0755, true)) {
            responder(true, "Não foi possível criar a pasta de uploads.");
        }
    }

    $caminhoFoto = $pastaUpload . $nomeFoto;

    if (!move_uploaded_file($_FILES["foto"]["tmp_name"], $caminhoFoto)) {
        responder(true, "Não foi possível salvar a foto.");
    }

    $caminhoBancoFoto = "uploads/" . $nomeFoto;
}

$conn->begin_transaction();

try {
    $sqlEnderecoExistente = "

        SELECT
            e.id

        FROM endereco e

        INNER JOIN morador_endereco me
            ON me.endereco_id = e.id
           AND me.morador_email = e.email

        WHERE
            e.email = ?
            AND e.cep = ?
            AND e.estado = ?
            AND e.cidade = ?
            AND e.rua = ?
            AND e.bairro = ?
            AND e.numero = ?
            AND (
                e.complemento = ?
                OR (
                    e.complemento IS NULL
                    AND ? = ''
                )
            )

        LIMIT 1
    ";

    $stmtEnderecoExistente = $conn->prepare($sqlEnderecoExistente);

    if (!$stmtEnderecoExistente) {
        throw new Exception("Erro ao verificar endereço: " . $conn->error);
    }

    $stmtEnderecoExistente->bind_param(
        "sssssssss",
        $emailMorador,
        $cep,
        $estado,
        $cidade,
        $rua,
        $bairro,
        $numero,
        $complemento,
        $complemento,
    );

    $stmtEnderecoExistente->execute();

    $resultadoEnderecoExistente = $stmtEnderecoExistente->get_result();

    $enderecoEncontrado = $resultadoEnderecoExistente->fetch_assoc();

    $stmtEnderecoExistente->close();

    if ($enderecoEncontrado) {
        $enderecoId = (int) $enderecoEncontrado["id"];
    } else {
        $sqlEndereco = "
                INSERT INTO endereco
                (
                    email,
                    cep,
                    estado,
                    cidade,
                    rua,
                    bairro,
                    numero,
                    complemento
                )
                VALUES
                (
                    ?,
                    ?,
                    ?,
                    ?,
                    ?,
                    ?,
                    ?,
                    NULLIF(?, '')
                )
            ";

        $stmtEndereco = $conn->prepare($sqlEndereco);

        if (!$stmtEndereco) {
            throw new Exception("Erro ao preparar endereço: " . $conn->error);
        }

        $stmtEndereco->bind_param(
            "ssssssss",
            $emailMorador,
            $cep,
            $estado,
            $cidade,
            $rua,
            $bairro,
            $numero,
            $complemento,
        );

        if (!$stmtEndereco->execute()) {
            throw new Exception("Erro ao cadastrar endereço: " . $stmtEndereco->error);
        }

        $enderecoId = (int) $stmtEndereco->insert_id;

        $stmtEndereco->close();

        $sqlMoradorEndereco = "
            INSERT INTO morador_endereco
            (
                endereco_id,
                morador_email
            )
            VALUES
            (
                ?,
                ?
            )
        ";

        $stmtMoradorEndereco = $conn->prepare($sqlMoradorEndereco);

        if (!$stmtMoradorEndereco) {
            throw new Exception("Erro ao preparar vínculo do endereço: " . $conn->error);
        }

        $stmtMoradorEndereco->bind_param("is", $enderecoId, $emailMorador);

        if (!$stmtMoradorEndereco->execute()) {
            throw new Exception(
                "Erro ao vincular endereço ao morador: " . $stmtMoradorEndereco->error,
            );
        }

        $stmtMoradorEndereco->close();
    }

    $statusInicial = "Em análise";

    $sqlStatus = "
        SELECT status
        FROM status_agendamento
        WHERE status = ?
        LIMIT 1
    ";

    $stmtStatus = $conn->prepare($sqlStatus);

    if (!$stmtStatus) {
        throw new Exception("Erro ao verificar status: " . $conn->error);
    }

    $stmtStatus->bind_param("s", $statusInicial);

    $stmtStatus->execute();

    $resultadoStatus = $stmtStatus->get_result();

    $statusExiste = $resultadoStatus->fetch_assoc();

    $stmtStatus->close();

    if (!$statusExiste) {
        throw new Exception("O status 'Em análise' não existe na tabela status_agendamento.");
    }

    $criadoPor = $emailMorador;

    $sqlAgendamento = "
        INSERT INTO agendamento
        (
            criado_por,
            descricao,
            data_pedido,
            foto,
            morador_email,
            status
        )
        VALUES
        (
            ?,
            ?,
            CURRENT_TIMESTAMP,
            ?,
            ?,
            ?
        )
    ";

    $stmtAgendamento = $conn->prepare($sqlAgendamento);

    if (!$stmtAgendamento) {
        throw new Exception("Erro ao preparar pedido: " . $conn->error);
    }

    $stmtAgendamento->bind_param(
        "sssss",
        $criadoPor,
        $descricaoCompleta,
        $caminhoBancoFoto,
        $emailMorador,
        $statusInicial,
    );

    if (!$stmtAgendamento->execute()) {
        throw new Exception("Erro ao criar pedido: " . $stmtAgendamento->error);
    }

    $agendamentoId = (int) $stmtAgendamento->insert_id;

    $stmtAgendamento->close();

    $sqlAgendamentoEndereco = "
        INSERT INTO agendamento_morador_endereco
        (
            agendamento_id,
            endereco_id,
            morador_email
        )
        VALUES
        (
            ?,
            ?,
            ?
        )
    ";

    $stmtAgendamentoEndereco = $conn->prepare($sqlAgendamentoEndereco);

    if (!$stmtAgendamentoEndereco) {
        throw new Exception("Erro ao preparar vínculo do pedido com o endereço: " . $conn->error);
    }

    $stmtAgendamentoEndereco->bind_param("iis", $agendamentoId, $enderecoId, $emailMorador);

    if (!$stmtAgendamentoEndereco->execute()) {
        throw new Exception(
            "Erro ao vincular pedido ao endereço: " . $stmtAgendamentoEndereco->error,
        );
    }

    $stmtAgendamentoEndereco->close();

    $conn->commit();

    responder(false, "Pedido criado com sucesso!", [
        "id" => $agendamentoId,
    ]);
} catch (Throwable $e) {
    $conn->rollback();

    if ($caminhoBancoFoto !== null) {
        $arquivo = __DIR__ . "/" . $caminhoBancoFoto;

        if (file_exists($arquivo)) {
            unlink($arquivo);
        }
    }

    responder(true, $e->getMessage(), [], 500);
}

?>
