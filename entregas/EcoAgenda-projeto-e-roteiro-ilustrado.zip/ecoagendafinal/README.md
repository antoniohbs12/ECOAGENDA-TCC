# EcoAgenda

Projeto PHP com MySQL. Esta versão reorganiza os arquivos sem mudar as URLs das páginas, os endpoints dos formulários ou a estrutura do banco.

## Organização

- `configuracoes/`: configurações centrais do banco, e-mail e consulta de CPF.
- `recursos/scripts/`: scripts separados em público, autenticação, cadastro, morador, Secretaria, motorista e administrador.
- `recursos/estilos/`: estilos nos mesmos grupos dos scripts.
- `assets/icons/`: ícones existentes.
- `cadastro/`: páginas e endpoints de cadastro.
- `agendamento/`: registro das solicitações e uploads existentes.
- `login/`: autenticação e recuperação de acesso.
- `login/dashboard_morador/`: funções e páginas do morador.
- `login/secretaria/`: funções e páginas da Secretaria.
- `login/motorista/`: funções e páginas do motorista; mapas mantidos.
- `login/administrador/`: funções e páginas administrativas; mapas e bibliotecas mantidos.
- `login/interface/`: componentes compartilhados, fontes e funções auxiliares.
- `documentacao/`: instruções da reorganização e resultados das verificações.

Os mapas, GeoJSON, bibliotecas cartográficas e uploads mantêm seus caminhos. A camada PHP já era dividida por perfil; essa divisão foi preservada para evitar mudanças nas rotas e nas chamadas dos formulários.

## Configurações

Edite `configuracoes/banco.php` para a conexão MySQL, `configuracoes/email.php` para e-mail e `configuracoes/cpf.php` para a integração de CPF. Os valores são os mesmos do projeto recebido.

Os arquivos `config.php`, `login/email_config.php` e `cadastro/cpf_config.php` foram mantidos como encaminhadores para a configuração central. Não os exclua: páginas existentes continuam incluindo esses caminhos. As configurações centrais preservam os nomes e o escopo das variáveis usados pelo sistema.

## Aplicação da atualização

1. Faça uma cópia da pasta atual e um backup do banco antes da substituição.
2. Se houve novos uploads ou mudanças locais desde o envio do RAR, preserve-os: este pacote contém os arquivos daquela versão recebida.
3. Coloque a pasta `ecoagendafinal` no mesmo local utilizado atualmente pelo servidor PHP. Mantenha o nome da pasta para preservar os links existentes.
4. Confira as configurações em `configuracoes/`. Não há migração SQL nem necessidade de recriar ou apagar o banco.
5. Recarregue o navegador com Ctrl+F5 para atualizar referências de arquivos que podem estar em cache.
6. Teste no ambiente local: acesso nos quatro perfis, criação de pedido, edição permitida de endereço, encaminhamento, atualização de status e mapas.

O pacote não contém um dump SQL nem altera registros do banco.
