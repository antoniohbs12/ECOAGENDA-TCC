(function () {
    const WHATS_NUMBER = "5541987075000";
    const form = document.getElementById("contactForm");
    const nameInput = document.getElementById("name");

    if (!form || !nameInput) return;

    nameInput.addEventListener("input", function () {
        if (nameInput.value.trim()) showNameError(false);
    });

    function showNameError(show) {
        nameInput.setAttribute("aria-invalid", String(show));
        const fb = nameInput.parentNode.querySelector(".invalid-feedback");
        if (show) {
            nameInput.classList.add("is-invalid");
            if (fb) fb.style.display = "block";
        } else {
            nameInput.classList.remove("is-invalid");
            if (fb) fb.style.display = "none";
        }
    }

    form.addEventListener("submit", function (e) {
        e.preventDefault();
        const nome = (nameInput.value || "").trim();
        if (!nome) {
            showNameError(true);
            nameInput.focus();
            return;
        }
        showNameError(false);

        const mensagem = `Olá! Meu nome é ${nome} e tenho uma dúvida sobre a coleta de resíduos volumosos inservíveis de madeira e móveis em Pinhais. Poderia me ajudar?`;
        const url = "https://wa.me/" + WHATS_NUMBER + "?text=" + encodeURIComponent(mensagem);

        window.open(url, "_blank", "noopener,noreferrer");
    });
})();
