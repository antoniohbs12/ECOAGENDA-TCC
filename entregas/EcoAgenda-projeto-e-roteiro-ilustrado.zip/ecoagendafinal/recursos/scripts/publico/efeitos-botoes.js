(() => {
    const init = () => {
        document
            .querySelectorAll(
                '#contactForm button[type="submit"], #criarPedidoBtn, #botaoEntrarPrincipal'
            )
            .forEach((button) => {
                button.addEventListener("pointerenter", (event) => {
                    if (event.pointerType === "mouse") button.classList.add("is-hovered");
                });
                button.addEventListener("pointerleave", () =>
                    button.classList.remove("is-hovered")
                );
                button.addEventListener("pointercancel", () =>
                    button.classList.remove("is-hovered")
                );
                button.addEventListener("blur", () => button.classList.remove("is-hovered"));
            });
    };
    if (document.readyState === "loading") document.addEventListener("DOMContentLoaded", init);
    else init();
})();
