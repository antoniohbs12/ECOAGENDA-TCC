(() => {
    const routes = {
        administrador: "login/administrador/administrador.php",
        secretaria: "login/secretaria/secretaria.php",
        motorista: "login/motorista/motorista.php"
    };
    async function session() {
        try {
            const response = await fetch("sessao.php", {
                cache: "no-store",
                credentials: "same-origin"
            });
            if (!response.ok) return;
            const data = await response.json();
            if (data.logado && routes[data.perfil]) {
                location.replace(routes[data.perfil]);
                return;
            }
            if (data.logado && data.perfil === "morador") {
                for (const id of ["menuCadastro", "menuLogin"])
                    document.getElementById(id).style.display = "none";
                for (const id of ["menuUsuario", "menuNome", "menuSair"])
                    document.getElementById(id).style.display = "block";
                document.getElementById("nomeUsuario").textContent = data.nome;
                const button = document.getElementById("botaoEntrarPrincipal");
                button.textContent = "Acessar meus pedidos";
                button.href = "login/dashboard_morador/dashboard_morador.php?secao=acompanhar";
            }
        } catch {}
    }
    function init() {
        session();
        const nav = document.getElementById("mainNav"),
            toggle = document.querySelector(".navbar-toggler"),
            menu = document.getElementById("navbarResponsive");
        function close() {
            menu.classList.remove("show");
            toggle.setAttribute("aria-expanded", "false");
        }
        toggle.addEventListener("click", () => {
            const open = menu.classList.toggle("show");
            toggle.setAttribute("aria-expanded", String(open));
            if (open && !matchMedia("(prefers-reduced-motion: reduce)").matches)
                menu.animate(
                    [
                        { opacity: 0, transform: "translateY(-8px)" },
                        { opacity: 1, transform: "none" }
                    ],
                    { duration: 200 }
                );
        });
        menu.querySelectorAll("a").forEach((a) => a.addEventListener("click", close));
        document.addEventListener("keydown", (e) => {
            if (e.key === "Escape") {
                close();
                toggle.focus();
            }
        });
        window.addEventListener(
            "scroll",
            () => nav.classList.toggle("navbar-shrink", scrollY > 20),
            { passive: true }
        );
        if (
            !matchMedia("(prefers-reduced-motion: reduce)").matches &&
            "IntersectionObserver" in window
        ) {
            const observer = new IntersectionObserver(
                (entries) =>
                    entries.forEach((entry) => {
                        if (entry.isIntersecting) {
                            entry.target.animate(
                                [
                                    { opacity: 0, transform: "translateY(18px)" },
                                    { opacity: 1, transform: "none" }
                                ],
                                { duration: 500, easing: "ease-out" }
                            );
                            observer.unobserve(entry.target);
                        }
                    }),
                { threshold: 0.12 }
            );
            document
                .querySelectorAll(".masthead-content,.page-section,.footer")
                .forEach((el) => observer.observe(el));
        }
    }
    if (document.readyState === "loading") document.addEventListener("DOMContentLoaded", init);
    else init();
    window.addEventListener("pageshow", (e) => {
        if (e.persisted) session();
    });
})();
