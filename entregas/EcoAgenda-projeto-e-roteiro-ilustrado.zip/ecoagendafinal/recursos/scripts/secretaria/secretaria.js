(() => {
    "use strict";
    const qs = (selector, root = document) => root.querySelector(selector);
    const qsa = (selector, root = document) => Array.from(root.querySelectorAll(selector));
    const sections = qsa(".section");
    const menuLinks = qsa(".menu-link");
    function abrirSecao(nome) {
        sections.forEach((section) => {
            section.classList.toggle("active", section.id === `section-${nome}`);
        });
        menuLinks.forEach((link) => {
            link.classList.toggle("active", link.dataset.section === nome);
        });
        const titulo = qs("#tituloPagina");
        const subtitulo = qs("#subtituloPagina");
        const textos = {
            inicio: ["Dashboard", "Valide e encaminhe as solicitações de coleta."],
            pedidos: ["Pedidos", "Visualize, edite, valide, encaminhe ou cancele solicitações."],
            buscar: ["Buscar pedido", "Localize um pedido por CPF ou pelo ID do pedido."],
            novo: ["Novo Pedido", "Registre uma solicitação recebida pela Secretaria."]
        };
        if (textos[nome]) {
            if (titulo) {
                titulo.textContent = textos[nome][0];
            }
            if (subtitulo) {
                subtitulo.textContent = textos[nome][1];
            }
        }
    }
    menuLinks.forEach((link) => {
        link.addEventListener("click", () => {
            abrirSecao(link.dataset.section);
        });
    });
    qsa("[data-go-section]").forEach((button) => {
        button.addEventListener("click", () => {
            abrirSecao(button.dataset.goSection);
        });
    });
    function abrirModal(id) {
        const modal = qs(`#${id}`);
        if (modal) {
            modal.hidden = false;
        }
    }
    function fecharModal(modal) {
        if (modal) {
            modal.hidden = true;
        }
    }
    qsa("[data-close-modal]").forEach((button) => {
        button.addEventListener("click", () => {
            fecharModal(button.closest(".modal"));
        });
    });
    qsa(".modal").forEach((modal) => {
        modal.addEventListener("click", (event) => {
            if (event.target === modal) {
                fecharModal(modal);
            }
        });
    });
    document.addEventListener("keydown", (event) => {
        if (event.key === "Escape") {
            qsa(".modal").forEach((modal) => {
                modal.hidden = true;
            });
        }
    });
    function dadosPedido(id) {
        return qs(`#dados-${id}`);
    }
    function valor(elemento, atributo) {
        return elemento?.dataset?.[atributo] || "";
    }
    qsa(".btn-ver-pedido").forEach((button) => {
        button.addEventListener("click", () => {
            const dados = dadosPedido(button.dataset.id);
            if (!dados) {
                return;
            }
            const texto = (valorTexto, fallback = "—") => {
                return valorTexto && valorTexto.trim() ? valorTexto : fallback;
            };
            const idEl = qs("#modalPedidoId");
            const statusEl = qs("#modalStatus");
            const moradorEl = qs("#modalMorador");
            const cpfEl = qs("#modalCpf");
            const telefoneEl = qs("#modalTelefone");
            const motoristaEl = qs("#modalMotorista");
            const dataEl = qs("#modalData");
            const horaEl = qs("#modalHora");
            const enderecoEl = qs("#modalEndereco");
            const descricaoEl = qs("#modalDescricao");
            const criadoPorEl = qs("#modalCriadoPor");
            const fotoMoradorBloco = qs("#modalFotoMoradorAtual");
            const fotoMorador = qs("#modalFotoMorador");
            const fotoMoradorLink = qs("#modalFotoMoradorLink");
            if (idEl) {
                idEl.textContent = `Pedido #${button.dataset.id}`;
            }
            if (statusEl) {
                statusEl.textContent = texto(valor(dados, "status"));
            }
            if (moradorEl) {
                moradorEl.textContent = texto(valor(dados, "morador"), "Morador");
            }
            if (cpfEl) {
                cpfEl.textContent = eaCpfVisual(valor(dados, "cpf"));
            }
            if (telefoneEl) {
                telefoneEl.textContent = texto(valor(dados, "telefone"), "Não informado");
            }
            if (motoristaEl) {
                motoristaEl.textContent = texto(valor(dados, "motorista"), "Ainda não atribuído");
            }
            const dataPedido = valor(dados, "data");
            if (dataEl) {
                if (dataPedido) {
                    const dt = new Date(dataPedido.replace(" ", "T"));
                    if (!Number.isNaN(dt.getTime())) {
                        dataEl.textContent = dt.toLocaleDateString("pt-BR");
                    } else {
                        dataEl.textContent = dataPedido;
                    }
                } else {
                    dataEl.textContent = "—";
                }
            }
            if (horaEl) {
                horaEl.textContent = valor(dados, "hora") || "Ainda não registrado";
            }
            if (enderecoEl) {
                enderecoEl.textContent = texto(valor(dados, "endereco"), "Não informado");
            }
            if (descricaoEl) {
                descricaoEl.textContent = texto(valor(dados, "descricao"));
            }
            if (criadoPorEl) {
                criadoPorEl.textContent = texto(valor(dados, "criado"));
            }
            const fotoMoradorCaminho = valor(dados, "fotoMorador");
            if (fotoMoradorCaminho && fotoMoradorBloco && fotoMorador && fotoMoradorLink) {
                const urlFoto = `../../agendamento/${fotoMoradorCaminho}`;
                fotoMorador.src = urlFoto;
                fotoMoradorLink.href = urlFoto;
                fotoMoradorBloco.hidden = false;
            } else {
                if (fotoMorador) {
                    fotoMorador.src = "";
                }
                if (fotoMoradorLink) {
                    fotoMoradorLink.href = "#";
                }
                if (fotoMoradorBloco) {
                    fotoMoradorBloco.hidden = true;
                }
            }
            abrirModal("modalDetalhes");
        });
    });
    qsa(".btn-editar").forEach((button) => {
        button.addEventListener("click", () => {
            const dados = dadosPedido(button.dataset.id);
            if (!dados) {
                return;
            }
            const setValue = (selector, atributo) => {
                const field = qs(selector);
                if (field) {
                    field.value = valor(dados, atributo);
                }
            };
            const id = qs("#editarId");
            const titulo = qs("#editarNumero");
            if (id) {
                id.value = button.dataset.id;
            }
            if (titulo) {
                titulo.textContent = `Pedido #${button.dataset.id}`;
            }
            setValue("#editarDescricao", "descricao");
            setValue("#editarCep", "cep");
            setValue("#editarEstado", "estado");
            setValue("#editarCidade", "cidade");
            setValue("#editarRua", "rua");
            setValue("#editarBairro", "bairro");
            setValue("#editarNumeroEndereco", "numero");
            setValue("#editarComplemento", "complemento");
            abrirModal("modalEditar");
        });
    });
    qsa(".btn-encaminhar").forEach((button) => {
        button.addEventListener("click", () => {
            const input = qs("#encaminharId");
            const titulo = qs("#encaminharNumero");
            if (input) {
                input.value = button.dataset.id;
            }
            if (titulo) {
                titulo.textContent = `Pedido #${button.dataset.id}`;
            }
            abrirModal("modalEncaminhar");
        });
    });
    qsa(".filtro").forEach((button) => {
        button.addEventListener("click", () => {
            qsa(".filtro").forEach((item) => {
                item.classList.remove("active");
            });
            button.classList.add("active");
            const filtro = button.dataset.filter;
            let visiveis = 0;
            qsa(".pedido-card").forEach((card) => {
                const mostrar = filtro === "todos" || card.dataset.status === filtro;
                card.style.display = mostrar ? "" : "none";
                if (mostrar) {
                    visiveis++;
                }
            });
            const vazio = qs("#semResultadoFiltro");
            if (vazio) {
                vazio.hidden = visiveis !== 0;
            }
        });
    });
    function limparCPF(valor) {
        return valor.replace(/\D/g, "");
    }
    function formatarCPF(valor) {
        const numeros = limparCPF(valor).slice(0, 11);
        if (numeros.length <= 3) {
            return numeros;
        }
        if (numeros.length <= 6) {
            return `${numeros.slice(0, 3)}.` + `${numeros.slice(3)}`;
        }
        if (numeros.length <= 9) {
            return `${numeros.slice(0, 3)}.` + `${numeros.slice(3, 6)}.` + `${numeros.slice(6)}`;
        }
        return (
            `${numeros.slice(0, 3)}.` +
            `${numeros.slice(3, 6)}.` +
            `${numeros.slice(6, 9)}-` +
            `${numeros.slice(9)}`
        );
    }
    [qs("#cpfBusca"), qs("#novoCpf")].forEach((input) => {
        if (!input) {
            return;
        }
        input.addEventListener("input", () => {
            input.value = formatarCPF(input.value);
        });
    });
    const tipoBuscaCpf = qs("#tipoBuscaCpf");
    const tipoBuscaId = qs("#tipoBuscaId");
    const campoBuscaPedido = qs("#campoBuscaPedido");
    const buscarPedidoButton = qs("#buscarPedido");
    const resultadoBuscaPedido = qs("#resultadoBuscaPedido");
    const resultadoPedidosBusca = qs("#resultadoPedidosBusca");

    let tipoBuscaPedido = "cpf";

    function limparResultadoBuscaPedido() {
        if (resultadoBuscaPedido) {
            resultadoBuscaPedido.textContent = "";
        }

        if (resultadoPedidosBusca) {
            resultadoPedidosBusca.innerHTML = "";
        }
    }

    function atualizarTipoBusca(tipo) {
        tipoBuscaPedido = tipo;

        if (!campoBuscaPedido) return;

        const ativarBotao = (botao, ativo) => {
            if (!botao) return;
            botao.classList.toggle("btn-primary", ativo);
            botao.classList.toggle("btn-secondary", !ativo);
            botao.classList.toggle("active", ativo);
        };

        ativarBotao(tipoBuscaCpf, tipo === "cpf");
        ativarBotao(tipoBuscaId, tipo === "id");

        campoBuscaPedido.value = "";
        limparResultadoBuscaPedido();

        if (tipo === "cpf") {
            campoBuscaPedido.placeholder = "Digite o CPF";
            campoBuscaPedido.maxLength = 14;
        } else {
            campoBuscaPedido.placeholder = "Digite o ID do pedido";
            campoBuscaPedido.maxLength = 20;
        }
    }

    function mostrarPedidosEncontrados(encontrados) {
        if (!resultadoPedidosBusca) return;

        resultadoPedidosBusca.innerHTML = "";

        encontrados.forEach((card) => {
            const clone = card.cloneNode(true);
            const dados = clone.querySelector(".dados-pedido");
            if (dados) {
                dados.remove();
            }

            const acoes = clone.querySelector(".pedido-actions");
            if (acoes) {
                acoes
                    .querySelectorAll(".btn-editar, .btn-encaminhar, .inline-form")
                    .forEach((el) => el.remove());

                if (!acoes.querySelector(".btn-historico-pedido")) {
                    const botaoHistorico = document.createElement("button");
                    botaoHistorico.type = "button";
                    botaoHistorico.className = "btn-small btn-historico-pedido";
                    botaoHistorico.dataset.id = card.dataset.id || "";
                    botaoHistorico.textContent = "Mostrar histórico";
                    acoes.appendChild(botaoHistorico);
                }
            }

            resultadoPedidosBusca.appendChild(clone);
        });
    }

    const historicoPedidosSecretariaEl = document.getElementById("historicoPedidosSecretaria");

    let historicoPedidosSecretaria = [];

    if (historicoPedidosSecretariaEl) {
        try {
            historicoPedidosSecretaria = JSON.parse(
                historicoPedidosSecretariaEl.textContent || "[]"
            );
        } catch (erro) {
            console.error("Não foi possível carregar o histórico dos pedidos.", erro);
        }
    }

    const modalHistoricoPedido = qs("#modalHistoricoPedido");

    const historicoPedidoLista = qs("#historicoPedidoLista");

    const historicoPedidoVazio = qs("#historicoPedidoVazio");

    const historicoPedidoNumero = qs("#historicoPedidoNumero");

    const escaparHtml = (valor) =>
        String(valor ?? "")
            .replace(/&/g, "&amp;")
            .replace(/</g, "&lt;")
            .replace(/>/g, "&gt;")
            .replace(/"/g, "&quot;")
            .replace(/'/g, "&#039;");

    const formatarDataHoraHistorico = (valor) => {
        if (!valor) return "—";
        const data = new Date(String(valor).replace(" ", "T"));
        if (Number.isNaN(data.getTime())) return String(valor);
        return data.toLocaleString("pt-BR");
    };

    const formatarDataHistorico = (valor) => {
        if (!valor) return "—";
        const data = new Date(String(valor).replace(" ", "T"));
        if (Number.isNaN(data.getTime())) return String(valor);
        return data.toLocaleString("pt-BR");
    };

    const classeHistoricoStatus = (status) => {
        const normalizado = String(status || "")
            .toLowerCase()
            .normalize("NFD")
            .replace(/[\u0300-\u036f]/g, "");

        if (normalizado.includes("conclu")) return "concluido";
        if (normalizado.includes("andamento")) return "andamento";
        if (normalizado.includes("cancel") || normalizado.includes("suspens")) return "cancelado";
        if (normalizado.includes("encamin") || normalizado.includes("agend")) return "confirmado";
        return "pendente";
    };

    function abrirHistoricoPedido(id) {
        const registros = historicoPedidosSecretaria.filter(
            (registro) => String(registro.agendamento_id) === String(id)
        );

        if (!modalHistoricoPedido || !historicoPedidoLista || !historicoPedidoVazio) {
            return;
        }

        if (historicoPedidoNumero) {
            historicoPedidoNumero.textContent = `Pedido #${id}`;
        }

        historicoPedidoLista.innerHTML = "";

        if (!registros.length) {
            historicoPedidoVazio.hidden = false;
            abrirModal("modalHistoricoPedido");
            return;
        }

        historicoPedidoVazio.hidden = true;

        historicoPedidoLista.innerHTML = registros
            .map((registro, indice) => {
                const statusClasse = classeHistoricoStatus(registro.status);
                const foto = registro.foto
                    ? `../../agendamento/${String(registro.foto).replace(/^\/+/, "")}`
                    : "";

                const fotoHtml = foto
                    ? `
                    <div class="historico-registro-foto">
                        <span class="historico-label">Foto registrada</span>
                        <a href="${escaparHtml(foto)}" target="_blank" rel="noopener" class="historico-foto-link">
                            <img src="${escaparHtml(foto)}" alt="Foto registrada no histórico" loading="lazy">
                            <span>Abrir foto</span>
                        </a>
                    </div>`
                    : `
                    <div class="historico-registro-foto sem-foto-historico">
                        <span class="historico-label">Foto registrada</span>
                        <strong>Não há foto neste registro.</strong>
                    </div>`;

                return `
                <article class="historico-registro-card">
                    <div class="historico-registro-topo">
                        <div>
                            <span class="historico-registro-numero">REGISTRO ${indice + 1}</span>
                            <strong class="historico-registro-data">${escaparHtml(formatarDataHoraHistorico(registro.data_comando))}</strong>
                        </div>
                        <span class="historico-status ${escaparHtml(statusClasse)}">${escaparHtml(registro.status || "—")}</span>
                    </div>

                    <div class="historico-campos-grid">
                        <div class="historico-campo destaque">
                            <span>Ação registrada</span>
                            <strong>${escaparHtml(registro.comando || "—")}</strong>
                        </div>
                        <div class="historico-campo">
                            <span>Morador</span>
                            <strong>${escaparHtml(registro.morador_email || "—")}</strong>
                        </div>
                        <div class="historico-campo">
                            <span>Quem realizou</span>
                            <strong>${escaparHtml(registro.perfil_usuario || "Secretaria")}</strong>
                        </div>
                        <div class="historico-campo">
                            <span>Criado por</span>
                            <strong>${escaparHtml(registro.criado_por || "—")}</strong>
                        </div>
                        <div class="historico-campo">
                            <span>Data original do pedido</span>
                            <strong>${escaparHtml(formatarDataHistorico(registro.data_pedido))}</strong>
                        </div>
                    </div>

                    <div class="historico-campo historico-descricao">
                        <span>Descrição registrada</span>
                        <p>${escaparHtml(registro.descricao || "—")}</p>
                    </div>

                    ${fotoHtml}
                </article>`;
            })
            .join("");

        abrirModal("modalHistoricoPedido");
    }

    document.addEventListener("click", (event) => {
        const botaoHistorico = event.target.closest(".btn-historico-pedido");
        if (!botaoHistorico) return;

        const id = String(botaoHistorico.dataset.id || "");
        if (!id) return;

        abrirHistoricoPedido(id);
    });

    if (tipoBuscaCpf) {
        tipoBuscaCpf.addEventListener("click", () => {
            atualizarTipoBusca("cpf");
        });
    }

    if (tipoBuscaId) {
        tipoBuscaId.addEventListener("click", () => {
            atualizarTipoBusca("id");
        });
    }

    if (campoBuscaPedido) {
        campoBuscaPedido.addEventListener("input", (event) => {
            if (tipoBuscaPedido === "cpf") {
                campoBuscaPedido.value = formatarCPF(event.target.value);
            } else {
                campoBuscaPedido.value = event.target.value.replace(/\D/g, "");
            }
        });

        campoBuscaPedido.addEventListener("keydown", (event) => {
            if (event.key === "Enter") {
                event.preventDefault();
                buscarPedidoButton?.click();
            }
        });
    }

    if (buscarPedidoButton && campoBuscaPedido) {
        buscarPedidoButton.addEventListener("click", () => {
            const cards = qsa("#section-pedidos .pedido-card");
            let encontrados = [];

            if (tipoBuscaPedido === "cpf") {
                const cpf = limparCPF(campoBuscaPedido.value);

                if (cpf.length !== 11) {
                    if (resultadoBuscaPedido) {
                        resultadoBuscaPedido.textContent =
                            "Digite um CPF completo para realizar a busca.";
                    }
                    if (resultadoPedidosBusca) {
                        resultadoPedidosBusca.innerHTML = "";
                    }
                    return;
                }

                encontrados = cards.filter((card) => {
                    return limparCPF(card.dataset.cpf || "") === cpf;
                });
            } else {
                const id = campoBuscaPedido.value.replace(/\D/g, "");

                if (!id) {
                    if (resultadoBuscaPedido) {
                        resultadoBuscaPedido.textContent =
                            "Digite o ID do pedido para realizar a busca.";
                    }
                    if (resultadoPedidosBusca) {
                        resultadoPedidosBusca.innerHTML = "";
                    }
                    return;
                }

                encontrados = cards.filter((card) => {
                    return String(card.dataset.id || "") === id;
                });
            }

            if (resultadoBuscaPedido) {
                resultadoBuscaPedido.textContent = "";
            }

            if (encontrados.length === 0) {
                if (resultadoBuscaPedido) {
                    resultadoBuscaPedido.innerHTML = "<strong>Nenhum pedido encontrado.</strong>";
                }

                if (resultadoPedidosBusca) {
                    resultadoPedidosBusca.innerHTML = "";
                }

                return;
            }

            mostrarPedidosEncontrados(encontrados);
        });
    }

    if (resultadoPedidosBusca) {
        resultadoPedidosBusca.addEventListener("click", (event) => {
            const botaoHistorico = event.target.closest(".btn-historico-pedido");
            if (botaoHistorico) {
                const id = String(botaoHistorico.dataset.id || "");
                if (id) {
                    abrirHistoricoPedido(id);
                }
                return;
            }

            const botao = event.target.closest(".btn-ver-pedido");
            if (!botao) return;

            const id = String(botao.dataset.id || "");
            if (!id) return;

            const original = qsa(`#section-pedidos .btn-ver-pedido`).find(
                (item) => String(item.dataset.id || "") === id
            );

            if (original) {
                original.click();
            }
        });
    }

    atualizarTipoBusca("cpf");

    const novoCpfCampo = qs("#novoCpf");
    const novoTelefoneCampo = qs("#novoTelefone");
    const novoEmailCampo = qs("#novoEmail");
    const novoNomeCampo = qs("#novoNome");
    let consultaCpf = 0;

    function limparDadosMorador() {
        for (const campo of [novoNomeCampo, novoEmailCampo, novoTelefoneCampo]) {
            if (campo) {
                campo.readOnly = false;
                campo.value = "";
            }
        }
        if (novoEmailCampo) novoEmailCampo.value = "";
    }

    function formatarTelefone(valor) {
        const numeros = (valor || "").replace(/\D/g, "").slice(0, 11);

        if (numeros.length <= 10) {
            if (numeros.length <= 2) return numeros;
            return `(${numeros.slice(0, 2)}) ${numeros.slice(2, 6)}-${numeros.slice(6)}`;
        }

        return `(${numeros.slice(0, 2)}) ${numeros.slice(2, 7)}-${numeros.slice(7)}`;
    }

    async function buscarMoradorPorCPF() {
        if (!novoCpfCampo) return;

        const cpf = novoCpfCampo.value.replace(/\D/g, "");
        const consulta = ++consultaCpf;

        if (cpf.length !== 11) {
            limparDadosMorador();
            return;
        }

        try {
            const dados = new FormData();
            dados.append("acao", "buscar_morador");
            dados.append("cpf", cpf);

            const resposta = await fetch("secretaria.php", {
                method: "POST",
                body: dados
            });

            if (!resposta.ok) {
                throw new Error("Não foi possível consultar o morador.");
            }

            const resultado = await resposta.json();
            if (consulta !== consultaCpf || cpf !== novoCpfCampo.value.replace(/\D/g, "")) return;

            if (!resultado.sucesso) {
                limparDadosMorador();
                alert(resultado.mensagem || "Morador não encontrado.");
                return;
            }

            limparDadosMorador();
            const aviso = qs("#novoMoradorAviso");
            if (resultado.encontrado === false) {
                aviso.textContent = resultado.mensagem;
                novoNomeCampo?.focus();
                return;
            }
            aviso.textContent = "Dados localizados. Os pedidos serão vinculados a este morador.";
            if (novoNomeCampo) novoNomeCampo.value = resultado.nome || "";
            for (const campo of [novoNomeCampo, novoEmailCampo, novoTelefoneCampo])
                if (campo) campo.readOnly = true;
            if (novoTelefoneCampo) {
                novoTelefoneCampo.value = formatarTelefone(resultado.telefone || "");
            }

            if (novoEmailCampo) {
                novoEmailCampo.value = resultado.email || "";
            }
        } catch (erro) {
            console.error("Erro ao buscar morador:", erro);
            limparDadosMorador();
            alert("Não foi possível consultar o cadastro do morador.");
        }
    }

    if (novoCpfCampo) {
        novoCpfCampo.addEventListener("blur", buscarMoradorPorCPF);
        novoCpfCampo.addEventListener("input", () => {
            consultaCpf++;
            limparDadosMorador();
        });
    }

    const formNovoPedido = qs("#section-novo form");

    if (formNovoPedido) {
        formNovoPedido.addEventListener("reset", () => {
            setTimeout(limparDadosMorador, 0);
        });
    }

    function formatarCEP(valor) {
        const numeros = (valor || "").replace(/\D/g, "").slice(0, 8);
        if (numeros.length <= 5) {
            return numeros;
        }
        return `${numeros.slice(0, 5)}-` + `${numeros.slice(5)}`;
    }
    function limparCamposEndereco(campos) {
        const ids = [campos.estado, campos.cidade, campos.rua, campos.bairro];
        ids.forEach((id) => {
            const campo = qs(id);
            if (campo) {
                campo.value = "";
            }
        });
    }
    async function consultarCEP(inputId, campos) {
        const input = qs(inputId);
        if (!input) {
            return;
        }
        const cep = input.value.replace(/\D/g, "");
        if (cep.length !== 8) {
            return;
        }
        input.value = formatarCEP(cep);
        const camposCarregando = [campos.estado, campos.cidade, campos.rua, campos.bairro];
        camposCarregando.forEach((id) => {
            const campo = qs(id);
            if (campo) {
                campo.value = "Consultando...";
            }
        });
        try {
            const resposta = await fetch(`https://viacep.com.br/ws/${cep}/json/`);
            if (!resposta.ok) {
                throw new Error("Erro ao consultar o ViaCEP.");
            }
            const dados = await resposta.json();
            if (dados.erro) {
                limparCamposEndereco(campos);
                alert("CEP não encontrado.");
                return;
            }
            if (inputId === "#novoCep") {
                const cidade = (dados.localidade || "").trim().toLowerCase();
                const estado = (dados.uf || "").trim().toUpperCase();
                if (cidade !== "pinhais" || estado !== "PR") {
                    limparCamposEndereco(campos);
                    input.value = "";
                    alert("O endereço da coleta precisa ser de Pinhais/PR.");
                    input.focus();
                    return;
                }
            }
            const preencher = (seletor, valorCampo) => {
                const campo = qs(seletor);
                if (campo) {
                    campo.value = valorCampo || "";
                }
            };
            preencher(campos.estado, dados.uf);
            preencher(campos.cidade, dados.localidade);
            preencher(campos.rua, dados.logradouro);
            preencher(campos.bairro, dados.bairro);
        } catch (erro) {
            console.error("Erro ao consultar CEP:", erro);
            limparCamposEndereco(campos);
            alert("Não foi possível consultar o CEP. Verifique sua conexão.");
        }
    }
    [
        {
            input: "#novoCep",
            campos: {
                estado: "#novoEstado",
                cidade: "#novoCidade",
                rua: "#novoRua",
                bairro: "#novoBairro"
            }
        },
        {
            input: "#editarCep",
            campos: {
                estado: "#editarEstado",
                cidade: "#editarCidade",
                rua: "#editarRua",
                bairro: "#editarBairro"
            }
        }
    ].forEach((config) => {
        const input = qs(config.input);
        if (!input) {
            return;
        }
        input.addEventListener("input", () => {
            input.value = formatarCEP(input.value);
        });
        input.addEventListener("blur", () => {
            const cep = input.value.replace(/\D/g, "");
            if (cep.length === 8) {
                consultarCEP(config.input, config.campos);
            }
        });
    });
    abrirSecao("inicio");
})();
