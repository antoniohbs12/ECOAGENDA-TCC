document.addEventListener("DOMContentLoaded", () => {

    const botaoCriarPedido =
        document.getElementById("criarPedidoBtn");


    if (!botaoCriarPedido) {
        return;
    }


    botaoCriarPedido.addEventListener(
        "click",
        async (event) => {

            event.preventDefault();


            try {

                const resposta =
                    await fetch(
                        "sessao.php",
                        {
                            method: "GET",
                            credentials: "same-origin"
                        }
                    );


                const dados =
                    await resposta.json();


                /* NÃO ESTÁ LOGADO */

                if (!dados.logado) {

                    window.location.href =
                        "login/login.html";

                    return;

                }


                /* MORADOR LOGADO */

                if (
                    dados.perfil === "morador"
                ) {

                    window.location.href =
                        "login/dashboard_morador/dashboard_morador.php?secao=novo-pedido";

                    return;

                }


                /* OUTROS PERFIS */

                alert(
                    "Esta opção está disponível para moradores."
                );

            } catch (erro) {

                console.error(
                    "Erro ao verificar sessão:",
                    erro
                );

                window.location.href =
                    "login/login.html";

            }

        }
    );

});