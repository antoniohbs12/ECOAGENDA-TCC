document.addEventListener("DOMContentLoaded", () => {

    const filtros = document.querySelectorAll(".filtro");
    const pedidos = document.querySelectorAll(".pedido");
    const semResultado = document.getElementById("semResultadoFiltro");


    /* ABRIR / FECHAR DETALHES */

    pedidos.forEach((pedido) => {

        const botao = pedido.querySelector(".btn-detalhes");
        const detalhes = pedido.querySelector(".pedido-detalhes");

        if (!botao || !detalhes) {
            return;
        }

        botao.addEventListener("click", () => {

            const estavaFechado = detalhes.hidden;

            /* Fecha outros pedidos */
            if (estavaFechado) {

                pedidos.forEach((outroPedido) => {

                    if (outroPedido === pedido) {
                        return;
                    }

                    const outrosDetalhes =
                        outroPedido.querySelector(".pedido-detalhes");

                    const outroBotao =
                        outroPedido.querySelector(".btn-detalhes");

                    if (outrosDetalhes) {
                        outrosDetalhes.hidden = true;
                    }

                    if (outroBotao) {

                        const abrir =
                            outroBotao.querySelector(".texto-abrir");

                        const fechar =
                            outroBotao.querySelector(".texto-fechar");

                        if (abrir) {
                            abrir.hidden = false;
                        }

                        if (fechar) {
                            fechar.hidden = true;
                        }

                    }

                });
            }


            /* Abre ou fecha o pedido clicado */
            detalhes.hidden = !estavaFechado;


            const textoAbrir =
                botao.querySelector(".texto-abrir");

            const textoFechar =
                botao.querySelector(".texto-fechar");


            if (textoAbrir) {
                textoAbrir.hidden = estavaFechado;
            }

            if (textoFechar) {
                textoFechar.hidden = !estavaFechado;
            }


            /* Leva o pedido para uma posição confortável */
            if (estavaFechado) {

                setTimeout(() => {

                    pedido.scrollIntoView({
                        behavior: "smooth",
                        block: "nearest"
                    });

                }, 50);

            }

        });

    });


    /* FILTROS */

    filtros.forEach((filtro) => {

        filtro.addEventListener("click", () => {

            const filtroSelecionado =
                filtro.dataset.filtro;


            filtros.forEach((item) => {
                item.classList.remove("active");
            });

            filtro.classList.add("active");


            let encontrados = 0;


            pedidos.forEach((pedido) => {

                const status =
                    pedido.dataset.status;

                const mostrar =
                    filtroSelecionado === "todos" ||
                    status === filtroSelecionado;

                pedido.hidden = !mostrar;


                if (mostrar) {
                    encontrados++;
                }


                /*
                   Se o pedido foi escondido pelo filtro,
                   também fecha os detalhes.
                */

                if (!mostrar) {

                    const detalhes =
                        pedido.querySelector(".pedido-detalhes");

                    const botao =
                        pedido.querySelector(".btn-detalhes");

                    if (detalhes) {
                        detalhes.hidden = true;
                    }

                    if (botao) {

                        const abrir =
                            botao.querySelector(".texto-abrir");

                        const fechar =
                            botao.querySelector(".texto-fechar");

                        if (abrir) {
                            abrir.hidden = false;
                        }

                        if (fechar) {
                            fechar.hidden = true;
                        }

                    }

                }

            });


            if (semResultado) {
                semResultado.hidden =
                    encontrados > 0;
            }

        });

    });

});
