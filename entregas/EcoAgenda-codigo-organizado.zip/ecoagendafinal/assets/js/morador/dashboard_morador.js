document.addEventListener("DOMContentLoaded", () => {

    const parametros =
        new URLSearchParams(window.location.search);

    const secao =
        parametros.get("secao");


    if (secao === "novo-pedido") {

        const botaoNovoPedido =
            document.querySelector(
                '[data-section="novo-pedido"]'
            );


        if (botaoNovoPedido) {

            botaoNovoPedido.click();

        }

    }

});