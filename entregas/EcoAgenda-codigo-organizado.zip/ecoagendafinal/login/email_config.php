<?php
// Compatibilidade com os includes existentes. Configuração centralizada em config/.
return require __DIR__ . '/../config/email.php';
