<?php

session_start();

require_once "../config.php";


/* VERIFICAR LOGIN */

if (!isset($_SESSION["email"])) {

    header("Location: login.html");
    exit();

}


/* VERIFICAR MOTORISTA */

if (
    !isset($_SESSION["perfil"]) ||
    $_SESSION["perfil"] !== "motorista"
) {

    header("Location: ../index.html");
    exit();

}


/* RECEBER DADOS */

$idPedido = $_POST["id"] ?? "";

$novoStatus = $_POST["status"] ?? "";


if (
    empty($idPedido) ||
    empty($novoStatus)
) {

    header("Location: motorista.php");
    exit();

}


$idPedido = (int)$idPedido;

$novoStatus = (int)$novoStatus;


/* STATUS PERMITIDOS */

$statusPermitidos = [
    2,
    3,
    4,
    5
];


if (!in_array(
    $novoStatus,
    $statusPermitidos
)) {

    header("Location: motorista.php");
    exit();

}


/* VERIFICAR SE EXISTE FOTO */

if (
    isset($_FILES["foto_motorista"]) &&
    $_FILES["foto_motorista"]["error"] === UPLOAD_ERR_OK
) {

    $arquivo = $_FILES["foto_motorista"];


    /* LIMITE DE 10 MB */

    if ($arquivo["size"] > 10 * 1024 * 1024) {

        die(
            "A foto deve ter no máximo 10 MB."
        );

    }


    /* VERIFICAR TIPO REAL DO ARQUIVO */

    $finfo = finfo_open(FILEINFO_MIME_TYPE);

    $tipo = finfo_file(
        $finfo,
        $arquivo["tmp_name"]
    );

    finfo_close($finfo);


    /* FORMATOS PERMITIDOS */

    $tiposPermitidos = [

        "image/jpeg" => "jpg",

        "image/png" => "png",

        "image/webp" => "webp",

        "image/avif" => "avif",

        "image/heic" => "heic",

        "image/heif" => "heif"

    ];


    if (!isset(
        $tiposPermitidos[$tipo]
    )) {

        die(
            "Formato de imagem não permitido. " .
            "Tipo recebido: " .
            htmlspecialchars($tipo)
        );

    }


    $extensao =
        $tiposPermitidos[$tipo];


    /* CRIAR PASTA */

    $pasta =
        "../agendamento/uploads/";


    if (!is_dir($pasta)) {

        if (!mkdir(
            $pasta,
            0777,
            true
        )) {

            die(
                "Não foi possível criar a pasta de uploads."
            );

        }

    }


    /* NOME ÚNICO */

    $nomeArquivo =
        "motorista_" .
        $idPedido .
        "_" .
        time() .
        "." .
        $extensao;


    $caminhoCompleto =
        $pasta .
        $nomeArquivo;


    /* SALVAR FOTO */

    if (!move_uploaded_file(
        $arquivo["tmp_name"],
        $caminhoCompleto
    )) {

        die(
            "Não foi possível salvar a foto."
        );

    }


    /* CAMINHO NO BANCO */

    $fotoMotorista =
        "uploads/" .
        $nomeArquivo;


    /* ATUALIZAR FOTO */

    $sqlFoto = "
        UPDATE agendamento
        SET foto_motorista = ?
        WHERE ID = ?
    ";


    $stmtFoto =
        $conn->prepare($sqlFoto);


    if (!$stmtFoto) {

        die(
            "Erro ao preparar foto: " .
            $conn->error
        );

    }


    $stmtFoto->bind_param(
        "si",
        $fotoMotorista,
        $idPedido
    );


    if (!$stmtFoto->execute()) {

        die(
            "Erro ao salvar foto no banco: " .
            $stmtFoto->error
        );

    }


    $stmtFoto->close();

}


/* ATUALIZAR STATUS */

$sql = "
    UPDATE agendamento
    SET status_id = ?
    WHERE ID = ?
";


$stmt =
    $conn->prepare($sql);


if (!$stmt) {

    die(
        "Erro ao preparar atualização: " .
        $conn->error
    );

}


$stmt->bind_param(
    "ii",
    $novoStatus,
    $idPedido
);


if (!$stmt->execute()) {

    die(
        "Erro ao atualizar status: " .
        $stmt->error
    );

}


$stmt->close();

$conn->close();


/* VOLTAR PARA MOTORISTA */

header(
    "Location: motorista.php"
);

exit();

?>