<?php

session_start();

/* VERIFICA SE O USUÁRIO ESTÁ LOGADO */

if (!isset($_SESSION["email"])) {

    header("Location: ../index.html");
    exit();

}


/* VERIFICA SE O USUÁRIO É MORADOR */

if (
    !isset($_SESSION["perfil"]) ||
    $_SESSION["perfil"] !== "morador"
) {

    header("Location: ../index.html");
    exit();

}

?>