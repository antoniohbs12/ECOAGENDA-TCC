<?php

session_start();

require_once "../config.php";


/* FUNÇÃO DE REDIRECIONAMENTO POR PERFIL */

function redirecionarPerfil($perfil)
{
    switch ($perfil) {

        case "morador":
            header("Location: dashboard_morador/dashboard_morador.php");
            exit();

        case "secretaria":
            header("Location: secretaria/secretaria.php");
            exit();

        case "motorista":
            header("Location: motorista/motorista.php");
            exit();

        case "administrador":
            header("Location: administrador/administrador.php");
            exit();

        default:
            header("Location: login.html");
            exit();
    }
}


/* SE JÁ ESTIVER LOGADO */

if (
    isset($_SESSION["email"]) &&
    isset($_SESSION["perfil"])
) {

    redirecionarPerfil(
        $_SESSION["perfil"]
    );
}


/* LOGIN */

if ($_SERVER["REQUEST_METHOD"] !== "POST") {

    header("Location: login.html");
    exit();
}


$identificador = trim(
    $_POST["login"] ??
    $_POST["email"] ??
    ""
);

$senha = $_POST["senha"] ?? "";


/* VALIDAÇÃO */

if ($identificador === "" || $senha === "") {

    header(
        "Location: login.html?erro=" .
        urlencode("Informe seu e-mail ou CPF e a senha.")
    );

    exit();
}


/* IDENTIFICADOR: E-MAIL OU CPF */

$isEmail = filter_var(
    $identificador,
    FILTER_VALIDATE_EMAIL
);

$cpfDigitado = preg_replace(
    '/\D+/',
    '',
    $identificador
);

if (!$isEmail && strlen($cpfDigitado) !== 11) {

    header(
        "Location: login.html?erro=" .
        urlencode("Informe um e-mail ou CPF válido.")
    );

    exit();
}


/* BUSCAR USUÁRIO */

if ($isEmail) {

    $sql = "
        SELECT
            email,
            senha,
            nome
        FROM usuario
        WHERE email = ?
        LIMIT 1
    ";

    $parametroLogin = $identificador;

} else {

    /* LOGIN POR CPF
 * O CPF fica cadastrado na tabela morador.
 * A consulta localiza o e-mail correspondente na tabela usuario.
 * Aceita CPF com ou sem pontuação. */

    $sql = "
        SELECT
            u.email,
            u.senha,
            u.nome
        FROM usuario u
        INNER JOIN morador m
            ON m.email = u.email
        WHERE REPLACE(
                  REPLACE(
                      REPLACE(TRIM(m.cpf), '.', ''),
                      '-',
                      ''
                  ),
                  ' ',
                  ''
              ) = ?
        LIMIT 1
    ";

    $parametroLogin = $cpfDigitado;
}


$stmt = $conn->prepare($sql);


if (!$stmt) {

    header(
        "Location: login.html?erro=" .
        urlencode(
            "Erro ao preparar o login."
        )
    );

    exit();
}


$stmt->bind_param(
    "s",
    $parametroLogin
);


if (!$stmt->execute()) {

    $stmt->close();

    header(
        "Location: login.html?erro=" .
        urlencode(
            "Erro ao consultar o usuário."
        )
    );

    exit();
}


$resultado =
    $stmt->get_result();


/* USUÁRIO NÃO ENCONTRADO */

if (
    $resultado->num_rows === 0
) {

    $stmt->close();

    header(
        "Location: login.html?erro=" .
        urlencode(
            "E-mail/CPF ou senha inválidos."
        )
    );

    exit();
}


$usuario =
    $resultado->fetch_assoc();


$stmt->close();


/* SENHA */

if (
    !password_verify(
        $senha,
        $usuario["senha"]
    )
) {

    header(
        "Location: login.html?erro=" .
        urlencode(
            "E-mail/CPF ou senha inválidos."
        )
    );

    exit();
}


/* DADOS USADOS A PARTIR DAQUI
 * O restante do login continua utilizando o e-mail real do usuário.
 * Assim, quem entrar pelo CPF será tratado exatamente como quem entrou
 * pelo e-mail. */

$email = $usuario["email"];


/* BUSCAR USUÁRIO */

$sql = "
    SELECT
        email,
        senha,
        nome
    FROM usuario
    WHERE email = ?
    LIMIT 1
";


$stmt = $conn->prepare($sql);


if (!$stmt) {

    header(
        "Location: login.html?erro=" .
        urlencode(
            "Erro ao preparar o login."
        )
    );

    exit();
}


$stmt->bind_param(
    "s",
    $email
);


if (!$stmt->execute()) {

    $stmt->close();

    header(
        "Location: login.html?erro=" .
        urlencode(
            "Erro ao consultar o usuário."
        )
    );

    exit();
}


$resultado =
    $stmt->get_result();


/* E-MAIL NÃO CADASTRADO */

if (
    $resultado->num_rows === 0
) {

    $stmt->close();

    header(
        "Location: login.html?erro=" .
        urlencode(
            "E-mail/CPF ou senha inválidos."
        )
    );

    exit();
}


$usuario =
    $resultado->fetch_assoc();


$stmt->close();


/* SENHA */

if (
    !password_verify(
        $senha,
        $usuario["senha"]
    )
) {

    header(
        "Location: login.html?erro=" .
        urlencode(
            "E-mail/CPF ou senha inválidos."
        )
    );

    exit();
}


/* DESCOBRIR PERFIL */

$perfil = null;
$cpf = null;


/* MORADOR */

$sql = "
    SELECT
        email,
        cpf
    FROM morador
    WHERE email = ?
    LIMIT 1
";


$stmt =
    $conn->prepare($sql);


if ($stmt) {

    $stmt->bind_param(
        "s",
        $email
    );

    $stmt->execute();

    $result =
        $stmt->get_result();


    if ($result->num_rows > 0) {

        $dadosMorador =
            $result->fetch_assoc();

        $perfil = "morador";

        $cpf =
            $dadosMorador["cpf"];
    }


    $stmt->close();
}


/* MOTORISTA */

if ($perfil === null) {

    $sql = "
        SELECT
            email,
            ativo
        FROM motorista
        WHERE email = ?
        LIMIT 1
    ";


    $stmt =
        $conn->prepare($sql);


    if ($stmt) {

        $stmt->bind_param(
            "s",
            $email
        );

        $stmt->execute();

        $result =
            $stmt->get_result();


        if ($result->num_rows > 0) {

            $motorista =
                $result->fetch_assoc();


            if (
                (int)$motorista["ativo"] !== 1
            ) {

                $stmt->close();

                header(
                    "Location: login.html?erro=" .
                    urlencode(
                        "Este motorista está inativo e não pode acessar o sistema."
                    )
                );

                exit();
            }


            $perfil = "motorista";
        }


        $stmt->close();
    }
}


/* SECRETARIA */

if ($perfil === null) {

    $sql = "
        SELECT email, ativo
        FROM secretaria
        WHERE email = ?
        LIMIT 1
    ";


    $stmt =
        $conn->prepare($sql);


    if ($stmt) {

        $stmt->bind_param(
            "s",
            $email
        );

        $stmt->execute();

        $result =
            $stmt->get_result();


        if ($result->num_rows > 0) {

            $secretaria = $result->fetch_assoc();

            if ((int)$secretaria["ativo"] !== 1) {

                $stmt->close();

                header(
                    "Location: login.html?erro=" .
                    urlencode(
                        "Esta Secretaria está inativa e não pode acessar o sistema."
                    )
                );

                exit();
            }

            $perfil = "secretaria";
        }


        $stmt->close();
    }
}


/* ADMINISTRADOR */

if ($perfil === null) {

    $sql = "
        SELECT email
        FROM administrador
        WHERE email = ?
        LIMIT 1
    ";


    $stmt =
        $conn->prepare($sql);


    if ($stmt) {

        $stmt->bind_param(
            "s",
            $email
        );

        $stmt->execute();

        $result =
            $stmt->get_result();


        if ($result->num_rows > 0) {

            $perfil = "administrador";
        }


        $stmt->close();
    }
}


/* USUÁRIO SEM PERFIL */

if ($perfil === null) {

    header(
        "Location: login.html?erro=" .
        urlencode(
            "Usuário cadastrado sem perfil definido."
        )
    );

    exit();
}


/* CRIAR SESSÃO */

session_regenerate_id(true);


$_SESSION["email"] =
    $usuario["email"];


$_SESSION["nome"] =
    $usuario["nome"];


$_SESSION["perfil"] =
    $perfil;


/* DADOS DO MORADOR */

if ($perfil === "morador") {

    $_SESSION["cpf"] =
        $cpf;
}


/* DADOS DO MOTORISTA */

if ($perfil === "motorista") {

    $_SESSION["motorista_email"] =
        $email;
}


/* LIMPAR DADOS DE OUTROS PERFIS */

if ($perfil !== "morador") {

    unset(
        $_SESSION["cpf"]
    );
}


if ($perfil !== "motorista") {

    unset(
        $_SESSION["motorista_id"],
        $_SESSION["motorista_email"]
    );
}


/* REDIRECIONAR */

redirecionarPerfil(
    $perfil
);

?>