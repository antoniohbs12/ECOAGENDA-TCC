<?php
require_once __DIR__ . "/../interface/cpf_visual.php";

session_start();

require_once "../../config.php";
require_once __DIR__ . "/motorista_prazos.php";


/* PROTEÇÃO */

if (
    !isset($_SESSION["email"]) ||
    !isset($_SESSION["perfil"]) ||
    $_SESSION["perfil"] !== "motorista"
) {
    header("Location: ../login.html");
    exit();
}


$motoristaEmail =
    $_SESSION["email"];

$nomeMotorista =
    $_SESSION["nome"] ?? "Motorista";


$mensagem = "";
$tipoMensagem = "success";


/* FUNÇÕES */

function e($valor): string
{
    return htmlspecialchars(
        (string)$valor,
        ENT_QUOTES,
        "UTF-8"
    );
}


function dataBR(?string $data): string
{
    if (empty($data)) {
        return "—";
    }

    $timestamp =
        strtotime($data);

    return $timestamp
        ? date("d/m/Y", $timestamp)
        : "—";
}


function dataHoraBR(?string $data): string
{
    if (empty($data)) {
        return "—";
    }

    $timestamp =
        strtotime($data);

    return $timestamp
        ? date("d/m/Y H:i", $timestamp)
        : "—";
}


function horaBR(?string $data): string
{
    if (empty($data)) {
        return "—";
    }

    $timestamp =
        strtotime($data);

    return $timestamp
        ? date("H:i", $timestamp)
        : "—";
}


function classeStatus(string $status): string
{
    $statusNormalizado = mb_strtolower(
        trim($status),
        "UTF-8"
    );

    switch ($statusNormalizado) {
        case "encaminhado":
            return "confirmado";

        case "a caminho":
            return "a-caminho";

        case "em andamento":
            return "andamento";

        case "concluído":
        case "concluido":
            return "concluido";

        case "suspenso":
            return "cancelado";

        default:
            return "pendente";
    }
}


/*
|--------------------------------------------------------------------------
| DEFINIR USUÁRIO DA TRIGGER
|--------------------------------------------------------------------------
|
| A trigger trg_agendamento_update usa:
|
| @usuario_logado
|
*/

function definirUsuarioLogado(
    mysqli $conn,
    string $email
): void {

    $sql = "
        SET @usuario_logado = ?
    ";

    $stmt =
        $conn->prepare($sql);

    if (!$stmt) {
        throw new Exception(
            "Erro ao definir usuário da operação: " .
            $conn->error
        );
    }

    $stmt->bind_param(
        "s",
        $email
    );

    if (!$stmt->execute()) {
        throw new Exception(
            "Erro ao definir usuário da operação: " .
            $stmt->error
        );
    }

    $stmt->close();
}


/*
 * Envia aviso de mudança de status por e-mail.
 * Falhas no envio não desfazem uma alteração já salva no banco.
 */
function enviarEmailStatusEcoAgenda(mysqli $conn, array $pedido, string $statusNovo): void
{
    try {
        require_once __DIR__ . "/../../login/notificar_status.php";

        $emailMorador = trim((string)($pedido["morador_email"] ?? ""));
        $agendamentoId = (int)($pedido["id"] ?? 0);

        if ($emailMorador === "" || $agendamentoId <= 0 ||
            !function_exists("notificarMoradorStatus")) {
            return;
        }

        $nomeMorador = "Morador";
        $stmtNome = $conn->prepare(
            "SELECT nome FROM usuario WHERE email = ? LIMIT 1"
        );

        if ($stmtNome) {
            $stmtNome->bind_param("s", $emailMorador);
            if ($stmtNome->execute()) {
                $dadosNome = $stmtNome->get_result()->fetch_assoc();
                if (!empty($dadosNome["nome"])) {
                    $nomeMorador = (string)$dadosNome["nome"];
                }
            }
            $stmtNome->close();
        }

        if (!notificarMoradorStatus(
            $emailMorador,
            $nomeMorador,
            $agendamentoId,
            $statusNovo
        )) {
            error_log(
                "EcoAgenda: não foi possível enviar e-mail de status do pedido #" .
                $agendamentoId
            );
        }
    } catch (Throwable $erroNotificacao) {
        error_log("EcoAgenda: falha na notificação de status: " . $erroNotificacao->getMessage());
    }
}


/* DADOS DO MOTORISTA */

$sqlMotorista = "

    SELECT

        m.email,
        m.cnh,
        m.cpf,
        m.telefone,
        m.ativo,

        u.nome

    FROM motorista m

    INNER JOIN usuario u
        ON u.email = m.email

    WHERE m.email = ?

    LIMIT 1
";


$stmtMotorista =
    $conn->prepare(
        $sqlMotorista
    );


if (!$stmtMotorista) {

    die(
        "Erro ao carregar motorista: " .
        $conn->error
    );
}


$stmtMotorista->bind_param(
    "s",
    $motoristaEmail
);


$stmtMotorista->execute();


$dadosMotorista =
    $stmtMotorista
        ->get_result()
        ->fetch_assoc();


$stmtMotorista->close();


if (!$dadosMotorista) {

    session_destroy();

    die(
        "Cadastro do motorista não encontrado."
    );
}


if (
    (int)$dadosMotorista["ativo"] !== 1
) {

    session_destroy();

    header(
        "Location: ../login.html"
    );

    exit();
}


/* AÇÕES DO MOTORISTA */

if (
    $_SERVER["REQUEST_METHOD"] === "POST"
) {

    $acao =
        $_POST["acao"] ?? "";

    $agendamentoId =
        (int)(
            $_POST["agendamento_id"] ?? 0
        );


    /* IR ATÉ O LOCAL — altera o status para A caminho */

    if ($acao === "ir_local") {
        if ($agendamentoId <= 0) {
            $mensagem = "Pedido inválido.";
            $tipoMensagem = "error";
        } else {
            $conn->begin_transaction();

            try {
                $sqlPedidoCaminho = "
                    SELECT a.id, a.morador_email, a.status
                    FROM agendamento a
                    INNER JOIN coleta c
                        ON c.agendamento_id = a.id
                       AND c.motorista_email = ?
                    WHERE a.id = ?
                    ORDER BY c.data_inicio DESC
                    LIMIT 1
                ";

                $stmtPedidoCaminho = $conn->prepare($sqlPedidoCaminho);
                if (!$stmtPedidoCaminho) {
                    throw new Exception("Erro ao buscar pedido: " . $conn->error);
                }

                $stmtPedidoCaminho->bind_param("si", $motoristaEmail, $agendamentoId);
                $stmtPedidoCaminho->execute();
                $pedidoCaminho = $stmtPedidoCaminho->get_result()->fetch_assoc();
                $stmtPedidoCaminho->close();

                if (!$pedidoCaminho) {
                    throw new Exception("Pedido não encontrado ou não está agendado para este motorista.");
                }

                if (mb_strtolower(trim($pedidoCaminho["status"]), "UTF-8") !== "encaminhado") {
                    throw new Exception("Somente pedidos agendados podem ser colocados a caminho.");
                }

                definirUsuarioLogado($conn, $motoristaEmail);
                $novoStatusCaminho = "A caminho";
                $sqlStatusCaminho = "
                    UPDATE agendamento
                    SET status = ?
                    WHERE id = ? AND status = 'Encaminhado'
                    LIMIT 1
                ";

                $stmtStatusCaminho = $conn->prepare($sqlStatusCaminho);
                if (!$stmtStatusCaminho) {
                    throw new Exception("Erro ao preparar atualização do status: " . $conn->error);
                }

                $stmtStatusCaminho->bind_param("si", $novoStatusCaminho, $agendamentoId);
                if (!$stmtStatusCaminho->execute()) {
                    throw new Exception("Erro ao atualizar o status: " . $stmtStatusCaminho->error);
                }

                if ($stmtStatusCaminho->affected_rows !== 1) {
                    $stmtStatusCaminho->close();
                    throw new Exception("O pedido não pôde ser marcado como A caminho. Atualize a página e tente novamente.");
                }

                $stmtStatusCaminho->close();
                $conn->commit();

                enviarEmailStatusEcoAgenda($conn, $pedidoCaminho, "A caminho");
                $mensagem = "Status atualizado para A caminho. Ao chegar ao endereço, clique em Iniciar coleta.";
            } catch (Throwable $e) {
                $conn->rollback();
                $mensagem = $e->getMessage();
                $tipoMensagem = "error";
            }
        }
    }


    /* INICIAR COLETA */

    if (
        $acao === "iniciar"
    ) {

        if (!eaDiaUtil(new DateTimeImmutable('now', new DateTimeZone('America/Sao_Paulo')))) {
            $mensagem = "Não é possível iniciar coletas em fins de semana ou feriados. Inicie no próximo dia útil.";
            $tipoMensagem = "error";
        } elseif (
            $agendamentoId <= 0
        ) {

            $mensagem =
                "Pedido inválido.";

            $tipoMensagem =
                "error";

        } else {

            $conn->begin_transaction();

            try {

                /* Buscar pedido vinculado ao motorista */

                $sqlPedido = "

                    SELECT

                        a.id,
                        a.criado_por,
                        a.descricao,
                        a.data_pedido,
                        a.foto,
                        a.morador_email,
                        a.status,

                        c.data_inicio,
                        c.data_chegada,
                        c.data_finalizacao,
                        c.foto AS foto_coleta

                    FROM agendamento a

                    INNER JOIN coleta c
                        ON c.agendamento_id = a.id
                       AND c.motorista_email = ?

                    WHERE a.id = ?

                    ORDER BY
                        c.data_inicio DESC

                    LIMIT 1
                ";


                $stmtPedido =
                    $conn->prepare(
                        $sqlPedido
                    );


                if (!$stmtPedido) {

                    throw new Exception(
                        "Erro ao buscar pedido: " .
                        $conn->error
                    );
                }


                $stmtPedido->bind_param(
                    "si",
                    $motoristaEmail,
                    $agendamentoId
                );


                $stmtPedido->execute();


                $pedido =
                    $stmtPedido
                        ->get_result()
                        ->fetch_assoc();


                $stmtPedido->close();


                if (!$pedido) {

                    throw new Exception(
                        "Pedido não encontrado ou não está agendado para este motorista."
                    );
                }


                /*
                | Somente pedidos marcados como A caminho
                */

                if (
                    mb_strtolower(
                        trim(
                            $pedido["status"]
                        ),
                        "UTF-8"
                    ) !== "a caminho"
                ) {

                    throw new Exception(
                        "Primeiro clique em Ir até o local para marcar o pedido como A caminho."
                    );
                }


                /* Buscar registro atual da coleta */

                $sqlColeta = "

                    SELECT
                        motorista_email,
                        agendamento_id,
                        data_inicio,
                        data_chegada,
                        data_finalizacao,
                        foto

                    FROM coleta

                    WHERE motorista_email = ?
                      AND agendamento_id = ?

                    ORDER BY
                        data_inicio DESC

                    LIMIT 1
                ";


                $stmtColeta =
                    $conn->prepare(
                        $sqlColeta
                    );


                if (!$stmtColeta) {

                    throw new Exception(
                        "Erro ao buscar coleta: " .
                        $conn->error
                    );
                }


                $stmtColeta->bind_param(
                    "si",
                    $motoristaEmail,
                    $agendamentoId
                );


                $stmtColeta->execute();


                $coleta =
                    $stmtColeta
                        ->get_result()
                        ->fetch_assoc();


                $stmtColeta->close();


                if (!$coleta) {

                    throw new Exception(
                        "Não existe uma coleta vinculada a este pedido."
                    );
                }


                /* Registrar o INÍCIO REAL da coleta
 * O registro criado pela Secretaria possui data_inicio apenas
 * para satisfazer a estrutura atual da tabela coleta.
 * Quando o motorista inicia de fato, este valor é atualizado
 * para o horário real da ação. */

                $dataInicioAnterior =
                    $coleta["data_inicio"];


                $dataInicioNovo =
                    date("Y-m-d H:i:s");


                $sqlInicioColeta = "

                    UPDATE coleta

                    SET data_inicio = ?

                    WHERE motorista_email = ?

                      AND agendamento_id = ?

                      AND data_inicio = ?

                    LIMIT 1
                ";


                $stmtInicioColeta =
                    $conn->prepare(
                        $sqlInicioColeta
                    );


                if (!$stmtInicioColeta) {

                    throw new Exception(
                        "Erro ao preparar início da coleta: " .
                        $conn->error
                    );
                }


                $stmtInicioColeta->bind_param(
                    "ssis",
                    $dataInicioNovo,
                    $motoristaEmail,
                    $agendamentoId,
                    $dataInicioAnterior
                );


                if (
                    !$stmtInicioColeta->execute()
                ) {

                    throw new Exception(
                        "Erro ao registrar o início da coleta: " .
                        $stmtInicioColeta->error
                    );
                }


                if (
                    $stmtInicioColeta->affected_rows !== 1
                ) {

                    $stmtInicioColeta->close();

                    throw new Exception(
                        "A coleta não pôde ser iniciada. O registro pode ter sido alterado por outra operação."
                    );
                }


                $stmtInicioColeta->close();


                /* Atualizar STATUS do AGENDAMENTO */

                definirUsuarioLogado(
                    $conn,
                    $motoristaEmail
                );


                $novoStatus =
                    "Em andamento";


                $sqlUpdate = "

                    UPDATE agendamento

                    SET status = ?

                    WHERE id = ?

                      AND status = 'A caminho'

                    LIMIT 1
                ";


                $stmtUpdate =
                    $conn->prepare(
                        $sqlUpdate
                    );


                if (!$stmtUpdate) {

                    throw new Exception(
                        "Erro ao preparar mudança de status: " .
                        $conn->error
                    );
                }


                $stmtUpdate->bind_param(
                    "si",
                    $novoStatus,
                    $agendamentoId
                );


                if (
                    !$stmtUpdate->execute()
                ) {

                    throw new Exception(
                        "Erro ao iniciar coleta: " .
                        $stmtUpdate->error
                    );
                }


                if (
                    $stmtUpdate->affected_rows !== 1
                ) {

                    $stmtUpdate->close();

                    throw new Exception(
                        "O status do pedido não pôde ser atualizado. Tente novamente."
                    );
                }


                $stmtUpdate->close();


                /*
                | O trigger trg_agendamento_update registra automaticamente
                | a alteração do status no agendamento_historico.
                | Evitamos inserir um segundo histórico manualmente.
                */

                $conn->commit();

                enviarEmailStatusEcoAgenda($conn, $pedido, "Em andamento");

                $mensagem =
                    "Coleta iniciada e marcada como Em andamento.";

            } catch (Throwable $e) {

                $conn->rollback();

                $mensagem =
                    $e->getMessage();

                $tipoMensagem =
                    "error";
            }
        }
    }


    /* SUSPENDER COLETA
 * A ação grava o status definitivo "Suspenso".
 * A foto e a justificativa ficam registradas no agendamento_historico. */

    if (
        $acao === "suspender"
    ) {

        $justificativa = trim(
            $_POST["justificativa_suspensao"] ?? ""
        );

        if ($agendamentoId <= 0) {

            $mensagem = "Pedido inválido.";
            $tipoMensagem = "error";

        } elseif ($justificativa === "") {

            $mensagem = "Informe a justificativa para suspender a coleta.";
            $tipoMensagem = "error";

        } elseif (mb_strlen($justificativa, "UTF-8") > 225) {

            $mensagem = "A justificativa deve ter no máximo 225 caracteres.";
            $tipoMensagem = "error";

        } elseif (
            !isset($_FILES["foto_suspensao"]) ||
            $_FILES["foto_suspensao"]["error"] === UPLOAD_ERR_NO_FILE
        ) {

            $mensagem = "A foto do ocorrido é obrigatória para suspender a coleta.";
            $tipoMensagem = "error";

        } else {

            $conn->begin_transaction();

            $nomeFotoSuspensao = null;

            try {

                $sqlPedido = "
                    SELECT
                        a.id,
                        a.criado_por,
                        a.descricao,
                        a.data_pedido,
                        a.morador_email,
                        a.status
                    FROM agendamento a
                    INNER JOIN coleta c
                        ON c.agendamento_id = a.id
                       AND c.motorista_email = ?
                    WHERE a.id = ?
                    LIMIT 1
                ";

                $stmtPedido = $conn->prepare($sqlPedido);

                if (!$stmtPedido) {
                    throw new Exception(
                        "Erro ao buscar pedido: " . $conn->error
                    );
                }

                $stmtPedido->bind_param(
                    "si",
                    $motoristaEmail,
                    $agendamentoId
                );

                $stmtPedido->execute();
                $pedidoSuspensao = $stmtPedido
                    ->get_result()
                    ->fetch_assoc();
                $stmtPedido->close();

                if (!$pedidoSuspensao) {
                    throw new Exception(
                        "Pedido não encontrado ou não pertence a este motorista."
                    );
                }

                if (
                    mb_strtolower(
                        trim($pedidoSuspensao["status"]),
                        "UTF-8"
                    ) !== "em andamento"
                ) {
                    throw new Exception(
                        "Somente pedidos em andamento podem ser suspensos."
                    );
                }

                $arquivo = $_FILES["foto_suspensao"];

                if ($arquivo["error"] !== UPLOAD_ERR_OK) {
                    throw new Exception(
                        "Erro ao enviar a foto do ocorrido."
                    );
                }

                if ($arquivo["size"] > 5 * 1024 * 1024) {
                    throw new Exception(
                        "A foto deve ter no máximo 5 MB."
                    );
                }

                $tiposPermitidos = [
                    "image/jpeg" => "jpg",
                    "image/png" => "png",
                    "image/webp" => "webp"
                ];

                $finfo = finfo_open(FILEINFO_MIME_TYPE);
                if (!$finfo) {
                    throw new Exception("Não foi possível validar a foto.");
                }

                $tipoArquivo = finfo_file(
                    $finfo,
                    $arquivo["tmp_name"]
                );
                finfo_close($finfo);

                if (!isset($tiposPermitidos[$tipoArquivo])) {
                    throw new Exception(
                        "Formato de imagem não permitido. Use JPG, PNG ou WEBP."
                    );
                }

                $extensao = $tiposPermitidos[$tipoArquivo];
                $nomeFotoSuspensao = uniqid("suspensao_", true) . "." . $extensao;
                $pastaUpload = __DIR__ . "/../../agendamento/uploads/";

                if (!is_dir($pastaUpload)) {
                    if (!mkdir($pastaUpload, 0755, true)) {
                        throw new Exception(
                            "Não foi possível criar a pasta de uploads."
                        );
                    }
                }

                $caminhoFoto = $pastaUpload . $nomeFotoSuspensao;

                if (!move_uploaded_file(
                    $arquivo["tmp_name"],
                    $caminhoFoto
                )) {
                    throw new Exception(
                        "Não foi possível salvar a foto do ocorrido."
                    );
                }

                $caminhoBancoSuspensao = "uploads/" . $nomeFotoSuspensao;

                definirUsuarioLogado(
                    $conn,
                    $motoristaEmail
                );

                $novoStatusSuspensao = "Suspenso";

                $sqlStatus = "
                    UPDATE agendamento
                    SET status = ?
                    WHERE id = ?
                      AND status = 'Em andamento'
                    LIMIT 1
                ";

                $stmtStatus = $conn->prepare($sqlStatus);

                if (!$stmtStatus) {
                    throw new Exception(
                        "Erro ao preparar suspensão: " . $conn->error
                    );
                }

                $stmtStatus->bind_param(
                    "si",
                    $novoStatusSuspensao,
                    $agendamentoId
                );

                if (!$stmtStatus->execute()) {
                    throw new Exception(
                        "Erro ao suspender a coleta: " . $stmtStatus->error
                    );
                }

                if ($stmtStatus->affected_rows !== 1) {
                    $stmtStatus->close();
                    throw new Exception(
                        "A coleta não pôde ser suspensa. O status pode ter sido alterado."
                    );
                }

                $stmtStatus->close();

                /*
                | O trigger registra a mudança de status automaticamente.
                | Este segundo registro guarda a justificativa e a foto
                | específica da ocorrência que motivou a suspensão.
                */
                $sqlHistorico = "
                    INSERT INTO agendamento_historico
                    (
                        agendamento_id,
                        criado_por,
                        descricao,
                        data_pedido,
                        foto,
                        morador_email,
                        status,
                        comando,
                        data_comando,
                        usuario_logado
                    )
                    VALUES (?, ?, ?, ?, ?, ?, ?, 'COLETA_SUSPENSA', NOW(), ?)
                ";

                $stmtHistorico = $conn->prepare($sqlHistorico);

                if (!$stmtHistorico) {
                    throw new Exception(
                        "Erro ao preparar o histórico da suspensão: " . $conn->error
                    );
                }

                $stmtHistorico->bind_param(
                    "isssssss",
                    $agendamentoId,
                    $pedidoSuspensao["criado_por"],
                    $justificativa,
                    $pedidoSuspensao["data_pedido"],
                    $caminhoBancoSuspensao,
                    $pedidoSuspensao["morador_email"],
                    $novoStatusSuspensao,
                    $motoristaEmail
                );

                if (!$stmtHistorico->execute()) {
                    throw new Exception(
                        "Erro ao registrar a justificativa da suspensão: " . $stmtHistorico->error
                    );
                }

                $stmtHistorico->close();

                $conn->commit();

                enviarEmailStatusEcoAgenda($conn, $pedidoSuspensao, "Suspenso");

                $mensagem = "Coleta suspensa com sucesso.";

            } catch (Throwable $e) {

                $conn->rollback();

                if ($nomeFotoSuspensao !== null) {
                    $arquivo =
                        __DIR__ .
                        "/../../agendamento/uploads/" .
                        $nomeFotoSuspensao;

                    if (file_exists($arquivo)) {
                        unlink($arquivo);
                    }
                }

                $mensagem = $e->getMessage();
                $tipoMensagem = "error";
            }
        }
    }


    /* CONCLUIR COLETA */

    if (
        $acao === "concluir"
    ) {

        if (
            $agendamentoId <= 0
        ) {

            $mensagem =
                "Pedido inválido.";

            $tipoMensagem =
                "error";

        } else {

            $conn->begin_transaction();

            $nomeFoto = null;
            $caminhoBanco = null;

            try {

                /* Buscar pedido */

                $sqlPedido = "

                    SELECT

                        a.id,
                        a.criado_por,
                        a.descricao,
                        a.data_pedido,
                        a.foto,
                        a.morador_email,
                        a.status,

                        c.data_inicio,
                        c.data_chegada,
                        c.data_finalizacao,
                        c.foto AS foto_coleta

                    FROM agendamento a

                    INNER JOIN coleta c
                        ON c.agendamento_id = a.id
                       AND c.motorista_email = ?

                    WHERE a.id = ?

                    ORDER BY
                        c.data_inicio DESC

                    LIMIT 1
                ";


                $stmtPedido =
                    $conn->prepare(
                        $sqlPedido
                    );


                if (!$stmtPedido) {

                    throw new Exception(
                        "Erro ao buscar pedido: " .
                        $conn->error
                    );
                }


                $stmtPedido->bind_param(
                    "si",
                    $motoristaEmail,
                    $agendamentoId
                );


                $stmtPedido->execute();


                $pedido =
                    $stmtPedido
                        ->get_result()
                        ->fetch_assoc();


                $stmtPedido->close();


                if (!$pedido) {

                    throw new Exception(
                        "Pedido não encontrado ou não pertence a este motorista."
                    );
                }


                /* Verificar status */

                if (
                    mb_strtolower(
                        trim(
                            $pedido["status"]
                        ),
                        "UTF-8"
                    ) !== "em andamento"
                ) {

                    throw new Exception(
                        "Somente pedidos em andamento podem ser concluídos."
                    );
                }


                /* Buscar data_inicio da coleta */

                $sqlColeta = "

                    SELECT

                        motorista_email,
                        agendamento_id,
                        data_inicio,
                        data_chegada,
                        data_finalizacao,
                        foto

                    FROM coleta

                    WHERE motorista_email = ?
                      AND agendamento_id = ?

                    ORDER BY
                        data_inicio DESC

                    LIMIT 1
                ";


                $stmtColeta =
                    $conn->prepare(
                        $sqlColeta
                    );


                if (!$stmtColeta) {

                    throw new Exception(
                        "Erro ao buscar coleta: " .
                        $conn->error
                    );
                }


                $stmtColeta->bind_param(
                    "si",
                    $motoristaEmail,
                    $agendamentoId
                );


                $stmtColeta->execute();


                $coleta =
                    $stmtColeta
                        ->get_result()
                        ->fetch_assoc();


                $stmtColeta->close();


                if (!$coleta) {

                    throw new Exception(
                        "Registro de coleta não encontrado."
                    );
                }


                /* FOTO DO MOTORISTA - OBRIGATÓRIA PARA CONCLUIR */

                if (
                    !isset($_FILES["foto_motorista"]) ||
                    $_FILES["foto_motorista"]["error"] === UPLOAD_ERR_NO_FILE
                ) {
                    throw new Exception(
                        "A foto da coleta é obrigatória para concluir o pedido."
                    );
                }

                if (
                    $_FILES["foto_motorista"]["error"] === UPLOAD_ERR_OK
                ) {

                    if (
                        $_FILES[
                            "foto_motorista"
                        ]["error"]
                        !== UPLOAD_ERR_OK
                    ) {

                        throw new Exception(
                            "Erro ao enviar a foto do motorista."
                        );
                    }


                    if (
                        $_FILES[
                            "foto_motorista"
                        ]["size"]
                        >
                        5 * 1024 * 1024
                    ) {

                        throw new Exception(
                            "A foto deve ter no máximo 5 MB."
                        );
                    }


                    $tiposPermitidos = [

                        "image/jpeg",

                        "image/png",

                        "image/webp"
                    ];


                    $tipoArquivo =
                        mime_content_type(
                            $_FILES[
                                "foto_motorista"
                            ]["tmp_name"]
                        );


                    if (
                        !in_array(
                            $tipoArquivo,
                            $tiposPermitidos,
                            true
                        )
                    ) {

                        throw new Exception(
                            "Formato de imagem não permitido."
                        );
                    }


                    $extensoes = [

                        "image/jpeg" =>
                            "jpg",

                        "image/png" =>
                            "png",

                        "image/webp" =>
                            "webp"
                    ];


                    $extensao =
                        $extensoes[
                            $tipoArquivo
                        ];


                    $nomeFoto =
                        uniqid(
                            "motorista_",
                            true
                        )
                        .
                        "."
                        .
                        $extensao;


                    $pastaUpload =
                        __DIR__ .
                        "/../../agendamento/uploads/";


                    if (
                        !is_dir(
                            $pastaUpload
                        )
                    ) {

                        if (
                            !mkdir(
                                $pastaUpload,
                                0755,
                                true
                            )
                        ) {

                            throw new Exception(
                                "Não foi possível criar a pasta de uploads."
                            );
                        }
                    }


                    $caminhoFoto =
                        $pastaUpload .
                        $nomeFoto;


                    if (
                        !move_uploaded_file(
                            $_FILES[
                                "foto_motorista"
                            ]["tmp_name"],
                            $caminhoFoto
                        )
                    ) {

                        throw new Exception(
                            "Não foi possível salvar a foto."
                        );
                    }


                    $caminhoBanco =
                        "uploads/" .
                        $nomeFoto;
                }


                /* ATUALIZAR COLETA */

                $dataInicio =
                    $coleta[
                        "data_inicio"
                    ];


                $fotoFinal =
                    $caminhoBanco ??
                    ($coleta["foto"] ?? null);


                $sqlUpdateColeta = "

                    UPDATE coleta

                    SET

                        data_finalizacao =
                            NOW(),

                        foto = ?

                    WHERE
                        motorista_email = ?

                        AND agendamento_id = ?

                        AND data_inicio = ?

                    LIMIT 1
                ";


                $stmtUpdateColeta =
                    $conn->prepare(
                        $sqlUpdateColeta
                    );


                if (!$stmtUpdateColeta) {

                    throw new Exception(
                        "Erro ao preparar finalização da coleta: " .
                        $conn->error
                    );
                }


                $stmtUpdateColeta->bind_param(
                    "ssis",
                    $fotoFinal,
                    $motoristaEmail,
                    $agendamentoId,
                    $dataInicio
                );


                if (
                    !$stmtUpdateColeta->execute()
                ) {

                    throw new Exception(
                        "Erro ao finalizar coleta: " .
                        $stmtUpdateColeta->error
                    );
                }


                if (
                    $stmtUpdateColeta->affected_rows !== 1
                ) {

                    $stmtUpdateColeta->close();

                    throw new Exception(
                        "O registro da coleta não pôde ser finalizado."
                    );
                }


                $stmtUpdateColeta->close();


                /* ATUALIZAR STATUS DO AGENDAMENTO */

                definirUsuarioLogado(
                    $conn,
                    $motoristaEmail
                );


                $novoStatus =
                    "Concluído";


                $sqlUpdateAgendamento = "

                    UPDATE agendamento

                    SET status = ?

                    WHERE id = ?

                      AND status = 'Em andamento'

                    LIMIT 1
                ";


                $stmtUpdateAgendamento =
                    $conn->prepare(
                        $sqlUpdateAgendamento
                    );


                if (!$stmtUpdateAgendamento) {

                    throw new Exception(
                        "Erro ao preparar conclusão: " .
                        $conn->error
                    );
                }


                $stmtUpdateAgendamento->bind_param(
                    "si",
                    $novoStatus,
                    $agendamentoId
                );


                if (
                    !$stmtUpdateAgendamento->execute()
                ) {

                    throw new Exception(
                        "Erro ao atualizar status: " .
                        $stmtUpdateAgendamento->error
                    );
                }


                $stmtUpdateAgendamento->close();


                /*
                | O trigger trg_agendamento_update registra automaticamente
                | a alteração para Concluído no histórico.
                */

                $conn->commit();

                enviarEmailStatusEcoAgenda($conn, $pedido, "Concluído");

                $mensagem =
                    "Coleta concluída com sucesso.";

            } catch (Throwable $e) {

                $conn->rollback();


                /*
                | Apagar foto caso a transação tenha falhado
                */

                if (
                    $nomeFoto !== null
                ) {

                    $arquivo =
                        __DIR__ .
                        "/../../agendamento/uploads/" .
                        $nomeFoto;

                    if (
                        file_exists(
                            $arquivo
                        )
                    ) {

                        unlink(
                            $arquivo
                        );
                    }
                }


                $mensagem =
                    $e->getMessage();

                $tipoMensagem =
                    "error";
            }
        }
    }
}


/* BUSCAR PEDIDOS DO MOTORISTA */

$pedidos = [];


$sqlPedidos = "

    SELECT

        a.id,

        a.criado_por,

        a.descricao,

        a.data_pedido,

        a.foto,

        a.morador_email,

        a.status,

        m.cpf AS morador_cpf,

        CASE
            WHEN LOWER(a.status) IN ('concluído', 'concluido')
                THEN NULL
            ELSE m.telefone
        END AS morador_telefone,

        u_morador.nome AS morador_nome,

        e.cep,

        e.estado,

        e.cidade,

        e.rua,

        e.bairro,

        e.numero,

        e.complemento,

        c.data_inicio,

        c.data_chegada,

        c.data_finalizacao,

        c.foto AS foto_motorista

    FROM agendamento a


    INNER JOIN coleta c
        ON c.agendamento_id = a.id
       AND c.motorista_email = ?


    LEFT JOIN morador m
        ON m.email = a.morador_email


    LEFT JOIN usuario u_morador
        ON u_morador.email = m.email


    LEFT JOIN agendamento_morador_endereco ame
        ON ame.agendamento_id = a.id
       AND ame.morador_email = a.morador_email
       AND ame.endereco_id = (
           SELECT MAX(ame_atual.endereco_id)
           FROM agendamento_morador_endereco ame_atual
           WHERE ame_atual.agendamento_id = a.id
             AND ame_atual.morador_email = a.morador_email
       )


    LEFT JOIN morador_endereco me
        ON me.endereco_id = ame.endereco_id
       AND me.morador_email = ame.morador_email


    LEFT JOIN endereco e
        ON e.id = me.endereco_id
       AND e.email = me.morador_email


    ORDER BY

        CASE

            WHEN LOWER(a.status)
                = 'encaminhado'
            THEN 1

            WHEN LOWER(a.status)
                = 'a caminho'
            THEN 2

            WHEN LOWER(a.status)
                = 'em andamento'
            THEN 3

            WHEN LOWER(a.status)
                IN ('concluído', 'concluido')
            THEN 4

            WHEN LOWER(a.status)
                = 'suspenso'
            THEN 5

            ELSE 5

        END,

        a.id DESC,

        c.data_inicio DESC
";


$stmtPedidos =
    $conn->prepare(
        $sqlPedidos
    );


if (!$stmtPedidos) {

    die(
        "Erro ao carregar pedidos: " .
        $conn->error
    );
}


$stmtPedidos->bind_param(
    "s",
    $motoristaEmail
);


$stmtPedidos->execute();


$resultadoPedidos =
    $stmtPedidos->get_result();


while (
    $pedido =
    $resultadoPedidos->fetch_assoc()
) {

    /*
    | Montar endereço para a interface
    */

    $partesEndereco = [];

    if (
        !empty(
            $pedido["rua"]
        )
    ) {

        $partesEndereco[] =
            $pedido["rua"];
    }

    if (
        !empty(
            $pedido["numero"]
        )
    ) {

        $partesEndereco[] =
            "nº " .
            $pedido["numero"];
    }

    if (
        !empty(
            $pedido["complemento"]
        )
    ) {

        $partesEndereco[] =
            $pedido["complemento"];
    }

    if (
        !empty(
            $pedido["bairro"]
        )
    ) {

        $partesEndereco[] =
            $pedido["bairro"];
    }

    if (
        !empty(
            $pedido["cidade"]
        )
    ) {

        $partesEndereco[] =
            $pedido["cidade"];
    }

    if (
        !empty(
            $pedido["estado"]
        )
    ) {

        $partesEndereco[] =
            $pedido["estado"];
    }

    if (
        !empty(
            $pedido["cep"]
        )
    ) {

        $partesEndereco[] =
            "CEP: " .
            $pedido["cep"];
    }


    $pedido["endereco"] =
        implode(
            ", ",
            $partesEndereco
        );


    $pedidos[] =
        $pedido;
}


$stmtPedidos->close();


/* ESTATÍSTICAS */

$totalPedidos =
    count($pedidos);

$confirmados = 0;
$andamento   = 0;
$concluidos  = 0;
$cancelados  = 0;


foreach (
    $pedidos
    as $pedido
) {

    $statusNormalizado =
        mb_strtolower(
            trim(
                $pedido["status"]
            ),
            "UTF-8"
        );


    if (
        $statusNormalizado ===
        "encaminhado"
    ) {

        $confirmados++;

    } elseif (
        $statusNormalizado === "a caminho" ||
        $statusNormalizado === "em andamento"
    ) {

        $andamento++;

    } elseif (
        $statusNormalizado ===
        "concluído" ||
        $statusNormalizado ===
        "concluido"
    ) {

        $concluidos++;

    } elseif (
        $statusNormalizado ===
        "suspenso"
    ) {

        $cancelados++;
    }
}


$demandasMotorista = [];
foreach ($pedidos as &$pedido) {
    $pedido['prazo_motorista'] = prazoMotorista($pedido);
    if ($pedido['prazo_motorista']['ativo']) $demandasMotorista[] = $pedido;
}
unset($pedido);
usort($pedidos, 'ordenarUrgenciaMotorista');
usort($demandasMotorista, static function ($a, $b) {
    return [$a['prazo_motorista']['limite'] ?: '9999', (int)$a['id']] <=> [$b['prazo_motorista']['limite'] ?: '9999', (int)$b['id']];
});
$agendaMotorista = array_map(static function ($p) {
    return ['id'=>(int)$p['id'], 'status'=>(in_array(mb_strtolower(trim($p['status']),'UTF-8'),['encaminhado','confirmado','agendado'],true)?'Agendado':$p['status']), 'local'=>trim(($p['rua'] ?? '') . ', ' . ($p['numero'] ?? '') . ' · ' . ($p['bairro'] ?? '')),
        'emitido'=>substr($p['data_pedido'],0,10), 'urgencia'=>$p['prazo_motorista']['urgencia'], 'restantes'=>$p['prazo_motorista']['restantes'], 'material'=>materialMotorista($p['descricao']), 'limite'=>$p['prazo_motorista']['limite'], 'classe'=>$p['prazo_motorista']['classe']];
}, $demandasMotorista);

/* INICIAIS */

$partesNome =
    preg_split(
        '/\s+/',
        trim(
            $nomeMotorista
        )
    );


$iniciais = "";


if (
    !empty(
        $partesNome[0]
    )
) {

    $iniciais .=
        strtoupper(
            substr(
                $partesNome[0],
                0,
                1
            )
        );
}


if (
    count($partesNome) > 1
) {

    $iniciais .=
        strtoupper(
            substr(
                $partesNome[
                    count($partesNome) - 1
                ],
                0,
                1
            )
        );
}


$iniciais =
    substr(
        $iniciais ?: "M",
        0,
        2
    );

?>

<!DOCTYPE html>

<html lang="pt-BR">

<head>

    <meta charset="UTF-8">

    <meta
        name="viewport"
        content="width=device-width, initial-scale=1.0">

    <title>
        EcoAgenda - Motorista
    </title>

    <link
        rel="stylesheet"
        href="motorista.css?v=20261009-4">

<link rel="stylesheet" href="../interface/calendario.css?v=20261016-dia">
<script defer src="../interface/calendario.js?v=20261016-dia"></script>
<script defer src="mapa_motorista.js?v=20261011-1"></script>
<link rel="stylesheet" href="../interface/identidade.css?v=20261011-1">
<script defer src="../interface/identidade.js?v=20261011-1"></script>
<script defer src="../interface/fluxos.js?v=20261011-1"></script>
<script src="../interface/cpf_visual.js?v=20261023-1"></script>
</head>


<body>
<svg class="ea-sprite" aria-hidden="true" xmlns="http://www.w3.org/2000/svg"><defs><symbol id="ea-calendar" viewBox="0 0 24 24"><rect x="3" y="5" width="18" height="16" rx="3"/><path d="M16 3v4M8 3v4M3 11h18M8 15h2M14 15h2"/></symbol><symbol id="ea-box" viewBox="0 0 24 24"><path d="m12 3 9 5v9l-9 5-9-5V8l9-5ZM3 8l9 5 9-5M12 13v9M7.5 5.5l9 5"/></symbol><symbol id="ea-user" viewBox="0 0 24 24"><circle cx="12" cy="8" r="4"/><path d="M4 21v-2a8 8 0 0 1 16 0v2"/></symbol><symbol id="ea-leaf" viewBox="0 0 24 24"><path d="M20 3C10 2 3 7 4 14s12 10 15 1c1-3 1-8 1-12ZM5 20l10-10"/></symbol></defs></svg>

<div class="dashboard">


    <!-- =====================================================
         SIDEBAR
    ====================================================== -->

    <aside class="sidebar">

        <div class="logo"><img src="../../assets/icons/logo-ecoagenda-branco.png" alt="EcoAgenda"></div>

        <div class="perfil-side">
            Motorista
        </div>


        <nav class="menu" aria-label="Navegação do motorista">

            <button
                type="button"
                class="menu-link active"
                data-section="inicio">

                <span>
                    <svg class="ea-icon" aria-hidden="true"><use href="#ea-calendar"/></svg>
                </span>

                Dashboard

            </button>


            <button
                type="button"
                class="menu-link"
                data-section="pedidos">

                <span>
                    <svg class="ea-icon" aria-hidden="true"><use href="#ea-box"/></svg>
                </span>

                Minhas coletas

            </button>


            <button
                type="button"
                class="menu-link"
                data-section="perfil">

                <span>
                    <svg class="ea-icon" aria-hidden="true"><use href="#ea-user"/></svg>
                </span>

                Meu perfil

            </button>

        </nav>

    </aside>



    <!-- =====================================================
         MAIN
    ====================================================== -->

    <main class="main">


        <header class="topbar">

            <div class="ea-greeting">
                <span class="ea-greeting-icon"><svg class="ea-icon" aria-hidden="true"><use href="#ea-leaf"/></svg></span>
                <div><h1 id="tituloPagina" class="sr-only">Dashboard</h1>
                <strong>Vamos cuidar de Pinhais.</strong>
                <p id="subtituloPagina">Organize seu dia, uma coleta de cada vez.</p></div>
            </div>
            <div class="top-actions">

                <span class="motorista-nome">

                    <?= e(
                        $nomeMotorista
                    ) ?>

                </span>


                <a
                    href="../logout.php"
                    class="logout">

                    Sair

                </a>


                <div class="avatar">

                    <?= e(
                        $iniciais
                    ) ?>

                </div>

            </div>

        </header>



        <div class="content">


            <?php if (
                $mensagem !== ""
            ): ?>

                <div
                    class="alerta <?= e(
                        $tipoMensagem
                    ) ?>">

                    <?= e(
                        $mensagem
                    ) ?>

                </div>

            <?php endif; ?>



            <!-- =================================================
                 DASHBOARD
            ================================================== -->

            <section
                class="section active"
                id="section-inicio">


                <div class="mot-agenda ea-calendar" data-calendar="mot-agenda-data">
                    <div class="mot-heading">
                        <div><span class="mot-eyebrow">Seu planejamento</span><h2>Seu calendário de coletas</h2>
                        <p>Pedidos no dia em que foram emitidos, com o prazo na etiqueta. Você decide a ordem das coletas.</p></div>
                        <div class="mot-navigation"><button type="button" id="mot-prev" data-calendar-prev aria-label="Semana anterior">‹</button>
                        <button type="button" id="mot-current" data-calendar-current>Esta semana</button>
                        <button type="button" id="mot-next" data-calendar-next aria-label="Próxima semana">›</button></div>
                    </div>
                    <div class="mot-week-heading"><strong id="mot-week-label" data-calendar-label aria-live="polite"></strong><span>5 dias úteis · exceto fins de semana e feriados</span></div>
                    <div id="mot-calendar" data-calendar-days class="mot-calendar" aria-label="Pedidos por data de emissão"></div>
                    <p class="mot-calendar-help">Clique em um pedido para ver os detalhes e atualizar a coleta. <span>No celular, deslize a semana para os lados.</span></p>
                    <p class="ea-calendar-other" data-calendar-other hidden></p><div class="mot-legend ea-deadline-legend"><span class="verde">4–5 dias úteis</span><span class="amarelo">2–3 dias úteis</span><span class="vermelho">1 dia útil ou vence hoje</span><span class="cinza">Prazo vencido</span></div>
                    <noscript>Ative o JavaScript para navegar pelo calendário. Você também pode consultar os pedidos em Minhas coletas.</noscript>
                </div>
                <script type="application/json" id="mot-agenda-data"><?= json_encode(['feriados'=>eaCalendarioFeriados(),'hoje'=>(new DateTimeImmutable('now', new DateTimeZone('America/Sao_Paulo')))->format('Y-m-d'), 'pedidos'=>$agendaMotorista], JSON_HEX_TAG|JSON_HEX_AMP|JSON_HEX_APOS|JSON_HEX_QUOT|JSON_UNESCAPED_UNICODE) ?></script>
            </section>



            <!-- =================================================
                 MINHAS COLETAS
            ================================================== -->

            <section
                class="section"
                id="section-pedidos">


                <div class="mot-filters-row">
                    <label class="mot-detail-filter">Status dos pedidos
                        <select id="mot-status-filter"><option value="todos">Todos os status</option><option value="confirmado">Agendados</option><option value="a-caminho">A caminho</option><option value="andamento">Em andamento</option><option value="concluido">Concluídos</option><option value="cancelado">Suspensos</option></select>
                    </label>
                    <label class="mot-detail-filter">Prazo dos pedidos
                        <select id="mot-detail-filter"><option value="todos">Todos os prazos</option><option value="valido">Dentro do prazo</option><option value="vencido">Prazo vencido</option></select>
                    </label>
<button type="button" class="btn-secondary mot-map-button" id="mot-show-map" aria-haspopup="dialog"><svg class="ea-icon" viewBox="0 0 24 24" aria-hidden="true"><path d="m3 5 6-2 6 2 6-2v16l-6 2-6-2-6 2V5ZM9 3v16M15 5v16"/></svg>Visualizar mapa</button>
                </div>
                <div class="cards-pedidos">


                    <?php foreach (
                        $pedidos
                        as $pedido
                    ): ?>


                        <?php

                        $classe = classeStatus($pedido["status"]);
                        $filtroStatus = match (mb_strtolower(trim($pedido["status"]), "UTF-8")) {
                            "encaminhado" => "confirmado",
                            "a caminho" => "a-caminho",
                            "em andamento" => "andamento",
                            "concluído", "concluido" => "concluido",
                            "suspenso" => "cancelado",
                            default => "outro"
                        };

                        ?>


                        <article
                            class="pedido-card"
                            id="mot-pedido-<?= (int)$pedido["id"] ?>"
                            data-prazo="<?= e($pedido["prazo_motorista"]["classe"]) ?>"
                            data-status="<?= e($filtroStatus) ?>">


                            <div class="mot-compact-heading">
                                <div class="mot-order-number" aria-label="Pedido <?= (int)$pedido['id'] ?>"><span class="ea-order-icon"><svg class="ea-icon" aria-hidden="true"><use href="#ea-box"/></svg></span><span class="ea-order-label">Pedido<strong><?= (int)$pedido['id'] ?></strong></span></div>
                                <span class="status <?= e($classe) ?>"><?= e(mb_strtolower(trim($pedido['status']), 'UTF-8') === 'encaminhado' ? 'Agendado' : $pedido['status']) ?></span>
                            </div>
                            <div class="mot-compact-info">
                                <div><span>Local de coleta</span><strong><?= e($pedido['endereco'] ?: 'Endereço não informado') ?></strong></div>
                                <div><span>Material de coleta</span><strong><?= e(materialMotorista($pedido['descricao'])) ?></strong></div>
                            </div>
                            <div class="mot-compact-footer">
                                <div class="mot-deadline-badges"><span class="mot-badge ea-urgency <?= e($pedido['prazo_motorista']['urgencia']) ?>"><?= e($pedido['prazo_motorista']['texto']) ?></span>
                                <?php if ($pedido['prazo_motorista']['classe'] === 'hoje'): ?><span class="mot-badge ea-urgency vermelho">Vence hoje</span><?php endif; ?></div>
                                <button type="button" class="btn-small btn-detalhes" data-id="<?= (int)$pedido['id'] ?>">Ver detalhes <span aria-hidden="true">→</span></button>
                            </div>
                            <div
                                class="pedido-actions" id="mot-actions-<?= (int)$pedido['id'] ?>" hidden>


                                <?php if (mb_strtolower(trim($pedido["status"]), "UTF-8") === "encaminhado"): ?>

                                    <form method="POST" class="inline-form">
                                        <input type="hidden" name="acao" value="ir_local">
                                        <input type="hidden" name="agendamento_id" value="<?= (int)$pedido["id"] ?>">
                                        <button type="submit" class="btn-small btn-iniciar">
                                            Ir até o local
                                        </button>
                                    </form>

                                <?php elseif (mb_strtolower(trim($pedido["status"]), "UTF-8") === "a caminho"): ?>

                                    <form method="POST" class="inline-form">
                                        <input type="hidden" name="acao" value="iniciar">
                                        <input type="hidden" name="agendamento_id" value="<?= (int)$pedido["id"] ?>">
                                        <button type="submit" class="btn-small btn-iniciar">
                                            Iniciar coleta
                                        </button>
                                    </form>

                                <?php endif; ?>


                                <?php if (
                                    $classe === "andamento"
                                ): ?>

                                    <button
                                        type="button"
                                        class="btn-small btn-concluir"
                                        data-id="<?= (int)$pedido["id"] ?>">

                                        Concluir coleta

                                    </button>

                                    <button
                                        type="button"
                                        class="btn-small btn-suspender"
                                        data-id="<?= (int)$pedido["id"] ?>">

                                        Suspender coleta

                                    </button>

                                <?php endif; ?>


                            </div>



                            <!-- DADOS PARA O JS -->

                            <div
                                class="dados-pedido"

                                id="dados-<?= (int)$pedido["id"] ?>"

                                data-id="<?= (int)$pedido["id"] ?>"
                                data-prazo="<?= e(dataBR($pedido['prazo_motorista']['limite'])) ?>"
                                data-prazo-texto="<?= e($pedido['prazo_motorista']['texto']) ?>"
                                data-prazo-hoje="<?= $pedido['prazo_motorista']['classe'] === 'hoje' ? '1' : '0' ?>"
                                data-chegada="<?= e(dataHoraBR($pedido['data_chegada'])) ?>"
                                data-finalizacao="<?= e(dataHoraBR($pedido['data_finalizacao'])) ?>"

                                data-descricao="<?= e(
                                    $pedido["descricao"]
                                ) ?>"

                                data-status="<?= e(
                                    mb_strtolower(trim($pedido["status"]), "UTF-8") === "encaminhado"
                                        ? "Agendado"
                                        : $pedido["status"]
                                ) ?>"

                                data-morador="<?= e(
                                    $pedido[
                                        "morador_nome"
                                    ] ?? ""
                                ) ?>"

                                data-cpf="<?= e(
                                    $pedido[
                                        "morador_cpf"
                                    ] ?? ""
                                ) ?>"

                                data-telefone="<?= e($pedido["morador_telefone"] ?? "") ?>"

                                data-endereco="<?= e(
                                    $pedido[
                                        "endereco"
                                    ] ?? ""
                                ) ?>"

                                data-data="<?= e(
                                    in_array($classe, ["confirmado", "a-caminho"], true)
                                        ? ""
                                        : ($pedido[
                                            "data_inicio"
                                        ] ?? "")
                                ) ?>"

                                data-hora="<?= e(
                                    in_array($classe, ["confirmado", "a-caminho"], true)
                                        ? ""
                                        : horaBR(
                                            $pedido[
                                                "data_inicio"
                                            ] ?? ""
                                        )
                                ) ?>"

                                data-foto="<?= e(
                                    $pedido[
                                        "foto"
                                    ] ?? ""
                                ) ?>"

                                data-foto-motorista="<?= e(
                                    $pedido[
                                        "foto_motorista"
                                    ] ?? ""
                                ) ?>"

                            ></div>


                        </article>


                    <?php endforeach; ?>


                    <?php if (
                        empty($pedidos)
                    ): ?>

                        <div class="sem-registros">

                            Ainda não existem coletas agendadas para você.

                        </div>

                    <?php endif; ?>


                </div>



                <div
                    id="semResultadoFiltro"
                    class="sem-registros"
                    hidden>

                    Nenhuma coleta encontrada para este filtro.

                </div>


            </section>



            <!-- =================================================
                 PERFIL
            ================================================== -->

            <section
                class="section"
                id="section-perfil">


                <div
                    class="painel perfil-card">


                    <div
                        class="profile-header">


                        <div
                            class="big-avatar">

                            <?= e(
                                $iniciais
                            ) ?>

                        </div>


                        <div>

                            <h2>

                                <?= e(
                                    $nomeMotorista
                                ) ?>

                            </h2>


                            <p>
                                Motorista cadastrado no EcoAgenda.
                            </p>

                        </div>

                    </div>



                    <div
                        class="perfil-grid">


                        <div>

                            <span>
                                E-mail
                            </span>

                            <strong>

                                <?= e(
                                    $dadosMotorista[
                                        "email"
                                    ]
                                ) ?>

                            </strong>

                        </div>


                        <div>

                            <span>
                                CPF
                            </span>

                            <strong>

                                <?= e(eaCpfVisual($dadosMotorista['cpf'])) ?>

                            </strong>

                        </div>


                        <div>

                            <span>
                                Telefone
                            </span>

                            <strong>

                                <?= e(
                                    $dadosMotorista[
                                        "telefone"
                                    ]
                                ) ?>

                            </strong>

                        </div>


                        <div>

                            <span>
                                CNH
                            </span>

                            <strong>

                                <?= e(
                                    $dadosMotorista[
                                        "cnh"
                                    ]
                                ) ?>

                            </strong>

                        </div>


                        <div>

                            <span>
                                Situação
                            </span>

                            <strong>

                                <?= (
                                    (int)
                                    $dadosMotorista[
                                        "ativo"
                                    ] === 1
                                )
                                ? "Ativo"
                                : "Inativo"
                                ?>

                            </strong>

                        </div>


                    </div>



                    <div
                        class="info-box">

                        Para alterar seus dados cadastrais,
                        procure a administração responsável pelo sistema.

                    </div>


                </div>

            </section>


        </div>

    </main>

</div>



<!-- =========================================================
     MODAL DETALHES
========================================================= -->

<div
    class="modal"
    id="modalDetalhes"
    role="dialog" aria-modal="true" aria-labelledby="modalPedidoId modalTitulo"
    hidden>


    <div class="modal-box">


        <div class="modal-header">


            <div>

                <span
                    id="modalPedidoId">

                    Pedido

                </span>


                <h2
                    id="modalTitulo">

                    Detalhes da coleta

                </h2>

            </div>


            <button
                type="button"
                class="modal-close"
                data-close-modal>

                ×

            </button>

        </div>



        <div class="modal-body mot-details-layout">
            <div class="mot-details-main">
                <section class="mot-details-group" aria-labelledby="mot-local-title">
                    <h3 id="mot-local-title">Local e material da coleta</h3>
                    <div class="detalhes-grid">
                        <div class="full"><span>Endereço de coleta</span><strong id="modalEndereco">—</strong></div>
                        <div><span>Material de coleta</span><strong id="mot-modal-material">—</strong></div>
                        <div><span>Quantidade aproximada</span><strong id="mot-modal-quantidade">—</strong></div>
                        <div class="full"><span>Descrição do pedido</span><strong id="modalDescricao">—</strong></div>
                    </div>
                </section>
                <section class="mot-details-group" aria-labelledby="mot-tracking-title">
                    <h3 id="mot-tracking-title">Prazo e acompanhamento</h3>
                    <div class="modal-status"><span>Status da coleta</span><strong id="modalStatus">—</strong></div>
                    <div class="detalhes-grid">
                        <div><span>Prazo de atendimento</span><strong id="mot-modal-prazo">—</strong></div>
                        <div><span>Situação do prazo</span><strong id="mot-modal-prazo-texto">—</strong></div>
                        <div><span>Início da coleta</span><strong id="modalData">—</strong></div>
                        <div><span>Horário de início</span><strong id="modalHora">—</strong></div>
                        <div><span>Chegada</span><strong id="mot-modal-chegada">—</strong></div>
                        <div><span>Finalização</span><strong id="mot-modal-finalizacao">—</strong></div>
                    </div>
                </section>
            </div>
            <div class="mot-details-aside">
                <section class="mot-details-group" aria-labelledby="mot-resident-title">
                    <h3 id="mot-resident-title">Dados do morador</h3>
                    <div class="detalhes-grid">
                        <div><span>Morador</span><strong id="modalMorador">—</strong></div>
                        <div><span>CPF</span><strong id="modalCpf">—</strong></div>
                        <div id="blocoTelefoneMorador"><span>Telefone</span><strong id="modalTelefone">—</strong></div>
                    </div>
                </section>
                <section id="modalFotoMotoristaAtual" class="foto-modal mot-details-group" hidden>
                    <h3>Registro da coleta</h3>
                    <img id="modalFotoMotorista" src="" alt="Foto da coleta">
                </section>
            </div>
        </div>

        <div
            class="modal-footer">
            <div id="mot-modal-actions" class="pedido-actions"></div>



            <button
                type="button"
                class="btn-secondary"
                data-close-modal>

                Fechar

            </button>


        </div>

    </div>

</div>



<!-- =========================================================
     MODAL CONCLUIR
========================================================= -->

<div
    class="modal"
    id="modalConcluir"
    role="dialog" aria-modal="true" aria-label="Concluir coleta"
    hidden>


    <div
        class="modal-box small">


        <div class="modal-header">


            <div>

                <span>
                    Finalizar coleta
                </span>

                <h2>
                    Concluir pedido
                </h2>

            </div>


            <button
                type="button"
                class="modal-close"
                data-close-modal>

                ×

            </button>

        </div>



        <form
            method="POST"
            enctype="multipart/form-data"
            class="modal-form">


            <input
                type="hidden"
                name="acao"
                value="concluir">


            <input
                type="hidden"
                name="agendamento_id"
                id="concluirId">


            <div class="info-box">

                Confirme a conclusão da coleta.
                A foto do material coletado é obrigatória para finalizar o pedido.

            </div>


            <div class="campo">

                <label
                    for="foto_motorista">

                    Foto da coleta

                    <span>
                        obrigatória
                    </span>

                </label>


                <input
                    type="file"
                    id="foto_motorista"
                    name="foto_motorista"
                    accept="image/jpeg,image/png,image/webp"
                    capture="environment"
                    required>

            </div>


            <div
                id="previewFoto"
                class="preview"
                hidden>


                <img
                    id="previewImagem"
                    src=""
                    alt="Pré-visualização">

            </div>



            <div
                class="form-actions">


                <button
                    type="button"
                    class="btn-secondary"
                    data-close-modal>

                    Cancelar

                </button>


                <button
                    type="submit"
                    class="btn-primary">

                    Concluir coleta

                </button>

            </div>


        </form>

    </div>

</div>




<!-- =========================================================
     MODAL SUSPENDER COLETA
========================================================= -->

<div
    class="modal"
    id="modalSuspender"
    role="dialog" aria-modal="true" aria-label="Suspender coleta"
    hidden>

    <div
        class="modal-box small">

        <div class="modal-header">

            <div>

                <span>
                    Suspensão da coleta
                </span>

                <h2>
                    Suspender coleta
                </h2>

            </div>

            <button
                type="button"
                class="modal-close"
                data-close-modal>

                ×

            </button>

        </div>

        <form
            method="POST"
            enctype="multipart/form-data"
            class="modal-form">

            <input
                type="hidden"
                name="acao"
                value="suspender">

            <input
                type="hidden"
                name="agendamento_id"
                id="suspenderId">

            <div class="warning-box">
                Registre a foto do ocorrido e descreva o motivo da suspensão. O pedido será registrado com status <strong>Suspenso</strong>.
            </div>

            <div class="campo">

                <label
                    for="foto_suspensao">

                    Foto do ocorrido

                    <span>
                        obrigatória
                    </span>

                </label>

                <input
                    type="file"
                    id="foto_suspensao"
                    name="foto_suspensao"
                    accept="image/jpeg,image/png,image/webp"
                    capture="environment"
                    required>

            </div>

            <div
                id="previewFotoSuspensao"
                class="preview"
                hidden>

                <img
                    id="previewImagemSuspensao"
                    src=""
                    alt="Pré-visualização da foto do ocorrido">

            </div>

            <div class="campo">

                <label
                    for="justificativaSuspensao">

                    Justificativa

                    <span>
                        obrigatória
                    </span>

                </label>

                <textarea
                    id="justificativaSuspensao"
                    name="justificativa_suspensao"
                    maxlength="225"
                    rows="5"
                    placeholder="Descreva o que foi encontrado no local e por que a coleta não pôde ser realizada."
                    required></textarea>

                <small class="contador-caracteres">
                    Máximo de 225 caracteres.
                </small>

            </div>

            <div class="form-actions">

                <button
                    type="button"
                    class="btn-secondary"
                    data-close-modal>

                    Voltar

                </button>

                <button
                    type="submit"
                    class="btn-danger">

                    Confirmar suspensão

                </button>

            </div>

        </form>

    </div>

</div>


<script
    src="motorista.js?v=20261023-cpf">
</script>


<div class="modal" id="mot-map-modal" hidden role="dialog" aria-modal="true" aria-labelledby="mot-map-title"><div class="modal-box mot-map-box"><div class="modal-header"><div><span>Seu planejamento</span><h2 id="mot-map-title">Mapa das suas coletas</h2></div><button type="button" class="modal-close" data-close-modal aria-label="Fechar mapa">×</button></div><iframe id="mot-map-frame" title="Localização das coletas atribuídas a você"></iframe></div></div>
</body>

</html>