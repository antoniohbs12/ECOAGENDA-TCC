# Onde encontrar cada parte

- `configuracoes/banco.php`: conexão com MySQL; valores preservados.
- `configuracoes/email.php`: configuração do envio de e-mail.
- `configuracoes/cpf.php`: configuração da consulta de CPF.
- `recursos/scripts/`: JavaScript organizado por perfil ou função.
- `recursos/estilos/`: CSS organizado pelos mesmos grupos.
- `cadastro/`: cadastro e confirmação.
- `agendamento/`: criação das solicitações e arquivos enviados.
- `login/`: entrada, saída e recuperação de acesso.
- `login/dashboard_morador/`: painel e funções do morador.
- `login/secretaria/`: análise e encaminhamento.
- `login/motorista/`: execução das coletas.
- `login/administrador/`: indicadores, relatórios e gestão.
- `login/interface/`: código compartilhado entre as telas.
- `assets/icons/`: imagens de ícones existentes.
- `login/administrador/vendor/`: bibliotecas externas usadas pelos mapas. Não é código próprio do projeto; seus arquivos e licenças devem ser preservados.
- `documentacao/`: instruções e verificações.

Os nomes das pastas que fazem parte das URLs das páginas foram mantidos para preservar formulários, links e redirecionamentos existentes. Os três arquivos antigos de configuração continuam como encaminhadores; não os remova.

Nesta revisão foram removidos 249 comentários PHP e 104 comentários JavaScript. Permaneceram os avisos e comentários relacionados a mapas, licenças e atribuições. Os comentários das configurações centrais foram preservados junto com seu conteúdo. HTML, scripts embutidos em HTML e bibliotecas externas não passaram pela remoção de comentários; as mudanças de caminhos necessárias foram aplicadas nas referências aos recursos.

Verificações: sintaxe de 48 PHP e 26 JavaScript; equivalência de tokens dos 48 PHP após normalizar somente as mudanças previstas de caminhos; equivalência da árvore sintática dos JavaScript revisados; referências estáticas locais sem pendências; preservação dos arquivos de mapas/GeoJSON, uploads e configurações.

As páginas inicial, login e cadastro foram comparadas em navegador antes/depois: imagens idênticas, nenhum recurso local ausente e nenhum novo erro de JavaScript. São testes locais com resposta de sessão simulada, sem banco real nem integrações externas.

Não há alteração de esquema ou dados do MySQL. A verificação completa do atendimento com o banco e contas do usuário continua dependendo do ambiente local. Faça backup da pasta atual, mantenha uploads mais recentes e recarregue com Ctrl+F5 após substituir os arquivos.
