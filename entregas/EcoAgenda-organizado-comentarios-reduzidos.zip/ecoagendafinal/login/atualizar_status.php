<?php

session_start();

require_once "../config.php";


                     

if (!isset($_SESSION["email"])) {

    header("Location: login.html");
    exit();

}


                         

if (
    !isset($_SESSION["perfil"]) ||
    $_SESSION["perfil"] !== "motorista"
) {

    header("Location: ../index.html");
    exit();

}


                   

$idPedido = $_POST["id"] ?? "";

$novoStatus = $_POST["status"] ?? "";


if (
    empty($idPedido) ||
    empty($novoStatus)
) {

    header("Location: motorista.php");
    exit();

}


$idPedido = (int)$idPedido;

$novoStatus = (int)$novoStatus;


                       

$statusPermitidos = [
    2,
    3,
    4,
    5
];


if (!in_array(
    $novoStatus,
    $statusPermitidos
)) {

    header("Location: motorista.php");
    exit();

}


                              

if (
    isset($_FILES["foto_motorista"]) &&
    $_FILES["foto_motorista"]["error"] === UPLOAD_ERR_OK
) {

    $arquivo = $_FILES["foto_motorista"];


                         

    if ($arquivo["size"] > 10 * 1024 * 1024) {

        die(
            "A foto deve ter no máximo 10 MB."
        );

    }


                                        

    $finfo = finfo_open(FILEINFO_MIME_TYPE);

    $tipo = finfo_file(
        $finfo,
        $arquivo["tmp_name"]
    );

    finfo_close($finfo);


                             

    $tiposPermitidos = [

        "image/jpeg" => "jpg",

        "image/png" => "png",

        "image/webp" => "webp",

        "image/avif" => "avif",

        "image/heic" => "heic",

        "image/heif" => "heif"

    ];


    if (!isset(
        $tiposPermitidos[$tipo]
    )) {

        die(
            "Formato de imagem não permitido. " .
            "Tipo recebido: " .
            htmlspecialchars($tipo)
        );

    }


    $extensao =
        $tiposPermitidos[$tipo];


                     

    $pasta =
        "../agendamento/uploads/";


    if (!is_dir($pasta)) {

        if (!mkdir(
            $pasta,
            0777,
            true
        )) {

            die(
                "Não foi possível criar a pasta de uploads."
            );

        }

    }


                     

    $nomeArquivo =
        "motorista_" .
        $idPedido .
        "_" .
        time() .
        "." .
        $extensao;


    $caminhoCompleto =
        $pasta .
        $nomeArquivo;


                     

    if (!move_uploaded_file(
        $arquivo["tmp_name"],
        $caminhoCompleto
    )) {

        die(
            "Não foi possível salvar a foto."
        );

    }


                          

    $fotoMotorista =
        "uploads/" .
        $nomeArquivo;


                        

    $sqlFoto = "
        UPDATE agendamento
        SET foto_motorista = ?
        WHERE ID = ?
    ";


    $stmtFoto =
        $conn->prepare($sqlFoto);


    if (!$stmtFoto) {

        die(
            "Erro ao preparar foto: " .
            $conn->error
        );

    }


    $stmtFoto->bind_param(
        "si",
        $fotoMotorista,
        $idPedido
    );


    if (!$stmtFoto->execute()) {

        die(
            "Erro ao salvar foto no banco: " .
            $stmtFoto->error
        );

    }


    $stmtFoto->close();

}


                      

$sql = "
    UPDATE agendamento
    SET status_id = ?
    WHERE ID = ?
";


$stmt =
    $conn->prepare($sql);


if (!$stmt) {

    die(
        "Erro ao preparar atualização: " .
        $conn->error
    );

}


$stmt->bind_param(
    "ii",
    $novoStatus,
    $idPedido
);


if (!$stmt->execute()) {

    die(
        "Erro ao atualizar status: " .
        $stmt->error
    );

}


$stmt->close();

$conn->close();


                           

header(
    "Location: motorista.php"
);

exit();

?>