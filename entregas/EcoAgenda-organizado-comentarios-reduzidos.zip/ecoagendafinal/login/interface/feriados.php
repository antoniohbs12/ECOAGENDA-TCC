<?php
                                                                              
                                                                             
                                                                                           
                                                                            
   
function eaFeriadosLocais(int $ano): array { return [sprintf('%04d-03-20',$ano)=>'Aniversário de Pinhais']; }
function eaFeriados(int $ano): array {
    static $cache=[];if(isset($cache[$ano]))return $cache[$ano];
    $fixos=['01-01'=>'Confraternização Universal','04-21'=>'Tiradentes','05-01'=>'Dia do Trabalho','09-07'=>'Independência do Brasil','10-12'=>'Nossa Senhora Aparecida','11-02'=>'Finados','11-15'=>'Proclamação da República','12-25'=>'Natal'];
    if($ano>=2024)$fixos['11-20']='Dia Nacional de Zumbi e da Consciência Negra';
    $dias=eaFeriadosLocais($ano);foreach($fixos as $data=>$nome)$dias[sprintf('%04d-',$ano).$data]=$nome;ksort($dias);return $cache[$ano]=$dias;
}
function eaDiaUtil(DateTimeInterface $data): bool {return (int)$data->format('N')<=5 && !isset(eaFeriados((int)$data->format('Y'))[$data->format('Y-m-d')]);}
function eaCalendarioFeriados(): array {
    $hoje=new DateTimeImmutable('now',new DateTimeZone('America/Sao_Paulo'));$ano=(int)$hoje->format('Y');
    return eaFeriados($ano-1)+eaFeriados($ano)+eaFeriados($ano+1);
}
