<?php
session_start();
require_once __DIR__.'/../../config.php';
mysqli_report(MYSQLI_REPORT_ERROR | MYSQLI_REPORT_STRICT);
function h($s){return htmlspecialchars((string)$s, ENT_QUOTES, 'UTF-8');}
function editavel($s){return in_array(mb_strtolower(trim($s),'UTF-8'),['pendente','em análise','em analise','agendado','encaminhado','confirmado'],true);}
$perfil=$_SESSION['perfil']??'';$email=$_SESSION['email']??'';
if(!$email || !in_array($perfil,['morador','secretaria'],true)){http_response_code(403);exit('Acesso não permitido.');}
if($perfil==='secretaria'){
 $s=$conn->prepare('SELECT ativo FROM secretaria WHERE email=?');$s->bind_param('s',$email);$s->execute();
 if((int)($s->get_result()->fetch_assoc()['ativo']??0)!==1){http_response_code(403);exit('Acesso não permitido.');}
}
$_SESSION['endereco_csrf']??=bin2hex(random_bytes(32));
$id=(int)($_GET['id']??$_POST['id']??0);$erro='';$sucesso=false;$pedido=null;$atual=[];
$limites=['cep'=>20,'estado'=>2,'cidade'=>100,'bairro'=>100,'rua'=>150,'numero'=>20,'complemento'=>100];
$campos=['cep'=>'CEP','estado'=>'Estado','cidade'=>'Cidade','bairro'=>'Bairro','rua'=>'Rua','numero'=>'Número','complemento'=>'Complemento'];
try{
 $conn->begin_transaction();
 $s=$conn->prepare('SELECT * FROM agendamento WHERE id=? FOR UPDATE');$s->bind_param('i',$id);$s->execute();$pedido=$s->get_result()->fetch_assoc();
 if(!$pedido || ($perfil==='morador' && $pedido['morador_email']!==$email)){http_response_code(403);throw new RuntimeException('Pedido não disponível para este usuário.');}
 if(!editavel($pedido['status'])){http_response_code(409);throw new RuntimeException('O endereço só pode ser corrigido antes de a coleta estar A caminho.');}
 $s=$conn->prepare('SELECT e.* FROM agendamento_morador_endereco a JOIN endereco e ON e.id=a.endereco_id WHERE a.agendamento_id=? AND a.morador_email=? ORDER BY e.id DESC LIMIT 1');$s->bind_param('is',$id,$pedido['morador_email']);$s->execute();$atual=$s->get_result()->fetch_assoc()?:[];
 if($_SERVER['REQUEST_METHOD']==='POST'){
  if(!hash_equals($_SESSION['endereco_csrf'],(string)($_POST['csrf']??''))){http_response_code(403);throw new RuntimeException('Sessão inválida. Reabra a edição e tente novamente.');}
  $novo=[];foreach($campos as $k=>$label){$novo[$k]=trim((string)($_POST[$k]??''));if(($k!=='complemento'&&$novo[$k]==='')||mb_strlen($novo[$k])>$limites[$k])throw new RuntimeException('Confira o campo '.$label.'.');}
  $novo['cep']=preg_replace('/\D/','',$novo['cep']);$novo['estado']=strtoupper($novo['estado']);
  if(strlen($novo['cep'])!==8 || mb_strtolower($novo['cidade'],'UTF-8')!=='pinhais'||$novo['estado']!=='PR')throw new RuntimeException('Informe um CEP válido e um endereço de Pinhais — PR.');
  $antes=array_intersect_key($atual,$campos);
  if($antes!=$novo){
   $s=$conn->prepare('INSERT INTO endereco (email,cep,estado,cidade,rua,bairro,numero,complemento) VALUES (?,?,?,?,?,?,?,?)');
   $s->bind_param('ssssssss',$pedido['morador_email'],$novo['cep'],$novo['estado'],$novo['cidade'],$novo['rua'],$novo['bairro'],$novo['numero'],$novo['complemento']);$s->execute();$eid=$conn->insert_id;
   $s=$conn->prepare('INSERT INTO morador_endereco (endereco_id,morador_email) VALUES (?,?)');$s->bind_param('is',$eid,$pedido['morador_email']);$s->execute();
                                                                                     
                                                                                    
   $s=$conn->prepare('DELETE FROM agendamento_morador_endereco WHERE agendamento_id=? AND morador_email=?');
   $s->bind_param('is',$id,$pedido['morador_email']);$s->execute();
   $s=$conn->prepare('INSERT INTO agendamento_morador_endereco (agendamento_id,endereco_id,morador_email) VALUES (?,?,?)');$s->bind_param('iis',$id,$eid,$pedido['morador_email']);$s->execute();
   $formatar=function($a)use($campos){$partes=[];foreach($campos as $k=>$label)$partes[]=$label.': '.($a[$k]??'');return implode(' | ',$partes);};
   $registro="Correção do endereço pelo perfil $perfil.\nAnterior: ".$formatar($atual)."\nNovo: ".$formatar($novo);
   $s=$conn->prepare("INSERT INTO agendamento_historico (agendamento_id,criado_por,descricao,data_pedido,foto,morador_email,status,comando,data_comando,usuario_logado) SELECT id,criado_por,?,data_pedido,foto,morador_email,status,'ENDERECO',NOW(),? FROM agendamento WHERE id=?");foreach(mb_str_split($registro,190,'UTF-8') as $indice=>$trecho){$parte='Endereço (parte '.($indice+1).'): '.$trecho;$s->bind_param('ssi',$parte,$email,$id);$s->execute();}
  }
  $atual=$novo;$sucesso=true;
 }
 $conn->commit();
}catch(Throwable $e){$conn->rollback();$erro=$e instanceof RuntimeException?$e->getMessage():'Não foi possível salvar o endereço. Tente novamente.';if(!($e instanceof RuntimeException))error_log('EcoAgenda edição endereço: '.$e->getMessage());}
$permitido=$pedido && ($perfil==='secretaria'||$pedido['morador_email']===$email) && editavel($pedido['status']);
?>
<!doctype html><html lang="pt-BR"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>Corrigir endereço</title><link rel="stylesheet" href="base.css"><link rel="stylesheet" href="endereco_edicao.css"></head><body class="ea-address-page">
<main><h1>Corrigir endereço · Pedido <?= $id ?></h1><p>Corrija apenas o endereço informado incorretamente. A edição fica disponível em Em análise e Agendado. Quando a coleta estiver A caminho, não será mais possível editar.</p>
<?php if($erro): ?><p role="alert" class="ea-address-error"><?= h($erro) ?></p><?php endif; ?>
<?php if($sucesso): ?><p role="status" class="ea-address-success">Endereço atualizado com sucesso. A alteração foi registrada no histórico.</p><button type="button" id="addressDone">Voltar ao pedido</button>
<?php elseif($permitido): ?><form method="post"><input type="hidden" name="id" value="<?= $id ?>"><input type="hidden" name="csrf" value="<?= h($_SESSION['endereco_csrf']) ?>"><div class="ea-address-grid">
<?php foreach($campos as $k=>$label): ?><label><?= h($label) ?><input name="<?= $k ?>" value="<?= h($_POST[$k]??$atual[$k]??'') ?>" maxlength="<?= $limites[$k] ?>" <?= $k==='complemento'?'':'required' ?> <?= $k==='cep'?'inputmode="numeric"':'' ?>></label><?php endforeach; ?>
</div><button type="submit">Salvar endereço</button></form><?php endif; ?>
</main><script>document.getElementById('addressDone')?.addEventListener('click',()=>parent.postMessage({type:'ea-address-saved',id:<?= $id ?>},location.origin));document.querySelector('form')?.addEventListener('submit',e=>{if(e.target.checkValidity()){const b=e.target.querySelector('button');b.disabled=true;b.textContent='Salvando…';}});</script></body></html>
