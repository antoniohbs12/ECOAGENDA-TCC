                                                                             
(() => {
    const holidayURL=new URL('calendario_feriados.php',document.currentScript.src);
    const reduced=matchMedia('(prefers-reduced-motion: reduce)');
    const date=value=>{const [y,m,d]=value.split('-').map(Number);return new Date(y,m-1,d,12);};
    const iso=d=>`${d.getFullYear()}-${String(d.getMonth()+1).padStart(2,'0')}-${String(d.getDate()).padStart(2,'0')}`;
    document.querySelectorAll('[data-calendar]').forEach(root=>{
        const source=document.getElementById(root.dataset.calendar);if(!source)return;
        const agenda=JSON.parse(source.textContent),today=date(agenda.hoje);
        const monday=d=>{const x=new Date(d);x.setDate(x.getDate()-(x.getDay()+6)%7);return x;};
        let week=monday(today);const holidays=agenda.feriados||{};const years=new Set([today.getFullYear()-1,today.getFullYear(),today.getFullYear()+1]);let pendingYear=null;
        const container=root.querySelector('[data-calendar-days]');
        const dialog=document.createElement('dialog');
        dialog.className='ea-calendar ea-day-dialog';
        const heading=document.createElement('header');heading.className='ea-day-dialog-heading';
        const title=document.createElement('h2');title.id=`${root.dataset.calendar}-day-title`;
        dialog.setAttribute('aria-labelledby',title.id);
        const close=document.createElement('button');close.type='button';close.className='ea-day-close';close.textContent='Fechar ×';
        const summary=document.createElement('p');summary.className='ea-day-summary';
        const list=document.createElement('div');list.className='ea-day-orders';
        heading.append(title,close);dialog.append(heading,summary,list);document.body.append(dialog);
        let opener=null,closing=false;
        function closeDay(){
            if(closing||!dialog.open)return;closing=true;
            const finish=()=>{dialog.close();closing=false;opener?.focus({preventScroll:true});};
            if(reduced.matches||!dialog.animate){finish();return;}
            dialog.animate([{opacity:1,transform:'translateY(0)'},{opacity:0,transform:'translateY(12px)'}],{duration:160,easing:'ease-in'}).finished.then(finish,finish);
        }
        close.addEventListener('click',closeDay);
        dialog.addEventListener('cancel',event=>{event.preventDefault();closeDay();});
        dialog.addEventListener('click',event=>{if(event.target!==dialog)return;const r=dialog.getBoundingClientRect();if(event.clientX<r.left||event.clientX>r.right||event.clientY<r.top||event.clientY>r.bottom)closeDay();});
        function openDay(col,d,trigger){
            opener=trigger;list.replaceChildren();
            title.textContent=d.toLocaleDateString('pt-BR',{weekday:'long',day:'2-digit',month:'long',year:'numeric'});
            const cards=col.querySelectorAll('.mot-calendar-order');
            summary.textContent=cards.length?`${cards.length} ${cards.length===1?'pedido emitido':'pedidos emitidos'} neste dia.`:'Nenhum pedido emitido neste dia para exibir.';
            col.querySelectorAll('.ea-holiday-notice,.ea-weekend-notice').forEach(note=>list.append(note.cloneNode(true)));
            cards.forEach(card=>{
                const copy=card.cloneNode(true);
                copy.addEventListener('click',()=>{dialog.close();opener?.focus({preventScroll:true});card.click();});
                list.append(copy);
            });
            dialog.showModal();close.focus({preventScroll:true});
            if(!reduced.matches&&dialog.animate)dialog.animate([{opacity:0,transform:'translateY(18px) scale(.98)'},{opacity:1,transform:'translateY(0) scale(1)'}],{duration:240,easing:'cubic-bezier(.2,.8,.2,1)'});
        }
        function render(direction=0){
            root.dataset.week=iso(week);
            const year=week.getFullYear();
            if(!years.has(year)&&pendingYear!==year){pendingYear=year;const url=new URL(holidayURL);url.searchParams.set('ano',year);fetch(url).then(r=>{if(!r.ok)throw Error();return r.json();}).then(data=>{Object.assign(holidays,data);[year-1,year,year+1].forEach(y=>years.add(y));if(week.getFullYear()===year)render();}).catch(()=>window.EcoFlow?.toast('Não foi possível consultar os feriados deste ano. Tente novamente.',{error:true})).finally(()=>{pendingYear=null;});}
            container.replaceChildren();
            const end=new Date(week);end.setDate(end.getDate()+6);
            root.querySelector('[data-calendar-label]').textContent=`${week.toLocaleDateString('pt-BR')} — ${end.toLocaleDateString('pt-BR')}`;
            let shown=0;
            for(let i=0;i<7;i++){
                const d=new Date(week);d.setDate(d.getDate()+i);const key=iso(d);
                const col=document.createElement('div');col.className=`mot-day${i>4?' mot-weekend':''}${key===agenda.hoje?' mot-today':''}`;col.dataset.date=key;
                const head=document.createElement('button');head.type='button';head.className='mot-day-heading';head.setAttribute('aria-haspopup','dialog');head.setAttribute('aria-label',`Ver pedidos emitidos em ${d.toLocaleDateString('pt-BR')}`);head.addEventListener('click',()=>openDay(col,d,head));col.addEventListener('click',event=>{if(!event.target.closest('button'))openDay(col,d,head);});
                const name=document.createElement('span');name.className='mot-day-name';name.textContent=['Segunda','Terça','Quarta','Quinta','Sexta','Sábado','Domingo'][i];
                const num=document.createElement('strong');num.className='mot-day-number';num.textContent=String(d.getDate()).padStart(2,'0');
                const sub=document.createElement('span');sub.className='mot-day-subtitle';sub.textContent=key===agenda.hoje?'Hoje':d.toLocaleDateString('pt-BR',{month:'short'}).replace('.','');head.append(name,num,sub);col.append(head);
                const holiday=holidays[key];if(holiday){col.classList.add('mot-holiday');const note=document.createElement('p');note.className='ea-holiday-notice';note.textContent=`Feriado · ${holiday}. As coletas voltam no próximo dia útil.`;col.append(note);}else if(i>4){const note=document.createElement('p');note.className='ea-weekend-notice';note.textContent='Fim de semana · as coletas voltam no próximo dia útil.';col.append(note);}
                const orders=agenda.pedidos.filter(p=>p.emitido===key).sort((a,b)=>a.limite.localeCompare(b.limite)||a.id-b.id);shown+=orders.length;
                orders.forEach(p=>{
                    const button=document.createElement('button');button.type='button';button.className=`mot-calendar-order ea-urgency ${p.urgencia}`;button.dataset.id=p.id;
                    button.setAttribute('aria-label',`Ver detalhes do pedido ${p.id}, ${p.local}`);
                    const number=document.createElement('strong');number.className='mot-calendar-number';const label=document.createElement('span');label.textContent='Pedido';const value=document.createElement('b');value.textContent=p.id;number.append(label,value);
                    const local=document.createElement('span');local.className='mot-order-local';local.textContent=p.local;
                    const material=document.createElement('span');material.className='mot-order-material';material.textContent=p.material;
                    const limit=document.createElement('span');limit.className=`ea-deadline-tag ${p.urgencia}`;
                    limit.textContent=p.limite?`Até ${date(p.limite).toLocaleDateString('pt-BR',{day:'2-digit',month:'2-digit'})} (${date(p.limite).toLocaleDateString('pt-BR',{weekday:'long'})})`:'Prazo não informado';
                    const notice=document.createElement('span');notice.className='ea-days-left';notice.textContent=p.classe==='encerrado'?'Pedido encerrado':p.classe==='vencido'?'Prazo vencido':p.classe==='hoje'?'Vence hoje':p.restantes===null?'Prazo não informado':`${p.restantes} ${p.restantes===1?'dia útil restante':'dias úteis restantes'}`;
                    const open=document.createElement('span');open.className='mot-order-open';open.textContent='Ver detalhes →';const status=document.createElement('span');status.className='ea-status-token';status.textContent=p.status||'Em análise';button.append(number,local,material,status,limit,notice,open);
                    button.addEventListener('click',()=>{
                        if(root.dataset.calendar==='adm-agenda-data')document.querySelector(`#section-pedidos .btn-detalhes[data-id="${p.id}"]`)?.click();
                        else document.dispatchEvent(new CustomEvent('ea-calendar-open',{detail:{id:p.id}}));
                    });col.append(button);
                });
                if(!orders.length){const empty=document.createElement('p');empty.className='mot-day-empty';empty.textContent='Nenhum pedido emitido';col.append(empty);}
                container.append(col);
            }
            const other=root.querySelector('[data-calendar-other]');other.replaceChildren();other.hidden=shown===agenda.pedidos.length;
            if(!other.hidden){
                const missing=agenda.pedidos.filter(p=>p.emitido<iso(week)||p.emitido>iso(end)).sort((a,b)=>a.limite.localeCompare(b.limite));
                other.append(document.createTextNode(`${missing.length} coleta(s) a atender foram emitidas em outras semanas. `));
                const go=document.createElement('button');go.type='button';go.textContent='Ver semana do pedido mais urgente';go.addEventListener('click',()=>{week=monday(date(missing[0].emitido));render(-1);});other.append(go);
            }
            if(!reduced.matches&&container.animate){container.getAnimations().forEach(a=>a.cancel());container.animate([{opacity:0,transform:`translateX(${direction*16}px)`},{opacity:1,transform:'translateX(0)'}],{duration:260,easing:'ease-out'});}
        }
        document.addEventListener('ea-calendar-go',event=>{
            const {source,date:target,id,order}=event.detail||{};if(source&&source!==root.dataset.calendar)return;
                                                                                           
            if(order&&!agenda.pedidos.some(p=>p.id===order.id))agenda.pedidos.push(order);
            if(!/^\d{4}-\d{2}-\d{2}$/.test(target||''))return;
            week=monday(date(target));render();
            if(id)requestAnimationFrame(()=>{const card=container.querySelector(`[data-id="${Number(id)}"]`);card?.scrollIntoView({block:'center',inline:'center',behavior:reduced.matches?'instant':'smooth'});card?.focus({preventScroll:true});});
        });
        root.querySelector('[data-calendar-prev]').addEventListener('click',()=>{week.setDate(week.getDate()-7);render(-1);});
        root.querySelector('[data-calendar-next]').addEventListener('click',()=>{week.setDate(week.getDate()+7);render(1);});
        root.querySelector('[data-calendar-current]').addEventListener('click',()=>{week=monday(today);render();});render();
    });
})();
