<?php

session_start();

require_once "../config.php";


                                             

function redirecionarPerfil($perfil)
{
    switch ($perfil) {

        case "morador":
            header("Location: dashboard_morador/dashboard_morador.php");
            exit();

        case "secretaria":
            header("Location: secretaria/secretaria.php");
            exit();

        case "motorista":
            header("Location: motorista/motorista.php");
            exit();

        case "administrador":
            header("Location: administrador/administrador.php");
            exit();

        default:
            header("Location: login.html");
            exit();
    }
}


                           

if (
    isset($_SESSION["email"]) &&
    isset($_SESSION["perfil"])
) {

    redirecionarPerfil(
        $_SESSION["perfil"]
    );
}


           

if ($_SERVER["REQUEST_METHOD"] !== "POST") {

    header("Location: login.html");
    exit();
}


$identificador = trim(
    $_POST["login"] ??
    $_POST["email"] ??
    ""
);

$senha = $_POST["senha"] ?? "";


                 

if ($identificador === "" || $senha === "") {

    header(
        "Location: login.html?erro=" .
        urlencode("Informe seu e-mail ou CPF e a senha.")
    );

    exit();
}


                                  

$isEmail = filter_var(
    $identificador,
    FILTER_VALIDATE_EMAIL
);

$cpfDigitado = preg_replace(
    '/\D+/',
    '',
    $identificador
);

if (!$isEmail && strlen($cpfDigitado) !== 11) {

    header(
        "Location: login.html?erro=" .
        urlencode("Informe um e-mail ou CPF válido.")
    );

    exit();
}


                     

if ($isEmail) {

    $sql = "
        SELECT
            email,
            senha,
            nome
        FROM usuario
        WHERE email = ?
        LIMIT 1
    ";

    $parametroLogin = $identificador;

} else {

                    
                                           
                                                                 
                                        

    $sql = "
        SELECT
            u.email,
            u.senha,
            u.nome
        FROM usuario u
        INNER JOIN morador m
            ON m.email = u.email
        WHERE REPLACE(
                  REPLACE(
                      REPLACE(TRIM(m.cpf), '.', ''),
                      '-',
                      ''
                  ),
                  ' ',
                  ''
              ) = ?
        LIMIT 1
    ";

    $parametroLogin = $cpfDigitado;
}


$stmt = $conn->prepare($sql);


if (!$stmt) {

    header(
        "Location: login.html?erro=" .
        urlencode(
            "Erro ao preparar o login."
        )
    );

    exit();
}


$stmt->bind_param(
    "s",
    $parametroLogin
);


if (!$stmt->execute()) {

    $stmt->close();

    header(
        "Location: login.html?erro=" .
        urlencode(
            "Erro ao consultar o usuário."
        )
    );

    exit();
}


$resultado =
    $stmt->get_result();


                              

if (
    $resultado->num_rows === 0
) {

    $stmt->close();

    header(
        "Location: login.html?erro=" .
        urlencode(
            "E-mail/CPF ou senha inválidos."
        )
    );

    exit();
}


$usuario =
    $resultado->fetch_assoc();


$stmt->close();


           

if (
    !password_verify(
        $senha,
        $usuario["senha"]
    )
) {

    header(
        "Location: login.html?erro=" .
        urlencode(
            "E-mail/CPF ou senha inválidos."
        )
    );

    exit();
}


                              
                                                                     
                                                                        
                  

$email = $usuario["email"];


                     

$sql = "
    SELECT
        email,
        senha,
        nome
    FROM usuario
    WHERE email = ?
    LIMIT 1
";


$stmt = $conn->prepare($sql);


if (!$stmt) {

    header(
        "Location: login.html?erro=" .
        urlencode(
            "Erro ao preparar o login."
        )
    );

    exit();
}


$stmt->bind_param(
    "s",
    $email
);


if (!$stmt->execute()) {

    $stmt->close();

    header(
        "Location: login.html?erro=" .
        urlencode(
            "Erro ao consultar o usuário."
        )
    );

    exit();
}


$resultado =
    $stmt->get_result();


                            

if (
    $resultado->num_rows === 0
) {

    $stmt->close();

    header(
        "Location: login.html?erro=" .
        urlencode(
            "E-mail/CPF ou senha inválidos."
        )
    );

    exit();
}


$usuario =
    $resultado->fetch_assoc();


$stmt->close();


           

if (
    !password_verify(
        $senha,
        $usuario["senha"]
    )
) {

    header(
        "Location: login.html?erro=" .
        urlencode(
            "E-mail/CPF ou senha inválidos."
        )
    );

    exit();
}


                      

$perfil = null;
$cpf = null;


             

$sql = "
    SELECT
        email,
        cpf
    FROM morador
    WHERE email = ?
    LIMIT 1
";


$stmt =
    $conn->prepare($sql);


if ($stmt) {

    $stmt->bind_param(
        "s",
        $email
    );

    $stmt->execute();

    $result =
        $stmt->get_result();


    if ($result->num_rows > 0) {

        $dadosMorador =
            $result->fetch_assoc();

        $perfil = "morador";

        $cpf =
            $dadosMorador["cpf"];
    }


    $stmt->close();
}


               

if ($perfil === null) {

    $sql = "
        SELECT
            email,
            ativo
        FROM motorista
        WHERE email = ?
        LIMIT 1
    ";


    $stmt =
        $conn->prepare($sql);


    if ($stmt) {

        $stmt->bind_param(
            "s",
            $email
        );

        $stmt->execute();

        $result =
            $stmt->get_result();


        if ($result->num_rows > 0) {

            $motorista =
                $result->fetch_assoc();


            if (
                (int)$motorista["ativo"] !== 1
            ) {

                $stmt->close();

                header(
                    "Location: login.html?erro=" .
                    urlencode(
                        "Este motorista está inativo e não pode acessar o sistema."
                    )
                );

                exit();
            }


            $perfil = "motorista";
        }


        $stmt->close();
    }
}


                

if ($perfil === null) {

    $sql = "
        SELECT email, ativo
        FROM secretaria
        WHERE email = ?
        LIMIT 1
    ";


    $stmt =
        $conn->prepare($sql);


    if ($stmt) {

        $stmt->bind_param(
            "s",
            $email
        );

        $stmt->execute();

        $result =
            $stmt->get_result();


        if ($result->num_rows > 0) {

            $secretaria = $result->fetch_assoc();

            if ((int)$secretaria["ativo"] !== 1) {

                $stmt->close();

                header(
                    "Location: login.html?erro=" .
                    urlencode(
                        "Esta Secretaria está inativa e não pode acessar o sistema."
                    )
                );

                exit();
            }

            $perfil = "secretaria";
        }


        $stmt->close();
    }
}


                   

if ($perfil === null) {

    $sql = "
        SELECT email
        FROM administrador
        WHERE email = ?
        LIMIT 1
    ";


    $stmt =
        $conn->prepare($sql);


    if ($stmt) {

        $stmt->bind_param(
            "s",
            $email
        );

        $stmt->execute();

        $result =
            $stmt->get_result();


        if ($result->num_rows > 0) {

            $perfil = "administrador";
        }


        $stmt->close();
    }
}


                         

if ($perfil === null) {

    header(
        "Location: login.html?erro=" .
        urlencode(
            "Usuário cadastrado sem perfil definido."
        )
    );

    exit();
}


                   

session_regenerate_id(true);


$_SESSION["email"] =
    $usuario["email"];


$_SESSION["nome"] =
    $usuario["nome"];


$_SESSION["perfil"] =
    $perfil;


                      

if ($perfil === "morador") {

    $_SESSION["cpf"] =
        $cpf;
}


                        

if ($perfil === "motorista") {

    $_SESSION["motorista_email"] =
        $email;
}


                                   

if ($perfil !== "morador") {

    unset(
        $_SESSION["cpf"]
    );
}


if ($perfil !== "motorista") {

    unset(
        $_SESSION["motorista_id"],
        $_SESSION["motorista_email"]
    );
}


                  

redirecionarPerfil(
    $perfil
);

?>