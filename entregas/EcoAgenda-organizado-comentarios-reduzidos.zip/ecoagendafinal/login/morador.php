<?php

session_start();

                                         

if (!isset($_SESSION["email"])) {

    header("Location: ../index.html");
    exit();

}


                                       

if (
    !isset($_SESSION["perfil"]) ||
    $_SESSION["perfil"] !== "morador"
) {

    header("Location: ../index.html");
    exit();

}

?>