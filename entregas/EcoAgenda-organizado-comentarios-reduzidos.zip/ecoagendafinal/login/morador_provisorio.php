<?php
                                                                                     
                                                                                     
                                                                                    
   
const EA_SENHA_PROVISORIA = '!ecoagenda:telefone:v1';
function eaMoradorProvisorio(mysqli $conn, string $cpf, string $email): bool {
    $stmt=$conn->prepare("SELECT m.cpf, u.senha FROM morador m JOIN usuario u ON u.email=m.email WHERE m.email=? LIMIT 1");
    $stmt->bind_param('s',$email);$stmt->execute();$row=$stmt->get_result()->fetch_assoc();$stmt->close();
    return $row && $row['senha']===EA_SENHA_PROVISORIA && preg_replace('/\D/','',$row['cpf'])===$cpf;
}
function eaCriarContatoTelefonico(mysqli $conn, string $cpf, string $nome, string $email, string $telefone): array {
    $email=strtolower(trim($email));$telefone=preg_replace('/\D/','',$telefone);
    if (!preg_match('/^\d{11}$/',$cpf) || preg_match('/^(\d)\1{10}$/',$cpf)) throw new RuntimeException('Informe um CPF válido.');
    for($t=9;$t<11;$t++){ $soma=0;for($i=0;$i<$t;$i++)$soma+=(int)$cpf[$i]*(($t+1)-$i);if(((10*$soma)%11)%10!==(int)$cpf[$t])throw new RuntimeException('Informe um CPF válido.'); }
    if (mb_strlen(trim($nome))<3 || !filter_var($email,FILTER_VALIDATE_EMAIL) || !preg_match('/^\d{10,11}$/',$telefone)) throw new RuntimeException('Informe nome, e-mail e telefone válidos do morador.');
    $stmt=$conn->prepare('SELECT email FROM usuario WHERE email=? FOR UPDATE');$stmt->bind_param('s',$email);$stmt->execute();$existing=$stmt->get_result()->fetch_assoc();$stmt->close();
    if($existing)throw new RuntimeException('Este e-mail pertence a outro cadastro. Confira o CPF e o e-mail informados.');
    $senha=EA_SENHA_PROVISORIA;
    $stmt=$conn->prepare('INSERT INTO usuario (email,senha,nome) VALUES (?,?,?)');$stmt->bind_param('sss',$email,$senha,$nome);$stmt->execute();$stmt->close();
    $stmt=$conn->prepare("INSERT INTO morador (email,cpf,telefone,nascimento) VALUES (?,?,?,'1000-01-01')");$stmt->bind_param('sss',$email,$cpf,$telefone);$stmt->execute();$stmt->close();
    return ['email'=>$email,'cpf'=>$cpf];
}
