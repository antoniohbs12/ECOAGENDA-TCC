<?php
                                                                               
function eaCurva(array $points, bool $pdf=false): string {
    if(!$points)return '';
    $num=static fn($n)=>rtrim(rtrim(number_format((float)$n,2,'.',''),'0'),'.');
    $path=$pdf ? $num($points[0][0]).' '.$num($points[0][1]).' m ' : 'M '.$num($points[0][0]).' '.$num($points[0][1]).' ';
    for($i=1;$i<count($points);$i++){
        $a=$points[$i-1];$b=$points[$i];$mid=($a[0]+$b[0])/2;
        $coords=implode(' ',array_map($num,[$mid,$a[1],$mid,$b[1],$b[0],$b[1]]));
        $path.=$pdf?$coords.' c ':'C '.$coords.' ';
    }
    return $path;
}
