console.log("NOVO_PEDIDO.JS FOI CARREGADO!");

let enderecoCadastrado = null;
let enderecoSelecionado = false;

const API_URL = "../../agendamento/agendamento.php";

const textoEndereco = document.getElementById("textoEndereco");
const outroEndereco = document.getElementById("outroEndereco");
const btnUsarEndereco = document.getElementById("btnUsarEndereco");
const btnOutroEndereco = document.getElementById("btnOutroEndereco");

const tipoResiduo = document.getElementById("tipo_residuo");
const quantidade = document.getElementById("quantidade");
const descricao = document.getElementById("descricao");

const campoFoto = document.getElementById("foto");
const uploadBox = document.getElementById("uploadBox");
const previewContainer = document.getElementById("previewContainer");
const previewFoto = document.getElementById("previewFoto");
const removerFoto = document.getElementById("removerFoto");

const enviarPedido = document.getElementById("enviarPedido");
const mensagem = document.getElementById("mensagem");

function mostrarMensagem(texto, tipo) {
    mensagem.textContent = texto;
    mensagem.className = `message ${tipo}`;
    mensagem.hidden = false;
    mensagem.scrollIntoView({ behavior: "smooth", block: "nearest" });
}

function limparMensagem() {
    mensagem.hidden = true;
    mensagem.textContent = "";
    mensagem.className = "message";
}

function normalizar(valor) {
    return (valor || "").trim().toLowerCase();
}

function formatarEndereco(endereco) {
    return `
        ${endereco.rua || ""}, ${endereco.numero || ""}<br>
        ${endereco.bairro || ""}<br>
        ${endereco.cidade || ""} - ${endereco.estado || ""}<br>
        CEP: ${endereco.cep || ""}
    `;
}

function enderecoAtual() {
    if (enderecoSelecionado && outroEndereco.hidden === false) {
        return {
            cep: document.getElementById("cep").value.trim(),
            estado: document.getElementById("estado").value.trim(),
            cidade: document.getElementById("cidade").value.trim(),
            rua: document.getElementById("rua").value.trim(),
            bairro: document.getElementById("bairro").value.trim(),
            numero: document.getElementById("numero").value.trim(),
            complemento: document.getElementById("complemento").value.trim()
        };
    }

    return enderecoCadastrado;
}

function validarPinhais(endereco) {
    return (
        normalizar(endereco?.cidade) === "pinhais" &&
        normalizar(endereco?.estado) === "pr"
    );
}

function montarEndereco(endereco) {
    const partes = [
        endereco.rua,
        endereco.numero ? `nº ${endereco.numero}` : "",
        endereco.complemento ? `Compl.: ${endereco.complemento}` : "",
        endereco.bairro,
        endereco.cidade,
        endereco.estado,
        endereco.cep ? `CEP: ${endereco.cep}` : ""
    ];

    return partes.filter(Boolean).join(", ");
}

async function carregarEndereco() {
    try {
        const resposta = await fetch(API_URL, {
            method: "GET",
            headers: {
                "Accept": "application/json"
            }
        });

        const dados = await resposta.json();

        if (!resposta.ok || dados.erro) {
            textoEndereco.textContent =
                dados.mensagem || "Nenhum endereço cadastrado.";
            return;
        }

        enderecoCadastrado = dados.endereco;

        textoEndereco.innerHTML =
            formatarEndereco(enderecoCadastrado);

        if (!validarPinhais(enderecoCadastrado)) {
            outroEndereco.hidden = false;

            btnUsarEndereco.style.display = "none";
            btnOutroEndereco.textContent = "Informar endereço de Pinhais";

            textoEndereco.innerHTML += `
                <br>
                <strong class="endereco-erro">
                    ⚠️ O endereço cadastrado não é de Pinhais/PR.
                </strong>
            `;
        }
    } catch (erro) {
        console.error(erro);
        textoEndereco.textContent =
            "Não foi possível carregar seu endereço.";
    }
}

btnUsarEndereco.addEventListener("click", () => {
    limparMensagem();

    if (!enderecoCadastrado) {
        mostrarMensagem(
            "Não foi possível carregar o endereço cadastrado.",
            "error"
        );
        return;
    }

    if (!validarPinhais(enderecoCadastrado)) {
        mostrarMensagem(
            "O endereço cadastrado não pertence a Pinhais/PR. Informe outro endereço.",
            "error"
        );
        outroEndereco.hidden = false;
        enderecoSelecionado = false;
        return;
    }

    enderecoSelecionado = false;
    outroEndereco.hidden = true;

    btnUsarEndereco.classList.add("selected");
    btnOutroEndereco.classList.remove("selected");
});

btnOutroEndereco.addEventListener("click", () => {
    limparMensagem();

    enderecoSelecionado = true;
    outroEndereco.hidden = false;

    btnOutroEndereco.classList.add("selected");
    btnUsarEndereco.classList.remove("selected");
});


             

const campoCep = document.getElementById("cep");

campoCep.addEventListener("input", () => {
    let valor = campoCep.value.replace(/\D/g, "").slice(0, 8);

    if (valor.length > 5) {
        valor = `${valor.slice(0, 5)}-${valor.slice(5)}`;
    }

    campoCep.value = valor;
});

campoCep.addEventListener("blur", async () => {
    const cep = campoCep.value.replace(/\D/g, "");

    if (cep.length !== 8) {
        return;
    }

    try {
        campoCep.disabled = true;

        const resposta =
            await fetch(`https://viacep.com.br/ws/${cep}/json/`);

        const dados = await resposta.json();

        if (dados.erro) {
            mostrarMensagem("CEP não encontrado.", "error");
            return;
        }

        document.getElementById("estado").value =
            dados.uf || "";

        document.getElementById("cidade").value =
            dados.localidade || "";

        document.getElementById("rua").value =
            dados.logradouro || "";

        document.getElementById("bairro").value =
            dados.bairro || "";

        const novoEndereco = {
            estado: dados.uf,
            cidade: dados.localidade,
            rua: dados.logradouro,
            bairro: dados.bairro
        };

        if (!validarPinhais(novoEndereco)) {
            document.getElementById("estado").value = "";
            document.getElementById("cidade").value = "";
            document.getElementById("rua").value = "";
            document.getElementById("bairro").value = "";

            mostrarMensagem(
                "Este CEP não pertence a Pinhais/PR.",
                "error"
            );
            return;
        }

        limparMensagem();

    } catch (erro) {
        console.error(erro);

        mostrarMensagem(
            "Não foi possível consultar o CEP.",
            "error"
        );
    } finally {
        campoCep.disabled = false;
    }
});


          

function validarFoto(arquivo) {
    const tipos = [
        "image/jpeg",
        "image/png",
        "image/webp"
    ];

    if (!tipos.includes(arquivo.type)) {
        mostrarMensagem(
            "Formato de imagem não permitido. Use JPG, PNG ou WEBP.",
            "error"
        );
        return false;
    }

    if (arquivo.size > 5 * 1024 * 1024) {
        mostrarMensagem(
            "A foto deve ter no máximo 5 MB.",
            "error"
        );
        return false;
    }

    return true;
}

function mostrarFoto(arquivo) {
    if (!arquivo || !validarFoto(arquivo)) {
        campoFoto.value = "";
        previewContainer.hidden = true;
        previewFoto.src = "";
        return;
    }

    const leitor = new FileReader();

    leitor.onload = (evento) => {
        previewFoto.src = evento.target.result;
        previewContainer.hidden = false;
    };

    leitor.readAsDataURL(arquivo);
}

campoFoto.addEventListener("change", () => {
    limparMensagem();

    const arquivo = campoFoto.files[0];

    if (arquivo) {
        mostrarFoto(arquivo);
    }
});

uploadBox.addEventListener("dragover", (evento) => {
    evento.preventDefault();
    uploadBox.classList.add("dragover");
});

uploadBox.addEventListener("dragleave", () => {
    uploadBox.classList.remove("dragover");
});

uploadBox.addEventListener("drop", (evento) => {
    evento.preventDefault();
    uploadBox.classList.remove("dragover");

    const arquivo = evento.dataTransfer.files[0];

    if (!arquivo) {
        return;
    }

    mostrarFoto(arquivo);

    if (validarFoto(arquivo)) {
        const dataTransfer = new DataTransfer();
        dataTransfer.items.add(arquivo);
        campoFoto.files = dataTransfer.files;
    }
});

removerFoto.addEventListener("click", () => {
    campoFoto.value = "";
    previewContainer.hidden = true;
    previewFoto.src = "";
    limparMensagem();
});


                   

enviarPedido.addEventListener("click", async () => {

    limparMensagem();

    const tipo = tipoResiduo.value.trim();
    const qtd = quantidade.value.trim();
    const desc = descricao.value.trim();

    if (!tipo) {
        mostrarMensagem(
            "Informe o tipo de resíduo.",
            "error"
        );
        tipoResiduo.focus();
        return;
    }

    if (!desc) {
        mostrarMensagem(
            "Descreva o material que será coletado.",
            "error"
        );
        descricao.focus();
        return;
    }

    const endereco = enderecoAtual();

    if (!endereco) {
        mostrarMensagem(
            "Não foi possível identificar o endereço da coleta.",
            "error"
        );
        return;
    }

    if (!validarPinhais(endereco)) {
        mostrarMensagem(
            "A coleta pode ser solicitada somente para endereços de Pinhais/PR.",
            "error"
        );
        return;
    }

    if (!endereco.numero) {
        mostrarMensagem(
            "Informe o número do endereço da coleta.",
            "error"
        );
        document.getElementById("numero").focus();
        return;
    }

    const formulario = new FormData();

    formulario.append("tipo_residuo", tipo);
    formulario.append("quantidade", qtd);
    formulario.append("descricao", desc);
    formulario.append("cep", endereco.cep || "");
    formulario.append("estado", endereco.estado || "");
    formulario.append("cidade", endereco.cidade || "");
    formulario.append("rua", endereco.rua || "");
    formulario.append("bairro", endereco.bairro || "");
    formulario.append("numero", endereco.numero || "");
    formulario.append("complemento", endereco.complemento || "");

    if (campoFoto.files.length > 0) {
        formulario.append("foto", campoFoto.files[0]);
    }

    enviarPedido.disabled = true;
    enviarPedido.textContent = "Enviando...";
    window.EcoFlow?.busy("Enviando seu pedido…");

    try {

        const resposta = await fetch(API_URL, {
            method: "POST",
            body: formulario
        });

        const dados = await resposta.json();

        if (!resposta.ok || dados.erro) {
            mostrarMensagem(
                dados.mensagem ||
                "Não foi possível enviar o pedido.",
                "error"
            );
            return;
        }

        mostrarMensagem(
            `Pedido criado com sucesso! Número do pedido: ${dados.id}`,
            "success"
        );

        tipoResiduo.value = "";
        quantidade.value = "";
        descricao.value = "";

        if (campoFoto) {
            campoFoto.value = "";
        }

        previewContainer.hidden = true;
        previewFoto.src = "";

        window.EcoFlow?.busy(false);
        window.EcoFlow?.toast(`Pedido ${dados.id} criado com sucesso.`);
        let destino='dashboard_morador.php?secao=acompanhar';
        try {
            const origem=JSON.parse(sessionStorage.getItem('ecoagenda:origem-pedido'));
            if(origem && new URL(origem.path,location.origin).origin===location.origin && origem.path.includes('/login/dashboard_morador/')){
                destino=origem.path;sessionStorage.setItem('ecoagenda:restaurar-origem',JSON.stringify(origem));
            }
            sessionStorage.setItem('ecoagenda:resultado',JSON.stringify({time:Date.now(),text:`Pedido ${dados.id} criado com sucesso.`}));
        } catch {}
        setTimeout(()=>location.assign(destino),650);

    } catch (erro) {
        console.error(erro);

        mostrarMensagem(
            "Não foi possível enviar o pedido. Verifique o servidor.",
            "error"
        );

    } finally {
        window.EcoFlow?.busy(false);
        enviarPedido.disabled = false;
        enviarPedido.textContent = "Enviar pedido";
    }
});

             

carregarEndereco();

                                                                                            
if (tipoResiduo) tipoResiduo.addEventListener('focus', () => {
    const aviso = document.getElementById('orientacao-madeira');
    if (!aviso || !aviso.hidden) return;
    aviso.hidden = false;
    if (aviso.animate && !matchMedia('(prefers-reduced-motion: reduce)').matches)
        aviso.animate([{opacity:0,transform:'translateY(-4px)'},{opacity:1,transform:'none'}],{duration:180,easing:'ease-out'});
});
