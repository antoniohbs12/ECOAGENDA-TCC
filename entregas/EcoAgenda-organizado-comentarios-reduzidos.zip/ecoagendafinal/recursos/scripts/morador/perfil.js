document.addEventListener("DOMContentLoaded", () => {

    const tabs = document.querySelectorAll(".tab");
    const contents = document.querySelectorAll(".tab-content");

    const novaSenha = document.getElementById("nova_senha");
    const confirmarSenha = document.getElementById("confirmar_senha");
    const senhaDiferente = document.getElementById("senhaDiferente");


              

    function abrirAba(nome) {

        tabs.forEach((tab) => {
            tab.classList.toggle(
                "active",
                tab.dataset.tab === nome
            );
        });

        contents.forEach((content) => {
            content.classList.toggle(
                "active",
                content.id === `tab-${nome}`
            );
        });

        const url = new URL(window.location.href);

        url.searchParams.set("aba", nome);

        window.history.replaceState(
            {},
            "",
            url
        );
    }


    tabs.forEach((tab) => {

        tab.addEventListener("click", () => {
            abrirAba(tab.dataset.tab);
        });

    });


                            

    const abaUrl =
        new URLSearchParams(
            window.location.search
        ).get("aba");

    if (
        abaUrl &&
        ["geral", "endereco", "senha"].includes(abaUrl)
    ) {
        abrirAba(abaUrl);
    }


                 

    const cep = document.getElementById("cep");

    if (cep) {

        cep.addEventListener("input", () => {

            let valor =
                cep.value
                    .replace(/\D/g, "")
                    .slice(0, 8);

            if (valor.length > 5) {
                valor =
                    `${valor.slice(0, 5)}-${valor.slice(5)}`;
            }

            cep.value = valor;
        });


        cep.addEventListener("blur", async () => {

            const valor =
                cep.value.replace(/\D/g, "");

            if (valor.length !== 8) {
                return;
            }

            const estado =
                document.getElementById("estado");

            const cidade =
                document.getElementById("cidade");

            const rua =
                document.getElementById("rua");

            const bairro =
                document.getElementById("bairro");


            try {

                cep.disabled = true;

                const resposta =
                    await fetch(
                        `https://viacep.com.br/ws/${valor}/json/`
                    );

                const dados =
                    await resposta.json();


                if (dados.erro) {

                    alert("CEP não encontrado.");

                    return;
                }


                if (
                    (dados.localidade || "")
                        .trim()
                        .toLowerCase() !== "pinhais" ||
                    (dados.uf || "")
                        .trim()
                        .toLowerCase() !== "pr"
                ) {

                    estado.value = "";
                    cidade.value = "";
                    rua.value = "";
                    bairro.value = "";

                    alert(
                        "Este CEP não pertence a Pinhais/PR."
                    );

                    return;
                }


                estado.value =
                    dados.uf || "";

                cidade.value =
                    dados.localidade || "";

                rua.value =
                    dados.logradouro || "";

                bairro.value =
                    dados.bairro || "";

            } catch (erro) {

                console.error(erro);

                alert(
                    "Não foi possível consultar o CEP."
                );

            } finally {

                cep.disabled = false;
            }

        });

    }


                                 

    function verificarSenhas() {

        if (!novaSenha || !confirmarSenha || !senhaDiferente) {
            return true;
        }

        const diferentes =
            novaSenha.value !==
            confirmarSenha.value;

        senhaDiferente.hidden = !diferentes;

        return !diferentes;
    }


    if (novaSenha) {
        novaSenha.addEventListener(
            "input",
            verificarSenhas
        );
    }

    if (confirmarSenha) {
        confirmarSenha.addEventListener(
            "input",
            verificarSenhas
        );
    }


    const formularioSenha =
        confirmarSenha?.closest("form");

    if (formularioSenha) {

        formularioSenha.addEventListener(
            "submit",
            (evento) => {

                if (!verificarSenhas()) {
                    evento.preventDefault();
                    confirmarSenha.focus();
                }

            }
        );

    }

});
