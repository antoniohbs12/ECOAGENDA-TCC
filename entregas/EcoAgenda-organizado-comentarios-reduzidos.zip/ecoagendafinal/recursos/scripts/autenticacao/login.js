document.addEventListener("DOMContentLoaded", () => {

                                                                
                              
                                                                

    const mostrarSenha = document.getElementById("mostrarSenha");
    const senha = document.getElementById("senha");

    if (mostrarSenha && senha) {

        mostrarSenha.addEventListener("click", () => {

            if (senha.type === "password") {
                senha.type = "text";
                mostrarSenha.textContent = "🙈";
            } else {
                senha.type = "password";
                mostrarSenha.textContent = "👁";
            }

        });

    }


                                                                
                                              
                                                                

    const parametros = new URLSearchParams(window.location.search);
    const erro = parametros.get("erro");

    if (erro) {

                          
        const message=document.getElementById('mensagemErro');
        if(message){message.textContent=erro;message.style.display='block';message.setAttribute('role','alert');}

                                                
        const novaURL =
            window.location.origin +
            window.location.pathname;

        window.history.replaceState({}, document.title, novaURL);
    }


                                                                
                   
                                                                

    const btnGov = document.getElementById("btnGov");

    if (btnGov) {

        btnGov.addEventListener("click", () => {

            alert(
                "O acesso pelo Gov.br será disponibilizado posteriormente."
            );

        });

    }

});