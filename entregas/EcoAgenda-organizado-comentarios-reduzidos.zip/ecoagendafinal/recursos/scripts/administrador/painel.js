                                                                                
(() => {
    function go(section){
        document.querySelector(`.menu-link[data-section="${section}"]`)?.click();
        window.EcoFlow?.animate(document.getElementById('section-'+section),[{opacity:0,transform:'translateY(10px)'},{opacity:1,transform:'none'}]);
    }
    function statusOrders(status){
        go('pedidos');const section=document.getElementById('section-pedidos');
        const filtro=section.querySelector('[data-ea-status]'),prazo=section.querySelector('[data-ea-prazo]');
        filtro.value=status;prazo.value='todos';filtro.dispatchEvent(new Event('change'));prazo.dispatchEvent(new Event('change'));filtro.focus({preventScroll:true});
    }
    function init(){
        document.querySelectorAll('.adm-resumo-card').forEach(card=>{
            const status=card.classList.contains('total')?'todos':window.EcoStatus.key(card.querySelector('.adm-resumo-label').textContent);
            const action=document.createElement('button');action.type='button';action.className='adm-resumo-action';action.textContent=status==='todos'?'Visualizar todos os pedidos →':`Visualizar pedidos: ${window.EcoStatus.nomes[status]} →`;
            card.append(action);card.addEventListener('click',()=>statusOrders(status));
            card.addEventListener('pointerenter',()=>card.classList.add('is-pointed'));card.addEventListener('pointerleave',()=>card.classList.remove('is-pointed'));
        });
        document.querySelectorAll('.adm-equipe-item').forEach(card=>{
            const secretary=card.querySelector('.adm-equipe-info span').textContent.includes('Secretaria');
            card.tabIndex=0;card.setAttribute('role','button');card.setAttribute('aria-label',`Ver ${secretary?'secretarias':'motoristas'}: ${card.querySelector('strong').textContent}`);
            card.addEventListener('click',()=>go(secretary?'secretarias':'motoristas'));
            card.addEventListener('keydown',e=>{if(e.key==='Enter'||e.key===' '){e.preventDefault();card.click();}});
            const sample=document.querySelector(`.menu-link[data-section="${secretary?'secretarias':'motoristas'}"] .ea-nav-icon`);
            if(sample){const icon=sample.cloneNode(true);const img=icon.querySelector('img');if(img)img.src='../interface/icones/secretaria-verde.png';card.querySelector('.adm-equipe-avatar').replaceChildren(icon);}
        });
        document.querySelectorAll('[data-go-section]').forEach(button=>button.addEventListener('click',()=>window.EcoFlow?.animate(document.querySelector('.section.active'),[{opacity:0,transform:'translateY(8px)'},{opacity:1,transform:'none'}])));
        const weekly=document.querySelector('.adm-weekly-card'),source=document.getElementById('adm-weekly-data');
        if(weekly&&source){
            const orders=JSON.parse(source.textContent),view=document.createElement('div');view.className='adm-weekly-detail';view.hidden=true;weekly.append(view);
            function open(key){
                const selected=orders.filter(p=>p.chave===key);weekly.querySelector('.adm-weekly-content').hidden=true;weekly.querySelector('.adm-card-header').hidden=true;view.hidden=false;view.replaceChildren();
                const back=document.createElement('button');back.type='button';back.className='btn-secondary';back.textContent='← Voltar às coletas da semana';back.addEventListener('click',()=>{view.hidden=true;weekly.querySelector('.adm-weekly-content').hidden=false;weekly.querySelector('.adm-card-header').hidden=false;window.EcoFlow?.animate(weekly,[{opacity:.4},{opacity:1}]);weekly.querySelector(`[data-weekly-status="${key}"]`)?.focus({preventScroll:true});});
                const title=document.createElement('h3');title.textContent=`${window.EcoStatus.nomes[key]} · ${selected.length} pedido(s)`;view.append(back,title);
                const list=document.createElement('div');list.className='adm-weekly-orders';view.append(list);
                if(!selected.length){const empty=document.createElement('p');empty.textContent='Nenhum pedido com este status na semana.';list.append(empty);}
                selected.forEach(p=>{
                    const card=document.createElement('article');card.className='adm-weekly-order';const head=document.createElement('div');head.className='adm-weekly-order-head';const number=document.createElement('strong');number.textContent=`Pedido ${p.id}`;head.append(number,window.EcoStatus.badge(p.status));card.append(head);
                    for(const [label,value] of [['Local de coleta',p.local],['Material',p.material],['Solicitado em',p.emitido.split('-').reverse().join('/')],['Prazo da coleta',p.limite?p.limite.split('-').reverse().join('/'):'Não informado']]){const row=document.createElement('p'),caption=document.createElement('span'),text=document.createElement('strong');caption.textContent=label;text.textContent=value;row.append(caption,text);card.append(row);}
                    const calendar=document.createElement('button');calendar.type='button';calendar.className='btn-small';calendar.textContent='Visualizar o pedido no calendário →';calendar.addEventListener('click',()=>document.dispatchEvent(new CustomEvent('ea-calendar-go',{detail:{source:'adm-agenda-data',date:p.emitido,id:p.id,order:p}})));card.append(calendar);list.append(card);
                });
                window.EcoFlow?.animate(view,[{opacity:0,transform:'translateX(12px)'},{opacity:1,transform:'none'}]);back.focus({preventScroll:true});
            }
            weekly.querySelectorAll('[data-weekly-status]').forEach(button=>button.addEventListener('click',()=>open(button.dataset.weeklyStatus)));
        }
        animateChart();
    }
    function animateChart(){document.querySelectorAll('.adm-chart-line').forEach(path=>{const length=path.getTotalLength();window.EcoFlow?.animate(path,[{strokeDasharray:length,strokeDashoffset:length},{strokeDasharray:length,strokeDashoffset:0}],650);});}
    let filtering=false;
    document.addEventListener('submit',async event=>{
        const form=event.target;if(!form.matches('.adm-relatorio-filtros'))return;event.preventDefault();if(filtering)return;filtering=true;
        const button=event.submitter||form.querySelector('[type=submit]'),card=form.closest('.adm-relatorio-card'),label=button.textContent;button.disabled=true;button.textContent='Carregando…';card.setAttribute('aria-busy','true');
        const url=new URL(location.href);for(const [k,v] of new FormData(form))url.searchParams.set(k,v);
        const controller=new AbortController(),timer=setTimeout(()=>controller.abort(),20000);
        try{
            const response=await fetch(url,{signal:controller.signal,cache:'no-store'});if(!response.ok)throw Error();const doc=new DOMParser().parseFromString(await response.text(),'text/html'),next=doc.querySelector('.adm-relatorio-card');if(!next)throw Error();
            const top=card.getBoundingClientRect().top;card.replaceWith(next);history.replaceState(null,'',url);animateChart();window.EcoFlow?.animate(next,[{opacity:.4},{opacity:1}]);
                                                                                                             
            document.querySelectorAll('.adm-mapa-card[data-map-mode]').forEach(map=>{const fresh=doc.querySelector(`.adm-mapa-card[data-map-mode="${map.dataset.mapMode}"]`);if(!fresh)return;map.querySelector('iframe').src=fresh.querySelector('iframe').getAttribute('src');map.querySelector('.adm-mapa-total strong').textContent=fresh.querySelector('.adm-mapa-total strong').textContent;});
            window.scrollBy({top:next.getBoundingClientRect().top-top,behavior:'instant'});window.EcoFlow?.toast('Período atualizado.');
        }catch{window.EcoFlow?.toast('Não foi possível atualizar o período. Tente novamente.',{error:true});}
        finally{clearTimeout(timer);filtering=false;button.disabled=false;button.textContent=label;card.removeAttribute('aria-busy');}
    });
    if(document.readyState==='loading')document.addEventListener('DOMContentLoaded',init);else init();
})();
