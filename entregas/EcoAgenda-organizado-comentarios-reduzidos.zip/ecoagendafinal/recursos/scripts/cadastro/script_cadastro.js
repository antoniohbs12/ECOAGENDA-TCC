"use strict";

                       
                                                    
                                                             

const sidebarTitles = {
    1: "Crie sua conta",
    2: "Insira seu endereço",
    3: "Confirmação"
};

const sidebarTexts = {
    1: "Cadastre-se na EcoAgenda e comece a agendar coletas de resíduos de forma simples e sustentável.",
    2: "Informe seu endereço residencial. O endereço pode ser de qualquer cidade.",
    3: "Confira seus dados e finalize seu cadastro."
};

let passoAtual = 1;
let cpfValidado = false;
let cpfValidadoValor = "";


                   

document.addEventListener("DOMContentLoaded", function () {

    inicializarCadastro();

});


                 

function inicializarCadastro() {

    configurarBotoesSenha();
    configurarMascaraCPF();
    configurarMascaraCEP();
    configurarPIN();
    configurarCEP();
    configurarFormulario();

}


                        

async function proximoPasso(passo) {

    console.log("Tentando avançar para o passo:", passo);


    if (passo === 2) {

        const primeiroNome =
            obterValor("primeiro_nome");

        const sobrenome =
            obterValor("sobrenome");

        const nascimento =
            obterValor("nascimento");

        const cpf =
            obterValor("cpf");

        const email =
            obterValor("email");

        const telefone =
            obterValor("telefone");

        const senha =
            obterValor("senha");

        const confirmarSenha =
            obterValor("confirmar_senha");


                                 

        if (
            !primeiroNome ||
            !sobrenome ||
            !nascimento ||
            !cpf ||
            !email ||
            !telefone ||
            !senha ||
            !confirmarSenha
        ) {

            alert(
                "Por favor, preencha todos os campos obrigatórios da Etapa 1."
            );

            return;
        }   


                                         

        const cpfLimpo =
            cpf.replace(/\D/g, "");

        if (!cpfAlgoritmoValido(cpfLimpo)) {

            atualizarStatusCPF(
                "CPF inválido. Confira os números informados.",
                "erro"
            );

            focarElemento("cpf");
            return;
        }

        if (
            !cpfValidado ||
            cpfValidadoValor !== cpfLimpo
        ) {

            const botaoContinuar =
                document.querySelector(
                    '#step-1 .btn-primary'
                );

            if (botaoContinuar) {
                botaoContinuar.disabled = true;
                botaoContinuar.textContent = "Validando CPF...";
            }

            try {

                const resultadoCPF =
                    await validarCPFComAPI(cpfLimpo);

                if (!resultadoCPF.sucesso) {
                    focarElemento("cpf");
                    return;
                }

            } finally {

                if (botaoContinuar) {
                    botaoContinuar.disabled = false;
                    botaoContinuar.textContent = "Continuar";
                }

            }
        }


                                

        if (!dataNascimentoValida(nascimento)) {

            alert(
                "Informe uma data de nascimento válida."
            );

            focarElemento("nascimento");

            return;
        }


                          

        if (!temPeloMenos16Anos(nascimento)) {

            alert(
                "Para se cadastrar, é necessário ter 16 anos completos ou mais."
            );

            focarElemento("nascimento");

            return;
        }


                    

        if (senha !== confirmarSenha) {

            alert(
                "As senhas informadas não coincidem."
            );

            focarElemento("confirmar_senha");

            return;
        }

    }


    if (passo === 3) {

        const email = obterValor("email").toLowerCase();
        if (!email || !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email)) {
            alert("Informe um e-mail válido antes de continuar.");
            focarElemento("email");
            return;
        }

        const botaoContinuar = document.querySelector('#step-2 .btn-primary');
        if (botaoContinuar) {
            botaoContinuar.disabled = true;
            botaoContinuar.textContent = "Enviando código...";
        }

        try {
            const resultadoEmail = await solicitarCodigoCadastro(email);
            if (!resultadoEmail.sucesso) {
                alert(resultadoEmail.mensagem || "Não foi possível enviar o código por e-mail.");
                return;
            }
            mudarPasso(passo);
            mostrarStatusCodigoEmail(resultadoEmail.mensagem || "Código enviado para seu e-mail.", "sucesso");
        } finally {
            if (botaoContinuar) {
                botaoContinuar.disabled = false;
                botaoContinuar.textContent = "Continuar";
            }
        }
        return;
    }

    mudarPasso(passo);
}


                                          
async function solicitarCodigoCadastro(email) {
    try {
        const resposta = await fetch("enviar_codigo_cadastro.php", {
            method: "POST",
            headers: { "Content-Type": "application/json", "Accept": "application/json" },
            body: JSON.stringify({ email })
        });
        const dados = await resposta.json();
        return { sucesso: resposta.ok && dados.sucesso === true, mensagem: dados.mensagem || "Não foi possível enviar o código." };
    } catch (erro) {
        console.error("Erro ao enviar código de cadastro:", erro);
        return { sucesso: false, mensagem: "Não foi possível conectar ao servidor para enviar o código. Tente novamente." };
    }
}

async function reenviarCodigoCadastro() {
    const email = obterValor("email").toLowerCase();
    const link = document.querySelector('.resend-text a');
    if (link) { link.style.pointerEvents = "none"; link.textContent = "Enviando..."; }
    mostrarStatusCodigoEmail("Enviando um novo código...", "validando");
    try {
        const resultado = await solicitarCodigoCadastro(email);
        mostrarStatusCodigoEmail(resultado.mensagem, resultado.sucesso ? "sucesso" : "erro");
    } finally {
        if (link) { link.style.pointerEvents = ""; link.textContent = "Envie novamente"; }
    }
}

function mostrarStatusCodigoEmail(mensagem, tipo) {
    const status = document.getElementById("codigoEmailStatus");
    if (!status) return;
    status.textContent = mensagem || "";
    status.className = "cpf-status";
    if (tipo) status.classList.add(tipo);
}


                               

function cpfAlgoritmoValido(cpf) {

    const valor = String(cpf || "").replace(/\D/g, "");

    if (valor.length !== 11) {
        return false;
    }

    if (/^(\d)\1{10}$/.test(valor)) {
        return false;
    }

    let soma = 0;

    for (let i = 0; i < 9; i++) {
        soma += Number(valor[i]) * (10 - i);
    }

    let resto = soma % 11;
    let digito1 = resto < 2 ? 0 : 11 - resto;

    if (digito1 !== Number(valor[9])) {
        return false;
    }

    soma = 0;

    for (let i = 0; i < 10; i++) {
        soma += Number(valor[i]) * (11 - i);
    }

    resto = soma % 11;
    const digito2 = resto < 2 ? 0 : 11 - resto;

    return digito2 === Number(valor[10]);
}


                         

async function validarCPFComAPI(cpf) {

    atualizarStatusCPF(
        "Consultando CPF...",
        "validando"
    );

    try {

        const resposta =
            await fetch(
                "validar_cpf.php",
                {
                    method: "POST",
                    headers: {
                        "Content-Type": "application/json",
                        "Accept": "application/json"
                    },
                    body: JSON.stringify({ cpf })
                }
            );

        let dados;

        try {
            dados = await resposta.json();
        } catch (erroJSON) {
            throw new Error(
                "A resposta do servidor não é válida."
            );
        }

        if (dados.sucesso === true) {

            cpfValidado = true;
            cpfValidadoValor = cpf;

            atualizarStatusCPF(
                "✓ CPF encontrado e validado.",
                "sucesso"
            );

            return { sucesso: true };
        }

        cpfValidado = false;
        cpfValidadoValor = "";

        atualizarStatusCPF(
            dados.mensagem || "CPF não encontrado.",
            "erro"
        );

        return {
            sucesso: false
        };

    } catch (erro) {

        console.error(
            "Erro ao validar CPF:",
            erro
        );

        cpfValidado = false;
        cpfValidadoValor = "";

        atualizarStatusCPF(
            "Não foi possível consultar o CPF agora. Tente novamente.",
            "erro"
        );

        return {
            sucesso: false
        };
    }
}


function atualizarStatusCPF(mensagem, tipo) {

    const status =
        document.getElementById("cpfStatus");

    if (!status) {
        return;
    }

    status.textContent = mensagem || "";
    status.className = "cpf-status";

    if (tipo) {
        status.classList.add(tipo);
    }
}


            

function passoAnterior(passo) {

    mudarPasso(passo);

}


                 

function mudarPasso(passo) {

    console.log("Mudando para o passo:", passo);

    passoAtual = passo;


    const etapas =
        document.querySelectorAll(".form-step");


    etapas.forEach(function (etapa) {

        etapa.classList.remove("active");

    });


    const etapaDestino =
        document.getElementById(
            "step-" + passo
        );


    if (!etapaDestino) {

        console.error(
            "Etapa não encontrada: step-" + passo
        );

        return;
    }


    etapaDestino.classList.add("active");


                   

    for (let i = 1; i <= 3; i++) {

        const item =
            document.getElementById(
                "step-head-" + i
            );


        if (item) {

            item.classList.toggle(
                "active",
                i <= passo
            );

        }

    }


                

    const linha1 =
        document.getElementById("line-1");

    const linha2 =
        document.getElementById("line-2");


    if (linha1) {

        linha1.classList.toggle(
            "active",
            passo >= 2
        );

    }


    if (linha2) {

        linha2.classList.toggle(
            "active",
            passo >= 3
        );

    }


              

    for (let i = 1; i <= 3; i++) {

        const dot =
            document.getElementById(
                "dot" + i
            );


        if (dot) {

            dot.classList.toggle(
                "active",
                i === passo
            );

        }

    }


                 

    const titulo =
        document.getElementById(
            "sidebar-title"
        );


    const texto =
        document.getElementById(
            "sidebar-text"
        );


    if (titulo) {

        titulo.textContent =
            sidebarTitles[passo] || "Cadastro";

    }


    if (texto) {

        texto.textContent =
            sidebarTexts[passo] || "";

    }


                                                  

    window.scrollTo({
        top: 0,
        behavior: "smooth"
    });

}


                                              
                                           
                               

window.proximoPasso =
    proximoPasso;

window.passoAnterior =
    passoAnterior;

window.mudarPasso =
    mudarPasso;


                              

function configurarBotoesSenha() {

    const botoes =
        document.querySelectorAll(
            ".btn-toggle-pass"
        );


    botoes.forEach(function (botao) {

        botao.addEventListener(
            "click",
            function (event) {

                event.preventDefault();
                event.stopPropagation();


                const targetId =
                    botao.getAttribute(
                        "data-target"
                    );


                const campo =
                    document.getElementById(
                        targetId
                    );


                if (!campo) {

                    console.error(
                        "Campo de senha não encontrado:",
                        targetId
                    );

                    return;
                }


                if (
                    campo.type === "password"
                ) {

                    campo.type = "text";

                    botao.textContent = "🙈";

                } else {

                    campo.type = "password";

                    botao.textContent = "👁";

                }

            }
        );

    });

}


                 

function configurarMascaraCPF() {

    const campo =
        document.getElementById("cpf");


    if (!campo) {
        return;
    }


    campo.addEventListener(
        "input",
        function () {

            let valor =
                campo.value.replace(
                    /\D/g,
                    ""
                );


            valor =
                valor.substring(
                    0,
                    11
                );


            if (valor.length > 9) {

                valor =
                    valor.replace(
                        /(\d{3})(\d{3})(\d{3})(\d{1})/,
                        "$1.$2.$3-$4"
                    );

            } else if (valor.length > 6) {

                valor =
                    valor.replace(
                        /(\d{3})(\d{3})(\d+)/,
                        "$1.$2.$3"
                    );

            } else if (valor.length > 3) {

                valor =
                    valor.replace(
                        /(\d{3})(\d+)/,
                        "$1.$2"
                    );

            }


            campo.value =
                valor;

            cpfValidado = false;
            cpfValidadoValor = "";

            if (valor.length < 11) {
                atualizarStatusCPF("", "");
            }

        }
    );

}


                 

function configurarMascaraCEP() {

    const campo =
        document.getElementById("cep");


    if (!campo) {
        return;
    }


    campo.addEventListener(
        "input",
        function () {

            let valor =
                campo.value.replace(
                    /\D/g,
                    ""
                );


            valor =
                valor.substring(
                    0,
                    8
                );


            if (valor.length > 5) {

                valor =
                    valor.substring(0, 5) +
                    "-" +
                    valor.substring(5);

            }


            campo.value =
                valor;

        }
    );

}


         

function configurarPIN() {

    const caixas =
        document.querySelectorAll(
            ".pin-box"
        );


    caixas.forEach(
        function (caixa, indice) {

            caixa.addEventListener(
                "input",
                function () {

                    caixa.value =
                        caixa.value
                            .replace(
                                /\D/g,
                                ""
                            )
                            .substring(
                                0,
                                1
                            );


                    if (
                        caixa.value &&
                        indice < caixas.length - 1
                    ) {

                        caixas[
                            indice + 1
                        ].focus();

                    }

                }
            );


            caixa.addEventListener(
                "keydown",
                function (event) {

                    if (
                        event.key === "Backspace" &&
                        !caixa.value &&
                        indice > 0
                    ) {

                        caixas[
                            indice - 1
                        ].focus();

                    }

                }
            );

        }
    );

}


             

function configurarCEP() {

    const campo =
        document.getElementById("cep");


    if (!campo) {
        return;
    }


    campo.addEventListener(
        "blur",
        buscarCEP
    );

}


async function buscarCEP() {

    const campo =
        document.getElementById("cep");


    if (!campo) {
        return;
    }


    const cep =
        campo.value.replace(
            /\D/g,
            ""
        );


    if (cep.length !== 8) {
        return;
    }


    try {

        const resposta =
            await fetch(
                "https://viacep.com.br/ws/" +
                cep +
                "/json/"
            );


        if (!resposta.ok) {

            throw new Error(
                "Falha na consulta do CEP."
            );

        }


        const dados =
            await resposta.json();


        if (dados.erro) {

            alert(
                "CEP não encontrado."
            );

            limparEndereco();

            return;
        }


        preencherCampo(
            "estado",
            dados.uf
        );


        preencherCampo(
            "cidade",
            dados.localidade
        );


        preencherCampo(
            "rua",
            dados.logradouro
        );


        preencherCampo(
            "bairro",
            dados.bairro
        );


    } catch (erro) {

        console.error(
            erro
        );


        alert(
            "Não foi possível consultar o CEP."
        );

    }

}


                     

function limparEndereco() {

    preencherCampo(
        "estado",
        ""
    );


    preencherCampo(
        "cidade",
        ""
    );


    preencherCampo(
        "rua",
        ""
    );


    preencherCampo(
        "bairro",
        ""
    );

}


                  

function dataNascimentoValida(
    dataNascimento
) {

    if (!dataNascimento) {
        return false;
    }


    const nascimento =
        new Date(
            dataNascimento +
            "T00:00:00"
        );


    if (
        Number.isNaN(
            nascimento.getTime()
        )
    ) {

        return false;

    }


    const hoje =
        new Date();


    hoje.setHours(
        0,
        0,
        0,
        0
    );


    nascimento.setHours(
        0,
        0,
        0,
        0
    );


    if (
        nascimento > hoje
    ) {

        return false;

    }


    return true;

}


                          

function temPeloMenos16Anos(
    dataNascimento
) {

    if (
        !dataNascimentoValida(
            dataNascimento
        )
    ) {

        return false;

    }


    const nascimento =
        new Date(
            dataNascimento +
            "T00:00:00"
        );


    const hoje =
        new Date();


    let idade =
        hoje.getFullYear() -
        nascimento.getFullYear();


    const mesAtual =
        hoje.getMonth();


    const diaAtual =
        hoje.getDate();


    const mesNascimento =
        nascimento.getMonth();


    const diaNascimento =
        nascimento.getDate();


    if (
        mesAtual < mesNascimento ||
        (
            mesAtual === mesNascimento &&
            diaAtual < diaNascimento
        )
    ) {

        idade--;

    }


    return idade >= 16;

}


                

function configurarFormulario() {

    const formulario =
        document.getElementById(
            "cadastroForm"
        );


    if (!formulario) {
        return;
    }


    formulario.addEventListener(
        "submit",
        function (event) {

            const codigoEmail = Array.from(document.querySelectorAll(".pin-box"))
                .map(campo => campo.value).join("");
            if (!/^\d{6}$/.test(codigoEmail)) {
                event.preventDefault();
                alert("Digite os 6 dígitos do código enviado para seu e-mail.");
                const primeiraCaixa = document.querySelector(".pin-box");
                if (primeiraCaixa) primeiraCaixa.focus();
                return;
            }

            const nascimento =
                obterValor(
                    "nascimento"
                );


            const senha =
                obterValor(
                    "senha"
                );


            const confirmarSenha =
                obterValor(
                    "confirmar_senha"
                );


            if (
                !dataNascimentoValida(
                    nascimento
                )
            ) {

                event.preventDefault();

                alert(
                    "Informe uma data de nascimento válida."
                );

                focarElemento(
                    "nascimento"
                );

                return;
            }


            if (
                !temPeloMenos16Anos(
                    nascimento
                )
            ) {

                event.preventDefault();

                alert(
                    "Para se cadastrar, é necessário ter 16 anos completos ou mais."
                );

                focarElemento(
                    "nascimento"
                );

                return;
            }


            if (
                senha !== confirmarSenha
            ) {

                event.preventDefault();

                alert(
                    "As senhas informadas não coincidem."
                );

                focarElemento(
                    "confirmar_senha"
                );

                return;
            }


            const cep =
                obterValor(
                    "cep"
                ).replace(
                    /\D/g,
                    ""
                );


            if (
                cep.length !== 8
            ) {

                event.preventDefault();

                alert(
                    "Informe um CEP válido."
                );

                focarElemento(
                    "cep"
                );

                return;
            }


            const numero =
                obterValor(
                    "numero"
                );


            if (!numero) {

                event.preventDefault();

                alert(
                    "Informe o número do endereço."
                );

                focarElemento(
                    "numero"
                );

                return;
            }

        }
    );

}


                        

function obterValor(id) {

    const elemento =
        document.getElementById(id);


    if (!elemento) {
        return "";
    }


    return (
        elemento.value ||
        ""
    ).trim();

}


function focarElemento(id) {

    const elemento =
        document.getElementById(id);


    if (elemento) {

        elemento.focus();

    }

}


function preencherCampo(
    id,
    valor
) {

    const elemento =
        document.getElementById(id);


    if (elemento) {

        elemento.value =
            valor || "";

    }

}