<?php
declare(strict_types=1);
require_once __DIR__.'/../administrador/mapa_geocodificar.php';

// Referência geográfica do bairro, nunca coordenada atribuída ao imóvel.
function referenciaBairroMotorista(array $endereco): ?array
{
    if (normalizarMapa((string)($endereco['cidade'] ?? '')) !== 'pinhais') return null;
    $nome = normalizarMapa((string)($endereco['bairro'] ?? ''));
    if ($nome === '') return null;
    static $pontos = [];
    if (array_key_exists($nome, $pontos)) return $pontos[$nome];
    foreach (carregarGeoMapa()['features'] as $feature) {
        if (normalizarMapa((string)($feature['properties']['bairro'] ?? '')) !== $nome) continue;
        $g = $feature['geometry'];
        $poligonos = $g['type'] === 'Polygon' ? [$g['coordinates']] : $g['coordinates'];
        $melhor = null; $largura = 0;
        foreach ($poligonos as $aneis) {
            $ys = array_column($aneis[0], 1); $min = min($ys); $max = max($ys);
            // Busca um ponto interior em faixas horizontais, respeitando buracos.
            for ($linha = 1; $linha < 20; $linha++) {
                $lat = $min + ($max - $min) * $linha / 20; $xs = [];
                foreach ($aneis as $anel) {
                    for ($i = 0, $j = count($anel)-1; $i < count($anel); $j = $i++) {
                        [$x1,$y1] = $anel[$i]; [$x2,$y2] = $anel[$j];
                        if (($y1 > $lat) !== ($y2 > $lat)) $xs[] = $x1 + ($lat-$y1)*($x2-$x1)/($y2-$y1);
                    }
                }
                sort($xs, SORT_NUMERIC);
                for ($i = 0; $i+1 < count($xs); $i++) {
                    $lng = ($xs[$i]+$xs[$i+1])/2; $dist = $xs[$i+1]-$xs[$i];
                    if ($dist <= $largura || !pontoDentroAnelMapa($lng,$lat,$aneis[0])) continue;
                    $buraco = false;
                    foreach (array_slice($aneis,1) as $anel) if (pontoDentroAnelMapa($lng,$lat,$anel)) $buraco = true;
                    if (!$buraco) { $largura=$dist; $melhor=['lat'=>$lat,'lng'=>$lng,'precisao'=>'bairro_aproximado','fonte'=>'GeoPinhais — referência do bairro']; }
                }
            }
        }
        return $pontos[$nome] = $melhor;
    }
    return $pontos[$nome] = null;
}
function comReferenciaMotorista(array $endereco, array $pos): array
{
    if (isset($pos['lat'],$pos['lng']) && is_numeric($pos['lat']) && is_numeric($pos['lng'])) return $pos;
    if (empty($endereco['endereco_id']) || empty($endereco['rua']) || empty($endereco['numero'])) return $pos;
    try { return referenciaBairroMotorista($endereco) ?? $pos; }
    catch (Throwable $e) { return $pos; }
}
