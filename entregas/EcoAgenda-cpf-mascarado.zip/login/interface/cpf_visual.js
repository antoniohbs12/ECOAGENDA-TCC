window.eaCpfVisual = function (valor) {
    const cpf = String(valor ?? '').replace(/\D/g, '');
    return cpf.length === 11 ? cpf.slice(0, 3) + '.***.***-' + cpf.slice(-2) : '—';
};
