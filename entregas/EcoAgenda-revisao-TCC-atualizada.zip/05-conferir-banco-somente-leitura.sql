-- Execute no MySQL do projeto. Não altera dados e não lista moradores.
SELECT VERSION() AS versao_servidor, @@version_comment AS distribuicao;
USE ecoagenda;
SHOW CREATE TABLE usuario;
SHOW CREATE TABLE secretaria;
SHOW CREATE TABLE motorista;
SHOW CREATE TABLE morador;
SHOW CREATE TABLE endereco;
SHOW CREATE TABLE agendamento;
SHOW CREATE TABLE coleta;
SHOW CREATE TABLE agendamento_morador_endereco;
SHOW CREATE TABLE agendamento_historico;
