<?php
session_start();
require_once "../../config.php";

/* =========================================================
   PROTEÇÃO
========================================================= */
if (!isset($_SESSION["email"]) || !isset($_SESSION["perfil"]) || $_SESSION["perfil"] !== "secretaria") {
    header("Location: ../login.html");
    exit();
}

$secretariaEmail = $_SESSION["email"];

$stmtAtivo = $conn->prepare("SELECT ativo FROM secretaria WHERE email = ? LIMIT 1");
if (!$stmtAtivo) {
    session_unset();
    session_destroy();
    header("Location: ../login.html?erro=" . urlencode("Não foi possível validar o acesso da Secretaria."));
    exit();
}
$stmtAtivo->bind_param("s", $secretariaEmail);
$stmtAtivo->execute();
$dadosAtivo = $stmtAtivo->get_result()->fetch_assoc();
$stmtAtivo->close();

if (!$dadosAtivo || (int)$dadosAtivo["ativo"] !== 1) {
    session_unset();
    session_destroy();
    header("Location: ../login.html?erro=" . urlencode("Esta Secretaria está inativa e não pode acessar o sistema."));
    exit();
}

$nomeSecretaria = $_SESSION["nome"] ?? "Secretaria";
$mensagem = "";
$tipoMensagem = "success";
$mostrarNotificacaoEncaminhamento = false;
$notificacaoMotorista = "";
$notificacaoPrazo = "";

/* =========================================================
   FUNÇÕES
========================================================= */
function e($valor): string
{
    return htmlspecialchars((string)$valor, ENT_QUOTES, "UTF-8");
}

function dataBR($data): string
{
    if (empty($data)) {
        return "—";
    }
    $timestamp = strtotime($data);
    return $timestamp ? date("d/m/Y", $timestamp) : "—";
}

function dataHoraBR($data): string
{
    if (empty($data)) {
        return "—";
    }
    $timestamp = strtotime($data);
    return $timestamp ? date("d/m/Y H:i", $timestamp) : "—";
}

function horaBR($data): string
{
    if (empty($data)) {
        return "—";
    }
    $timestamp = strtotime($data);
    return $timestamp ? date("H:i", $timestamp) : "—";
}

function classeStatus(string $status): string
{
    switch (mb_strtolower(trim($status), "UTF-8")) {
        case "em análise":
        case "em analise":
            return "pendente";
        case "encaminhado":
            return "confirmado";
        case "em andamento":
            return "andamento";
        case "concluído":
        case "concluido":
            return "concluido";
        case "suspenso":
            return "cancelado";
        default:
            return "pendente";
    }
}

function statusExibicao(string $status): string
{
    $normalizado = mb_strtolower(trim($status), "UTF-8");
    if ($normalizado === "encaminhado" || $normalizado === "agendado") {
        return "Agendado";
    }

    return $status;
}

function definirUsuarioLogado(mysqli $conn, string $email): void
{
    $emailSeguro = $conn->real_escape_string($email);
    if (!$conn->query("SET @usuario_logado = '{$emailSeguro}'")) {
        throw new Exception("Erro ao definir usuário da operação: " . $conn->error);
    }
}


/*
 * Envia aviso de mudança de status por e-mail.
 * Falhas no envio não desfazem uma alteração já salva no banco.
 */
function enviarEmailStatusEcoAgenda(mysqli $conn, array $pedido, string $statusNovo): void
{
    try {
        require_once __DIR__ . "/../../login/notificar_status.php";

        $emailMorador = trim((string)($pedido["morador_email"] ?? ""));
        $agendamentoId = (int)($pedido["id"] ?? 0);

        if ($emailMorador === "" || $agendamentoId <= 0 ||
            !function_exists("notificarMoradorStatus")) {
            return;
        }

        $nomeMorador = "Morador";
        $stmtNome = $conn->prepare(
            "SELECT nome FROM usuario WHERE email = ? LIMIT 1"
        );

        if ($stmtNome) {
            $stmtNome->bind_param("s", $emailMorador);
            if ($stmtNome->execute()) {
                $dadosNome = $stmtNome->get_result()->fetch_assoc();
                if (!empty($dadosNome["nome"])) {
                    $nomeMorador = (string)$dadosNome["nome"];
                }
            }
            $stmtNome->close();
        }

        if (!notificarMoradorStatus(
            $emailMorador,
            $nomeMorador,
            $agendamentoId,
            $statusNovo
        )) {
            error_log(
                "EcoAgenda: não foi possível enviar e-mail de status do pedido #" .
                $agendamentoId
            );
        }
    } catch (Throwable $erroNotificacao) {
        error_log("EcoAgenda: falha na notificação de status: " . $erroNotificacao->getMessage());
    }
}

function buscarPedido(mysqli $conn, int $id): ?array
{
    $sql = "
        SELECT
            a.id,
            a.criado_por,
            a.descricao,
            a.data_pedido,
            a.foto,
            a.morador_email,
            a.status,
            m.cpf AS morador_cpf,
            m.telefone AS morador_telefone,
            u.nome AS morador_nome
        FROM agendamento a
        INNER JOIN morador m ON m.email = a.morador_email
        INNER JOIN usuario u ON u.email = m.email
        WHERE a.id = ?
        LIMIT 1
    ";

    $stmt = $conn->prepare($sql);
    if (!$stmt) {
        throw new Exception("Erro ao buscar pedido: " . $conn->error);
    }
    $stmt->bind_param("i", $id);
    $stmt->execute();
    $pedido = $stmt->get_result()->fetch_assoc();
    $stmt->close();
    return $pedido ?: null;
}

function buscarEnderecoDoPedido(mysqli $conn, int $agendamentoId, string $moradorEmail): ?array
{
    $sql = "
        SELECT e.*
        FROM agendamento_morador_endereco ame
        INNER JOIN morador_endereco me
            ON me.endereco_id = ame.endereco_id
           AND me.morador_email = ame.morador_email
        INNER JOIN endereco e
            ON e.id = me.endereco_id
           AND e.email = me.morador_email
        WHERE ame.agendamento_id = ?
          AND ame.morador_email = ?
        LIMIT 1
    ";

    $stmt = $conn->prepare($sql);
    if (!$stmt) {
        throw new Exception("Erro ao buscar endereço: " . $conn->error);
    }
    $stmt->bind_param("is", $agendamentoId, $moradorEmail);
    $stmt->execute();
    $endereco = $stmt->get_result()->fetch_assoc();
    $stmt->close();
    return $endereco ?: null;
}

function dataComCincoDiasUteis(string $dataBase): string
{
    $data = new DateTime($dataBase);
    $dias = 0;

    while ($dias < 5) {
        $data->modify('+1 day');
        if ((int)$data->format('N') <= 5) {
            $dias++;
        }
    }

    return $data->format('Y-m-d');
}

function diasUteisRestantes(string $dataPedido, ?string $dataReferencia = null): int
{
    $inicio = new DateTime(($dataReferencia ?: date('Y-m-d')) . ' 00:00:00');
    $fim = new DateTime(dataComCincoDiasUteis($dataPedido) . ' 00:00:00');

    if ($inicio >= $fim) {
        return 0;
    }

    $dias = 0;
    $cursor = clone $inicio;
    while ($cursor < $fim) {
        $cursor->modify('+1 day');
        if ((int)$cursor->format('N') <= 5 && $cursor <= $fim) {
            $dias++;
        }
    }

    return $dias;
}

function prazoColetaExibicao(?string $dataEnvio, ?string $status = null, ?string $dataFinalizacao = null): array
{
    $statusNormalizado = mb_strtolower(trim((string)$status), "UTF-8");
    $concluido = in_array($statusNormalizado, ["concluído", "concluido"], true);

    if ($concluido && !empty($dataFinalizacao)) {
        return [
            "enviado" => !empty($dataEnvio) ? dataHoraBR($dataEnvio) : "—",
            "rotulo_prazo" => "Coleta concluída",
            "prazo" => "Concluída em " . dataHoraBR($dataFinalizacao)
        ];
    }

    if (empty($dataEnvio)) {
        return [
            "enviado" => "Aguardando encaminhamento",
            "rotulo_prazo" => "Prazo da coleta",
            "prazo" => "Aguardando envio ao motorista"
        ];
    }

    $dataBase = substr($dataEnvio, 0, 10);
    $dataLimite = dataComCincoDiasUteis($dataBase);
    $diasRestantes = diasUteisRestantes($dataBase);

    if ($diasRestantes <= 0) {
        $prazo = "Prazo até " . dataBR($dataLimite) . " • Prazo encerrado";
    } else {
        $rotulo = $diasRestantes === 1 ? "1 dia útil restante" : $diasRestantes . " dias úteis restantes";
        $prazo = "Prazo até " . dataBR($dataLimite) . " • " . $rotulo;
    }

    return [
        "enviado" => dataHoraBR($dataEnvio),
        "rotulo_prazo" => "Prazo da coleta",
        "prazo" => $prazo
    ];
}

function escolherMotoristaAutomatico(mysqli $conn): ?array
{
    $sqlMotoristas = "
        SELECT m.email, u.nome
        FROM motorista m
        INNER JOIN usuario u ON u.email = m.email
        WHERE m.ativo = 1
        ORDER BY u.nome, m.email
    ";

    $resultado = $conn->query($sqlMotoristas);
    if (!$resultado) {
        throw new Exception("Erro ao consultar motoristas ativos: " . $conn->error);
    }

    $motoristas = [];
    while ($motorista = $resultado->fetch_assoc()) {
        $motorista['pendentes'] = 0;
        $motorista['pressao_prazo'] = 0;
        $motorista['menor_prazo_restante'] = PHP_INT_MAX;
        $motoristas[] = $motorista;
    }

    if (!$motoristas) {
        return null;
    }

    $sqlColetas = "
        SELECT c.motorista_email, a.data_pedido
        FROM coleta c
        INNER JOIN agendamento a ON a.id = c.agendamento_id
        WHERE c.motorista_email = ?
          AND LOWER(a.status) IN (
              'encaminhado', 'agendado', 'confirmado',
              'a caminho', 'em andamento'
          )
        ORDER BY a.data_pedido ASC, a.id ASC
    ";

    $stmt = $conn->prepare($sqlColetas);
    if (!$stmt) {
        throw new Exception("Erro ao preparar cálculo de carga dos motoristas: " . $conn->error);
    }

    foreach ($motoristas as &$motorista) {
        $stmt->bind_param('s', $motorista['email']);
        if (!$stmt->execute()) {
            $erro = $stmt->error;
            $stmt->close();
            throw new Exception("Erro ao calcular carga do motorista: " . $erro);
        }

        $resColetas = $stmt->get_result();
        while ($coleta = $resColetas->fetch_assoc()) {
            $restantes = diasUteisRestantes($coleta['data_pedido']);
            $motorista['pendentes']++;
            $motorista['menor_prazo_restante'] = min($motorista['menor_prazo_restante'], $restantes);
            $motorista['pressao_prazo'] += max(0, 6 - min(5, $restantes));
        }
    }
    unset($motorista);
    $stmt->close();

    usort($motoristas, static function (array $a, array $b): int {
        if ($a['pendentes'] !== $b['pendentes']) {
            return $a['pendentes'] <=> $b['pendentes'];
        }

        if ($a['pressao_prazo'] !== $b['pressao_prazo']) {
            return $a['pressao_prazo'] <=> $b['pressao_prazo'];
        }

        if ($a['menor_prazo_restante'] !== $b['menor_prazo_restante']) {
            return $b['menor_prazo_restante'] <=> $a['menor_prazo_restante'];
        }

        return strcasecmp(
            ($a['nome'] ?? '') . '|' . $a['email'],
            ($b['nome'] ?? '') . '|' . $b['email']
        );
    });

    return $motoristas[0];
}

function registrarSecretariaAgendamento(mysqli $conn, string $secretariaEmail, int $agendamentoId): void
{
    $sql = "
        INSERT INTO secretaria_agendamento (secretaria_email, agendamento_id)
        VALUES (?, ?)
        ON DUPLICATE KEY UPDATE secretaria_email = VALUES(secretaria_email)
    ";
    $stmt = $conn->prepare($sql);
    if (!$stmt) {
        throw new Exception("Erro ao relacionar Secretaria e pedido: " . $conn->error);
    }
    $stmt->bind_param("si", $secretariaEmail, $agendamentoId);
    if (!$stmt->execute()) {
        throw new Exception("Erro ao registrar o atendimento da Secretaria: " . $stmt->error);
    }
    $stmt->close();
}

/* =========================================================
   AÇÕES
========================================================= */
if ($_SERVER["REQUEST_METHOD"] === "POST") {
    $acao = $_POST["acao"] ?? "";
    $agendamentoId = (int)($_POST["agendamento_id"] ?? 0);

    /* ---------------------------------------------------------
       BUSCAR MORADOR POR CPF (AJAX)
    --------------------------------------------------------- */
    if ($acao === "buscar_morador") {
        header("Content-Type: application/json; charset=UTF-8");

        $cpf = trim($_POST["cpf"] ?? "");

        if ($cpf === "") {
            echo json_encode([
                "sucesso" => false,
                "mensagem" => "CPF não informado."
            ], JSON_UNESCAPED_UNICODE);
            exit;
        }

        $sqlMoradorBusca = "
            SELECT
                m.email,
                m.cpf,
                m.telefone,
                u.nome
            FROM morador m
            INNER JOIN usuario u ON u.email = m.email
            WHERE m.cpf = ?
            LIMIT 1
        ";

        $stmtMoradorBusca = $conn->prepare($sqlMoradorBusca);

        if (!$stmtMoradorBusca) {
            echo json_encode([
                "sucesso" => false,
                "mensagem" => "Erro ao consultar o morador."
            ], JSON_UNESCAPED_UNICODE);
            exit;
        }

        $stmtMoradorBusca->bind_param("s", $cpf);
        $stmtMoradorBusca->execute();
        $moradorBusca = $stmtMoradorBusca->get_result()->fetch_assoc();
        $stmtMoradorBusca->close();

        if (!$moradorBusca) {
            echo json_encode([
                "sucesso" => false,
                "mensagem" => "CPF não encontrado. Cadastre o morador antes de criar o pedido por telefone."
            ], JSON_UNESCAPED_UNICODE);
            exit;
        }

        echo json_encode([
            "sucesso" => true,
            "nome" => $moradorBusca["nome"] ?? "",
            "cpf" => $moradorBusca["cpf"] ?? "",
            "telefone" => $moradorBusca["telefone"] ?? "",
            "email" => $moradorBusca["email"] ?? ""
        ], JSON_UNESCAPED_UNICODE);
        exit;
    }

    /* ---------------------------------------------------------
       HISTÓRICO ESPECÍFICO DO PEDIDO (AJAX)
       Disponível apenas para a Secretaria.
    --------------------------------------------------------- */
    if ($acao === "historico_pedido") {
        header("Content-Type: application/json; charset=UTF-8");

        if ($agendamentoId <= 0) {
            echo json_encode([
                "sucesso" => false,
                "mensagem" => "Pedido inválido."
            ], JSON_UNESCAPED_UNICODE);
            exit;
        }

        $sqlHistoricoPedido = "
            SELECT
                h.id,
                h.agendamento_id,
                h.criado_por,
                h.descricao,
                h.data_pedido,
                h.foto,
                h.morador_email,
                h.status,
                h.comando,
                h.data_comando,
                h.usuario_logado,
                u.nome AS usuario_nome,
                CASE
                    WHEN h.usuario_logado LIKE 'MIGRACAO_%' THEN 'Administrador'
                    WHEN adm.email IS NOT NULL THEN 'Administrador'
                    WHEN sec.email IS NOT NULL THEN 'Secretaria'
                    WHEN mot.email IS NOT NULL THEN 'Motorista'
                    ELSE 'Morador'
                END AS perfil_usuario
            FROM agendamento_historico h
            LEFT JOIN usuario u ON u.email = h.usuario_logado
            LEFT JOIN administrador adm ON adm.email = h.usuario_logado
            LEFT JOIN secretaria sec ON sec.email = h.usuario_logado
            LEFT JOIN motorista mot ON mot.email = h.usuario_logado
            WHERE h.agendamento_id = ?
            ORDER BY h.data_comando DESC, h.id DESC
        ";

        $stmtHistoricoPedido = $conn->prepare($sqlHistoricoPedido);
        if (!$stmtHistoricoPedido) {
            echo json_encode([
                "sucesso" => false,
                "mensagem" => "Não foi possível consultar o histórico do pedido."
            ], JSON_UNESCAPED_UNICODE);
            exit;
        }

        $stmtHistoricoPedido->bind_param("i", $agendamentoId);
        $stmtHistoricoPedido->execute();
        $resultadoHistoricoPedido = $stmtHistoricoPedido->get_result();

        $historicoPedido = [];
        while ($registro = $resultadoHistoricoPedido->fetch_assoc()) {
            $historicoPedido[] = [
                "id" => (int)$registro["id"],
                "agendamento_id" => (int)$registro["agendamento_id"],
                "criado_por" => $registro["criado_por"],
                "descricao" => $registro["descricao"],
                "data_pedido" => $registro["data_pedido"],
                "foto" => $registro["foto"],
                "morador_email" => $registro["morador_email"],
                "status" => $registro["status"],
                "comando" => $registro["comando"],
                "data_comando" => $registro["data_comando"],
                "usuario_logado" => $registro["usuario_logado"],
                "usuario" => $registro["usuario_nome"] ?: ($registro["usuario_logado"] ?? "—"),
                "perfil_usuario" => $registro["perfil_usuario"] ?? "Morador"
            ];
        }
        $stmtHistoricoPedido->close();

        echo json_encode([
            "sucesso" => true,
            "agendamento_id" => $agendamentoId,
            "historico" => $historicoPedido
        ], JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);
        exit;
    }

    /* ---------------------------------------------------------
       SUSPENDER PEDIDO
    --------------------------------------------------------- */
    if ($acao === "cancelar") {
        if ($agendamentoId <= 0) {
            $mensagem = "Pedido inválido.";
            $tipoMensagem = "error";
        } else {
            $conn->begin_transaction();
            try {
                $pedido = buscarPedido($conn, $agendamentoId);
                if (!$pedido) {
                    throw new Exception("Pedido não encontrado.");
                }

                $statusAtual = mb_strtolower(trim($pedido["status"]), "UTF-8");
                if ($statusAtual === "concluído" || $statusAtual === "concluido") {
                    throw new Exception("Um pedido concluído não pode ser suspenso.");
                }

                registrarSecretariaAgendamento($conn, $secretariaEmail, $agendamentoId);
                definirUsuarioLogado($conn, $secretariaEmail);

                $sql = "UPDATE agendamento SET status = 'Suspenso' WHERE id = ? LIMIT 1";
                $stmt = $conn->prepare($sql);
                if (!$stmt) {
                    throw new Exception("Erro ao preparar cancelamento: " . $conn->error);
                }
                $stmt->bind_param("i", $agendamentoId);
                if (!$stmt->execute()) {
                    throw new Exception("Erro ao suspender pedido: " . $stmt->error);
                }
                $stmt->close();

                $pedido["status"] = "Suspenso";

                $conn->commit();

                enviarEmailStatusEcoAgenda($conn, $pedido, "Suspenso");

                $mensagem = "Pedido suspenso com sucesso.";
            } catch (Throwable $e) {
                $conn->rollback();
                $mensagem = $e->getMessage();
                $tipoMensagem = "error";
            }
        }
    }

    /* ---------------------------------------------------------
       ENCAMINHAR AUTOMATICAMENTE PARA MOTORISTA
       O sistema distribui entre todos os motoristas ativos,
       priorizando menor quantidade de coletas pendentes e,
       em caso de empate, menor pressão de prazo.
       "Encaminhado" continua persistido no banco; a interface
       apresenta esta etapa como "Agendado".
    --------------------------------------------------------- */
    if ($acao === "encaminhar") {
        if ($agendamentoId <= 0) {
            $mensagem = "Selecione um pedido para encaminhar.";
            $tipoMensagem = "error";
        } else {
            $conn->begin_transaction();
            try {
                $pedido = buscarPedido($conn, $agendamentoId);
                if (!$pedido) {
                    throw new Exception("Pedido não encontrado.");
                }

                $statusAtual = mb_strtolower(trim($pedido["status"]), "UTF-8");
                if ($statusAtual !== "em análise" && $statusAtual !== "em analise") {
                    throw new Exception("Somente pedidos em análise podem ser encaminhados.");
                }

                $motoristaEscolhido = escolherMotoristaAutomatico($conn);
                if (!$motoristaEscolhido) {
                    throw new Exception("Não existem motoristas ativos disponíveis para receber a coleta.");
                }

                $motoristaEmailSelecionado = $motoristaEscolhido["email"];

                registrarSecretariaAgendamento($conn, $secretariaEmail, $agendamentoId);

                $sqlColetaExistente = "
                    SELECT motorista_email, agendamento_id, data_inicio
                    FROM coleta
                    WHERE agendamento_id = ?
                    LIMIT 1
                ";
                $stmtColeta = $conn->prepare($sqlColetaExistente);
                if (!$stmtColeta) {
                    throw new Exception("Erro ao verificar coleta: " . $conn->error);
                }
                $stmtColeta->bind_param("i", $agendamentoId);
                $stmtColeta->execute();
                $coletaExistente = $stmtColeta->get_result()->fetch_assoc();
                $stmtColeta->close();

                if ($coletaExistente) {
                    throw new Exception("Este pedido já possui uma coleta vinculada a um motorista.");
                }

                $sqlColeta = "
                    INSERT INTO coleta
                    (
                        motorista_email,
                        agendamento_id,
                        data_inicio,
                        data_chegada,
                        data_finalizacao,
                        foto
                    )
                    VALUES (?, ?, NOW(), NULL, NULL, NULL)
                ";
                $stmtColeta = $conn->prepare($sqlColeta);
                if (!$stmtColeta) {
                    throw new Exception("Erro ao preparar encaminhamento: " . $conn->error);
                }
                $stmtColeta->bind_param("si", $motoristaEmailSelecionado, $agendamentoId);
                if (!$stmtColeta->execute()) {
                    throw new Exception("Erro ao encaminhar pedido: " . $stmtColeta->error);
                }
                $stmtColeta->close();

                definirUsuarioLogado($conn, $secretariaEmail);
                $sqlStatus = "UPDATE agendamento SET status = 'Encaminhado' WHERE id = ? AND status = 'Em análise' LIMIT 1";
                $stmtStatus = $conn->prepare($sqlStatus);
                if (!$stmtStatus) {
                    throw new Exception("Erro ao preparar mudança de status: " . $conn->error);
                }
                $stmtStatus->bind_param("i", $agendamentoId);
                if (!$stmtStatus->execute()) {
                    throw new Exception("Erro ao agendar pedido: " . $stmtStatus->error);
                }
                $stmtStatus->close();

                $pedido["status"] = "Encaminhado";
                $conn->commit();

                enviarEmailStatusEcoAgenda($conn, $pedido, "Agendado");

                $nomeMotorista = trim((string)($motoristaEscolhido["nome"] ?? ""));
                if ($nomeMotorista === "") {
                    $nomeMotorista = $motoristaEmailSelecionado;
                }

                $prazo = dataComCincoDiasUteis($pedido["data_pedido"]);
                $prazoFormatado = date("d/m/Y", strtotime($prazo));
                $mensagem = "Pedido #{$agendamentoId} agendado automaticamente para {$nomeMotorista}. Prazo: até {$prazoFormatado} (5 dias úteis).";
                $mostrarNotificacaoEncaminhamento = true;
                $notificacaoMotorista = $nomeMotorista;
                $notificacaoPrazo = $prazoFormatado;
            } catch (Throwable $e) {
                $conn->rollback();
                $mensagem = $e->getMessage();
                $tipoMensagem = "error";
            }
        }
    }

    /* ---------------------------------------------------------
       EDITAR
       No novo DER endereço é normalizado.
    --------------------------------------------------------- */
    if ($acao === "editar") {
        $descricao = trim($_POST["descricao"] ?? "");
        $cep = trim($_POST["cep"] ?? "");
        $estado = trim($_POST["estado"] ?? "");
        $cidade = trim($_POST["cidade"] ?? "");
        $rua = trim($_POST["rua"] ?? "");
        $bairro = trim($_POST["bairro"] ?? "");
        $numero = trim($_POST["numero"] ?? "");
        $complemento = trim($_POST["complemento"] ?? "");

        if ($agendamentoId <= 0 || $descricao === "" || $cep === "" || $estado === "" || $cidade === "" || $rua === "" || $bairro === "" || $numero === "") {
            $mensagem = "Preencha a descrição e todos os campos obrigatórios do endereço.";
            $tipoMensagem = "error";
        } else {
            $conn->begin_transaction();
            try {
                $pedido = buscarPedido($conn, $agendamentoId);
                if (!$pedido) {
                    throw new Exception("Pedido não encontrado.");
                }

                $enderecoAtual = buscarEnderecoDoPedido($conn, $agendamentoId, $pedido["morador_email"]);

                definirUsuarioLogado($conn, $secretariaEmail);

                $sqlUpdate = "UPDATE agendamento SET descricao = ? WHERE id = ? LIMIT 1";
                $stmt = $conn->prepare($sqlUpdate);
                if (!$stmt) {
                    throw new Exception("Erro ao preparar edição: " . $conn->error);
                }
                $stmt->bind_param("si", $descricao, $agendamentoId);
                if (!$stmt->execute()) {
                    throw new Exception("Erro ao editar pedido: " . $stmt->error);
                }
                $stmt->close();

                if ($enderecoAtual) {
                    $sqlEndereco = "
                        UPDATE endereco
                        SET cep = ?, estado = ?, cidade = ?, rua = ?, bairro = ?, numero = ?, complemento = ?
                        WHERE id = ? AND email = ?
                        LIMIT 1
                    ";
                    $stmtEndereco = $conn->prepare($sqlEndereco);
                    if (!$stmtEndereco) {
                        throw new Exception("Erro ao preparar atualização do endereço: " . $conn->error);
                    }
                    $enderecoId = (int)$enderecoAtual["id"];
                    $stmtEndereco->bind_param(
                        "sssssssis",
                        $cep,
                        $estado,
                        $cidade,
                        $rua,
                        $bairro,
                        $numero,
                        $complemento,
                        $enderecoId,
                        $pedido["morador_email"]
                    );
                    if (!$stmtEndereco->execute()) {
                        throw new Exception("Erro ao atualizar endereço: " . $stmtEndereco->error);
                    }
                    $stmtEndereco->close();
                } else {
                    $sqlEndereco = "
                        INSERT INTO endereco
                        (email, cep, estado, cidade, rua, bairro, numero, complemento)
                        VALUES (?, ?, ?, ?, ?, ?, ?, ?)
                    ";
                    $stmtEndereco = $conn->prepare($sqlEndereco);
                    if (!$stmtEndereco) {
                        throw new Exception("Erro ao preparar novo endereço: " . $conn->error);
                    }
                    $stmtEndereco->bind_param(
                        "ssssssss",
                        $pedido["morador_email"],
                        $cep,
                        $estado,
                        $cidade,
                        $rua,
                        $bairro,
                        $numero,
                        $complemento
                    );
                    if (!$stmtEndereco->execute()) {
                        throw new Exception("Erro ao cadastrar endereço: " . $stmtEndereco->error);
                    }
                    $novoEnderecoId = $stmtEndereco->insert_id;
                    $stmtEndereco->close();

                    $stmtRel = $conn->prepare("INSERT INTO morador_endereco (endereco_id, morador_email) VALUES (?, ?)");
                    if (!$stmtRel) {
                        throw new Exception("Erro ao relacionar endereço e morador: " . $conn->error);
                    }
                    $stmtRel->bind_param("is", $novoEnderecoId, $pedido["morador_email"]);
                    if (!$stmtRel->execute()) {
                        throw new Exception("Erro ao relacionar endereço e morador: " . $stmtRel->error);
                    }
                    $stmtRel->close();

                    $stmtAg = $conn->prepare("INSERT INTO agendamento_morador_endereco (agendamento_id, endereco_id, morador_email) VALUES (?, ?, ?)");
                    if (!$stmtAg) {
                        throw new Exception("Erro ao relacionar endereço ao pedido: " . $conn->error);
                    }
                    $stmtAg->bind_param("iis", $agendamentoId, $novoEnderecoId, $pedido["morador_email"]);
                    if (!$stmtAg->execute()) {
                        throw new Exception("Erro ao relacionar endereço ao pedido: " . $stmtAg->error);
                    }
                    $stmtAg->close();
                }

                registrarSecretariaAgendamento($conn, $secretariaEmail, $agendamentoId);

                $pedidoAtualizado = buscarPedido($conn, $agendamentoId);
                $pedidoAtualizado = $pedidoAtualizado ?: $pedido;

                $conn->commit();
                $mensagem = "Pedido atualizado com sucesso.";
            } catch (Throwable $e) {
                $conn->rollback();
                $mensagem = $e->getMessage();
                $tipoMensagem = "error";
            }
        }
    }

    /* ---------------------------------------------------------
       CRIAR PEDIDO POR TELEFONE
    --------------------------------------------------------- */
    if ($acao === "criar_pedido") {
        $cpf = trim($_POST["cpf"] ?? "");
        $descricao = trim($_POST["descricao"] ?? "");
        $cep = trim($_POST["cep"] ?? "");
        $estado = trim($_POST["estado"] ?? "");
        $cidade = trim($_POST["cidade"] ?? "");
        $rua = trim($_POST["rua"] ?? "");
        $bairro = trim($_POST["bairro"] ?? "");
        $numero = trim($_POST["numero"] ?? "");
        $complemento = trim($_POST["complemento"] ?? "");

        $estadoNormalizado = mb_strtoupper(trim($estado), "UTF-8");
        $cidadeNormalizada = mb_strtolower(trim($cidade), "UTF-8");

        if ($cpf === "" || $descricao === "" || $cep === "" || $estado === "" || $cidade === "" || $rua === "" || $bairro === "" || $numero === "") {
            $mensagem = "CPF, descrição e endereço são obrigatórios.";
            $tipoMensagem = "error";
        } elseif ($estadoNormalizado !== "PR" || $cidadeNormalizada !== "pinhais") {
            $mensagem = "O endereço da coleta precisa ser de Pinhais/PR.";
            $tipoMensagem = "error";
        } else {
            $conn->begin_transaction();
            try {
                $sqlMorador = "
                    SELECT m.email, m.cpf
                    FROM morador m
                    WHERE m.cpf = ?
                    LIMIT 1
                ";
                $stmtMorador = $conn->prepare($sqlMorador);
                if (!$stmtMorador) {
                    throw new Exception("Erro ao consultar morador: " . $conn->error);
                }
                $stmtMorador->bind_param("s", $cpf);
                $stmtMorador->execute();
                $morador = $stmtMorador->get_result()->fetch_assoc();
                $stmtMorador->close();

                if (!$morador) {
                    throw new Exception("CPF não encontrado. Cadastre o morador antes de criar o pedido por telefone.");
                }

                $sqlAgendamento = "
                    INSERT INTO agendamento
                    (
                        criado_por,
                        descricao,
                        data_pedido,
                        foto,
                        morador_email,
                        status
                    )
                    VALUES (?, ?, NOW(), NULL, ?, 'Em análise')
                ";
                $stmtAgendamento = $conn->prepare($sqlAgendamento);
                if (!$stmtAgendamento) {
                    throw new Exception("Erro ao preparar novo pedido: " . $conn->error);
                }
                $stmtAgendamento->bind_param("sss", $secretariaEmail, $descricao, $morador["email"]);
                if (!$stmtAgendamento->execute()) {
                    throw new Exception("Erro ao criar pedido: " . $stmtAgendamento->error);
                }
                $novoAgendamentoId = $stmtAgendamento->insert_id;
                $stmtAgendamento->close();

                $sqlEndereco = "
                    INSERT INTO endereco
                    (email, cep, estado, cidade, rua, bairro, numero, complemento)
                    VALUES (?, ?, ?, ?, ?, ?, ?, ?)
                ";
                $stmtEndereco = $conn->prepare($sqlEndereco);
                if (!$stmtEndereco) {
                    throw new Exception("Erro ao preparar endereço: " . $conn->error);
                }
                $stmtEndereco->bind_param("ssssssss", $morador["email"], $cep, $estado, $cidade, $rua, $bairro, $numero, $complemento);
                if (!$stmtEndereco->execute()) {
                    throw new Exception("Erro ao cadastrar endereço: " . $stmtEndereco->error);
                }
                $enderecoId = $stmtEndereco->insert_id;
                $stmtEndereco->close();

                $stmtRel = $conn->prepare("INSERT INTO morador_endereco (endereco_id, morador_email) VALUES (?, ?)");
                if (!$stmtRel) {
                    throw new Exception("Erro ao relacionar endereço: " . $conn->error);
                }
                $stmtRel->bind_param("is", $enderecoId, $morador["email"]);
                if (!$stmtRel->execute()) {
                    throw new Exception("Erro ao relacionar endereço: " . $stmtRel->error);
                }
                $stmtRel->close();

                $stmtAgEndereco = $conn->prepare("INSERT INTO agendamento_morador_endereco (agendamento_id, endereco_id, morador_email) VALUES (?, ?, ?)");
                if (!$stmtAgEndereco) {
                    throw new Exception("Erro ao relacionar endereço ao pedido: " . $conn->error);
                }
                $stmtAgEndereco->bind_param("iis", $novoAgendamentoId, $enderecoId, $morador["email"]);
                if (!$stmtAgEndereco->execute()) {
                    throw new Exception("Erro ao relacionar endereço ao pedido: " . $stmtAgEndereco->error);
                }
                $stmtAgEndereco->close();

                registrarSecretariaAgendamento($conn, $secretariaEmail, $novoAgendamentoId);

                $conn->commit();
                $mensagem = "Pedido criado por telefone com sucesso. Número: #" . $novoAgendamentoId;
            } catch (Throwable $e) {
                $conn->rollback();
                $mensagem = $e->getMessage();
                $tipoMensagem = "error";
            }
        }
    }
}

/* =========================================================
   DADOS DO DASHBOARD
========================================================= */
$motoristas = [];
$sqlMotoristas = "
    SELECT m.email, m.cpf, m.telefone, u.nome
    FROM motorista m
    INNER JOIN usuario u ON u.email = m.email
    WHERE m.ativo = 1
    ORDER BY u.nome, m.email
";
$resultMotoristas = $conn->query($sqlMotoristas);
if ($resultMotoristas) {
    while ($motorista = $resultMotoristas->fetch_assoc()) {
        $motoristas[] = $motorista;
    }
}

$stats = [
    "total" => 0,
    "pendentes" => 0,
    "confirmados" => 0,
    "andamento" => 0,
    "concluidos" => 0,
    "cancelados" => 0
];

$sqlStats = "
    SELECT
        COUNT(*) AS total,
        SUM(CASE WHEN LOWER(status) IN ('em análise','em analise') THEN 1 ELSE 0 END) AS pendentes,
        SUM(CASE WHEN LOWER(status) = 'encaminhado' THEN 1 ELSE 0 END) AS confirmados,
        SUM(CASE WHEN LOWER(status) = 'em andamento' THEN 1 ELSE 0 END) AS andamento,
        SUM(CASE WHEN LOWER(status) IN ('concluído','concluido') THEN 1 ELSE 0 END) AS concluidos,
        SUM(CASE WHEN LOWER(status) = 'suspenso' THEN 1 ELSE 0 END) AS cancelados
    FROM agendamento
";
$resultStats = $conn->query($sqlStats);
if ($resultStats) {
    $statsDb = $resultStats->fetch_assoc();
    foreach ($stats as $chave => $valor) {
        $stats[$chave] = (int)($statsDb[$chave] ?? 0);
    }
}

$pedidos = [];
$sqlPedidos = "
    SELECT
        a.id,
        a.criado_por,
        a.descricao,
        a.data_pedido,
        a.foto,
        a.morador_email,
        a.status,
        m.cpf AS morador_cpf,
        m.telefone AS morador_telefone,
        u.nome AS morador_nome,
        mot.email AS motorista_email,
        u_mot.nome AS motorista_nome,
        c.data_inicio,
        c.data_chegada,
        c.data_finalizacao,
        c.foto AS foto_motorista,
        e.id AS endereco_id,
        e.cep,
        e.estado,
        e.cidade,
        e.rua,
        e.bairro,
        e.numero,
        e.complemento
    FROM agendamento a
    INNER JOIN morador m ON m.email = a.morador_email
    INNER JOIN usuario u ON u.email = m.email
    LEFT JOIN coleta c ON c.agendamento_id = a.id
    LEFT JOIN motorista mot ON mot.email = c.motorista_email
    LEFT JOIN usuario u_mot ON u_mot.email = mot.email
    LEFT JOIN agendamento_morador_endereco ame ON ame.agendamento_id = a.id AND ame.morador_email = a.morador_email
    LEFT JOIN morador_endereco me ON me.endereco_id = ame.endereco_id AND me.morador_email = ame.morador_email
    LEFT JOIN endereco e ON e.id = me.endereco_id AND e.email = me.morador_email
    GROUP BY
        a.id, a.criado_por, a.descricao, a.data_pedido, a.foto, a.morador_email, a.status,
        m.cpf, m.telefone, u.nome, mot.email, u_mot.nome, c.data_inicio, c.data_chegada,
        c.data_finalizacao, c.foto, e.id, e.cep, e.estado, e.cidade, e.rua, e.bairro, e.numero, e.complemento
    ORDER BY
        CASE
            WHEN LOWER(a.status) IN ('em análise','em analise') THEN 1
            WHEN LOWER(a.status) = 'encaminhado' THEN 2
            WHEN LOWER(a.status) = 'em andamento' THEN 3
            WHEN LOWER(a.status) IN ('concluído','concluido') THEN 4
            WHEN LOWER(a.status) = 'suspenso' THEN 5
            ELSE 6
        END,
        a.id DESC
    LIMIT 200
";
$resultPedidos = $conn->query($sqlPedidos);
if ($resultPedidos) {
    while ($pedido = $resultPedidos->fetch_assoc()) {
        $partesEndereco = [];
        if (!empty($pedido["rua"])) $partesEndereco[] = $pedido["rua"];
        if (!empty($pedido["numero"])) $partesEndereco[] = "nº " . $pedido["numero"];
        if (!empty($pedido["complemento"])) $partesEndereco[] = $pedido["complemento"];
        if (!empty($pedido["bairro"])) $partesEndereco[] = $pedido["bairro"];
        if (!empty($pedido["cidade"])) $partesEndereco[] = $pedido["cidade"];
        if (!empty($pedido["estado"])) $partesEndereco[] = $pedido["estado"];
        if (!empty($pedido["cep"])) $partesEndereco[] = "CEP: " . $pedido["cep"];
        $pedido["endereco"] = implode(", ", $partesEndereco);
        $pedidos[] = $pedido;
    }
}


/* =========================================================
   HISTÓRICO COMPLETO DOS PEDIDOS
========================================================= */
$historico = [];
$sqlHistorico = "
    SELECT
        h.id,
        h.agendamento_id,
        h.criado_por,
        h.descricao,
        h.data_pedido,
        h.foto,
        h.morador_email,
        h.status,
        h.comando,
        h.data_comando,
        h.usuario_logado,
        u.nome AS usuario_nome,
        CASE
            WHEN adm.email IS NOT NULL THEN 'Administrador'
            WHEN sec.email IS NOT NULL THEN 'Secretaria'
            WHEN mot.email IS NOT NULL THEN 'Motorista'
            WHEN mr.email IS NOT NULL THEN 'Morador'
            WHEN UPPER(COALESCE(h.usuario_logado, '')) LIKE 'MIGRACAO%' THEN 'Administrador'
            WHEN UPPER(COALESCE(h.usuario_logado, '')) LIKE 'SISTEMA%' THEN 'Administrador'
            ELSE 'Morador'
        END AS perfil_usuario
    FROM agendamento_historico h
    LEFT JOIN usuario u ON u.email = h.usuario_logado
    LEFT JOIN administrador adm ON adm.email = h.usuario_logado
    LEFT JOIN secretaria sec ON sec.email = h.usuario_logado
    LEFT JOIN motorista mot ON mot.email = h.usuario_logado
    LEFT JOIN morador mr ON mr.email = h.usuario_logado
    ORDER BY h.agendamento_id ASC, h.data_comando ASC, h.id ASC
    LIMIT 1000
";
$resultHistorico = $conn->query($sqlHistorico);
if ($resultHistorico) {
    while ($registro = $resultHistorico->fetch_assoc()) {
        $historico[] = $registro;
    }
}

$partesNome = preg_split('/\s+/', trim($nomeSecretaria));
$iniciais = "";
if (!empty($partesNome[0])) {
    $iniciais .= strtoupper(substr($partesNome[0], 0, 1));
}
if (count($partesNome) > 1) {
    $iniciais .= strtoupper(substr($partesNome[count($partesNome) - 1], 0, 1));
}
$iniciais = substr($iniciais ?: "S", 0, 2);
?>

<!DOCTYPE html>
<html lang="pt-BR">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>EcoAgenda - Secretaria</title>
    <link rel="stylesheet" href="secretaria.css">

    <style>
        .foto-modal-morador {
            margin-top: 14px;
            padding: 12px;
            border-radius: 8px;
            background: #f7f9f8;
        }

        .foto-modal-morador[hidden] {
            display: none !important;
        }

        .foto-modal-titulo {
            margin-bottom: 8px;
            font-size: 10px;
            font-weight: 700;
            color: #2f3f35;
        }

        .foto-modal-morador img {
            display: block;
            width: 100%;
            max-height: 360px;
            object-fit: contain;
            border-radius: 7px;
            background: #fff;
        }
    </style>


    <style>
        .notificacao-encaminhamento-overlay {
            position: fixed;
            inset: 0;
            z-index: 9999;
            display: flex;
            align-items: center;
            justify-content: center;
            padding: 22px;
            background: rgba(18, 37, 27, 0.38);
        }
        .notificacao-encaminhamento {
            width: min(460px, 100%);
            background: #fff;
            border: 1px solid #b8dfc1;
            border-top: 5px solid #1f8a4c;
            border-radius: 14px;
            padding: 24px 24px 20px;
            box-shadow: 0 18px 55px rgba(18, 37, 27, 0.22);
        }
        .notificacao-encaminhamento .titulo {
            margin: 0 0 7px;
            color: #1f6e3a;
            font-size: 18px;
            font-weight: 800;
        }
        .notificacao-encaminhamento .texto {
            margin: 0;
            color: #415047;
            font-size: 12px;
            line-height: 1.55;
        }
        .notificacao-encaminhamento .destino {
            margin-top: 12px;
            padding: 12px 13px;
            border-radius: 9px;
            background: #edf9ef;
            border: 1px solid #c8e7cf;
            color: #275e37;
            font-size: 12px;
        }
        .notificacao-encaminhamento .acoes {
            display: flex;
            justify-content: flex-end;
            margin-top: 18px;
        }
        .notificacao-encaminhamento .btn-ok {
            border: 0;
            border-radius: 8px;
            padding: 10px 22px;
            background: #12622d;
            color: #fff;
            font-size: 11px;
            font-weight: 700;
            cursor: pointer;
        }
    </style>
<link rel="stylesheet" href="../interface/base.css?v=20261009">
<link rel="stylesheet" href="../interface/interface.css?v=20261009">
<script src="../interface/interface.js?v=20261009" defer></script>
</head>
<body class="eco-interface ea-secretaria">
<div class="dashboard">
    <aside class="sidebar">
        <div class="logo"><img src="../../assets/icons/logo-ecoagenda-branco.png" alt="EcoAgenda"></div>
        <div class="perfil-side">Secretaria</div>
        <nav class="menu">
            <button type="button" class="menu-link active" data-section="inicio"><span>▦</span>Dashboard</button>
            <button type="button" class="menu-link" data-section="pedidos"><span>▤</span>Pedidos</button>
            <button type="button" class="menu-link" data-section="buscar"><span>⌕</span>Buscar pedido</button>
            <button type="button" class="menu-link" data-section="novo"><span>＋</span>Novo Pedido</button>
        </nav>
    </aside>

    <main class="main">
        <header class="topbar">
            <div>
                <h1 id="tituloPagina">Dashboard</h1>
                <p id="subtituloPagina">Valide e encaminhe as solicitações de coleta.</p>
            </div>
            <div class="top-actions">
                <span class="secretaria-nome"><?= e($nomeSecretaria) ?></span>
                <a href="../logout.php" class="logout">Sair</a>
                <div class="avatar"><?= e($iniciais) ?></div>
            </div>
        </header>

        <div class="content">
            <?php if ($mensagem !== ""): ?>
                <div class="alerta <?= e($tipoMensagem) ?>"><?= e($mensagem) ?></div>
            <?php endif; ?>

            <section class="section active" id="section-inicio">
                <div class="stats">
                    <div class="stat-card total"><strong><?= $stats["total"] ?></strong><span>Todos os pedidos</span></div>
                    <div class="stat-card pendente"><strong><?= $stats["pendentes"] ?></strong><span>Em análise</span></div>
                    <div class="stat-card confirmado"><strong><?= $stats["confirmados"] ?></strong><span>Agendados</span></div>
                    <div class="stat-card andamento"><strong><?= $stats["andamento"] ?></strong><span>Em andamento</span></div>
                    <div class="stat-card concluido"><strong><?= $stats["concluidos"] ?></strong><span>Concluídos</span></div>
                    <div class="stat-card cancelado"><strong><?= $stats["cancelados"] ?></strong><span>Suspensos</span></div>
                </div>

                <div class="painel">
                    <div class="painel-header">
                        <div>
                            <h2>Pedidos aguardando validação</h2>
                            <p>Solicitações que ainda não foram encaminhadas para um motorista.</p>
                        </div>
                        <button type="button" class="btn-primary" data-go-section="pedidos">Ver pedidos</button>
                    </div>

                    <div class="lista-simples">
                        <?php $contadorEmAnalise = 0; ?>
                        <?php foreach ($pedidos as $pedido): ?>
                            <?php $statusPedidoNormalizado = mb_strtolower(trim($pedido["status"]), "UTF-8"); ?>
                            <?php if ($statusPedidoNormalizado !== "em análise" && $statusPedidoNormalizado !== "em analise") continue; ?>
                            <?php if ($contadorEmAnalise >= 6) break; ?>
                            <?php $contadorEmAnalise++; $classe = classeStatus($pedido["status"]); ?>
                            <div class="pedido-resumo" data-status="<?= e($classe) ?>" data-cpf="<?= e($pedido["morador_cpf"]) ?>">
                                <div class="icone-pedido"><img src="../../assets/icons/residuos-verde.png" alt="Resíduo" style="width:24px;height:24px;object-fit:contain;display:block;"></div>
                                <div>
                                    <strong>Pedido #<?= e($pedido["id"]) ?></strong>
                                    <p><?= e($pedido["morador_nome"] ?: "Morador") ?> • CPF <?= e($pedido["morador_cpf"]) ?></p>
                                </div>
                                <span class="status <?= e($classe) ?>"><?= e(statusExibicao($pedido["status"])) ?></span>
                                <button type="button" class="btn-small btn-ver-pedido" data-id="<?= (int)$pedido["id"] ?>">Ver pedido</button>
                            </div>
                        <?php endforeach; ?>
                        <?php if ($contadorEmAnalise === 0): ?>
                            <div class="sem-registros">Não há pedidos aguardando validação.</div>
                        <?php endif; ?>
                    </div>
                </div>
            </section>

            <section class="section" id="section-pedidos">
                <div class="section-top">
                    <div>
                        <h2>Pedidos</h2>
                        <p>Visualize, edite, valide, encaminhe ou cancele solicitações.</p>
                    </div>
                    <div class="filtros">
                        <button type="button" class="filtro active" data-filter="todos">Todos</button>
                        <button type="button" class="filtro" data-filter="pendente">Em análise</button>
                        <button type="button" class="filtro" data-filter="confirmado">Agendados</button>
                        <button type="button" class="filtro" data-filter="andamento">Em andamento</button>
                        <button type="button" class="filtro" data-filter="concluido">Concluídos</button>
                        <button type="button" class="filtro" data-filter="cancelado">Suspensos</button>
                    </div>
                </div>

                <div class="cards-pedidos">
                    <?php foreach ($pedidos as $pedido): ?>
                        <?php $classe = classeStatus($pedido["status"]); ?>
                        <article class="pedido-card" data-status="<?= e($classe) ?>" data-id="<?= (int)$pedido["id"] ?>" data-cpf="<?= e($pedido["morador_cpf"]) ?>">
                            <div class="pedido-card-top">
                                <div>
                                    <span class="numero-pedido">Pedido #<?= e($pedido["id"]) ?></span>
                                    <h3><?= e(mb_strimwidth($pedido["descricao"], 0, 90, "...")) ?></h3>
                                    <p>CPF: <?= e($pedido["morador_cpf"]) ?> • Pedido em <?= e(dataBR($pedido["data_pedido"])) ?></p>
                                </div>
                                <span class="status <?= e($classe) ?>"><?= e(statusExibicao($pedido["status"])) ?></span>
                            </div>

                            <?php $prazoInfo = prazoColetaExibicao($pedido["data_inicio"] ?? null, $pedido["status"] ?? null, $pedido["data_finalizacao"] ?? null); ?>
                            <div class="pedido-meta">
                                <div><span>Morador</span><strong><?= e($pedido["morador_nome"] ?: "Morador") ?></strong></div>
                                <div><span>Motorista</span><strong><?= e($pedido["motorista_nome"] ?: "Ainda não atribuído") ?></strong></div>
                                <div><span>Endereço</span><strong><?= e($pedido["endereco"] ?: "Não informado") ?></strong></div>
                                <div><span>Enviado ao motorista</span><strong><?= e($prazoInfo["enviado"]) ?></strong></div>
                                <div><span><?= e($prazoInfo["rotulo_prazo"]) ?></span><strong><?= e($prazoInfo["prazo"]) ?></strong></div>
                            </div>

                            <div class="pedido-actions">
                                <button type="button" class="btn-small btn-ver-pedido" data-id="<?= (int)$pedido["id"] ?>">Ver detalhes</button>
                                <button type="button" class="btn-small btn-editar" data-id="<?= (int)$pedido["id"] ?>">Editar</button>
                                <?php if ($classe === "pendente"): ?>
                                    <button type="button" class="btn-small btn-encaminhar" data-id="<?= (int)$pedido["id"] ?>">Encaminhar</button>
                                <?php endif; ?>
                                <?php if ($classe !== "cancelado" && $classe !== "concluido"): ?>
                                    <form method="POST" class="inline-form" onsubmit="return confirm('Tem certeza que deseja suspender este pedido?');">
                                        <input type="hidden" name="acao" value="cancelar">
                                        <input type="hidden" name="agendamento_id" value="<?= (int)$pedido["id"] ?>">
                                        <button type="submit" class="btn-small btn-cancelar">Suspender</button>
                                    </form>
                                <?php endif; ?>
                            </div>

                            <div class="dados-pedido"
                                 id="dados-<?= (int)$pedido["id"] ?>"
                                 data-descricao="<?= e($pedido["descricao"]) ?>"
                                 data-data="<?= e($pedido["data_pedido"]) ?>"
                                 data-hora="<?= e(horaBR($pedido["data_inicio"])) ?>"
                                 data-endereco="<?= e($pedido["endereco"]) ?>"
                                 data-cpf="<?= e($pedido["morador_cpf"]) ?>"
                                 data-status="<?= e($pedido["status"]) ?>"
                                 data-morador="<?= e($pedido["morador_nome"] ?? "") ?>"
                                 data-telefone="<?= e($pedido["morador_telefone"] ?? "") ?>"
                                 data-motorista="<?= e($pedido["motorista_nome"] ?? "") ?>"
                                 data-criado="<?= e($pedido["criado_por"] ?? "") ?>"
                                 data-foto-morador="<?= e($pedido["foto"] ?? "") ?>"
                                 data-cep="<?= e($pedido["cep"] ?? "") ?>"
                                 data-estado="<?= e($pedido["estado"] ?? "") ?>"
                                 data-cidade="<?= e($pedido["cidade"] ?? "") ?>"
                                 data-rua="<?= e($pedido["rua"] ?? "") ?>"
                                 data-bairro="<?= e($pedido["bairro"] ?? "") ?>"
                                 data-numero="<?= e($pedido["numero"] ?? "") ?>"
                                 data-complemento="<?= e($pedido["complemento"] ?? "") ?>"></div>
                        </article>
                    <?php endforeach; ?>

                    <?php if (empty($pedidos)): ?>
                        <div class="sem-registros">Nenhum pedido encontrado.</div>
                    <?php endif; ?>
                </div>

                <div id="semResultadoFiltro" class="sem-registros" hidden>Nenhum pedido encontrado para este filtro.</div>
            </section>

            <section class="section" id="section-buscar">
                <div class="painel">
                    <div class="section-top">
                        <div>
                            <h2>Buscar pedido</h2>
                            <p>Localize um pedido por CPF do morador ou pelo ID do pedido.</p>
                        </div>
                    </div>

                    <div class="busca-form">
                        <button type="button" id="tipoBuscaCpf" class="btn-primary">Buscar por CPF</button>
                        <button type="button" id="tipoBuscaId" class="btn-secondary">Buscar por ID</button>
                    </div>

                    <div class="busca-form">
                        <input type="text" id="campoBuscaPedido" placeholder="Digite o CPF" autocomplete="off">
                        <button type="button" id="buscarPedido" class="btn-primary">Buscar</button>
                    </div>

                    <div id="resultadoBuscaPedido" class="resultado-busca"></div>

                    <div
                        id="resultadoPedidosBusca"
                        class="cards-pedidos">
                    </div>
                </div>
            </section>

            <script type="application/json" id="historicoPedidosSecretaria"><?= json_encode($historico, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES | JSON_HEX_TAG | JSON_HEX_APOS | JSON_HEX_AMP | JSON_HEX_QUOT) ?></script>

            <section class="section" id="section-novo">
                <div class="painel">
                    <div class="section-top">
                        <div>
                            <h2>Novo pedido por telefone</h2>
                            <p>Registre uma solicitação recebida pela Secretaria.</p>
                        </div>
                    </div>

                    <div class="info-box">A Secretaria pode registrar um pedido recebido por telefone. O CPF precisa possuir cadastro de morador no sistema.</div>

                    <form method="POST" class="form-grid">
                        <input type="hidden" name="acao" value="criar_pedido">

                        <div class="campo">
                            <label>CPF do morador*</label>
                            <input type="text" name="cpf" id="novoCpf" maxlength="14" required>
                        </div>

                        <div class="campo">
                            <label>Telefone do morador</label>
                            <input type="text" id="novoTelefone" readonly>
                        </div>

                        <div class="campo">
                            <label>E-mail do morador</label>
                            <input type="email" id="novoEmail" readonly>
                        </div>

                        <div class="campo">
                            <label>CEP*</label>
                            <input type="text" name="cep" id="novoCep" maxlength="9" required>
                        </div>

                        <div class="campo">
                            <label>Estado*</label>
                            <input type="text" name="estado" id="novoEstado" maxlength="2" value="PR" required>
                        </div>

                        <div class="campo">
                            <label>Cidade*</label>
                            <input type="text" name="cidade" id="novoCidade" value="Pinhais" required>
                        </div>

                        <div class="campo campo-full">
                            <label>Rua*</label>
                            <input type="text" name="rua" id="novoRua" required>
                        </div>

                        <div class="campo">
                            <label>Bairro*</label>
                            <input type="text" name="bairro" id="novoBairro" required>
                        </div>

                        <div class="campo">
                            <label>Número*</label>
                            <input type="text" name="numero" id="novoNumero" required>
                        </div>

                        <div class="campo campo-full">
                            <label>Complemento</label>
                            <input type="text" name="complemento" id="novoComplemento">
                        </div>

                        <div class="campo campo-full">
                            <label>Descrição do resíduo*</label>
                            <textarea name="descricao" rows="4" placeholder="Descreva o material e a quantidade aproximada." required></textarea>
                        </div>

                        <div class="form-actions campo-full">
                            <button type="reset" class="btn-secondary">Limpar</button>
                            <button type="submit" class="btn-primary">Criar pedido</button>
                        </div>
                    </form>
                </div>
            </section>

        </div>
    </main>
</div>

<!-- MODAL DETALHES -->
<div class="modal" id="modalDetalhes" hidden>
    <div class="modal-box">
        <div class="modal-header">
            <div>
                <span id="modalPedidoId">Pedido</span>
                <h2 id="modalTitulo">Detalhes do pedido</h2>
            </div>
            <button type="button" class="modal-close" data-close-modal>×</button>
        </div>

        <div class="modal-body">
            <div class="modal-status-row"><span>Status</span><strong id="modalStatus">—</strong></div>
            <div class="detalhes-grid">
                <div><span>Morador</span><strong id="modalMorador">—</strong></div>
                <div><span>CPF</span><strong id="modalCpf">—</strong></div>
                <div><span>Telefone</span><strong id="modalTelefone">—</strong></div>
                <div><span>Motorista</span><strong id="modalMotorista">—</strong></div>
                <div><span>Pedido criado em</span><strong id="modalData">—</strong></div>
                <div><span>Início da coleta</span><strong id="modalHora">Ainda não registrado</strong></div>
                <div class="full"><span>Endereço</span><strong id="modalEndereco">—</strong></div>
                <div class="full"><span>Descrição</span><strong id="modalDescricao">—</strong></div>
                <div class="full"><span>Criado por</span><strong id="modalCriadoPor">—</strong></div>
            </div>

            <div id="modalFotoMoradorAtual" class="foto-modal-morador" hidden>
                <div class="foto-modal-titulo">📷 Foto enviada pelo morador</div>
                <a id="modalFotoMoradorLink" href="#" target="_blank" rel="noopener">
                    <img id="modalFotoMorador" src="" alt="Foto enviada pelo morador">
                </a>
            </div>
        </div>

        <div class="modal-footer"><button type="button" class="btn-secondary" data-close-modal>Fechar</button></div>
    </div>
</div>

<!-- =========================================================
     MODAL HISTÓRICO DO PEDIDO
========================================================= -->
<div class="modal" id="modalHistoricoPedido" hidden>
    <div class="modal-box modal-box-historico-pedido">
        <div class="modal-header">
            <div>
                <span id="historicoPedidoNumero">Histórico</span>
                <h2>Histórico do pedido</h2>
            </div>
            <button type="button" class="modal-close" data-close-modal>×</button>
        </div>

        <div class="modal-body historico-pedido-body">
            <div class="historico-intro">
                <strong id="historicoPedidoTitulo">Alterações registradas neste pedido.</strong>
                <span>Informações registradas em agendamento_historico.</span>
            </div>
            <div id="historicoPedidoLista" class="historico-pedido-lista"></div>
            <div id="historicoPedidoVazio" class="historico-vazio" hidden>Nenhum histórico registrado para este pedido.</div>
        </div>

        <div class="modal-footer">
            <button type="button" class="btn-secondary" data-close-modal>Fechar</button>
        </div>
    </div>
</div>


<!-- MODAL EDITAR -->
<div class="modal" id="modalEditar" hidden>
    <div class="modal-box">
        <div class="modal-header">
            <div><span>Editar pedido</span><h2 id="editarNumero">Pedido</h2></div>
            <button type="button" class="modal-close" data-close-modal>×</button>
        </div>

        <form method="POST" class="modal-form">
            <input type="hidden" name="acao" value="editar">
            <input type="hidden" name="agendamento_id" id="editarId">

            <div class="campo campo-full">
                <label>Descrição*</label>
                <textarea name="descricao" id="editarDescricao" rows="4" required></textarea>
            </div>

            <div class="grid-2">
                <div class="campo"><label>CEP*</label><input type="text" name="cep" id="editarCep" required></div>
                <div class="campo"><label>Estado*</label><input type="text" name="estado" id="editarEstado" maxlength="2" required></div>
            </div>

            <div class="grid-2">
                <div class="campo"><label>Cidade*</label><input type="text" name="cidade" id="editarCidade" required></div>
                <div class="campo"><label>Bairro*</label><input type="text" name="bairro" id="editarBairro" required></div>
            </div>

            <div class="grid-2">
                <div class="campo"><label>Rua*</label><input type="text" name="rua" id="editarRua" required></div>
                <div class="campo"><label>Número*</label><input type="text" name="numero" id="editarNumeroEndereco" required></div>
            </div>

            <div class="campo campo-full"><label>Complemento</label><input type="text" name="complemento" id="editarComplemento"></div>

            <div class="info-box">A data e o horário da coleta não são definidos pela Secretaria. Essas informações são registradas durante a execução da coleta.</div>

            <div class="form-actions">
                <button type="button" class="btn-secondary" data-close-modal>Cancelar</button>
                <button type="submit" class="btn-primary">Salvar alterações</button>
            </div>
        </form>
    </div>
</div>

<!-- MODAL ENCAMINHAR -->
<div class="modal" id="modalEncaminhar" hidden>
    <div class="modal-box small">
        <div class="modal-header">
            <div><span>Validar pedido</span><h2 id="encaminharNumero">Encaminhar ao motorista</h2></div>
            <button type="button" class="modal-close" data-close-modal>×</button>
        </div>

        <form method="POST" class="modal-form">
            <input type="hidden" name="acao" value="encaminhar">
            <input type="hidden" name="agendamento_id" id="encaminharId">

            <div class="info-box">O sistema distribuirá esta coleta automaticamente entre os motoristas ativos, considerando a quantidade de coletas pendentes e o prazo restante de 5 dias úteis.</div>

            <?php if (empty($motoristas)): ?>
                <div class="warning-box">Não existem motoristas ativos cadastrados.</div>
            <?php else: ?>
                <div class="info-box">O motorista será definido automaticamente no momento da validação. A Secretaria não precisa selecionar o motorista.</div>
            <?php endif; ?>

            <div class="form-actions">
                <button type="button" class="btn-secondary" data-close-modal>Cancelar</button>
                <button type="submit" class="btn-primary" <?= empty($motoristas) ? "disabled" : "" ?>>Validar e agendar</button>
            </div>
        </form>
    </div>
</div>

<?php if ($mostrarNotificacaoEncaminhamento): ?>
    <div class="notificacao-encaminhamento-overlay" id="notificacaoEncaminhamento" role="dialog" aria-modal="true" aria-labelledby="notificacaoEncaminhamentoTitulo">
        <div class="notificacao-encaminhamento">
            <h2 class="titulo" id="notificacaoEncaminhamentoTitulo">Pedido encaminhado com sucesso!</h2>
            <p class="texto">O sistema confirmou o agendamento e encaminhou automaticamente este pedido para o motorista responsável.</p>
            <div class="destino">
                <strong>Motorista:</strong> <?= e($notificacaoMotorista) ?><br>
                <strong>Prazo da coleta:</strong> até <?= e($notificacaoPrazo) ?> (5 dias úteis)
            </div>
            <div class="acoes">
                <button type="button" class="btn-ok" id="btnOkNotificacaoEncaminhamento">OK</button>
            </div>
        </div>
    </div>
    <script>
        (function () {
            const overlay = document.getElementById('notificacaoEncaminhamento');
            const ok = document.getElementById('btnOkNotificacaoEncaminhamento');
            if (!overlay || !ok) return;
            ok.addEventListener('click', function () { overlay.remove(); });
            ok.focus();
        })();
    </script>
<?php endif; ?>

<script src="secretaria.js?v=20260929-historico-busca-cpf-id"></script>
</body>
</html>
