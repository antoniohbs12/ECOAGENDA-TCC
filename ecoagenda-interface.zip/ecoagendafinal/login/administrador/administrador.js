/* Correção independente para o botão Editar motorista.
   A delegação de eventos evita que o botão deixe de funcionar caso
   algum componente anterior do painel interrompa a inicialização. */
document.addEventListener("click", (event) => {
    const botao = event.target.closest(".btn-editar-motorista");
    if (!botao) return;

    const modal = document.getElementById("modalMotorista");
    const campos = {
        id: document.getElementById("motoristaId"),
        nome: document.getElementById("motoristaNome"),
        email: document.getElementById("motoristaEmail"),
        cnh: document.getElementById("motoristaCnh"),
        cpf: document.getElementById("motoristaCpf"),
        telefone: document.getElementById("motoristaTelefone"),
        ativo: document.getElementById("motoristaAtivo")
    };

    if (!modal || Object.values(campos).some(campo => !campo)) {
        console.error("Não foi possível abrir a edição: modal ou campo ausente.");
        return;
    }

    campos.id.value = botao.dataset.id || botao.dataset.email || "";
    campos.nome.value = botao.dataset.nome || "";
    campos.email.value = botao.dataset.email || "";
    campos.cnh.value = botao.dataset.cnh || "";
    campos.cpf.value = botao.dataset.cpf || "";
    campos.telefone.value = botao.dataset.telefone || "";
    campos.ativo.checked = botao.dataset.ativo === "1";

    const senha = modal.querySelector('input[name="senha"]');
    if (senha) senha.value = "";

    modal.hidden = false;
    document.body.style.overflow = "hidden";
});

document.addEventListener("DOMContentLoaded", () => {

    const menuLinks =
        document.querySelectorAll(".menu-link");

    const sections =
        document.querySelectorAll(".section");

    const titulo =
        document.getElementById("tituloPagina");

    const subtitulo =
        document.getElementById("subtituloPagina");


    const textos = {

        inicio: [
            "Dashboard - ADM",
            "Visão geral dos seus pedidos de coleta."
        ],

        pedidos: [
            "Pedidos",
            "Visualize pedidos, responsáveis, status e fotos."
        ],

        buscar: [
            "Buscar pedido",
            "Localize um pedido por CPF do morador ou pelo ID do pedido."
        ],

        motoristas: [
            "Motoristas",
            "Gerencie os motoristas cadastrados."
        ],

        secretarias: [
            "Secretarias",
            "Gerencie os dados de acesso das secretarias."
        ],

        moradores: [
            "Moradores",
            "Consulte os moradores cadastrados."
        ],
        relatorios: [
            "Relatórios",
            "Relatórios e indicadores do EcoAgenda."
        ],

    };


    /* =====================================================
       NAVEGAÇÃO
    ====================================================== */

    function abrirSecao(nome) {
        window.__ecoAgendaAbrirSecao = abrirSecao;

        sections.forEach((section) => {

            section.classList.toggle(
                "active",
                section.id ===
                `section-${nome}`
            );

        });


        menuLinks.forEach((link) => {

            link.classList.toggle(
                "active",
                link.dataset.section === nome
            );

        });


        if (textos[nome]) {

            titulo.textContent =
                textos[nome][0];

            subtitulo.textContent =
                textos[nome][1];

        }


        window.scrollTo({
            top: 0,
            behavior: "smooth"
        });

    }


    menuLinks.forEach((link) => {

        link.addEventListener(
            "click",
            () => {

                abrirSecao(
                    link.dataset.section
                );

            }
        );

    });


    document
        .querySelectorAll("[data-go-section]")
        .forEach((botao) => {

            botao.addEventListener(
                "click",
                () => {

                    abrirSecao(
                        botao.dataset.goSection
                    );

                }
            );

        });


    /* =====================================================
       BUSCA DE PEDIDO
    ====================================================== */

    let tipoBuscaPedido = "cpf";

    const tipoBuscaCpf =
        document.getElementById("tipoBuscaCpf");

    const tipoBuscaId =
        document.getElementById("tipoBuscaId");

    const campoBuscaPedido =
        document.getElementById("campoBuscaPedido");

    const buscarPedido =
        document.getElementById("buscarPedido");

    const resultadoBuscaPedido =
        document.getElementById("resultadoBuscaPedido");

    const resultadoPedidosBusca =
        document.getElementById("resultadoPedidosBusca");

    const fontePedidosBusca =
        document.getElementById("fontePedidosBusca");

    function limparCPF(valor) {
        return (valor || "").replace(/\D/g, "");
    }

    function formatarCPF(valor) {
        const numeros = limparCPF(valor).slice(0, 11);
        if (numeros.length <= 3) return numeros;
        if (numeros.length <= 6) return `${numeros.slice(0, 3)}.${numeros.slice(3)}`;
        if (numeros.length <= 9) {
            return `${numeros.slice(0, 3)}.${numeros.slice(3, 6)}.${numeros.slice(6)}`;
        }
        return `${numeros.slice(0, 3)}.${numeros.slice(3, 6)}.${numeros.slice(6, 9)}-${numeros.slice(9)}`;
    }

    function limparResultadoBuscaPedido() {
        if (resultadoBuscaPedido) {
            resultadoBuscaPedido.textContent = "";
        }
        if (resultadoPedidosBusca) {
            resultadoPedidosBusca.innerHTML = "";
        }
    }

    function atualizarTipoBusca(tipo) {
        tipoBuscaPedido = tipo;

        const ativarBotao = (botao, ativo) => {
            if (!botao) return;
            botao.classList.toggle("btn-primary", ativo);
            botao.classList.toggle("btn-secondary", !ativo);
            botao.classList.toggle("active", ativo);
        };

        ativarBotao(tipoBuscaCpf, tipo === "cpf");
        ativarBotao(tipoBuscaId, tipo === "id");

        if (campoBuscaPedido) {
            campoBuscaPedido.value = "";
            campoBuscaPedido.placeholder =
                tipo === "cpf" ? "Digite o CPF" : "Digite o ID do pedido";
            campoBuscaPedido.maxLength = tipo === "cpf" ? 14 : 20;
            campoBuscaPedido.inputMode = "numeric";
        }

        limparResultadoBuscaPedido();
    }

    function mostrarPedidosEncontrados(encontrados) {
        if (!resultadoPedidosBusca) return;

        resultadoPedidosBusca.innerHTML = "";

        encontrados.forEach(card => {
            const clone = card.cloneNode(true);
            const fonte = clone.querySelector(".dados-pedido");
            if (fonte) fonte.remove();
            resultadoPedidosBusca.appendChild(clone);
        });
    }

    tipoBuscaCpf?.addEventListener("click", () => {
        atualizarTipoBusca("cpf");
    });

    /* =====================================================
       RELATÓRIOS MENSAIS
    ====================================================== */
    const paramsRelatorio = new URLSearchParams(window.location.search);
    if (paramsRelatorio.get("secao") === "relatorios") {
        // Relatórios agora fazem parte da Dashboard.
        abrirSecao("inicio");
    }

/* =====================================================
   HISTÓRICO DO PEDIDO
====================================================== */

const historicoPedidosAdminEl =
document.getElementById("historicoPedidosAdmin");

let historicoPedidosAdmin = [];

if (historicoPedidosAdminEl) {
try {
    historicoPedidosAdmin =
        JSON.parse(historicoPedidosAdminEl.textContent || "[]");
} catch (erro) {
    console.error("Não foi possível carregar o histórico dos pedidos.", erro);
}
}

const escaparHtml = (valor) =>
String(valor ?? "")
    .replace(/&/g, "&amp;")
    .replace(/</g, "&lt;")
    .replace(/>/g, "&gt;")
    .replace(/\"/g, "&quot;")
    .replace(/'/g, "&#039;");

const formatarDataHoraHistorico = (valor) => {
if (!valor) return "—";
const data = new Date(String(valor).replace(" ", "T"));
if (Number.isNaN(data.getTime())) return String(valor);
return data.toLocaleString("pt-BR");
};

const formatarDataHistorico = (valor) => {
if (!valor) return "—";
const data = new Date(String(valor).replace(" ", "T"));
if (Number.isNaN(data.getTime())) return String(valor);
return data.toLocaleString("pt-BR");
};

const classeHistoricoStatus = (status) => {
const normalizado = String(status || "")
    .toLowerCase()
    .normalize("NFD")
    .replace(/[\u0300-\u036f]/g, "");
if (normalizado.includes("conclu")) return "concluido";
if (normalizado.includes("andamento")) return "andamento";
if (normalizado.includes("cancel") || normalizado.includes("suspens")) return "cancelado";
if (normalizado.includes("encamin" ) || normalizado.includes("agend")) return "confirmado";
return "pendente";
};

function abrirHistoricoPedido(id) {
const registros = historicoPedidosAdmin
    .filter(registro => String(registro.agendamento_id) === String(id));

const modal = modais.historicoPedido;
const lista = document.getElementById("historicoPedidoLista");
const vazio = document.getElementById("historicoPedidoVazio");
const numero = document.getElementById("historicoPedidoNumero");

if (!modal || !lista || !vazio) return;

if (numero) {
    numero.textContent = `Pedido #${id}`;
}

lista.innerHTML = "";

if (!registros.length) {
    vazio.hidden = false;
    abrirModal(modal);
    return;
}

vazio.hidden = true;

lista.innerHTML = registros.map((registro, indice) => {
    const statusClasse = classeHistoricoStatus(registro.status);
    const foto = registro.foto
        ? `../../agendamento/${String(registro.foto).replace(/^\/+/, "")}`
        : "";

    const fotoHtml = foto
        ? `
            <div class="historico-registro-foto">
                <span class="historico-label">Foto registrada</span>
                <a href="${escaparHtml(foto)}" target="_blank" rel="noopener" class="historico-foto-link">
                    <img src="${escaparHtml(foto)}" alt="Foto registrada no histórico" loading="lazy">
                    <span>Abrir foto</span>
                </a>
            </div>`
        : `
            <div class="historico-registro-foto sem-foto-historico">
                <span class="historico-label">Foto registrada</span>
                <strong>Não há foto neste registro.</strong>
            </div>`;

    return `
        <article class="historico-registro-card">
            <div class="historico-registro-topo">
                <div>
                    <span class="historico-registro-numero">REGISTRO ${indice + 1}</span>
                    <strong class="historico-registro-data">${escaparHtml(formatarDataHoraHistorico(registro.data_comando))}</strong>
                </div>
                <span class="historico-status ${escaparHtml(statusClasse)}">${escaparHtml(registro.status || "—")}</span>
            </div>

            <div class="historico-campos-grid">
                <div class="historico-campo destaque">
                    <span>Ação registrada</span>
                    <strong>${escaparHtml(registro.comando || "—")}</strong>
                </div>
                <div class="historico-campo">
                    <span>Morador</span>
                    <strong>${escaparHtml(registro.morador_email || "—")}</strong>
                </div>
                <div class="historico-campo">
                    <span>Quem realizou</span>
                    <strong>${escaparHtml(registro.perfil_usuario || "Administrador")}</strong>
                </div>
                <div class="historico-campo">
                    <span>Criado por</span>
                    <strong>${escaparHtml(registro.criado_por || "—")}</strong>
                </div>
                <div class="historico-campo">
                    <span>Data original do pedido</span>
                    <strong>${escaparHtml(formatarDataHistorico(registro.data_pedido))}</strong>
                </div>
            </div>

            <div class="historico-campo historico-descricao">
                <span>Descrição registrada</span>
                <p>${escaparHtml(registro.descricao || "—")}</p>
            </div>

            ${fotoHtml}
        </article>`;
}).join("");

abrirModal(modal);
}

document.addEventListener("click", event => {
const botaoHistorico = event.target.closest(".btn-historico-pedido");
if (!botaoHistorico) return;

const id = String(botaoHistorico.dataset.id || "");
if (!id) return;
abrirHistoricoPedido(id);
});



    tipoBuscaId?.addEventListener("click", () => {
        atualizarTipoBusca("id");
    });

    campoBuscaPedido?.addEventListener("input", event => {
        if (tipoBuscaPedido === "cpf") {
            campoBuscaPedido.value = formatarCPF(event.target.value);
        } else {
            campoBuscaPedido.value = event.target.value.replace(/\D/g, "");
        }
    });

    campoBuscaPedido?.addEventListener("keydown", event => {
        if (event.key === "Enter") {
            event.preventDefault();
            buscarPedido?.click();
        }
    });

    buscarPedido?.addEventListener("click", () => {
        const cards = fontePedidosBusca
            ? Array.from(fontePedidosBusca.querySelectorAll(".pedido-card"))
            : [];

        let encontrados = [];

        if (tipoBuscaPedido === "cpf") {
            const cpf = limparCPF(campoBuscaPedido?.value);

            if (cpf.length !== 11) {
                if (resultadoBuscaPedido) {
                    resultadoBuscaPedido.textContent =
                        "Digite um CPF completo para realizar a busca.";
                }
                if (resultadoPedidosBusca) {
                    resultadoPedidosBusca.innerHTML = "";
                }
                return;
            }

            encontrados = cards.filter(card => {
                return limparCPF(card.dataset.cpf || "") === cpf;
            });
        } else {
            const id = (campoBuscaPedido?.value || "").replace(/\D/g, "");

            if (!id) {
                if (resultadoBuscaPedido) {
                    resultadoBuscaPedido.textContent =
                        "Digite o ID do pedido para realizar a busca.";
                }
                if (resultadoPedidosBusca) {
                    resultadoPedidosBusca.innerHTML = "";
                }
                return;
            }

            encontrados = cards.filter(card => {
                return String(card.dataset.id || "") === id;
            });
        }

        if (encontrados.length === 0) {
            if (resultadoBuscaPedido) {
                resultadoBuscaPedido.innerHTML =
                    "<strong>Nenhum pedido encontrado.</strong>";
            }
            if (resultadoPedidosBusca) {
                resultadoPedidosBusca.innerHTML = "";
            }
            return;
        }

        if (resultadoBuscaPedido) {
            resultadoBuscaPedido.textContent = "";
        }

        mostrarPedidosEncontrados(encontrados);
    });

    resultadoPedidosBusca?.addEventListener("click", event => {
        const botao = event.target.closest(".btn-detalhes");
        if (!botao) return;

        const id = String(botao.dataset.id || "");
        if (!id) return;

        const original = document.querySelector(
            `.btn-detalhes[data-id="${CSS.escape(id)}"]`
        );

        if (original) {
            original.click();
        }
    });

    atualizarTipoBusca("cpf");


    /* =====================================================
       MODAIS
    ====================================================== */

    const modais = {

        detalhes:
            document.getElementById(
                "modalDetalhes"
            ),

        historicoPedido:
            document.getElementById(
                "modalHistoricoPedido"
            ),

        novoMotorista:
            document.getElementById(
                "modalNovoMotorista"
            ),

        motorista:
            document.getElementById(
                "modalMotorista"
            ),

        novaSecretaria:
            document.getElementById(
                "modalNovaSecretaria"
            ),

        secretaria:
            document.getElementById(
                "modalSecretaria"
            )

    };


    function abrirModal(modal) {

        if (!modal) {
            return;
        }

        modal.hidden = false;
        document.body.style.overflow = "hidden";

    }


    function fecharModais() {

        Object.values(modais)
            .forEach((modal) => {

                if (modal) {
                    modal.hidden = true;
                }

            });

        document.body.style.overflow = "";

    }


    document
        .querySelectorAll("[data-close-modal]")
        .forEach((botao) => {

            botao.addEventListener(
                "click",
                fecharModais
            );

        });


    Object.values(modais)
        .forEach((modal) => {

            if (!modal) {
                return;
            }

            modal.addEventListener(
                "click",
                (event) => {

                    if (
                        event.target === modal
                    ) {
                        fecharModais();
                    }

                }
            );

        });


    document.addEventListener(
        "keydown",
        (event) => {

            if (event.key === "Escape") {
                fecharModais();
            }

        }
    );


    /* =====================================================
       DETALHES DO PEDIDO
    ====================================================== */

    document
        .querySelectorAll(".btn-detalhes")
        .forEach((botao) => {

            botao.addEventListener(
                "click",
                () => {

                    const id =
                        botao.dataset.id;

                    const dados =
                        document.getElementById(
                            `dados-${id}`
                        );

                    if (!dados) {
                        return;
                    }


                    document.getElementById(
                        "modalPedidoId"
                    ).textContent =
                        `Pedido #${dados.dataset.id}`;


                    document.getElementById(
                        "modalTitulo"
                    ).textContent =
                        dados.dataset.descricao ||
                        "Detalhes do pedido";


                    document.getElementById(
                        "modalStatus"
                    ).textContent =
                        dados.dataset.status || "—";


                    document.getElementById(
                        "modalMorador"
                    ).textContent =
                        dados.dataset.morador ||
                        "Morador";


                    document.getElementById(
                        "modalCpf"
                    ).textContent =
                        dados.dataset.cpf || "—";


                    document.getElementById(
                        "modalTelefone"
                    ).textContent =
                        dados.dataset.telefone || "—";


                    document.getElementById(
                        "modalMotoristaDetalhes"
                    ).textContent =
                        dados.dataset.motorista ||
                        "Não atribuído";


                    document.getElementById(
                        "modalData"
                    ).textContent =
                        formatarData(
                            dados.dataset.data
                        );


                    document.getElementById(
                        "modalHora"
                    ).textContent =
                        dados.dataset.hora ||
                        "Ainda não definido";


                    document.getElementById(
                        "modalEndereco"
                    ).textContent =
                        dados.dataset.endereco || "—";


                    document.getElementById(
                        "modalDescricao"
                    ).textContent =
                        dados.dataset.descricao || "—";


                    abrirModal(
                        modais.detalhes
                    );

                }
            );

        });


    /* =====================================================
       CADASTRAR MOTORISTA
    ====================================================== */

    const btnNovoMotorista =
        document.getElementById("btnNovoMotorista");

    const formNovoMotorista =
        document.getElementById("formNovoMotorista");

    btnNovoMotorista?.addEventListener(
        "click",
        () => {
            formNovoMotorista?.reset();
            abrirModal(modais.novoMotorista);
        }
    );


    /* =====================================================
       EDITAR MOTORISTA
    ====================================================== */

    document
        .querySelectorAll(
            ".btn-editar-motorista"
        )
        .forEach((botao) => {

            botao.addEventListener(
                "click",
                () => {

                    document.getElementById(
                        "motoristaId"
                    ).value =
                        botao.dataset.id;

                    document.getElementById(
                        "motoristaNome"
                    ).value =
                        botao.dataset.nome || "";

                    document.getElementById(
                        "motoristaEmail"
                    ).value =
                        botao.dataset.email;

                    document.getElementById(
                        "motoristaCnh"
                    ).value =
                        botao.dataset.cnh || "";

                    document.getElementById(
                        "motoristaCpf"
                    ).value =
                        botao.dataset.cpf;

                    document.getElementById(
                        "motoristaTelefone"
                    ).value =
                        botao.dataset.telefone;

                    document.getElementById(
                        "motoristaAtivo"
                    ).checked =
                        botao.dataset.ativo === "1";

                    const senhaMotorista =
                        document.querySelector('#modalMotorista input[name="senha"]');

                    if (senhaMotorista) {
                        senhaMotorista.value = "";
                    }

                    abrirModal(
                        modais.motorista
                    );

                }
            );

        });


    /* =====================================================
       CADASTRAR SECRETARIA
    ====================================================== */

    const btnNovaSecretaria =
        document.getElementById("btnNovaSecretaria");

    const formNovaSecretaria =
        document.getElementById("formNovaSecretaria");

    btnNovaSecretaria?.addEventListener(
        "click",
        () => {
            formNovaSecretaria?.reset();
            abrirModal(modais.novaSecretaria);
        }
    );


    /* =====================================================
       EDITAR SECRETARIA
    ====================================================== */

    document
        .querySelectorAll(
            ".btn-editar-secretaria"
        )
        .forEach((botao) => {

            botao.addEventListener(
                "click",
                () => {

                    document.getElementById(
                        "secretariaEmailAtual"
                    ).value =
                        botao.dataset.email;

                    document.getElementById(
                        "secretariaEmail"
                    ).value =
                        botao.dataset.email;

                    document.getElementById(
                        "secretariaNome"
                    ).value =
                        botao.dataset.nome;

                    const secretariaAtivo =
                        document.getElementById("secretariaAtivo");

                    if (secretariaAtivo) {
                        secretariaAtivo.checked =
                            botao.dataset.ativo === "1";
                    }

                    abrirModal(
                        modais.secretaria
                    );

                }
            );

        });


    formNovaSecretaria?.addEventListener(
        "submit",
        (event) => {
            const nome = document.getElementById("novaSecretariaNome");
            const email = document.getElementById("novaSecretariaEmail");
            const senha = document.getElementById("novaSecretariaSenha");

            if (nome && nome.value.trim() === "") {
                event.preventDefault();
                alert("Informe o nome da Secretaria.");
                nome.focus();
                return;
            }

            if (email && !email.value.includes("@")) {
                event.preventDefault();
                alert("Informe um e-mail válido.");
                email.focus();
                return;
            }

            if (senha && senha.value.length < 6) {
                event.preventDefault();
                alert("A senha deve ter pelo menos 6 caracteres.");
                senha.focus();
            }
        }
    );


    /* =====================================================
       DATA
    ====================================================== */

    function formatarData(data) {

        if (!data) {
            return "Ainda não definida";
        }

        const partes =
            data.split("-");

        if (partes.length !== 3) {
            return data;
        }

        return (
            partes[2] +
            "/" +
            partes[1] +
            "/" +
            partes[0]
        );

    }


    /* =====================================================
       VALIDAÇÃO DE CPF / CNH DE MOTORISTA
    ====================================================== */

    document
        .querySelectorAll('#modalNovoMotorista input[name="cpf"], #modalMotorista input[name="cpf"], #modalNovoMotorista input[name="cnh"], #modalMotorista input[name="cnh"]')
        .forEach((input) => {
            input.addEventListener("input", () => {
                input.value = input.value.replace(/\D/g, "").slice(0, 11);
            });
        });


    [formNovoMotorista, document.querySelector('#modalMotorista form')]
        .filter(Boolean)
        .forEach((form) => {
            form.addEventListener("submit", (event) => {
                const cpf = form.querySelector('input[name="cpf"]');
                const cnh = form.querySelector('input[name="cnh"]');
                const senha = form.querySelector('input[name="senha"]');

                if (cpf && cpf.value.replace(/\D/g, "").length !== 11) {
                    event.preventDefault();
                    alert("O CPF deve conter 11 dígitos.");
                    cpf.focus();
                    return;
                }

                if (cnh && cnh.value.replace(/\D/g, "").length !== 11) {
                    event.preventDefault();
                    alert("A CNH deve conter 11 dígitos.");
                    cnh.focus();
                    return;
                }

                if (senha && senha.value !== "" && senha.value.length < 6) {
                    event.preventDefault();
                    alert("A senha deve ter pelo menos 6 caracteres.");
                    senha.focus();
                    return;
                }
            });
        });


    /* =====================================================
       ALERTA
    ====================================================== */

    const alerta =
        document.querySelector(".alerta");

    if (alerta) {

        setTimeout(() => {

            alerta.style.opacity = "0";
            alerta.style.transition =
                "opacity .4s ease";

            setTimeout(() => {
                alerta.remove();
            }, 400);

        }, 5000);

    }

});


/* =====================================================
   DASHBOARD — INTERAÇÕES DO MAPA DE PINHAIS
===================================================== */
document.addEventListener("DOMContentLoaded", () => {
    document.querySelectorAll(".adm-mapa-bolha").forEach((bolha) => {
        bolha.addEventListener("click", () => {
            document.querySelectorAll(".adm-mapa-bolha.selecionada").forEach((item) => {
                item.classList.remove("selecionada");
            });
            bolha.classList.add("selecionada");
        });
    });
});


/* =====================================================
   AJUSTE PONTUAL — TAREFAS DA DASHBOARD
   Clique em qualquer parte da caixinha para navegar.
   Não substitui nem altera os listeners existentes.
===================================================== */
document.addEventListener("click", (event) => {
    const tarefa = event.target.closest(".adm-tarefa");
    if (!tarefa) return;

    const acao = tarefa.querySelector("[data-go-section]");
    const secao = acao?.dataset?.goSection;
    if (!secao) return;

    // Evita duplicar a ação caso o clique tenha sido disparado por algum controle interno.
    if (typeof window.__ecoAgendaAbrirSecao === "function") {
        window.__ecoAgendaAbrirSecao(secao);
    } else {
        const menu = document.querySelector(`.menu-link[data-section="${secao}"]`);
        if (menu) menu.click();
    }
});
