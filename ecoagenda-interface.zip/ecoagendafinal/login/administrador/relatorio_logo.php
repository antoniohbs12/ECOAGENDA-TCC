<?php
// Incorpora a logo PNG original no PDF, com transparência, sem depender de GD.
function pdfLogoPng(string $path): ?array
{
    if(!is_file($path))return null;
    $png=file_get_contents($path);
    if(substr($png,0,8)!=="\x89PNG\r\n\x1a\n")return null;
    $offset=8;$compressed='';$header=null;
    while($offset+12<=strlen($png)){
        $length=unpack('N',substr($png,$offset,4))[1];$type=substr($png,$offset+4,4);$chunk=substr($png,$offset+8,$length);$offset+=$length+12;
        if($type==='IHDR')$header=unpack('Nwidth/Nheight/Cdepth/Ctype/Ccompression/Cfilter/Cinterlace',$chunk);
        if($type==='IDAT')$compressed.=$chunk;
        if($type==='IEND')break;
    }
    if(!$header||$header['depth']!==8||$header['type']!==6||$header['interlace']!==0)return null;
    $raw=zlib_decode($compressed);if($raw===false)return null;
    $stride=$header['width']*4;$prev=array_fill(0,$stride,0);$rgb='';$alpha='';$offset=0;
    for($y=0;$y<$header['height'];$y++){
        $filter=ord($raw[$offset++]);$row=[];
        for($x=0;$x<$stride;$x++){
            $a=$x>=4?$row[$x-4]:0;$b=$prev[$x];$c=$x>=4?$prev[$x-4]:0;
            if($filter===4){$p=$a+$b-$c;$pa=abs($p-$a);$pb=abs($p-$b);$pc=abs($p-$c);$predict=$pa<=$pb&&$pa<=$pc?$a:($pb<=$pc?$b:$c);}
            else $predict=match($filter){0=>0,1=>$a,2=>$b,3=>intdiv($a+$b,2),default=>0};
            $row[$x]=(ord($raw[$offset++])+$predict)&255;
            if($x%4===3)$alpha.=chr($row[$x]);else $rgb.=chr($row[$x]);
        }
        $prev=$row;
    }
    return ['width'=>$header['width'],'height'=>$header['height'],'rgb'=>gzcompress($rgb),'alpha'=>gzcompress($alpha)];
}
