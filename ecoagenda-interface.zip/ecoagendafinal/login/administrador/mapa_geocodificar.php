<?php
declare(strict_types=1);
require_once __DIR__ . '/mapa_dados.php';

function pontoDentroAnelMapa(float $lng, float $lat, array $ring): bool
{
    $inside = false;
    for ($i = 0, $j = count($ring) - 1; $i < count($ring); $j = $i++) {
        [$xi, $yi] = $ring[$i]; [$xj, $yj] = $ring[$j];
        if (($yi > $lat) !== ($yj > $lat) && $lng < ($xj - $xi) * ($lat - $yi) / ($yj - $yi) + $xi) $inside = !$inside;
    }
    return $inside;
}
function pontoEmPinhaisMapa(float $lat, float $lng): bool
{
    foreach (carregarGeoMapa()['features'] as $f) {
        $geom = $f['geometry'];
        $polygons = $geom['type'] === 'Polygon' ? [$geom['coordinates']] : $geom['coordinates'];
        foreach ($polygons as $rings) {
            if (!pontoDentroAnelMapa($lng, $lat, $rings[0])) continue;
            $hole = false;
            foreach (array_slice($rings, 1) as $ring) if (pontoDentroAnelMapa($lng, $lat, $ring)) $hole = true;
            if (!$hole) return true;
        }
    }
    return false;
}
function consultaNominatimMapa(array $params, $lock): array
{
    // O serviço público exige no máximo uma requisição por segundo por aplicação.
    rewind($lock);
    $last = (float)stream_get_contents($lock);
    $wait = 1.1 - (microtime(true) - $last);
    if ($wait > 0) usleep((int)ceil($wait * 1000000));
    $urlBase = getenv('ECOAGENDA_GEOCODER_URL') ?: 'https://nominatim.openstreetmap.org/search';
    if (parse_url($urlBase, PHP_URL_SCHEME) !== 'https') throw new RuntimeException('Geocodificador precisa de HTTPS.');
    $url = $urlBase . '?' . http_build_query($params);
    $ch = curl_init($url);
    curl_setopt_array($ch, [CURLOPT_RETURNTRANSFER => true, CURLOPT_CONNECTTIMEOUT => 6, CURLOPT_TIMEOUT => 15,
        CURLOPT_USERAGENT => 'EcoAgenda-TCC/2.0 (https://github.com/antoniohbs12/ECOAGENDA-TCC)',
        CURLOPT_HTTPHEADER => ['Accept: application/json', 'Accept-Language: pt-BR'],
        CURLOPT_SSL_VERIFYPEER => true, CURLOPT_SSL_VERIFYHOST => 2, CURLOPT_FOLLOWLOCATION => false]);
    $ca = getenv('CODEX_PROXY_CERT');
    if ($ca && is_file($ca)) curl_setopt($ch, CURLOPT_CAINFO, $ca);
    $raw = curl_exec($ch); $status = curl_getinfo($ch, CURLINFO_HTTP_CODE); curl_close($ch);
    rewind($lock); ftruncate($lock, 0); fwrite($lock, (string)microtime(true)); fflush($lock);
    if ($raw === false || $status !== 200) throw new RuntimeException('Serviço de localização indisponível.');
    $result = json_decode($raw, true, 512, JSON_THROW_ON_ERROR);
    if (!is_array($result) || !array_is_list($result)) throw new RuntimeException('Resposta inválida.');
    return $result;
}
function salvarCacheLocalizacoesMapa(string $dir, array $cache): void
{
    $tmp = tempnam($dir, 'cache-');
    if ($tmp === false || file_put_contents($tmp, json_encode($cache, JSON_THROW_ON_ERROR)) === false || !rename($tmp, $dir . '/localizacoes.json')) throw new RuntimeException('Cache não pôde ser salvo.');
}
function geocodificarEnderecoMapa(array $endereco): array
{
    $key = chaveEnderecoMapa($endereco);
    $dir = pastaLocalizacoesMapa();
    if (!is_dir($dir) && !mkdir($dir, 0700, true) && !is_dir($dir)) throw new RuntimeException('Cache indisponível.');
    $lock = fopen($dir . '/geocoder.lock', 'c+');
    if (!$lock || !flock($lock, LOCK_EX)) throw new RuntimeException('Cache indisponível.');
    try {
        $cache = carregarLocalizacoesMapa();
        if (isset($cache[$key]['lat'], $cache[$key]['lng'])) return $cache[$key];
        if (($cache[$key]['retryAt'] ?? 0) > time()) return $cache[$key];
        if (normalizarMapa((string)($endereco['cidade'] ?? '')) !== 'pinhais') {
            $found = ['precisao' => 'fora_area', 'erro' => 'O endereço não pertence a Pinhais.'];
        } else {
            $common = ['format' => 'jsonv2', 'addressdetails' => 1, 'limit' => 3, 'countrycodes' => 'br',
                'city' => 'Pinhais', 'state' => 'Paraná', 'country' => 'Brasil',
                'viewbox' => '-49.205,-25.376,-49.102,-25.474', 'bounded' => 1];
            $found = ['precisao' => 'nao_encontrado', 'erro' => 'Endereço não localizado. Não foi criado um ponto fictício.', 'retryAt' => time() + 86400];
            foreach ([true, false] as $withNumber) {
                $params = $common + ['street' => ($withNumber ? $endereco['numero'] . ' ' : '') . $endereco['rua']];
                $results = consultaNominatimMapa($params, $lock);
                foreach ($results as $r) {
                    if (!isset($r['lat'], $r['lon']) || !is_numeric($r['lat']) || !is_numeric($r['lon'])) continue;
                    $lat = (float)$r['lat']; $lng = (float)$r['lon'];
                    if (!pontoEmPinhaisMapa($lat, $lng)) continue;
                    $address = $r['address'] ?? [];
                    $road = $address['road'] ?? $address['pedestrian'] ?? $address['residential'] ?? '';
                    if (normalizarMapa((string)$road) !== normalizarMapa((string)$endereco['rua'])) continue;
                    $house = (string)($address['house_number'] ?? '');
                    $exact = $house !== '' && normalizarMapa($house) === normalizarMapa((string)$endereco['numero']);
                    if ($house !== '' && !$exact) continue;
                    $found = ['lat' => $lat, 'lng' => $lng, 'precisao' => $exact ? 'endereco' : 'rua_aproximada', 'fonte' => 'Nominatim / OpenStreetMap', 'atualizadoEm' => date(DATE_ATOM)];
                    break 2;
                }
            }
        }
        $cache[$key] = $found;
        salvarCacheLocalizacoesMapa($dir, $cache);
        return $found;
    } catch (Throwable $error) {
        if (isset($cache)) {
            $cache[$key] = ['precisao' => 'temporariamente_indisponivel', 'retryAt' => time() + 120];
            salvarCacheLocalizacoesMapa($dir, $cache);
        }
        throw $error;
    } finally { flock($lock, LOCK_UN); fclose($lock); }
}
