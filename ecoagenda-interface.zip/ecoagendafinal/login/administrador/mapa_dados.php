<?php
declare(strict_types=1);

const BAIRROS_MAPA = [
    "Alphaville Graciosa",
    "Alto Tarumã",
    "Atuba",
    "Centro",
    "Emiliano Perneta",
    "Estância Pinhais",
    "Jardim Amélia",
    "Jardim Cláudia",
    "Jardim Karla",
    "Maria Antonieta",
    "Parque das Águas",
    "Parque das Nascentes",
    "Pineville",
    "Vargem Grande",
    "Weissópolis"
];

function normalizarMapa(string $valor): string
{
    $valor = trim(mb_strtolower($valor, "UTF-8"));

    // Compatibilidade com registros antigos do EcoAgenda.
    $valor = str_replace("jardim das nascentes", "parque das nascentes", $valor);

    $ascii = @iconv("UTF-8", "ASCII//TRANSLIT//IGNORE", $valor);
    if ($ascii !== false) {
        $valor = strtolower($ascii);
    }

    $valor = preg_replace('/[^a-z0-9]+/', ' ', $valor) ?? $valor;
    return trim(preg_replace('/\s+/', ' ', $valor) ?? $valor);
}

function buscarDadosMapa(mysqli $conn, int $mes, int $ano, array $bairros): array
{
    $inicio = sprintf("%04d-%02d-01 00:00:00", $ano, $mes);
    $fim = date("Y-m-d H:i:s", strtotime($inicio . " +1 month"));

    $dados = array_fill_keys($bairros, 0);

    // Um pedido conta uma vez. Vínculos conflitantes ficam fora do mapa,
    // em vez de atribuir a mesma coleta a dois bairros.
    $sql = "SELECT a.id, e.bairro
        FROM agendamento a
        LEFT JOIN agendamento_morador_endereco ame
            ON ame.agendamento_id = a.id AND ame.morador_email = a.morador_email
        LEFT JOIN endereco e ON e.id = ame.endereco_id AND e.email = ame.morador_email
        WHERE a.data_pedido >= ? AND a.data_pedido < ?";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("ss", $inicio, $fim);
    $stmt->execute();
    $result = $stmt->get_result();
    $canonicos = [];
    foreach ($bairros as $bairro) $canonicos[normalizarMapa($bairro)] = $bairro;
    $pedidos = [];
    while ($row = $result->fetch_assoc()) {
        $id = (int)$row["id"];
        $chave = normalizarMapa((string)($row["bairro"] ?? ""));
        $pedidos[$id][$canonicos[$chave] ?? "__sem_bairro"] = true;
    }
    $stmt->close();
    $semBairro = 0;
    foreach ($pedidos as $locais) {
        if (count($locais) === 1 && !isset($locais["__sem_bairro"])) {
            $dados[array_key_first($locais)]++;
        } else {
            $semBairro++;
        }
    }
    $total = count($pedidos);
    $max = 0;

    foreach ($dados as $valor) {
        $max = max($max, (int)$valor);
    }

    $ranking = [];
    foreach ($dados as $bairro => $valor) {
        $ranking[] = [
            "bairro" => $bairro,
            "total" => (int)$valor
        ];
    }

    usort($ranking, static function (array $a, array $b): int {
        if ($a["total"] === $b["total"]) {
            return strcasecmp($a["bairro"], $b["bairro"]);
        }
        return $b["total"] <=> $a["total"];
    });

    $mesesMapa = [
        1 => "Janeiro", 2 => "Fevereiro", 3 => "Março", 4 => "Abril",
        5 => "Maio", 6 => "Junho", 7 => "Julho", 8 => "Agosto",
        9 => "Setembro", 10 => "Outubro", 11 => "Novembro", 12 => "Dezembro"
    ];

    return [
        "mes" => $mes,
        "ano" => $ano,
        "mesNome" => $mesesMapa[$mes] ?? "",
        "dados" => $dados,
        "ranking" => $ranking,
        "total" => $total,
        "max" => $max,
        "semBairro" => $semBairro,
        "totalMapeado" => array_sum($dados),
        "atualizadoEm" => date("H:i:s")
    ];
}

const CORES_MAPA = ['#edf3ef', '#c4dfcf', '#89c5a0', '#479e70', '#167347'];
function carregarGeoMapa(): array
{
    $raw = file_get_contents(__DIR__ . '/pinhais_bairros_wgs84.geojson');
    $geo = json_decode($raw, true, 512, JSON_THROW_ON_ERROR);
    if (($geo['type'] ?? '') !== 'FeatureCollection' || count($geo['features'] ?? []) !== 15) {
        throw new RuntimeException('Limites dos bairros indisponíveis.');
    }
    return $geo;
}
function corDemandaMapa(int $valor, int $max): string
{
    return CORES_MAPA[$valor <= 0 ? 0 : min(4, max(1, (int)ceil($valor / max(1, $max) * 4)))];
}
function pastaLocalizacoesMapa(): string
{
    // Dados administrativos não pertencem ao pacote distribuído ou ao Git.
    return getenv('ECOAGENDA_MAP_DATA_DIR') ?: sys_get_temp_dir() . '/ecoagenda-mapa-' . substr(hash('sha256', dirname(__DIR__, 2)), 0, 16);
}
function chaveEnderecoMapa(array $endereco): string
{
    return hash('sha256', implode('|', array_map('normalizarMapa', [
        (string)($endereco['rua'] ?? ''), (string)($endereco['numero'] ?? ''),
        (string)($endereco['bairro'] ?? ''), (string)($endereco['cep'] ?? ''),
        (string)($endereco['cidade'] ?? ''), (string)($endereco['estado'] ?? '')
    ])));
}
function carregarLocalizacoesMapa(): array
{
    $path = pastaLocalizacoesMapa() . '/localizacoes.json';
    if (!is_file($path)) return [];
    $dados = json_decode((string)file_get_contents($path), true);
    return is_array($dados) ? $dados : [];
}
function buscarColetasMapa(mysqli $conn, int $mes, int $ano): array
{
    $inicio = sprintf('%04d-%02d-01 00:00:00', $ano, $mes);
    $fim = date('Y-m-d H:i:s', strtotime($inicio . ' +1 month'));
    $stmt = $conn->prepare("SELECT c.motorista_email, c.agendamento_id, c.data_inicio, c.data_finalizacao,
        e.id AS endereco_id, e.rua, e.numero, e.bairro, e.cep, e.cidade, e.estado
        FROM coleta c INNER JOIN agendamento a ON a.id = c.agendamento_id
        LEFT JOIN agendamento_morador_endereco ame ON ame.agendamento_id = a.id AND ame.morador_email = a.morador_email
        LEFT JOIN endereco e ON e.id = ame.endereco_id AND e.email = ame.morador_email
        WHERE c.data_finalizacao >= ? AND c.data_finalizacao < ?
        ORDER BY c.data_finalizacao DESC");
    $stmt->bind_param('ss', $inicio, $fim);
    $stmt->execute();
    $res = $stmt->get_result();
    $eventos = [];
    while ($row = $res->fetch_assoc()) {
        $id = $row['agendamento_id'] . '|' . $row['data_inicio'] . '|' . $row['motorista_email'];
        $eventos[$id][(string)($row['endereco_id'] ?? '__sem_endereco')] = $row;
    }
    $stmt->close();
    $locais = [];
    $semEndereco = 0;
    $cache = carregarLocalizacoesMapa();
    foreach ($eventos as $enderecos) {
        if (count($enderecos) !== 1) { $semEndereco++; continue; }
        $e = reset($enderecos);
        if (!$e['endereco_id'] || !$e['rua'] || !$e['numero']) { $semEndereco++; continue; }
        $chave = chaveEnderecoMapa($e);
        if (!isset($locais[$chave])) {
            $pos = $cache[$chave] ?? [];
            $coords = isset($pos['lat'], $pos['lng']) && is_numeric($pos['lat']) && is_numeric($pos['lng']);
            $locais[$chave] = [
                'chave' => $chave, 'enderecoId' => (int)$e['endereco_id'],
                'endereco' => $e['rua'] . ', ' . $e['numero'], 'bairro' => $e['bairro'] ?? '',
                'cidade' => $e['cidade'] ?? '', 'cep' => $e['cep'] ?? '',
                'lat' => $coords ? (float)$pos['lat'] : null, 'lng' => $coords ? (float)$pos['lng'] : null,
                'precisao' => $pos['precisao'] ?? 'pendente', 'total' => 0, 'pedidos' => []
            ];
        }
        $locais[$chave]['total']++;
        $locais[$chave]['pedidos'][] = ['id' => (int)$e['agendamento_id'], 'data' => $e['data_finalizacao']];
    }
    $semPosicao = 0;
    foreach ($locais as $local) if ($local['lat'] === null || $local['lng'] === null) $semPosicao += $local['total'];
    return ['total' => count($eventos), 'locais' => array_values($locais), 'semEndereco' => $semEndereco,
        'semPosicao' => $semPosicao, 'atualizadoEm' => date('H:i:s'), 'mes' => $mes, 'ano' => $ano];
}
