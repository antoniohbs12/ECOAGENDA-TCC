<?php

session_start();

require_once "../config.php";


/*
|--------------------------------------------------------------------------
| VERIFICAR LOGIN
|--------------------------------------------------------------------------
*/

if (
    !isset($_SESSION["email"]) ||
    !isset($_SESSION["perfil"]) ||
    $_SESSION["perfil"] !== "morador"
) {
    header("Location: login.html");
    exit();
}


$emailMorador = $_SESSION["email"];
$nome = $_SESSION["nome"] ?? "Morador";


/*
|--------------------------------------------------------------------------
| BUSCAR PEDIDOS DO MORADOR
|--------------------------------------------------------------------------
|
| O novo modelo utiliza:
|
| agendamento.morador_email
| agendamento.status
|
| O endereço é obtido por:
|
| agendamento_morador_endereco
| → morador_endereco
| → endereco
|
| Os dados da coleta são obtidos pela tabela:
|
| coleta
|
*/


$sql = "

    SELECT

        a.id,
        a.descricao,
        a.data_pedido,
        a.foto AS foto_morador,
        a.status,

        e.id AS endereco_id,
        e.cep,
        e.estado,
        e.cidade,
        e.rua,
        e.bairro,
        e.numero,
        e.complemento,

        c.motorista_email,
        c.data_inicio,
        c.data_chegada,
        c.data_finalizacao,
        c.foto AS foto_motorista,

        u.nome AS motorista_nome

    FROM agendamento a

    LEFT JOIN agendamento_morador_endereco ame
        ON ame.agendamento_id = a.id
       AND ame.morador_email = a.morador_email

    LEFT JOIN morador_endereco me
        ON me.endereco_id = ame.endereco_id
       AND me.morador_email = ame.morador_email

    LEFT JOIN endereco e
        ON e.id = me.endereco_id
       AND e.email = me.morador_email


    /*
    | Busca somente a última coleta registrada para o pedido.
    */
    LEFT JOIN (

        SELECT
            c1.*

        FROM coleta c1

        INNER JOIN (

            SELECT
                agendamento_id,
                MAX(data_inicio) AS ultima_data_inicio

            FROM coleta

            GROUP BY agendamento_id

        ) c2

            ON c2.agendamento_id = c1.agendamento_id
           AND c2.ultima_data_inicio = c1.data_inicio

    ) c

        ON c.agendamento_id = a.id


    LEFT JOIN motorista m
        ON m.email = c.motorista_email

    LEFT JOIN usuario u
        ON u.email = m.email


    WHERE a.morador_email = ?

    ORDER BY a.id DESC
";


$stmt = $conn->prepare($sql);


if (!$stmt) {

    die(
        "Erro ao buscar pedidos: " .
        $conn->error
    );
}


$stmt->bind_param(
    "s",
    $emailMorador
);


$stmt->execute();


$resultado = $stmt->get_result();


/*
|--------------------------------------------------------------------------
| FUNÇÕES
|--------------------------------------------------------------------------
*/

function classeStatus(string $status): string
{
    return match (
        mb_strtolower(
            trim($status),
            "UTF-8"
        )
    ) {

        "confirmado" =>
            "confirmado",

        "em andamento" =>
            "andamento",

        "concluído",
        "concluido" =>
            "concluido",

        "cancelado" =>
            "cancelado",

        default =>
            "pendente"
    };
}


function formatarData(?string $data): string
{
    if (
        empty($data)
    ) {
        return "—";
    }

    $timestamp =
        strtotime($data);

    if (!$timestamp) {
        return "—";
    }

    return date(
        "d/m/Y",
        $timestamp
    );
}


function formatarDataHora(?string $data): string
{
    if (
        empty($data)
    ) {
        return "—";
    }

    $timestamp =
        strtotime($data);

    if (!$timestamp) {
        return "—";
    }

    return date(
        "d/m/Y H:i",
        $timestamp
    );
}


function e($valor): string
{
    return htmlspecialchars(
        (string)$valor,
        ENT_QUOTES,
        "UTF-8"
    );
}


/*
|--------------------------------------------------------------------------
| INICIAIS
|--------------------------------------------------------------------------
*/

$partesNome =
    preg_split(
        '/\s+/',
        trim($nome)
    );

$iniciais = "";


if (!empty($partesNome[0])) {

    $iniciais .=
        strtoupper(
            substr(
                $partesNome[0],
                0,
                1
            )
        );
}


if (count($partesNome) > 1) {

    $ultimaParte =
        $partesNome[
            count($partesNome) - 1
        ];

    $iniciais .=
        strtoupper(
            substr(
                $ultimaParte,
                0,
                1
            )
        );
}


$iniciais =
    substr(
        $iniciais ?: "M",
        0,
        2
    );

?>

<!DOCTYPE html>

<html lang="pt-BR">

<head>

    <meta charset="UTF-8">

    <meta
        name="viewport"
        content="width=device-width, initial-scale=1.0">

    <title>
        EcoAgenda - Meus Pedidos
    </title>


    <link
        href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.3/dist/css/bootstrap.min.css"
        rel="stylesheet">


    <link
        href="https://fonts.googleapis.com/css2?family=Montserrat:wght@400;500;600;700&display=swap"
        rel="stylesheet">


    <link
        rel="stylesheet"
        href="meus_pedidos.css">

<link rel="stylesheet" href="interface/base.css?v=20261009-4">
<link rel="stylesheet" href="interface/interface.css?v=20261009-4">
<script src="interface/interface.js?v=20261009-4" defer></script>
</head>


<body class="eco-interface ea-morador">


<div class="container py-5">


    <!-- =====================================================
         CABEÇALHO
    ====================================================== -->

    <div class="cabecalho">

        <h1>
            📋 Meus Pedidos
        </h1>


        <p>
            Acompanhe o andamento das suas solicitações de coleta.
        </p>


        <!-- AVISO IMPORTANTE -->

        <div class="aviso-prazo">

            ⏱️
            <strong>
                Prazo para coleta
            </strong>

            <br>

            A Prefeitura tem
            <strong>
                até 5 dias úteis
            </strong>
            para realizar a coleta.

        </div>

    </div>



    <?php if ($resultado->num_rows === 0): ?>


        <!-- =================================================
             SEM PEDIDOS
        ================================================== -->

        <div class="sem-pedidos">

            <div class="icone">
                📦
            </div>


            <h3>
                Você ainda não possui pedidos.
            </h3>


            <p>
                Quando você solicitar uma coleta,
                ela aparecerá aqui.
            </p>


            <a
                href="dashboard_morador/dashboard_morador.php"
                class="btn btn-success">

                Criar novo pedido

            </a>

        </div>


    <?php else: ?>


        <!-- =================================================
             LISTA DE PEDIDOS
        ================================================== -->


        <?php while (
            $pedido =
            $resultado->fetch_assoc()
        ): ?>


            <?php

            $status =
                strtolower(
                    trim(
                        $pedido["status"]
                    )
                );


            $classeStatus =
                classeStatus(
                    $pedido["status"]
                );

            ?>


            <div class="pedido">


                <!-- =================================================
                     CABEÇALHO DO PEDIDO
                ================================================== -->

                <div class="pedido-topo">


                    <h3>

                        Pedido #
                        <?= e(
                            $pedido["id"]
                        ) ?>

                    </h3>


                    <span
                        class="status <?= e($classeStatus) ?>">

                        <?= e(
                            $pedido["status"]
                        ) ?>

                    </span>


                </div>



                <!-- =================================================
                     PROGRESSO
                ================================================== -->

                <?php if (
                    $classeStatus !== "cancelado"
                ): ?>


                    <div class="progresso">


                        <!-- ETAPA 1 -->

                        <div class="etapa ativa">

                            <div class="bolinha">
                                ✓
                            </div>

                            <span>
                                Pedido enviado
                            </span>

                        </div>


                        <div class="linha"></div>


                        <!-- ETAPA 2 -->

                        <div
                            class="
                                etapa
                                <?= in_array(
                                    $classeStatus,
                                    [
                                        "confirmado",
                                        "andamento",
                                        "concluido"
                                    ],
                                    true
                                )
                                ? "ativa"
                                : "" ?>
                            ">

                            <div class="bolinha">

                                2

                            </div>


                            <span>
                                Confirmado
                            </span>

                        </div>


                        <div class="linha"></div>


                        <!-- ETAPA 3 -->

                        <div
                            class="
                                etapa
                                <?= in_array(
                                    $classeStatus,
                                    [
                                        "andamento",
                                        "concluido"
                                    ],
                                    true
                                )
                                ? "ativa"
                                : "" ?>
                            ">

                            <div class="bolinha">

                                3

                            </div>


                            <span>
                                Em andamento
                            </span>

                        </div>


                        <div class="linha"></div>


                        <!-- ETAPA 4 -->

                        <div
                            class="
                                etapa
                                <?= $classeStatus === "concluido"
                                ? "ativa"
                                : "" ?>
                            ">

                            <div class="bolinha">

                                4

                            </div>


                            <span>
                                Concluído
                            </span>

                        </div>


                    </div>


                <?php endif; ?>



                <!-- =================================================
                     INFORMAÇÕES
                ================================================== -->

                <div class="informacoes">


                    <!-- DATA DO PEDIDO -->

                    <div class="info">

                        <strong>
                            📅 Pedido realizado
                        </strong>

                        <span>

                            <?= e(
                                formatarData(
                                    $pedido["data_pedido"]
                                )
                            ) ?>

                        </span>

                    </div>



                    <!-- INÍCIO DA COLETA -->

                    <div class="info">

                        <strong>
                            🚚 Início da coleta
                        </strong>

                        <span>

                            <?= e(
                                formatarDataHora(
                                    $pedido["data_inicio"]
                                )
                            ) ?>

                        </span>

                    </div>



                    <!-- CHEGADA -->

                    <div class="info">

                        <strong>
                            📍 Chegada
                        </strong>

                        <span>

                            <?= e(
                                formatarDataHora(
                                    $pedido["data_chegada"]
                                )
                            ) ?>

                        </span>

                    </div>



                    <!-- FINALIZAÇÃO -->

                    <div class="info">

                        <strong>
                            ✅ Coleta finalizada
                        </strong>

                        <span>

                            <?= e(
                                formatarDataHora(
                                    $pedido["data_finalizacao"]
                                )
                            ) ?>

                        </span>

                    </div>



                    <!-- MOTORISTA -->

                    <?php if (
                        !empty(
                            $pedido["motorista_nome"]
                        )
                    ): ?>

                        <div class="info">

                            <strong>
                                👷 Motorista
                            </strong>

                            <span>

                                <?= e(
                                    $pedido["motorista_nome"]
                                ) ?>

                            </span>

                        </div>

                    <?php endif; ?>



                    <!-- ENDEREÇO -->

                    <div class="info endereco">

                        <strong>
                            📍 Endereço
                        </strong>


                        <span>

                            <?= e(
                                $pedido["rua"]
                            ) ?>,

                            <?= e(
                                $pedido["numero"]
                            ) ?>


                            <?php if (
                                !empty(
                                    $pedido["complemento"]
                                )
                            ): ?>

                                -
                                <?= e(
                                    $pedido["complemento"]
                                ) ?>

                            <?php endif; ?>

                            <br>


                            <?= e(
                                $pedido["bairro"]
                            ) ?>


                            <br>


                            <?= e(
                                $pedido["cidade"]
                            ) ?>

                            -

                            <?= e(
                                $pedido["estado"]
                            ) ?>


                            <br>

                            CEP:

                            <?= e(
                                $pedido["cep"]
                            ) ?>

                        </span>

                    </div>



                    <!-- DESCRIÇÃO -->

                    <div class="info descricao">

                        <strong>
                            📝 Descrição
                        </strong>


                        <span>

                            <?= nl2br(
                                e(
                                    $pedido["descricao"]
                                )
                            ) ?>

                        </span>

                    </div>


                </div>



                <!-- =================================================
                     FOTO DO MORADOR
                ================================================== -->

                <?php if (
                    !empty(
                        $pedido["foto_morador"]
                    )
                ): ?>


                    <div class="foto">

                        <strong>
                            📷 Foto enviada no pedido
                        </strong>


                        <img
                            src="../agendamento/<?= e(
                                $pedido["foto_morador"]
                            ) ?>"
                            alt="Foto do resíduo">

                    </div>


                <?php endif; ?>



                <!-- =================================================
                     FOTO DO MOTORISTA
                ================================================== -->

                <?php if (
                    !empty(
                        $pedido["foto_motorista"]
                    )
                ): ?>


                    <div class="foto">

                        <strong>
                            📷 Foto realizada na coleta
                        </strong>


                        <img
                            src="../agendamento/<?= e(
                                $pedido["foto_motorista"]
                            ) ?>"
                            alt="Foto da coleta">

                    </div>


                <?php endif; ?>



                <!-- =================================================
                     CANCELADO
                ================================================== -->

                <?php if (
                    $classeStatus === "cancelado"
                ): ?>


                    <div class="alert alert-danger mt-3">

                        ❌
                        Este pedido foi cancelado.

                    </div>


                <?php endif; ?>


            </div>


        <?php endwhile; ?>


    <?php endif; ?>



    <!-- =====================================================
         BOTÕES
    ====================================================== -->

    <div class="text-center mt-4">


        <a
            href="dashboard_morador/dashboard_morador.php"
            class="btn btn-outline-success">

            ← Voltar ao Dashboard

        </a>


        <a
            href="../index.html"
            class="btn btn-outline-secondary">

            Início

        </a>


    </div>


</div>


</body>

</html>