
<?php

session_start();

require_once __DIR__ . '/../config.php';
require_once __DIR__ . '/enviar_email.php';


/* =========================================================
   VERIFICAR MÉTODO
========================================================= */

if ($_SERVER["REQUEST_METHOD"] !== "POST") {

    header(
        "Location: esqueci_senha.html"
    );

    exit();
}


/* =========================================================
   RECEBER E-MAIL
========================================================= */

$email =
    trim(
        $_POST["email"] ?? ""
    );


/* =========================================================
   VALIDAR E-MAIL
========================================================= */

if ($email === "") {

    echo "
    <script>

        alert('Digite seu e-mail.');

        history.back();

    </script>
    ";

    exit();
}


if (
    !filter_var(
        $email,
        FILTER_VALIDATE_EMAIL
    )
) {

    echo "
    <script>

        alert('Digite um e-mail válido.');

        history.back();

    </script>
    ";

    exit();
}


/* =========================================================
   PROCURAR USUÁRIO
========================================================= */

$sql = "
    SELECT
        email,
        nome
    FROM usuario
    WHERE email = ?
    LIMIT 1
";


$stmt =
    $conn->prepare($sql);


if (!$stmt) {

    die(
        "Erro ao preparar consulta: " .
        $conn->error
    );

}


$stmt->bind_param(
    "s",
    $email
);


if (!$stmt->execute()) {

    $stmt->close();

    die(
        "Erro ao consultar usuário."
    );

}


$resultado =
    $stmt->get_result();


/* =========================================================
   E-MAIL NÃO ENCONTRADO
========================================================= */

if (
    $resultado->num_rows === 0
) {

    $stmt->close();

    echo "
    <script>

        alert(
            'Não encontramos um usuário cadastrado com esse e-mail.'
        );

        history.back();

    </script>
    ";

    exit();
}


$usuario =
    $resultado->fetch_assoc();

$stmt->close();


/* =========================================================
   GERAR CÓDIGO
========================================================= */

$codigo =
    (string) random_int(
        100000,
        999999
    );


/* =========================================================
   SALVAR RECUPERAÇÃO NA SESSÃO
========================================================= */

$_SESSION["recuperacao_email"] =
    $usuario["email"];

$_SESSION["recuperacao_codigo"] =
    $codigo;

$_SESSION["recuperacao_expira"] =
    time() + 900;


/* =========================================================
   PREPARAR NOME
========================================================= */

$nomeUsuario =
    trim(
        (string) (
            $usuario["nome"] ?? "Morador"
        )
    );


if ($nomeUsuario === "") {

    $nomeUsuario = "Morador";

}


$nomeSeguro =
    htmlspecialchars(
        $nomeUsuario,
        ENT_QUOTES,
        "UTF-8"
    );


$codigoSeguro =
    htmlspecialchars(
        $codigo,
        ENT_QUOTES,
        "UTF-8"
    );


/* =========================================================
   MONTAR E-MAIL
========================================================= */

$htmlEmail = "

<!DOCTYPE html>

<html lang='pt-BR'>

<head>

    <meta charset='UTF-8'>

</head>


<body
    style='
        margin:0;
        background:#f5f7f6;
        font-family:Arial,sans-serif;
        color:#26342b;
    '
>


<div
    style='
        max-width:560px;
        margin:40px auto;
        padding:32px;
        background:#ffffff;
        border-radius:16px;
        box-shadow:0 8px 30px rgba(0,0,0,.08);
    '
>


    <h2
        style='
            margin:0 0 16px;
            color:#07612b;
        '
    >

        Recuperação de senha

    </h2>


    <p
        style='
            margin:0 0 12px;
            line-height:1.6;
        '
    >

        Olá,
        <strong>
            {$nomeSeguro}
        </strong>.

    </p>


    <p
        style='
            margin:0 0 20px;
            line-height:1.6;
            color:#555;
        '
    >

        Recebemos uma solicitação para
        redefinir a senha da sua conta
        no EcoAgenda.

    </p>


    <div
        style='
            padding:22px;
            text-align:center;
            background:#edf7ef;
            border-radius:12px;
        '
    >

        <div
            style='
                font-size:13px;
                color:#5a675f;
                margin-bottom:8px;
            '
        >

            Seu código de recuperação

        </div>


        <div
            style='
                font-size:36px;
                letter-spacing:8px;
                font-weight:700;
                color:#07612b;
            '
        >

            {$codigoSeguro}

        </div>

    </div>


    <p
        style='
            margin:20px 0 8px;
            line-height:1.6;
            color:#555;
        '
    >

        Este código é válido por
        <strong>15 minutos</strong>.

    </p>


    <p
        style='
            margin:0;
            line-height:1.6;
            color:#777;
            font-size:13px;
        '
    >

        Se você não solicitou a alteração
        da senha, ignore este e-mail.

    </p>


</div>


</body>

</html>

";


/* =========================================================
   ENVIAR PELO GMAIL SMTP
========================================================= */

$erroEnvio = null;
$enviado = enviarEmailEcoAgenda(
    $usuario["email"],
    "Código de recuperação de senha - EcoAgenda",
    $htmlEmail,
    "Seu código de recuperação do EcoAgenda é: {$codigo}. Ele é válido por 15 minutos.",
    $erroEnvio
);

if (!$enviado) {
    unset(
        $_SESSION["recuperacao_email"],
        $_SESSION["recuperacao_codigo"],
        $_SESSION["recuperacao_expira"]
    );

    error_log("EcoAgenda SMTP recuperação de senha: " . ($erroEnvio ?? "falha desconhecida"));

    echo "
    <script>
        alert('Não foi possível enviar o código por e-mail. Verifique a configuração do Gmail SMTP e tente novamente.');
        window.location.href = 'esqueci_senha.html';
    </script>
    ";
    exit();
}


/* =========================================================
   MASCARAR E-MAIL
========================================================= */

$parteEmail =
    explode(
        "@",
        $usuario["email"],
        2
    );


$emailMascarado =
    $usuario["email"];


if (
    count($parteEmail) === 2
) {

    $local =
        $parteEmail[0];

    $dominio =
        $parteEmail[1];


    if (
        strlen($local) > 2
    ) {

        $localMascara =
            substr(
                $local,
                0,
                2
            ) .
            str_repeat(
                "*",
                max(
                    1,
                    strlen($local) - 2
                )
            );

    } else {

        $localMascara =
            "***";

    }


    $emailMascarado =
        $localMascara .
        "@" .
        $dominio;

}

?>


<!DOCTYPE html>

<html lang="pt-BR">

<head>

    <meta charset="UTF-8">

    <meta
        name="viewport"
        content="width=device-width, initial-scale=1.0"
    >

    <title>
        EcoAgenda - E-mail enviado
    </title>


    <style>

        * {
            box-sizing: border-box;
        }


        body {

            margin: 0;

            min-height: 100vh;

            display: flex;

            justify-content: center;

            align-items: center;

            background: #f5f7f6;

            font-family: Arial, sans-serif;

        }


        .card {

            width: 450px;

            max-width: 90%;

            padding: 40px;

            background: white;

            border-radius: 16px;

            box-shadow:
                0 8px 30px
                rgba(0,0,0,.08);

            text-align: center;

        }


        .icone {

            width: 58px;

            height: 58px;

            margin: 0 auto 20px;

            display: flex;

            align-items: center;

            justify-content: center;

            border-radius: 50%;

            background: #edf7ef;

            color: #2d8d48;

            font-size: 28px;

            font-weight: 700;

        }


        h1 {

            margin: 0 0 12px;

            color: #07612b;

            font-size: 25px;

        }


        p {

            color: #666;

            line-height: 1.6;

            font-size: 14px;

            margin: 8px 0;

        }


        .email {

            margin: 20px 0;

            padding: 14px;

            background: #f3f6f4;

            border-radius: 9px;

            color: #07612b;

            font-weight: 700;

        }


        .btn {

            display: block;

            margin-top: 24px;

            padding: 13px;

            border-radius: 8px;

            background: #2d8d48;

            color: white;

            text-decoration: none;

            font-weight: 700;

        }


        .voltar {

            display: block;

            margin-top: 16px;

            color: #07612b;

            text-decoration: none;

            font-size: 13px;

        }

    </style>

<link rel="stylesheet" href="interface/acesso.css?v=20261009-4">
</head>


<body class="ea-access">


<div class="card">
<div class="ea-access-brand"><img src="../ECO AGENDA LOGO FINAL HORIZONTAL BRANCO.png" alt="EcoAgenda"></div>


    <div class="icone">

        ✓

    </div>


    <h1>

        Código enviado!

    </h1>


    <p>

        Enviamos o código de recuperação
        para o e-mail cadastrado abaixo.

    </p>


    <div class="email">

        <?= htmlspecialchars(
            $emailMascarado,
            ENT_QUOTES,
            "UTF-8"
        ) ?>

    </div>


    <p>

        O código é válido por
        <strong>15 minutos</strong>.

        Verifique também a caixa de spam
        ou lixo eletrônico.

    </p>


    <a
        href="nova_senha.html"
        class="btn"
    >

        Informar código

    </a>


    <a
        href="esqueci_senha.html"
        class="voltar"
    >

        Voltar

    </a>


</div>


</body>

</html>