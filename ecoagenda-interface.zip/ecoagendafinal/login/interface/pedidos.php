<?php
// Componentes de apresentação. Não grava pedidos nem altera o banco.
require_once __DIR__ . '/../motorista/motorista_prazos.php';
function eaEscape($value): string { return htmlspecialchars((string)$value, ENT_QUOTES, 'UTF-8'); }
function eaStatus(string $status): string {
    $normal=mb_strtolower(trim($status),'UTF-8');
    return match($normal){'encaminhado','agendado','confirmado'=>'agendado','a caminho'=>'caminho','em andamento'=>'andamento','concluído','concluido'=>'concluido','suspenso','cancelado'=>'suspenso',default=>'analise'};
}
function eaStatusNome(string $status): string {
    return match(eaStatus($status)){'agendado'=>'Agendado','caminho'=>'A caminho','andamento'=>'Em andamento','concluido'=>'Concluído','suspenso'=>'Suspenso',default=>'Em análise'};
}
function eaPrazo(array $pedido): array {
    // A apresentação segue os cinco dias úteis após data_pedido, como no motorista/ADM.
    $dados=$pedido;
    if(eaStatus((string)($pedido['status']??''))==='analise') $dados['status']='Encaminhado';
    return prazoMotorista($dados);
}
function eaData(?string $data): string {
    if(!$data) return '—';
    $d=DateTimeImmutable::createFromFormat('!Y-m-d',substr($data,0,10));
    return $d ? $d->format('d/m/Y') : '—';
}
function eaDescricao(string $descricao): array {
    $campos=[];
    foreach(explode('|',$descricao) as $parte){
        $p=explode(':',trim($parte),2);
        if(count($p)!==2) return ['material'=>materialMotorista($descricao),'quantidade'=>'Não informada','descricao'=>$descricao];
        $chave=mb_strtolower(trim($p[0]),'UTF-8');
        if(!in_array($chave,['tipo de resíduo','tipo de residuo','material','quantidade aproximada','descrição','descricao'],true) || isset($campos[$chave])) return ['material'=>materialMotorista($descricao),'quantidade'=>'Não informada','descricao'=>$descricao];
        $campos[$chave]=trim($p[1]);
    }
    return ['material'=>materialMotorista($descricao),'quantidade'=>$campos['quantidade aproximada']??'Não informada','descricao'=>$campos['descrição']??$campos['descricao']??'Sem descrição adicional'];
}
function eaResumoPedido(array $pedido,string $classeBotao='btn-ver-pedido',bool $morador=false): void {
    $prazo=eaPrazo($pedido); $id=(int)$pedido['id'];
    ?>
    <div class="mot-compact-heading">
        <div class="mot-order-number" aria-label="Pedido <?= $id ?>"><span class="ea-order-icon"><svg class="ea-icon" viewBox="0 0 24 24" aria-hidden="true"><path d="m12 3 9 5v9l-9 5-9-5V8l9-5ZM3 8l9 5 9-5M12 13v9M7.5 5.5l9 5"/></svg></span><span class="ea-order-label">Pedido<strong><?= $id ?></strong></span></div>
        <span class="status <?= eaStatus((string)$pedido['status']) ?>"><?= eaEscape(eaStatusNome((string)$pedido['status'])) ?></span>
    </div>
    <div class="mot-compact-info"><div><span>Local de coleta</span><strong><?= eaEscape($pedido['endereco'] ?: 'Endereço não informado') ?></strong></div><div><span>Material de coleta</span><strong><?= eaEscape(materialMotorista((string)$pedido['descricao'])) ?></strong></div></div>
    <div class="mot-compact-footer"><div class="mot-deadline-badges"><span class="mot-badge <?= eaEscape($prazo['classe']) ?>"><?= eaEscape($prazo['texto']) ?></span><?php if($prazo['classe']==='hoje'): ?><span class="mot-badge hoje">Vence hoje</span><?php endif; ?></div>
        <button type="button" class="btn-small <?= eaEscape($classeBotao) ?>" data-id="<?= $id ?>" <?= $morador ? 'data-toggle-details aria-expanded="false" aria-haspopup="dialog"' : '' ?>>Ver detalhes <span aria-hidden="true">→</span></button>
    </div>
    <?php
}
function eaFiltros(): void { ?>
<div class="mot-filters-row ea-order-filters"><label class="mot-detail-filter">Status dos pedidos<select data-ea-status><option value="todos">Todos os status</option><option value="analise">Em análise</option><option value="agendado">Agendados</option><option value="caminho">A caminho</option><option value="andamento">Em andamento</option><option value="concluido">Concluídos</option><option value="suspenso">Suspensos</option></select></label><label class="mot-detail-filter">Prazo dos pedidos<select data-ea-prazo><option value="todos">Todos os prazos</option><option value="valido">Dentro do prazo</option><option value="vencido">Prazo vencido</option></select></label></div>
<?php }
