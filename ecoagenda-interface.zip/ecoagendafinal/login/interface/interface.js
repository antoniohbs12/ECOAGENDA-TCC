/* Camada visual compartilhada. As ações e validações permanecem nos scripts de cada área. */
(() => {
    const reduzido=matchMedia('(prefers-reduced-motion: reduce)');
    function animar(el, delay=0) {
        if(!el || reduzido.matches || !el.animate || !el.getClientRects().length) return;
        el.getAnimations().forEach(a=>a.cancel());
        el.animate([{opacity:0,transform:'translateY(9px)'},{opacity:1,transform:'translateY(0)'}],{duration:280,delay,easing:'cubic-bezier(.2,.7,.2,1)',fill:'backwards'});
    }
    const desenhos={
        inicio:'<rect x="3" y="5" width="18" height="16" rx="3"/><path d="M8 3v4M16 3v4M3 11h18M8 15h2M14 15h2"/>',
        pedidos:'<path d="m12 3 9 5v9l-9 5-9-5V8l9-5ZM3 8l9 5 9-5M12 13v9M7.5 5.5l9 5"/>',
        perfil:'<circle cx="12" cy="8" r="4"/><path d="M4 21v-2a8 8 0 0 1 16 0v2"/>',
        novo:'<rect x="3" y="3" width="18" height="18" rx="4"/><path d="M12 7v10M7 12h10"/>',
        buscar:'<circle cx="10.5" cy="10.5" r="6.5"/><path d="m16 16 5 5"/>'
    };
    const titulo=document.querySelector('.topbar h1');
    if(titulo){
        titulo.classList.add('sr-only');
        const boasVindas=document.createElement('strong');boasVindas.className='ea-welcome';boasVindas.textContent='Vamos cuidar de Pinhais.';titulo.after(boasVindas);
    }
    document.querySelectorAll('.section-top h2').forEach(h=>{
        if(['Pedidos','Buscar pedido','Novo Pedido'].includes(h.textContent.trim())) h.classList.add('sr-only');
    });
    document.querySelectorAll('.menu-link').forEach(link=>{
        const nome=link.textContent.trim().toLowerCase();
        const tipo=nome.includes('perfil')?'perfil':nome.includes('buscar')?'buscar':nome.includes('novo')?'novo':nome.includes('dashboard')?'inicio':'pedidos';
        const icone=link.querySelector('.menu-icon,.menu-icon-image,span:first-child');
        if(icone){const span=document.createElement('span');span.className='ea-nav-icon';span.setAttribute('aria-hidden','true');span.innerHTML=`<svg viewBox="0 0 24 24">${desenhos[tipo]}</svg>`;icone.replaceWith(span);}
        link.setAttribute('aria-current',link.classList.contains('active')?'page':'false');
    });
    function identificar(root=document){
        root.querySelectorAll('.numero-pedido:not([data-ea-number])').forEach(el=>{
            const match=el.textContent.trim().match(/^Pedido\s*#\s*(\d+)$/i);if(!match)return;
            el.dataset.eaNumber='1';el.classList.add('ea-number');el.textContent='Pedido';
            const numero=document.createElement('strong');numero.textContent=match[1];el.append(numero);
        });
        root.querySelectorAll('.resumo-pedido-info>p,.tracking-item-copy>p').forEach(el=>{
            if(el.dataset.eaNumber)return;
            const node=[...el.childNodes].find(n=>n.nodeType===Node.TEXT_NODE && /Pedido\s*#\s*\d+/.test(n.textContent));
            if(!node)return;const match=node.textContent.match(/Pedido\s*#\s*(\d+)/);el.dataset.eaNumber='1';
            const badge=document.createElement('span');badge.className='ea-number';badge.textContent='Pedido';const numero=document.createElement('strong');numero.textContent=match[1];badge.append(numero);
            const fragment=document.createDocumentFragment();fragment.append(document.createTextNode(node.textContent.slice(0,match.index)),badge,document.createTextNode(node.textContent.slice(match.index+match[0].length)));node.replaceWith(fragment);
        });
    }
    identificar();animar(document.querySelector('.content') || document.querySelector('.container'));
    const observer=new MutationObserver(changes=>{
        let added=false;
        changes.forEach(({type,target,addedNodes})=>{
            if(type==='childList'){if(addedNodes.length)added=true;return;}
            if(target.matches('.section.active,.tab-content.active,.tracking-detail-panel:not([hidden]),.other-address:not([hidden])'))animar(target);
            if(target.matches('.modal:not([hidden])'))animar(target.querySelector('.modal-box'));
            if(target.matches('.menu-link'))target.setAttribute('aria-current',target.classList.contains('active')?'page':'false');
        });
        if(added)identificar();
    });
    observer.observe(document.body,{attributes:true,attributeFilter:['class','hidden'],childList:true,subtree:true});
})();
