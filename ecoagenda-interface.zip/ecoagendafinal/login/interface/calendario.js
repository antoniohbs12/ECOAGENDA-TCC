/* Calendário compartilhado: emissão é a posição; vencimento é a etiqueta. */
(() => {
    const reduced=matchMedia('(prefers-reduced-motion: reduce)');
    const date=value=>{const [y,m,d]=value.split('-').map(Number);return new Date(y,m-1,d,12);};
    const iso=d=>`${d.getFullYear()}-${String(d.getMonth()+1).padStart(2,'0')}-${String(d.getDate()).padStart(2,'0')}`;
    document.querySelectorAll('[data-calendar]').forEach(root=>{
        const source=document.getElementById(root.dataset.calendar);if(!source)return;
        const agenda=JSON.parse(source.textContent),today=date(agenda.hoje);
        const monday=d=>{const x=new Date(d);x.setDate(x.getDate()-(x.getDay()+6)%7);return x;};
        let week=monday(today);
        const container=root.querySelector('[data-calendar-days]');
        function render(direction=0){
            container.replaceChildren();
            const end=new Date(week);end.setDate(end.getDate()+6);
            root.querySelector('[data-calendar-label]').textContent=`${week.toLocaleDateString('pt-BR')} — ${end.toLocaleDateString('pt-BR')}`;
            let shown=0;
            for(let i=0;i<7;i++){
                const d=new Date(week);d.setDate(d.getDate()+i);const key=iso(d);
                const col=document.createElement('div');col.className=`mot-day${i>4?' mot-weekend':''}${key===agenda.hoje?' mot-today':''}`;col.dataset.date=key;
                const head=document.createElement('div');head.className='mot-day-heading';
                const name=document.createElement('span');name.className='mot-day-name';name.textContent=['Segunda','Terça','Quarta','Quinta','Sexta','Sábado','Domingo'][i];
                const num=document.createElement('strong');num.className='mot-day-number';num.textContent=String(d.getDate()).padStart(2,'0');
                const sub=document.createElement('span');sub.className='mot-day-subtitle';sub.textContent=key===agenda.hoje?'Hoje':d.toLocaleDateString('pt-BR',{month:'short'}).replace('.','');head.append(name,num,sub);col.append(head);
                const orders=agenda.pedidos.filter(p=>p.emitido===key).sort((a,b)=>a.limite.localeCompare(b.limite)||a.id-b.id);shown+=orders.length;
                orders.forEach(p=>{
                    const button=document.createElement('button');button.type='button';button.className=`mot-calendar-order ea-urgency ${p.urgencia}`;button.dataset.id=p.id;
                    button.setAttribute('aria-label',`Ver detalhes do pedido ${p.id}, ${p.local}`);
                    const number=document.createElement('strong');number.className='mot-calendar-number';const label=document.createElement('span');label.textContent='Pedido';const value=document.createElement('b');value.textContent=p.id;number.append(label,value);
                    const local=document.createElement('span');local.className='mot-order-local';local.textContent=p.local;
                    const material=document.createElement('span');material.className='mot-order-material';material.textContent=p.material;
                    const limit=document.createElement('span');limit.className=`ea-deadline-tag ${p.urgencia}`;
                    limit.textContent=p.limite?`Até ${date(p.limite).toLocaleDateString('pt-BR',{day:'2-digit',month:'2-digit'})} (${date(p.limite).toLocaleDateString('pt-BR',{weekday:'long'})})`:'Prazo não informado';
                    const notice=document.createElement('span');notice.className='ea-days-left';notice.textContent=p.classe==='vencido'?'Prazo vencido':p.classe==='hoje'?'Vence hoje':p.restantes===null?'Prazo não informado':`${p.restantes} ${p.restantes===1?'dia útil restante':'dias úteis restantes'}`;
                    const open=document.createElement('span');open.className='mot-order-open';open.textContent='Ver detalhes →';button.append(number,local,material,limit,notice,open);
                    button.addEventListener('click',()=>{
                        if(root.dataset.calendar==='adm-agenda-data')document.querySelector(`#section-pedidos .btn-detalhes[data-id="${p.id}"]`)?.click();
                        else document.dispatchEvent(new CustomEvent('ea-calendar-open',{detail:{id:p.id}}));
                    });col.append(button);
                });
                if(!orders.length){const empty=document.createElement('p');empty.className='mot-day-empty';empty.textContent='Nenhum pedido emitido';col.append(empty);}
                container.append(col);
            }
            const other=root.querySelector('[data-calendar-other]');other.replaceChildren();other.hidden=shown===agenda.pedidos.length;
            if(!other.hidden){
                const missing=agenda.pedidos.filter(p=>p.emitido<iso(week)||p.emitido>iso(end)).sort((a,b)=>a.limite.localeCompare(b.limite));
                other.append(document.createTextNode(`${missing.length} coleta(s) a atender foram emitidas em outras semanas. `));
                const go=document.createElement('button');go.type='button';go.textContent='Ver semana do pedido mais urgente';go.addEventListener('click',()=>{week=monday(date(missing[0].emitido));render(-1);});other.append(go);
            }
            if(!reduced.matches&&container.animate){container.getAnimations().forEach(a=>a.cancel());container.animate([{opacity:0,transform:`translateX(${direction*16}px)`},{opacity:1,transform:'translateX(0)'}],{duration:260,easing:'ease-out'});}
        }
        root.querySelector('[data-calendar-prev]').addEventListener('click',()=>{week.setDate(week.getDate()-7);render(-1);});
        root.querySelector('[data-calendar-next]').addEventListener('click',()=>{week.setDate(week.getDate()+7);render(1);});
        root.querySelector('[data-calendar-current]').addEventListener('click',()=>{week=monday(today);render();});render();
    });
})();
