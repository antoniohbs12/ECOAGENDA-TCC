/* Navegação visual dos cartões e detalhes; mantém as ações originais dos módulos. */
(() => {
    document.querySelectorAll('.ea-order-filters').forEach(filtros=>{
        const area=filtros.closest('section') || filtros.parentElement;
        const status=filtros.querySelector('[data-ea-status]'),prazo=filtros.querySelector('[data-ea-prazo]');
        const vazios=area.querySelector('.ea-filter-empty,#trackingFilterEmpty,#semResultadoFiltro');
        function filtrar(){
            let visiveis=0;
            area.querySelectorAll('.ea-orders-list>.ea-order-card').forEach(card=>{
                const prazoValido=prazo.value==='todos'||card.dataset.eaPrazo===prazo.value||(prazo.value==='valido'&&card.dataset.eaPrazo==='hoje');
                card.hidden=!((status.value==='todos'||card.dataset.eaStatus===status.value)&&prazoValido);
                if(!card.hidden)visiveis++;
            });
            if(vazios)vazios.hidden=visiveis>0;
        }
        status.addEventListener('change',filtrar);prazo.addEventListener('change',filtrar);filtrar();
    });
    const residentModal=document.getElementById('eaResidentModal');
    let painelAtual=null,origemPainel=null,botaoAtual=null;
    function fecharMorador(){
        if(!residentModal)return;
        residentModal.hidden=true;document.body.style.overflow='';
        if(painelAtual&&origemPainel){painelAtual.hidden=true;origemPainel.append(painelAtual);}
        botaoAtual?.setAttribute('aria-expanded','false');botaoAtual?.focus({preventScroll:true});
        painelAtual=null;
    }
    function abrirMorador(botao){
        if(!residentModal)return;
        if(painelAtual)fecharMorador();
        const card=botao.closest('.ea-order-card');const painel=card.querySelector('.tracking-detail-panel');if(!painel)return;
        origemPainel=card;painelAtual=painel;botaoAtual=botao;
        document.getElementById('eaResidentTitle').textContent=`Pedido #${botao.dataset.id}`;
        document.getElementById('eaResidentBody').append(painel);painel.hidden=false;residentModal.hidden=false;botao.setAttribute('aria-expanded','true');document.body.style.overflow='hidden';
        residentModal.querySelector('[data-ea-close]').focus({preventScroll:true});
    }
    document.querySelectorAll('[data-toggle-details]').forEach(button=>button.addEventListener('click',()=>abrirMorador(button)));
    residentModal?.querySelectorAll('[data-ea-close]').forEach(button=>button.addEventListener('click',fecharMorador));
    residentModal?.addEventListener('click',event=>{if(event.target===residentModal)fecharMorador();});
    function abrirLink(){if(residentModal && /^#pedido-\d+$/.test(location.hash))document.getElementById(location.hash.slice(1))?.querySelector('[data-toggle-details]')?.click();}
    abrirLink();window.addEventListener('hashchange',abrirLink);
    function descrever(raw){
        const partes=raw.split('|'),campos={};let reconhecida=true;
        partes.forEach(parte=>{
            const i=parte.indexOf(':');const chave=parte.slice(0,i).trim().normalize('NFD').replace(/[\u0300-\u036f]/g,'').toLowerCase();
            if(i<0||!['tipo de residuo','material','quantidade aproximada','descricao'].includes(chave)||Object.hasOwn(campos,chave))reconhecida=false;
            else campos[chave]=parte.slice(i+1).trim();
        });
        return {material:campos['tipo de residuo']||campos.material||'Não informado',quantidade:campos['quantidade aproximada']||'Não informada',descricao:reconhecida?(campos.descricao||'Sem descrição adicional'):raw};
    }
    function campo(grid,label,texto){const bloco=document.createElement('div'),nome=document.createElement('span'),valor=document.createElement('strong');nome.textContent=label;valor.textContent=texto||'—';bloco.append(nome,valor);grid.append(bloco);}
    function cardStatus(raw){
        const key=raw.trim().normalize('NFD').replace(/[\u0300-\u036f]/g,'').toLowerCase();
        return ({encaminhado:['agendado','Agendado'],agendado:['agendado','Agendado'],'a caminho':['caminho','A caminho'],'em andamento':['andamento','Em andamento'],concluido:['concluido','Concluído'],suspenso:['suspenso','Suspenso'],cancelado:['suspenso','Suspenso']})[key]||['analise','Em análise'];
    }
    const modal=document.getElementById('modalDetalhes');
    let focoAnterior=null;
    document.addEventListener('click',event=>{
        const botao=event.target.closest('.btn-ver-pedido,.btn-detalhes');if(!botao || !modal || modal.hidden)return;
        const id=botao.dataset.id,dados=document.getElementById(`dados-${id}`);if(!dados)return;
        focoAnterior=botao;
        document.getElementById('modalTitulo').textContent='Detalhes da coleta';
        const descricao=descrever(dados.dataset.descricao||'');
        document.getElementById('modalDescricao').textContent=descricao.descricao;
        let extras=modal.querySelector('.ea-modal-additions');
        if(!extras){
            const grid=modal.querySelector('.detalhes-grid');
            const local=document.getElementById('modalEndereco').parentElement;
            const descricaoBloco=document.getElementById('modalDescricao').parentElement;
            const principal=document.createElement('div');principal.className='detalhes-grid ea-detail-primary';
            local.querySelector('span').textContent='Local de coleta';
            descricaoBloco.querySelector('span').textContent='Descrição do pedido';
            principal.append(local);grid.before(principal);
            extras=document.createElement('div');extras.className='detalhes-grid ea-modal-additions';principal.after(extras);
            const texto=document.createElement('div');texto.className='detalhes-grid ea-detail-description';texto.append(descricaoBloco);extras.after(texto);
            grid.classList.add('ea-detail-people');
        }
        extras.replaceChildren();campo(extras,'Material de coleta',descricao.material);campo(extras,'Quantidade aproximada',descricao.quantidade);campo(extras,'Prazo de atendimento',dados.dataset.prazo);campo(extras,'Situação do prazo',dados.dataset.prazoTexto);if(document.body.classList.contains('ea-admin'))campo(extras,'Pedido realizado em',dados.dataset.criacao);
        if(dados.dataset.enviado)campo(extras,'Enviado ao motorista',dados.dataset.enviado);
        const chave=cardStatus(dados.dataset.status||'');
        const status=document.getElementById('modalStatus');
        status.className=`status ${chave[0]}`;status.textContent=chave[1];
        let actions=modal.querySelector('.ea-detail-actions');
        if(!actions){actions=document.createElement('div');actions.className='pedido-actions ea-detail-actions';modal.querySelector('.modal-footer').prepend(actions);}
        actions.replaceChildren();
        const card=[...document.querySelectorAll('.ea-orders-list>.ea-order-card')].find(c=>c.dataset.id===id);
        card?.querySelectorAll('.ea-original-actions button,.ea-original-actions a').forEach(original=>{
            if(original.tagName==='A'){actions.append(original.cloneNode(true));return;}
            const proxy=document.createElement('button');proxy.type='button';proxy.className='btn-small';proxy.textContent=original.textContent.trim();
            proxy.addEventListener('click',()=>{if(original.type!=='submit')modal.hidden=true;original.click();});actions.append(proxy);
        });
        modal.querySelector('[data-close-modal]')?.focus({preventScroll:true});
    });
    document.querySelectorAll('.modal').forEach(item=>{
        item.setAttribute('role','dialog');item.setAttribute('aria-modal','true');
        if(!item.hasAttribute('aria-labelledby'))item.setAttribute('aria-label',item.querySelector('.modal-header h2')?.textContent.trim()||'Detalhes');
    });
    new MutationObserver(()=>{
        const aberto=[...document.querySelectorAll('.modal')].find(m=>!m.hidden);
        document.body.style.overflow=aberto?'hidden':'';
    }).observe(document.body,{subtree:true,attributes:true,attributeFilter:['hidden']});
    document.addEventListener('keydown',event=>{
        if(event.key==='Escape'){
            if(residentModal&&!residentModal.hidden)fecharMorador();
            else if(focoAnterior?.isConnected)focoAnterior.focus({preventScroll:true});
        }
        if(event.key!=='Tab')return;
        const aberto=[...document.querySelectorAll('.modal')].reverse().find(m=>!m.hidden);if(!aberto)return;
        const itens=[...aberto.querySelectorAll('button,a[href],input,textarea,select')].filter(el=>!el.disabled&&el.getClientRects().length);if(!itens.length)return;
        const primeiro=itens[0],ultimo=itens.at(-1);
        if(event.shiftKey&&(document.activeElement===primeiro||!aberto.contains(document.activeElement))){event.preventDefault();ultimo.focus();}
        else if(!event.shiftKey&&(document.activeElement===ultimo||!aberto.contains(document.activeElement))){event.preventDefault();primeiro.focus();}
    });
})();
