<?php

session_start();

require_once "../config.php";


/* =========================================================
   VERIFICAR MÉTODO
========================================================= */

if (
    $_SERVER["REQUEST_METHOD"] !== "POST"
) {

    header(
        "Location: nova_senha.html"
    );

    exit();
}


/* =========================================================
   VERIFICAR RECUPERAÇÃO
========================================================= */

if (
    !isset($_SESSION["recuperacao_email"]) ||
    !isset($_SESSION["recuperacao_codigo"]) ||
    !isset($_SESSION["recuperacao_expira"])
) {

    echo "

    <script>

        alert(
            'Solicitação de recuperação inválida ou expirada.'
        );

        window.location.href =
            'esqueci_senha.html';

    </script>

    ";

    exit();
}


/* =========================================================
   VERIFICAR EXPIRAÇÃO
========================================================= */

if (
    time() >
    $_SESSION["recuperacao_expira"]
) {

    unset(
        $_SESSION["recuperacao_email"],
        $_SESSION["recuperacao_codigo"],
        $_SESSION["recuperacao_expira"]
    );


    echo "

    <script>

        alert(
            'O código de recuperação expirou.'
        );

        window.location.href =
            'esqueci_senha.html';

    </script>

    ";

    exit();
}


/* =========================================================
   RECEBER DADOS
========================================================= */

$codigo =
    trim(
        $_POST["codigo"] ?? ""
    );


$senha =
    $_POST["senha"] ?? "";


$confirmarSenha =
    $_POST["confirmar_senha"] ?? "";


/* =========================================================
   VALIDAR CÓDIGO
========================================================= */

if (
    !hash_equals(
        (string) $_SESSION["recuperacao_codigo"],
        (string) $codigo
    )
) {

    echo "

    <script>

        alert(
            'Código de recuperação incorreto.'
        );

        history.back();

    </script>

    ";

    exit();
}


/* =========================================================
   VALIDAR SENHA
========================================================= */

if (
    strlen($senha) < 6
) {

    echo "

    <script>

        alert(
            'A senha deve ter pelo menos 6 caracteres.'
        );

        history.back();

    </script>

    ";

    exit();
}


if (
    $senha !== $confirmarSenha
) {

    echo "

    <script>

        alert(
            'As senhas não coincidem.'
        );

        history.back();

    </script>

    ";

    exit();
}


/* =========================================================
   GERAR HASH DA NOVA SENHA
========================================================= */

$senhaHash =
    password_hash(
        $senha,
        PASSWORD_DEFAULT
    );


/* =========================================================
   PEGAR E-MAIL
========================================================= */

$email =
    $_SESSION["recuperacao_email"];


/* =========================================================
   ATUALIZAR SENHA NO BANCO
========================================================= */

$sql = "

    UPDATE usuario

    SET senha = ?

    WHERE email = ?

    LIMIT 1

";


$stmt =
    $conn->prepare($sql);


if (!$stmt) {

    die(
        "Erro ao preparar alteração: " .
        $conn->error
    );

}


$stmt->bind_param(
    "ss",
    $senhaHash,
    $email
);


if (
    !$stmt->execute()
) {

    die(
        "Erro ao alterar senha: " .
        $stmt->error
    );

}


$stmt->close();


/* =========================================================
   APAGAR DADOS DA RECUPERAÇÃO
========================================================= */

unset(
    $_SESSION["recuperacao_email"],
    $_SESSION["recuperacao_codigo"],
    $_SESSION["recuperacao_expira"]
);

?>


<!DOCTYPE html>

<html lang="pt-BR">

<head>

    <meta charset="UTF-8">

    <meta
        name="viewport"
        content="width=device-width, initial-scale=1.0"
    >

    <title>
        EcoAgenda - Senha alterada
    </title>


    <style>

        body {

            margin: 0;

            min-height: 100vh;

            display: flex;

            justify-content: center;

            align-items: center;

            background: #f5f7f6;

            font-family: Arial, sans-serif;

        }


        .card {

            width: 420px;

            max-width: 90%;

            padding: 40px;

            text-align: center;

            background: white;

            border-radius: 16px;

            box-shadow:
                0 8px 30px
                rgba(0,0,0,.08);

        }


        h1 {

            color: #07612b;

        }


        p {

            color: #666;

            line-height: 1.6;

        }


        a {

            display: block;

            margin-top: 25px;

            padding: 13px;

            border-radius: 8px;

            background: #2d8d48;

            color: white;

            text-decoration: none;

            font-weight: 700;

        }

    </style>

<link rel="stylesheet" href="interface/acesso.css?v=20261009-4">
</head>


<body class="ea-access">


<div class="card">
<div class="ea-access-brand"><img src="../ECO AGENDA LOGO FINAL HORIZONTAL BRANCO.png" alt="EcoAgenda"></div>


    <h1>

        Senha alterada!

    </h1>


    <p>

        Sua senha foi alterada com sucesso.

        <br><br>

        Agora você já pode entrar no
        EcoAgenda utilizando sua nova senha.

    </p>


    <a href="login.html">

        Ir para o login

    </a>


</div>


</body>

</html>