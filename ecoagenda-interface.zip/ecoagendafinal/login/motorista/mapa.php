<?php
declare(strict_types=1);
session_start();
header('Cache-Control: private, no-store');
if(($_SESSION['perfil']??'')!=='motorista'||empty($_SESSION['email'])){http_response_code(403);exit('Acesso negado.');}
$email=(string)$_SESSION['email'];
if(empty($_SESSION['motorista_mapa_csrf']))$_SESSION['motorista_mapa_csrf']=bin2hex(random_bytes(32));
$csrf=$_SESSION['motorista_mapa_csrf'];session_write_close();
require_once __DIR__.'/../../config.php';
require_once __DIR__.'/mapa_dados_motorista.php';
$pedidos=pedidosMapaMotorista($conn,$email);
function mapaResposta(int $status,array $dados): never {http_response_code($status);header('Content-Type: application/json; charset=UTF-8');echo json_encode($dados,JSON_UNESCAPED_UNICODE|JSON_INVALID_UTF8_SUBSTITUTE);exit;}
if($_SERVER['REQUEST_METHOD']==='POST'){
    if(!hash_equals($csrf,(string)($_SERVER['HTTP_X_MAPA_CSRF']??'')))mapaResposta(403,['erro'=>'Sessão inválida. Reabra o mapa.']);
    $body=json_decode((string)file_get_contents('php://input'),true);$id=filter_var($body['pedidoId']??null,FILTER_VALIDATE_INT);
    $encontrado=null;foreach($pedidos as $p)if((int)$p['id']===$id)$encontrado=$p;
    if(!$encontrado)mapaResposta(404,['erro'=>'Coleta não disponível para este motorista.']);
    if(empty($encontrado['endereco_id'])||empty($encontrado['rua'])||empty($encontrado['numero']))mapaResposta(422,['erro'=>'Endereço não disponível.']);
    require_once __DIR__.'/../administrador/mapa_geocodificar.php';
    try{$pos=geocodificarEnderecoMapa($encontrado);mapaResposta(($pos['precisao']??'')==='temporariamente_indisponivel'?503:200,$pos);}
    catch(Throwable $e){mapaResposta(503,['erro'=>'Não foi possível localizar agora. Tente novamente mais tarde.']);}
}
if($_SERVER['REQUEST_METHOD']!=='GET'){http_response_code(405);exit;}
$dados=dadosMapaMotorista($pedidos);
if(isset($_GET['dados']))mapaResposta(200,$dados);
$geo=carregarGeoMapa();
?>
<!doctype html><html lang="pt-BR"><head><meta charset="UTF-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>Suas coletas no mapa — EcoAgenda</title>
<link rel="stylesheet" href="../administrador/vendor/leaflet/leaflet.css"><link rel="stylesheet" href="../administrador/vendor/markercluster/MarkerCluster.css"><link rel="stylesheet" href="../interface/calendario.css?v=20261009-4"><link rel="stylesheet" href="mapa_motorista.css?v=20261009-4">
<script defer src="../administrador/vendor/leaflet/leaflet.js"></script><script defer src="../administrador/vendor/markercluster/leaflet.markercluster.js"></script><script defer src="mapa_motorista.js?v=20261009-4"></script></head><body class="driver-map">
<header class="map-toolbar"><label>Buscar coleta<input type="search" id="driver-map-search" placeholder="Pedido, endereço ou material"></label><button type="button" id="driver-map-home">Ver todos os locais</button><span id="driver-map-status" role="status"></span></header>
<div class="ea-deadline-legend"><span class="verde">4–5 dias úteis</span><span class="amarelo">2–3 dias úteis</span><span class="vermelho">1 dia útil ou vence hoje</span><span class="cinza">Suspenso, vencido ou sem prazo</span></div>
<main class="driver-map-layout"><div class="driver-map-panel"><div id="driver-map-canvas" aria-label="Mapa de Pinhais com suas coletas"></div><p id="driver-map-base-error" role="status" hidden>Não foi possível carregar as ruas. Os limites e os locais disponíveis continuam no mapa.</p></div><aside class="driver-map-aside"><h2>Suas coletas</h2><p>Coletas atribuídas a você, exceto concluídas. Selecione um pedido para ver o local; você decide a rota.</p><div id="driver-map-list"></div><p id="driver-map-empty" hidden>Nenhuma coleta encontrada.</p><p id="driver-map-missing" role="status"></p><button type="button" id="driver-map-retry" hidden>Tentar localizar novamente</button></aside></main>
<script type="application/json" id="driver-map-data"><?= json_encode(['dados'=>$dados,'geo'=>$geo,'csrf'=>$csrf],JSON_HEX_TAG|JSON_HEX_AMP|JSON_HEX_APOS|JSON_HEX_QUOT|JSON_UNESCAPED_UNICODE|JSON_INVALID_UTF8_SUBSTITUTE) ?></script></body></html>
