(() => {
    const trigger=document.getElementById('mot-show-map');
    if(trigger){
        const modal=document.getElementById('mot-map-modal'),frame=document.getElementById('mot-map-frame');
        trigger.addEventListener('click',()=>{modal.hidden=false;frame.src='mapa.php';document.body.style.overflow='hidden';modal.querySelector('[data-close-modal]').focus();});
        new MutationObserver(()=>{if(modal.hidden){frame.removeAttribute('src');document.body.style.overflow='';trigger.focus({preventScroll:true});}}).observe(modal,{attributes:true,attributeFilter:['hidden']});
        // Escape dentro do iframe retorna ao botão que abriu o mapa.
        window.addEventListener('message',e=>{if(e.origin===location.origin&&e.source===frame.contentWindow&&e.data?.tipo==='ecoagenda-fechar-mapa')modal.hidden=true;});
        return;
    }
    const source=document.getElementById('driver-map-data');if(!source)return;
    const cfg=JSON.parse(source.textContent),$=id=>document.getElementById(id),status=$('driver-map-status');
    if(!window.L||!L.markerClusterGroup){status.textContent='Mapa indisponível. Confira os arquivos do módulo.';return;}
    let data=cfg.dados,locating=false,refreshing=false;const attempted=new Set(),markers=new Map();
    const normalize=s=>String(s??'').normalize('NFD').replace(/[\u0300-\u036f]/g,'').toLowerCase();
    const map=L.map('driver-map-canvas',{scrollWheelZoom:true,minZoom:11,maxZoom:19,zoomControl:true});map.attributionControl.setPrefix(false);
    map.attributionControl.addAttribution('Limites: GeoPinhais (2012) · Base: <a href="https://www.openstreetmap.org/copyright" target="_blank" rel="noopener">OpenStreetMap</a> / <a href="https://carto.com/attributions" target="_blank" rel="noopener">CARTO</a>');
    map.createPane('geography');map.getPane('geography').style.zIndex=200;
    const renderer=L.canvas({pane:'geography',padding:.3});let geography;
    function baseStyle(f){const {layer,class:kind}=f.properties,scale=Math.min(2.8,2**(Math.max(0,map.getZoom()-13)*.4));
        if(layer==='transportation')return {color:['motorway','trunk','primary'].includes(kind)?'#c5c9c4':'#fff',weight:(['motorway','trunk','primary'].includes(kind)?2.4:1.1)*scale,opacity:.92,fill:false};
        if(layer==='waterway')return {color:'#a9cbd6',weight:scale,fill:false};
        if(layer==='building')return {color:'#d6dcd6',weight:.4,fillColor:'#e0e5de',fillOpacity:map.getZoom()>=14?.72:0,opacity:map.getZoom()>=14?.6:0};
        return {stroke:false,fillColor:({landcover:'#e0e9df',landuse:'#eef0ec',park:'#d6e3d3',water:'#b9d3dc'})[layer]||'#edf1ed',fillOpacity:1};}
    fetch('../administrador/pinhais_base.geojson?v=20261008-1').then(r=>{if(!r.ok)throw Error();return r.json();}).then(geo=>{if(geo.type!=='FeatureCollection')throw Error();geography=L.geoJSON(geo,{renderer,pane:'geography',interactive:false,style:baseStyle}).addTo(map);}).catch(()=>{$('driver-map-base-error').hidden=false;});
    map.on('zoomend',()=>geography?.setStyle(baseStyle));
    const borders=L.geoJSON(cfg.geo,{interactive:false,style:{color:'#97b5a1',weight:1,opacity:.65,fillOpacity:0,dashArray:'4 5'}}).addTo(map);
    const home=()=>map.fitBounds(borders.getBounds(),{padding:[20,20]});home();$('driver-map-home').addEventListener('click',home);
    const colors={verde:'#42875b',amarelo:'#ba8d32',vermelho:'#b95e53',cinza:'#7c8881'},priority={vermelho:0,amarelo:1,verde:2,cinza:3};
    const groups=L.markerClusterGroup({maxClusterRadius:35,showCoverageOnHover:false,spiderfyOnMaxZoom:true,iconCreateFunction:cluster=>{
        const children=cluster.getAllChildMarkers(),color=children.map(m=>m.options.urgencia).sort((a,b)=>priority[a]-priority[b])[0];
        return L.divIcon({className:`driver-cluster ${color}`,html:`<span>${children.length}</span>`,iconSize:[42,42]});
    }}).addTo(map);
    function popup(p){
        const node=document.createElement('div');node.className='driver-popup';
        const heading=document.createElement('h3');heading.textContent=`Pedido ${p.id}`;node.append(heading);
        for(const [label,text] of [['Local de coleta',p.endereco],['Prazo',`${p.etiqueta} · ${p.situacao}`],['Material de coleta',p.material],['Status',p.status]]){const row=document.createElement('p'),name=document.createElement('span'),value=document.createElement('strong');name.textContent=label;value.textContent=text;row.append(name,value);node.append(row);}
        if(p.precisao==='rua_aproximada'){const note=document.createElement('small');note.textContent='Localização aproximada da rua. Confira o número no endereço.';node.append(note);}return node;
    }
    function pin(p){const c=colors[p.urgencia]||colors.cinza;return L.divIcon({className:`driver-pin ${p.urgencia}`,iconSize:[32,42],iconAnchor:[16,42],popupAnchor:[0,-38],html:`<svg viewBox="0 0 32 42" aria-hidden="true"><path d="M16 1C7 1 1 7 1 16c0 11 15 25 15 25s15-14 15-25C31 7 25 1 16 1Z" fill="${c}" stroke="#fff" stroke-width="2"/><circle cx="16" cy="16" r="5" fill="#fff"/></svg>`});}
    function render(){
        groups.clearLayers();markers.clear();$('driver-map-list').replaceChildren();
        const query=normalize($('driver-map-search').value);
        const filtered=data.pedidos.filter(p=>normalize(`${p.id} ${p.endereco} ${p.material}`).includes(query));
        filtered.forEach(p=>{
            const coords=Number.isFinite(p.lat)&&Number.isFinite(p.lng);
            if(coords){const marker=L.marker([p.lat,p.lng],{icon:pin(p),title:`Pedido ${p.id} · ${p.etiqueta} · ${p.situacao}`,urgencia:p.urgencia}).bindPopup(popup(p),{maxHeight:300,maxWidth:310});groups.addLayer(marker);markers.set(p.id,marker);}
            const button=document.createElement('button');button.type='button';button.className=`driver-map-item ${p.urgencia}`;button.dataset.id=p.id;
            const title=document.createElement('strong');title.textContent=`Pedido ${p.id}`;const local=document.createElement('span');local.textContent=p.endereco;const tag=document.createElement('span');tag.className=`ea-deadline-tag ${p.urgencia}`;tag.textContent=p.etiqueta;const detail=document.createElement('small');detail.textContent=coords?p.situacao:`${p.situacao} · Localização pendente`;button.append(title,local,tag,detail);
            button.addEventListener('click',()=>{const marker=markers.get(p.id);if(marker)groups.zoomToShowLayer(marker,()=>marker.openPopup());else status.textContent='Este endereço ainda não foi localizado. Use o endereço informado no pedido.';});$('driver-map-list').append(button);
        });
        $('driver-map-empty').hidden=filtered.length>0;
        const missing=data.pedidos.filter(p=>!Number.isFinite(p.lat)||!Number.isFinite(p.lng));
        $('driver-map-missing').textContent=missing.length?`${missing.length} coleta(s) aguardam localização. Consulte o endereço informado na lista.`:'';
        $('driver-map-retry').hidden=!missing.some(p=>p.localizavel);
        status.textContent=`${filtered.length} coleta(s) · Atualizado às ${data.atualizadoEm}`;
    }
    async function locate(force=false){
        if(locating)return;locating=true;let failed=false;$('driver-map-retry').disabled=true;
        const pending=data.pedidos.filter(p=>p.lat===null&&p.localizavel&&(force||!attempted.has(p.chave)));
        for(const p of pending){
            if(attempted.has(p.chave)&&!force)continue;attempted.add(p.chave);
            status.textContent='Consultando os endereços das suas coletas…';const controller=new AbortController(),timer=setTimeout(()=>controller.abort(),35000);
            try{const response=await fetch('mapa.php',{method:'POST',headers:{'Content-Type':'application/json','X-Mapa-CSRF':cfg.csrf},body:JSON.stringify({pedidoId:p.id}),signal:controller.signal});if(!response.ok)throw Error();const pos=await response.json();
                for(const item of data.pedidos)if(item.chave===p.chave){item.lat=Number.isFinite(pos.lat)?pos.lat:null;item.lng=Number.isFinite(pos.lng)?pos.lng:null;item.precisao=pos.precisao;}
            }catch{failed=true;break;}finally{clearTimeout(timer);}
        }
        locating=false;$('driver-map-retry').disabled=false;render();if(failed)status.textContent='Serviço de localização indisponível. Os endereços continuam na lista.';
    }
    $('driver-map-retry').addEventListener('click',()=>locate(true));$('driver-map-search').addEventListener('input',render);
    new ResizeObserver(()=>map.invalidateSize({pan:false})).observe($('driver-map-canvas'));
    setInterval(async()=>{if(document.hidden||locating||refreshing)return;refreshing=true;const controller=new AbortController(),timer=setTimeout(()=>controller.abort(),15000);try{const r=await fetch('mapa.php?dados=1',{cache:'no-store',signal:controller.signal});if(!r.ok)throw Error();const next=await r.json();if(!Array.isArray(next.pedidos))throw Error();data=next;render();locate();}catch{status.textContent='Não foi possível atualizar. Exibindo os últimos dados carregados.';}finally{clearTimeout(timer);refreshing=false;}},60000);
    document.addEventListener('keydown',event=>{if(event.key==='Escape')parent.postMessage({tipo:'ecoagenda-fechar-mapa'},location.origin);});
    render();locate();
})();
