<?php
declare(strict_types=1);
require_once __DIR__.'/motorista_prazos.php';
require_once __DIR__.'/../administrador/mapa_dados.php';

function pedidosMapaMotorista(mysqli $conn, string $email): array
{
    // A identidade vem da sessão. Nenhum email ou endereço livre é aceito do navegador.
    $sql="SELECT a.id,a.descricao,a.data_pedido,a.status,e.id AS endereco_id,
        e.rua,e.numero,e.complemento,e.bairro,e.cep,e.cidade,e.estado
        FROM agendamento a
        LEFT JOIN agendamento_morador_endereco ame ON ame.agendamento_id=a.id AND ame.morador_email=a.morador_email
        LEFT JOIN endereco e ON e.id=ame.endereco_id AND e.email=ame.morador_email
        WHERE EXISTS(SELECT 1 FROM coleta c WHERE c.agendamento_id=a.id AND c.motorista_email=?)
          AND LOWER(a.status) NOT IN ('concluído','concluido')";
    $stmt=$conn->prepare($sql);$stmt->bind_param('s',$email);$stmt->execute();$res=$stmt->get_result();$agrupados=[];
    while($row=$res->fetch_assoc())$agrupados[(int)$row['id']][(string)($row['endereco_id']??'sem')]= $row;
    $stmt->close();$pedidos=[];
    foreach($agrupados as $enderecos){
        $p=reset($enderecos);
        if(count($enderecos)!==1){foreach(['endereco_id','rua','numero','bairro','cep','complemento','cidade','estado'] as $key)$p[$key]=null;}
        $p['prazo_motorista']=prazoMotorista($p);$pedidos[]=$p;
    }
    usort($pedidos,'ordenarUrgenciaMotorista');return $pedidos;
}
function dadosMapaMotorista(array $pedidos): array
{
    $cache=carregarLocalizacoesMapa();$items=[];
    foreach($pedidos as $p){
        $chave=chaveEnderecoMapa($p);$pos=$cache[$chave]??[];
        $valido=!empty($p['endereco_id'])&&!empty($p['rua'])&&!empty($p['numero']);
        $coords=$valido&&isset($pos['lat'],$pos['lng'])&&is_numeric($pos['lat'])&&is_numeric($pos['lng']);
        $endereco=$valido?implode(', ',array_filter([$p['rua'],'nº '.$p['numero'],$p['complemento'],$p['bairro'],$p['cidade'],$p['estado'],$p['cep']?'CEP: '.$p['cep']:null])):'Endereço não disponível';
        $items[]=['id'=>(int)$p['id'],'endereco'=>$endereco,'bairro'=>$p['bairro']??'','material'=>materialMotorista($p['descricao']),
            'status'=>in_array(mb_strtolower($p['status'],'UTF-8'),['encaminhado','confirmado'],true)?'Agendado':$p['status'],'limite'=>$p['prazo_motorista']['limite'],'etiqueta'=>etiquetaPrazoMotorista($p['prazo_motorista']),
            'situacao'=>$p['prazo_motorista']['classe']==='hoje'?'Vence hoje':$p['prazo_motorista']['texto'],
            'urgencia'=>$p['prazo_motorista']['urgencia'],'restantes'=>$p['prazo_motorista']['restantes'],
            'lat'=>$coords?(float)$pos['lat']:null,'lng'=>$coords?(float)$pos['lng']:null,
            'precisao'=>$pos['precisao']??'pendente','localizavel'=>$valido,'chave'=>$chave];
    }
    return ['pedidos'=>$items,'atualizadoEm'=>(new DateTimeImmutable('now',new DateTimeZone('America/Sao_Paulo')))->format('H:i')];
}
