<?php

session_start();

require_once "../../config.php";
require_once "../../login/enviar_email.php";


/* =========================================================
   PROTEÇÃO
========================================================= */

if (
    !isset($_SESSION["email"]) ||
    !isset($_SESSION["cpf"]) ||
    ($_SESSION["perfil"] ?? "") !== "morador"
) {
    header("Location: ../login.html");
    exit();
}

$emailSessao = $_SESSION["email"];
$cpfSessao = $_SESSION["cpf"];

$mensagem = "";
$tipoMensagem = "";
$dadosEmailConfirmados = false;


/* =========================================================
   FUNÇÕES
========================================================= */

function escape($valor): string
{
    return htmlspecialchars((string)$valor, ENT_QUOTES, "UTF-8");
}

/* Ao voltar da etapa de confirmação, cancelar o código pendente e
   retornar ao formulário de edição dos dados gerais. */
if (isset($_GET["cancelar_codigo_dados"]) && $_GET["cancelar_codigo_dados"] === "1") {
    unset(
        $_SESSION["perfil_dados_codigo_hash"],
        $_SESSION["perfil_dados_codigo_expira"],
        $_SESSION["perfil_dados_codigo_email"],
        $_SESSION["perfil_dados_codigo_tentativas"],
        $_SESSION["perfil_dados_codigo_enviado"],
        $_SESSION["perfil_dados_pendentes"]
    );
    header("Location: perfil.php?aba=geral");
    exit();
}


/* =========================================================
   SALVAR DADOS GERAIS
========================================================= */

if ($_SERVER["REQUEST_METHOD"] === "POST") {

    $acao = $_POST["acao"] ?? "";

    if ($acao === "reenviar_codigo_dados" && isset($_SESSION["perfil_dados_pendentes"]) && is_array($_SESSION["perfil_dados_pendentes"])) {
        foreach (["nome", "email", "cpf", "telefone", "nascimento"] as $campoPendente) {
            $_POST[$campoPendente] = $_SESSION["perfil_dados_pendentes"][$campoPendente] ?? "";
        }
        $acao = "geral";
    }

    /* -----------------------------------------------------
       CONFIRMAÇÃO POR E-MAIL PARA ALTERAR DADOS PESSOAIS
       O código é enviado ao e-mail que já está cadastrado.
    ----------------------------------------------------- */

    if ($acao === "confirmar_codigo_dados") {
        $codigoInformadoDados = trim((string)($_POST["codigo_dados"] ?? ""));
        $sessaoCodigoDadosValida =
            !empty($_SESSION["perfil_dados_codigo_enviado"]) &&
            isset($_SESSION["perfil_dados_codigo_hash"], $_SESSION["perfil_dados_codigo_expira"], $_SESSION["perfil_dados_codigo_email"], $_SESSION["perfil_dados_pendentes"]) &&
            hash_equals((string)$_SESSION["perfil_dados_codigo_email"], (string)$emailSessao);

        if (!$sessaoCodigoDadosValida) {
            $mensagem = "Solicite um novo código antes de confirmar a alteração.";
            $tipoMensagem = "erro";
            $acao = "__nao_salvar_dados__";
        } elseif ((int)$_SESSION["perfil_dados_codigo_expira"] < time()) {
            unset($_SESSION["perfil_dados_codigo_hash"], $_SESSION["perfil_dados_codigo_expira"], $_SESSION["perfil_dados_codigo_email"], $_SESSION["perfil_dados_codigo_tentativas"], $_SESSION["perfil_dados_codigo_enviado"], $_SESSION["perfil_dados_pendentes"]);
            $mensagem = "O código expirou. Volte a editar os dados para solicitar outro.";
            $tipoMensagem = "erro";
            $acao = "__nao_salvar_dados__";
        } elseif (!preg_match('/^\d{6}$/', $codigoInformadoDados)) {
            $mensagem = "Informe o código de 6 dígitos recebido por e-mail.";
            $tipoMensagem = "erro";
            $acao = "__nao_salvar_dados__";
        } elseif (!hash_equals((string)$_SESSION["perfil_dados_codigo_hash"], hash('sha256', $codigoInformadoDados))) {
            $_SESSION["perfil_dados_codigo_tentativas"] = (int)($_SESSION["perfil_dados_codigo_tentativas"] ?? 0) + 1;
            if ($_SESSION["perfil_dados_codigo_tentativas"] >= 5) {
                unset($_SESSION["perfil_dados_codigo_hash"], $_SESSION["perfil_dados_codigo_expira"], $_SESSION["perfil_dados_codigo_email"], $_SESSION["perfil_dados_codigo_tentativas"], $_SESSION["perfil_dados_codigo_enviado"], $_SESSION["perfil_dados_pendentes"]);
                $mensagem = "O limite de tentativas foi atingido. Edite os dados novamente para solicitar outro código.";
            } else {
                $mensagem = "Código incorreto. Confira o e-mail e tente novamente.";
            }
            $tipoMensagem = "erro";
            $acao = "__nao_salvar_dados__";
        } else {
            foreach (["nome", "email", "cpf", "telefone", "nascimento"] as $campoPendente) {
                $_POST[$campoPendente] = $_SESSION["perfil_dados_pendentes"][$campoPendente] ?? "";
            }
            $dadosEmailConfirmados = true;
            $acao = "geral";
        }
    }

    /* Primeira etapa: validar os campos e enviar o código, sem salvar ainda. */
    if ($acao === "geral" && !$dadosEmailConfirmados) {
        $nomePendente = trim((string)($_POST["nome"] ?? ""));
        $emailPendente = trim((string)($_POST["email"] ?? ""));
        $cpfPendente = preg_replace('/\D+/', '', (string)($_POST["cpf"] ?? ""));
        $telefonePendente = trim((string)($_POST["telefone"] ?? ""));
        $nascimentoPendente = trim((string)($_POST["nascimento"] ?? ""));

        if ($nomePendente === "" || $emailPendente === "" || $cpfPendente === "" || $telefonePendente === "" || $nascimentoPendente === "") {
            $mensagem = "Preencha todos os campos obrigatórios.";
            $tipoMensagem = "erro";
            $acao = "__nao_salvar_dados__";
        } elseif (!filter_var($emailPendente, FILTER_VALIDATE_EMAIL)) {
            $mensagem = "Informe um e-mail válido.";
            $tipoMensagem = "erro";
            $acao = "__nao_salvar_dados__";
        } elseif (strlen($cpfPendente) !== 11) {
            $mensagem = "Informe um CPF válido com 11 dígitos.";
            $tipoMensagem = "erro";
            $acao = "__nao_salvar_dados__";
        } elseif ($emailPendente === $emailSessao && $cpfPendente === preg_replace('/\D+/', '', (string)$cpfSessao)) {
            /* Alterações de nome, telefone ou nascimento não exigem código. */
            $dadosEmailConfirmados = true;
        } else {
            $codigoDados = (string)random_int(100000, 999999);
            $nomeCodigoSeguro = htmlspecialchars((string)($_SESSION["nome"] ?? "Morador"), ENT_QUOTES, "UTF-8");
            $codigoDadosSeguro = htmlspecialchars($codigoDados, ENT_QUOTES, "UTF-8");
            $htmlEmailDados = "<!DOCTYPE html><html lang='pt-BR'><head><meta charset='UTF-8'></head><body style='margin:0;background:#f5f7f6;font-family:Arial,sans-serif;color:#26342b;'><div style='max-width:560px;margin:40px auto;padding:32px;background:#fff;border-radius:16px;'><h2 style='color:#07612b;'>Confirmação de alteração de dados - EcoAgenda</h2><p>Olá, <strong>{$nomeCodigoSeguro}</strong>.</p><p>Use o código abaixo para confirmar a alteração dos dados do seu perfil.</p><div style='padding:22px;text-align:center;background:#edf7ef;border-radius:12px;'><div style='font-size:13px;color:#5a675f;margin-bottom:8px;'>Seu código de confirmação</div><div style='font-size:36px;letter-spacing:8px;font-weight:700;color:#07612b;'>{$codigoDadosSeguro}</div></div><p>Este código é válido por <strong>15 minutos</strong> e pode ser usado uma única vez.</p><p style='color:#777;font-size:13px;'>Se você não solicitou esta alteração, ignore este e-mail.</p></div></body></html>";

            $textoEmailDados = "Olá, " . ((string)($_SESSION["nome"] ?? "Morador")) . ".

Use o código {$codigoDados} para confirmar a alteração dos dados do seu perfil no EcoAgenda.

Este código é válido por 15 minutos.";

            $erroEmailDados = null;
            $enviadoDados = enviarEmailEcoAgenda(
                $emailSessao,
                "Código para alterar dados - EcoAgenda",
                $htmlEmailDados,
                $textoEmailDados,
                $erroEmailDados
            );

            if (!$enviadoDados) {
                $mensagem = "Não foi possível enviar o código por e-mail. " . ($erroEmailDados ?: "Verifique a configuração do Gmail SMTP.");
                $tipoMensagem = "erro";
                $acao = "__nao_salvar_dados__";
            } else {
                $_SESSION["perfil_dados_pendentes"] = ["nome" => $nomePendente, "email" => $emailPendente, "cpf" => $cpfPendente, "telefone" => $telefonePendente, "nascimento" => $nascimentoPendente];
                $_SESSION["perfil_dados_codigo_hash"] = hash('sha256', $codigoDados);
                $_SESSION["perfil_dados_codigo_expira"] = time() + 900;
                $_SESSION["perfil_dados_codigo_email"] = $emailSessao;
                $_SESSION["perfil_dados_codigo_tentativas"] = 0;
                $_SESSION["perfil_dados_codigo_enviado"] = true;
                header("Location: perfil.php?aba=geral");
                exit();
            }
        }
    }

    /* -----------------------------------------------------
       GERAL
    ----------------------------------------------------- */

    if ($acao === "geral") {

        $nome = trim($_POST["nome"] ?? "");
        $novoEmail = trim($_POST["email"] ?? "");
        $novoCpf = preg_replace('/\D+/', '', (string)($_POST["cpf"] ?? ""));
        $telefone = trim($_POST["telefone"] ?? "");
        $nascimento = trim($_POST["nascimento"] ?? "");

        if ($nome === "" || $novoEmail === "" || $novoCpf === "" || $telefone === "" || $nascimento === "") {
            $mensagem = "Preencha todos os campos obrigatórios.";
            $tipoMensagem = "erro";
        } elseif (!filter_var($novoEmail, FILTER_VALIDATE_EMAIL)) {
            $mensagem = "Informe um e-mail válido.";
            $tipoMensagem = "erro";
        } elseif (strlen($novoCpf) !== 11) {
            $mensagem = "Informe um CPF válido com 11 dígitos.";
            $tipoMensagem = "erro";
        } else {

            $conn->begin_transaction();

            try {

                /* Verificar se o e-mail já pertence a outra conta. */
                $sqlEmail = "
                    SELECT email
                    FROM usuario
                    WHERE email = ?
                      AND email <> ?
                    LIMIT 1
                ";
                $stmtEmail = $conn->prepare($sqlEmail);
                if (!$stmtEmail) {
                    throw new Exception("Erro ao verificar o e-mail: " . $conn->error);
                }
                $stmtEmail->bind_param("ss", $novoEmail, $emailSessao);
                $stmtEmail->execute();
                $emailExiste = $stmtEmail->get_result()->fetch_assoc();
                $stmtEmail->close();

                if ($emailExiste) {
                    throw new Exception("Este e-mail já está cadastrado em outra conta.");
                }

                /* Verificar se o CPF já pertence a outro morador. */
                $sqlCpf = "
                    SELECT email
                    FROM morador
                    WHERE cpf = ?
                      AND email <> ?
                    LIMIT 1
                ";
                $stmtCpf = $conn->prepare($sqlCpf);
                if (!$stmtCpf) {
                    throw new Exception("Erro ao verificar o CPF: " . $conn->error);
                }
                $stmtCpf->bind_param("ss", $novoCpf, $emailSessao);
                $stmtCpf->execute();
                $cpfExiste = $stmtCpf->get_result()->fetch_assoc();
                $stmtCpf->close();

                if ($cpfExiste) {
                    throw new Exception("Este CPF já está cadastrado em outra conta.");
                }

                /* Dados atuais do usuário, necessários para a migração segura do e-mail. */
                $sqlAtual = "
                    SELECT u.senha, u.nome, m.telefone, m.nascimento, m.cpf
                    FROM usuario u
                    INNER JOIN morador m ON m.email = u.email
                    WHERE u.email = ?
                    LIMIT 1
                ";
                $stmtAtual = $conn->prepare($sqlAtual);
                if (!$stmtAtual) {
                    throw new Exception("Erro ao carregar os dados atuais: " . $conn->error);
                }
                $stmtAtual->bind_param("s", $emailSessao);
                $stmtAtual->execute();
                $dadosAtuais = $stmtAtual->get_result()->fetch_assoc();
                $stmtAtual->close();

                if (!$dadosAtuais) {
                    throw new Exception("Cadastro do morador não encontrado.");
                }

                if ($novoEmail !== $emailSessao) {

                    /*
                     * O banco possui FKs NO ACTION em agendamento/endereco/
                     * morador_endereco. Por isso não alteramos a chave do
                     * usuário diretamente. Criamos a nova identidade,
                     * migramos todas as referências e removemos a antiga.
                     */

                    $cpfTemporario = "TMP" . bin2hex(random_bytes(7));

                    $sqlCpfTemporario = "
                        UPDATE morador
                        SET cpf = ?
                        WHERE email = ?
                        LIMIT 1
                    ";
                    $stmtTmpCpf = $conn->prepare($sqlCpfTemporario);
                    if (!$stmtTmpCpf) {
                        throw new Exception("Erro ao preparar atualização temporária do CPF: " . $conn->error);
                    }
                    $stmtTmpCpf->bind_param("ss", $cpfTemporario, $emailSessao);
                    if (!$stmtTmpCpf->execute()) {
                        throw new Exception("Erro ao preparar migração do cadastro: " . $stmtTmpCpf->error);
                    }
                    $stmtTmpCpf->close();

                    /* Criar nova conta de usuário com os mesmos dados de acesso. */
                    $sqlNovoUsuario = "
                        INSERT INTO usuario (email, senha, nome)
                        VALUES (?, ?, ?)
                    ";
                    $stmtNovoUsuario = $conn->prepare($sqlNovoUsuario);
                    if (!$stmtNovoUsuario) {
                        throw new Exception("Erro ao preparar novo e-mail: " . $conn->error);
                    }
                    $senhaAtualHash = $dadosAtuais["senha"];
                    $stmtNovoUsuario->bind_param("sss", $novoEmail, $senhaAtualHash, $nome);
                    if (!$stmtNovoUsuario->execute()) {
                        throw new Exception("Erro ao criar o novo e-mail de acesso: " . $stmtNovoUsuario->error);
                    }
                    $stmtNovoUsuario->close();

                    /* Criar o novo registro do morador. */
                    $sqlNovoMorador = "
                        INSERT INTO morador (email, cpf, telefone, nascimento)
                        VALUES (?, ?, ?, ?)
                    ";
                    $stmtNovoMorador = $conn->prepare($sqlNovoMorador);
                    if (!$stmtNovoMorador) {
                        throw new Exception("Erro ao preparar migração do morador: " . $conn->error);
                    }
                    $stmtNovoMorador->bind_param("ssss", $novoEmail, $novoCpf, $telefone, $nascimento);
                    if (!$stmtNovoMorador->execute()) {
                        throw new Exception("Erro ao criar o novo cadastro do morador: " . $stmtNovoMorador->error);
                    }
                    $stmtNovoMorador->close();

                    /* Copiar endereços e criar a correspondência de IDs. */
                    $sqlEnderecos = "
                        SELECT id, cep, estado, cidade, rua, bairro, numero, complemento
                        FROM endereco
                        WHERE email = ?
                        ORDER BY id ASC
                    ";
                    $stmtEnderecos = $conn->prepare($sqlEnderecos);
                    if (!$stmtEnderecos) {
                        throw new Exception("Erro ao carregar endereços: " . $conn->error);
                    }
                    $stmtEnderecos->bind_param("s", $emailSessao);
                    $stmtEnderecos->execute();
                    $resultadoEnderecos = $stmtEnderecos->get_result();
                    $mapaEnderecos = [];
                    while ($endereco = $resultadoEnderecos->fetch_assoc()) {
                        $sqlNovoEndereco = "
                            INSERT INTO endereco
                            (email, cep, estado, cidade, rua, bairro, numero, complemento)
                            VALUES (?, ?, ?, ?, ?, ?, ?, ?)
                        ";
                        $stmtNovoEndereco = $conn->prepare($sqlNovoEndereco);
                        if (!$stmtNovoEndereco) {
                            throw new Exception("Erro ao preparar cópia do endereço: " . $conn->error);
                        }
                        $stmtNovoEndereco->bind_param(
                            "ssssssss",
                            $novoEmail,
                            $endereco["cep"],
                            $endereco["estado"],
                            $endereco["cidade"],
                            $endereco["rua"],
                            $endereco["bairro"],
                            $endereco["numero"],
                            $endereco["complemento"]
                        );
                        if (!$stmtNovoEndereco->execute()) {
                            throw new Exception("Erro ao copiar endereço: " . $stmtNovoEndereco->error);
                        }
                        $novoEnderecoId = (int)$stmtNovoEndereco->insert_id;
                        $stmtNovoEndereco->close();
                        $mapaEnderecos[(int)$endereco["id"]] = $novoEnderecoId;

                        $sqlNovoVinculo = "
                            INSERT INTO morador_endereco (endereco_id, morador_email)
                            VALUES (?, ?)
                        ";
                        $stmtNovoVinculo = $conn->prepare($sqlNovoVinculo);
                        if (!$stmtNovoVinculo) {
                            throw new Exception("Erro ao preparar vínculo do endereço: " . $conn->error);
                        }
                        $stmtNovoVinculo->bind_param("is", $novoEnderecoId, $novoEmail);
                        if (!$stmtNovoVinculo->execute()) {
                            throw new Exception("Erro ao criar vínculo do endereço: " . $stmtNovoVinculo->error);
                        }
                        $stmtNovoVinculo->close();
                    }
                    $stmtEnderecos->close();

                    /* Copiar vínculos dos pedidos para os novos endereços/morador. */
                    $sqlVinculosAntigos = "
                        SELECT ame.agendamento_id, ame.endereco_id
                        FROM agendamento_morador_endereco ame
                        WHERE ame.morador_email = ?
                    ";
                    $stmtVinculos = $conn->prepare($sqlVinculosAntigos);
                    if (!$stmtVinculos) {
                        throw new Exception("Erro ao carregar vínculos de pedidos: " . $conn->error);
                    }
                    $stmtVinculos->bind_param("s", $emailSessao);
                    $stmtVinculos->execute();
                    $resultadoVinculos = $stmtVinculos->get_result();
                    while ($vinculo = $resultadoVinculos->fetch_assoc()) {
                        $oldEnderecoId = (int)$vinculo["endereco_id"];
                        if (!isset($mapaEnderecos[$oldEnderecoId])) {
                            continue;
                        }
                        $novoEnderecoId = $mapaEnderecos[$oldEnderecoId];

                        $sqlNovoAme = "
                            INSERT INTO agendamento_morador_endereco
                            (agendamento_id, endereco_id, morador_email)
                            VALUES (?, ?, ?)
                        ";
                        $stmtNovoAme = $conn->prepare($sqlNovoAme);
                        if (!$stmtNovoAme) {
                            throw new Exception("Erro ao preparar vínculo dos pedidos: " . $conn->error);
                        }
                        $agendamentoId = (int)$vinculo["agendamento_id"];
                        $stmtNovoAme->bind_param("iis", $agendamentoId, $novoEnderecoId, $novoEmail);
                        if (!$stmtNovoAme->execute()) {
                            throw new Exception("Erro ao copiar vínculo do pedido: " . $stmtNovoAme->error);
                        }
                        $stmtNovoAme->close();
                    }
                    $stmtVinculos->close();

                    /* Atualizar referências dos pedidos para o novo morador. */
                    $sqlUpdateAgendamentos = "
                        UPDATE agendamento
                        SET morador_email = CASE WHEN morador_email = ? THEN ? ELSE morador_email END,
                            criado_por = CASE WHEN criado_por = ? THEN ? ELSE criado_por END
                        WHERE morador_email = ? OR criado_por = ?
                    ";
                    $stmtUpdateAgendamentos = $conn->prepare($sqlUpdateAgendamentos);
                    if (!$stmtUpdateAgendamentos) {
                        throw new Exception("Erro ao preparar atualização dos pedidos: " . $conn->error);
                    }
                    $stmtUpdateAgendamentos->bind_param("ssssss", $emailSessao, $novoEmail, $emailSessao, $novoEmail, $emailSessao, $emailSessao);
                    if (!$stmtUpdateAgendamentos->execute()) {
                        throw new Exception("Erro ao atualizar os pedidos vinculados: " . $stmtUpdateAgendamentos->error);
                    }
                    $stmtUpdateAgendamentos->close();

                    /* Atualizar histórico, que não possui FK para morador/usuário. */
                    $sqlHistorico = "
                        UPDATE agendamento_historico
                        SET morador_email = CASE WHEN morador_email = ? THEN ? ELSE morador_email END,
                            criado_por = CASE WHEN criado_por = ? THEN ? ELSE criado_por END,
                            usuario_logado = CASE WHEN usuario_logado = ? THEN ? ELSE usuario_logado END
                    ";
                    $stmtHistorico = $conn->prepare($sqlHistorico);
                    if (!$stmtHistorico) {
                        throw new Exception("Erro ao preparar atualização do histórico: " . $conn->error);
                    }
                    $stmtHistorico->bind_param("ssssss", $emailSessao, $novoEmail, $emailSessao, $novoEmail, $emailSessao, $novoEmail);
                    if (!$stmtHistorico->execute()) {
                        throw new Exception("Erro ao atualizar o histórico: " . $stmtHistorico->error);
                    }
                    $stmtHistorico->close();

                    /* Remover vínculos/endereço antigos depois da migração. */
                    $stmtDeleteAme = $conn->prepare("DELETE FROM agendamento_morador_endereco WHERE morador_email = ?");
                    if (!$stmtDeleteAme) {
                        throw new Exception("Erro ao preparar limpeza dos vínculos antigos: " . $conn->error);
                    }
                    $stmtDeleteAme->bind_param("s", $emailSessao);
                    if (!$stmtDeleteAme->execute()) {
                        throw new Exception("Erro ao limpar vínculos antigos: " . $stmtDeleteAme->error);
                    }
                    $stmtDeleteAme->close();

                    $stmtDeleteMe = $conn->prepare("DELETE FROM morador_endereco WHERE morador_email = ?");
                    if (!$stmtDeleteMe) {
                        throw new Exception("Erro ao preparar limpeza dos endereços antigos: " . $conn->error);
                    }
                    $stmtDeleteMe->bind_param("s", $emailSessao);
                    if (!$stmtDeleteMe->execute()) {
                        throw new Exception("Erro ao limpar vínculos de endereço antigos: " . $stmtDeleteMe->error);
                    }
                    $stmtDeleteMe->close();

                    $stmtDeleteEndereco = $conn->prepare("DELETE FROM endereco WHERE email = ?");
                    if (!$stmtDeleteEndereco) {
                        throw new Exception("Erro ao preparar exclusão dos endereços antigos: " . $conn->error);
                    }
                    $stmtDeleteEndereco->bind_param("s", $emailSessao);
                    if (!$stmtDeleteEndereco->execute()) {
                        throw new Exception("Erro ao excluir endereços antigos: " . $stmtDeleteEndereco->error);
                    }
                    $stmtDeleteEndereco->close();

                    /* Excluir a identidade antiga somente depois de migrar as FKs. */
                    $stmtDeleteMorador = $conn->prepare("DELETE FROM morador WHERE email = ? LIMIT 1");
                    if (!$stmtDeleteMorador) {
                        throw new Exception("Erro ao preparar exclusão do cadastro antigo: " . $conn->error);
                    }
                    $stmtDeleteMorador->bind_param("s", $emailSessao);
                    if (!$stmtDeleteMorador->execute()) {
                        throw new Exception("Erro ao excluir o cadastro antigo: " . $stmtDeleteMorador->error);
                    }
                    $stmtDeleteMorador->close();

                    $stmtDeleteUsuario = $conn->prepare("DELETE FROM usuario WHERE email = ? LIMIT 1");
                    if (!$stmtDeleteUsuario) {
                        throw new Exception("Erro ao preparar exclusão do acesso antigo: " . $conn->error);
                    }
                    $stmtDeleteUsuario->bind_param("s", $emailSessao);
                    if (!$stmtDeleteUsuario->execute()) {
                        throw new Exception("Erro ao excluir o acesso antigo: " . $stmtDeleteUsuario->error);
                    }
                    $stmtDeleteUsuario->close();

                    $emailSessao = $novoEmail;
                    $cpfSessao = $novoCpf;
                    $_SESSION["email"] = $novoEmail;
                    $_SESSION["cpf"] = $novoCpf;
                } else {

                    /* Sem troca de e-mail: atualização direta dos dados gerais. */
                    $sqlUsuario = "
                        UPDATE usuario
                        SET nome = ?
                        WHERE email = ?
                        LIMIT 1
                    ";
                    $stmtUsuario = $conn->prepare($sqlUsuario);
                    if (!$stmtUsuario) {
                        throw new Exception("Erro ao preparar atualização do usuário: " . $conn->error);
                    }
                    $stmtUsuario->bind_param("ss", $nome, $emailSessao);
                    if (!$stmtUsuario->execute()) {
                        throw new Exception("Erro ao atualizar nome: " . $stmtUsuario->error);
                    }
                    $stmtUsuario->close();

                    $sqlMorador = "
                        UPDATE morador
                        SET cpf = ?, telefone = ?, nascimento = ?
                        WHERE email = ?
                        LIMIT 1
                    ";
                    $stmtMorador = $conn->prepare($sqlMorador);
                    if (!$stmtMorador) {
                        throw new Exception("Erro ao preparar atualização do morador: " . $conn->error);
                    }
                    $stmtMorador->bind_param("ssss", $novoCpf, $telefone, $nascimento, $emailSessao);
                    if (!$stmtMorador->execute()) {
                        throw new Exception("Erro ao atualizar dados do morador: " . $stmtMorador->error);
                    }
                    $stmtMorador->close();
                    $cpfSessao = $novoCpf;
                    $_SESSION["cpf"] = $novoCpf;
                }

                /* Garantir nome atualizado na sessão em qualquer cenário. */
                $_SESSION["nome"] = $nome;

                $conn->commit();

                unset($_SESSION["perfil_dados_codigo_hash"], $_SESSION["perfil_dados_codigo_expira"], $_SESSION["perfil_dados_codigo_email"], $_SESSION["perfil_dados_codigo_tentativas"], $_SESSION["perfil_dados_codigo_enviado"], $_SESSION["perfil_dados_pendentes"]);
                $mensagem = "Seus dados foram atualizados com sucesso.";
                $tipoMensagem = "sucesso";

            } catch (Throwable $e) {

                $conn->rollback();

                $mensagem = $e->getMessage();
                $tipoMensagem = "erro";
            }
        }
    }

    /* -----------------------------------------------------
       ENDEREÇO
    ----------------------------------------------------- */

    if ($acao === "endereco") {

        $cep = trim($_POST["cep"] ?? "");
        $estado = trim($_POST["estado"] ?? "");
        $cidade = trim($_POST["cidade"] ?? "");
        $rua = trim($_POST["rua"] ?? "");
        $bairro = trim($_POST["bairro"] ?? "");
        $numero = trim($_POST["numero"] ?? "");
        $complemento = trim($_POST["complemento"] ?? "");


        if (
            $cep === "" ||
            $estado === "" ||
            $cidade === "" ||
            $rua === "" ||
            $bairro === "" ||
            $numero === ""
        ) {

            $mensagem =
                "Preencha todos os campos obrigatórios do endereço.";

            $tipoMensagem = "erro";

        } else {

            $sqlBuscaEndereco = "
                SELECT id
                FROM endereco
                WHERE email = ?
                ORDER BY id ASC
                LIMIT 1
            ";

            $stmtBusca =
                $conn->prepare($sqlBuscaEndereco);

            if (!$stmtBusca) {

                $mensagem =
                    "Erro ao verificar endereço: " .
                    $conn->error;

                $tipoMensagem = "erro";

            } else {

                $stmtBusca->bind_param(
                    "s",
                    $emailSessao
                );

                $stmtBusca->execute();

                $resultadoBusca =
                    $stmtBusca->get_result();

                $enderecoExistente =
                    $resultadoBusca->fetch_assoc();

                $stmtBusca->close();


                if ($enderecoExistente) {

                    $sqlUpdate = "
                        UPDATE endereco
                        SET
                            cep = ?,
                            estado = ?,
                            cidade = ?,
                            rua = ?,
                            bairro = ?,
                            numero = ?,
                            complemento = ?
                        WHERE id = ?
                        LIMIT 1
                    ";

                    $stmtUpdate =
                        $conn->prepare($sqlUpdate);

                    if (!$stmtUpdate) {

                        $mensagem =
                            "Erro ao preparar atualização do endereço: " .
                            $conn->error;

                        $tipoMensagem = "erro";

                    } else {

                        $idEndereco =
                            (int)$enderecoExistente["id"];

                        $stmtUpdate->bind_param(
                            "sssssssi",
                            $cep,
                            $estado,
                            $cidade,
                            $rua,
                            $bairro,
                            $numero,
                            $complemento,
                            $idEndereco
                        );

                        if ($stmtUpdate->execute()) {

                            $mensagem =
                                "Endereço atualizado com sucesso.";

                            $tipoMensagem = "sucesso";

                        } else {

                            $mensagem =
                                "Erro ao atualizar endereço: " .
                                $stmtUpdate->error;

                            $tipoMensagem = "erro";
                        }

                        $stmtUpdate->close();
                    }

                } else {

                    $sqlInsert = "
                        INSERT INTO endereco
                        (
                            email,
                            cep,
                            estado,
                            cidade,
                            rua,
                            bairro,
                            numero,
                            complemento
                        )
                        VALUES (?, ?, ?, ?, ?, ?, ?, ?)
                    ";

                    $stmtInsert =
                        $conn->prepare($sqlInsert);

                    if (!$stmtInsert) {

                        $mensagem =
                            "Erro ao preparar cadastro do endereço: " .
                            $conn->error;

                        $tipoMensagem = "erro";

                    } else {

                        $stmtInsert->bind_param(
                            "ssssssss",
                            $emailSessao,
                            $cep,
                            $estado,
                            $cidade,
                            $rua,
                            $bairro,
                            $numero,
                            $complemento
                        );

                        if ($stmtInsert->execute()) {

                            $idEnderecoNovo =
                                (int)$stmtInsert->insert_id;

                            $stmtInsert->close();

                            $sqlVinculo = "
                                INSERT IGNORE INTO morador_endereco
                                (endereco_id, morador_email)
                                VALUES (?, ?)
                            ";

                            $stmtVinculo =
                                $conn->prepare($sqlVinculo);

                            if (!$stmtVinculo) {

                                $mensagem =
                                    "Erro ao preparar vínculo do endereço: " .
                                    $conn->error;

                                $tipoMensagem = "erro";

                            } else {

                                $stmtVinculo->bind_param(
                                    "is",
                                    $idEnderecoNovo,
                                    $emailSessao
                                );

                                if ($stmtVinculo->execute()) {

                                    $mensagem =
                                        "Endereço cadastrado com sucesso.";

                                    $tipoMensagem = "sucesso";

                                } else {

                                    $mensagem =
                                        "Erro ao vincular endereço: " .
                                        $stmtVinculo->error;

                                    $tipoMensagem = "erro";
                                }

                                $stmtVinculo->close();
                            }

                        } else {

                            $mensagem =
                                "Erro ao cadastrar endereço: " .
                                $stmtInsert->error;

                            $tipoMensagem = "erro";

                            $stmtInsert->close();
                        }
                    }
                }
            }
        }
    }


    /* -----------------------------------------------------
       SENHA
    ----------------------------------------------------- */

    if ($acao === "solicitar_codigo_senha") {

        $codigoPerfil = (string) random_int(100000, 999999);
        $nomeEmail = trim((string)($_SESSION["nome"] ?? "Morador"));
        $nomeEmailSeguro = htmlspecialchars($nomeEmail !== "" ? $nomeEmail : "Morador", ENT_QUOTES, "UTF-8");
        $codigoEmailSeguro = htmlspecialchars($codigoPerfil, ENT_QUOTES, "UTF-8");

        $htmlEmailPerfil = "<!DOCTYPE html>
<html lang='pt-BR'><head><meta charset='UTF-8'></head>
<body style='margin:0;background:#f5f7f6;font-family:Arial,sans-serif;color:#26342b;'>
  <div style='max-width:560px;margin:40px auto;padding:32px;background:#fff;border-radius:16px;'>
    <h2 style='color:#07612b;'>Confirmação de alteração de senha - EcoAgenda</h2>
    <p>Olá, <strong>{$nomeEmailSeguro}</strong>.</p>
    <p>Use o código abaixo para confirmar a alteração da senha da sua conta EcoAgenda.</p>
    <div style='padding:22px;text-align:center;background:#edf7ef;border-radius:12px;'>
      <div style='font-size:13px;color:#5a675f;margin-bottom:8px;'>Seu código de confirmação</div>
      <div style='font-size:36px;letter-spacing:8px;font-weight:700;color:#07612b;'>{$codigoEmailSeguro}</div>
    </div>
    <p>Este código é válido por <strong>15 minutos</strong> e pode ser usado uma única vez.</p>
    <p style='color:#777;font-size:13px;'>Se você não solicitou essa alteração, ignore este e-mail.</p>
  </div>
</body></html>";

        $textoEmailPerfil = "Olá, {$nomeEmail}.

Use o código {$codigoPerfil} para confirmar a alteração da senha da sua conta EcoAgenda.

Este código é válido por 15 minutos.";

        $erroEmailPerfil = null;
        $enviadoPerfil = enviarEmailEcoAgenda(
            $emailSessao,
            "Código para alterar senha - EcoAgenda",
            $htmlEmailPerfil,
            $textoEmailPerfil,
            $erroEmailPerfil
        );

        if (!$enviadoPerfil) {
            $mensagem = "Não foi possível enviar o código por e-mail. " . ($erroEmailPerfil ?: "Verifique a configuração do Gmail SMTP.");
            $tipoMensagem = "erro";
        } else {
            $_SESSION["perfil_senha_codigo"] = $codigoPerfil;
            $_SESSION["perfil_senha_codigo_expira"] = time() + 900;
            $_SESSION["perfil_senha_codigo_email"] = $emailSessao;
            $_SESSION["perfil_senha_codigo_tentativas"] = 0;
            $_SESSION["perfil_senha_codigo_enviado"] = true;

            $mensagem = "Enviamos um código de confirmação para o seu e-mail cadastrado. Verifique também a caixa de spam.";
            $tipoMensagem = "sucesso";
        }
    }

    if ($acao === "confirmar_codigo_senha") {

        $codigoInformado = trim((string)($_POST["codigo"] ?? ""));
        $novaSenha = (string)($_POST["nova_senha"] ?? "");
        $confirmarSenha = (string)($_POST["confirmar_senha"] ?? "");

        $sessaoCodigoValida =
            !empty($_SESSION["perfil_senha_codigo_enviado"]) &&
            isset($_SESSION["perfil_senha_codigo"], $_SESSION["perfil_senha_codigo_expira"], $_SESSION["perfil_senha_codigo_email"]) &&
            hash_equals((string)$_SESSION["perfil_senha_codigo_email"], (string)$emailSessao);

        if (!$sessaoCodigoValida) {
            $mensagem = "Solicite um novo código de confirmação antes de continuar.";
            $tipoMensagem = "erro";
        } elseif ((int)$_SESSION["perfil_senha_codigo_expira"] < time()) {
            unset($_SESSION["perfil_senha_codigo"], $_SESSION["perfil_senha_codigo_expira"], $_SESSION["perfil_senha_codigo_email"], $_SESSION["perfil_senha_codigo_tentativas"], $_SESSION["perfil_senha_codigo_enviado"]);
            $mensagem = "O código expirou. Solicite um novo código para continuar.";
            $tipoMensagem = "erro";
        } elseif (!preg_match('/^\d{6}$/', $codigoInformado)) {
            $mensagem = "Informe o código de 6 dígitos recebido por e-mail.";
            $tipoMensagem = "erro";
        } elseif ($novaSenha === "" || $confirmarSenha === "") {
            $mensagem = "Preencha a nova senha e a confirmação.";
            $tipoMensagem = "erro";
        } elseif ($novaSenha !== $confirmarSenha) {
            $mensagem = "A nova senha e a confirmação não coincidem.";
            $tipoMensagem = "erro";
        } elseif (strlen($novaSenha) < 6) {
            $mensagem = "A nova senha deve ter pelo menos 6 caracteres.";
            $tipoMensagem = "erro";
        } elseif (!hash_equals((string)$_SESSION["perfil_senha_codigo"], $codigoInformado)) {
            $_SESSION["perfil_senha_codigo_tentativas"] = (int)($_SESSION["perfil_senha_codigo_tentativas"] ?? 0) + 1;
            if ($_SESSION["perfil_senha_codigo_tentativas"] >= 5) {
                unset($_SESSION["perfil_senha_codigo"], $_SESSION["perfil_senha_codigo_expira"], $_SESSION["perfil_senha_codigo_email"], $_SESSION["perfil_senha_codigo_tentativas"], $_SESSION["perfil_senha_codigo_enviado"]);
                $mensagem = "O limite de tentativas foi atingido. Solicite um novo código.";
            } else {
                $mensagem = "Código incorreto. Confira o e-mail e tente novamente.";
            }
            $tipoMensagem = "erro";
        } else {
            $hashNovaSenha = password_hash($novaSenha, PASSWORD_DEFAULT);
            $sqlUpdateSenhaPerfil = "UPDATE usuario SET senha = ? WHERE email = ? LIMIT 1";
            $stmtUpdateSenhaPerfil = $conn->prepare($sqlUpdateSenhaPerfil);

            if (!$stmtUpdateSenhaPerfil) {
                $mensagem = "Erro ao preparar alteração de senha.";
                $tipoMensagem = "erro";
            } else {
                $stmtUpdateSenhaPerfil->bind_param("ss", $hashNovaSenha, $emailSessao);

                if ($stmtUpdateSenhaPerfil->execute() && $stmtUpdateSenhaPerfil->affected_rows >= 0) {
                    unset($_SESSION["perfil_senha_codigo"], $_SESSION["perfil_senha_codigo_expira"], $_SESSION["perfil_senha_codigo_email"], $_SESSION["perfil_senha_codigo_tentativas"], $_SESSION["perfil_senha_codigo_enviado"]);
                    $mensagem = "Senha alterada com sucesso! Você já pode usar a nova senha no próximo acesso.";
                    $tipoMensagem = "sucesso";
                } else {
                    $mensagem = "Não foi possível alterar a senha. Tente novamente.";
                    $tipoMensagem = "erro";
                }

                $stmtUpdateSenhaPerfil->close();
            }
        }
    }
}


$etapaSenha =
    !empty($_SESSION["perfil_senha_codigo_enviado"]) &&
    isset($_SESSION["perfil_senha_codigo_expira"], $_SESSION["perfil_senha_codigo_email"]) &&
    (int)$_SESSION["perfil_senha_codigo_expira"] >= time() &&
    hash_equals((string)$_SESSION["perfil_senha_codigo_email"], (string)$emailSessao);

if (!$etapaSenha && !empty($_SESSION["perfil_senha_codigo_enviado"])) {
    unset($_SESSION["perfil_senha_codigo"], $_SESSION["perfil_senha_codigo_expira"], $_SESSION["perfil_senha_codigo_email"], $_SESSION["perfil_senha_codigo_tentativas"], $_SESSION["perfil_senha_codigo_enviado"]);
}

$etapaDados =
    !empty($_SESSION["perfil_dados_codigo_enviado"]) &&
    isset($_SESSION["perfil_dados_codigo_hash"], $_SESSION["perfil_dados_codigo_expira"], $_SESSION["perfil_dados_codigo_email"], $_SESSION["perfil_dados_pendentes"]) &&
    (int)$_SESSION["perfil_dados_codigo_expira"] >= time() &&
    hash_equals((string)$_SESSION["perfil_dados_codigo_email"], (string)$emailSessao);

if (!$etapaDados && !empty($_SESSION["perfil_dados_codigo_enviado"])) {
    unset($_SESSION["perfil_dados_codigo_hash"], $_SESSION["perfil_dados_codigo_expira"], $_SESSION["perfil_dados_codigo_email"], $_SESSION["perfil_dados_codigo_tentativas"], $_SESSION["perfil_dados_codigo_enviado"], $_SESSION["perfil_dados_pendentes"]);
}


/* =========================================================
   BUSCAR DADOS ATUAIS
========================================================= */

$sqlDados = "
    SELECT
        u.nome,
        u.email,
        m.cpf,
        m.telefone,
        m.nascimento
    FROM usuario u
    INNER JOIN morador m
        ON m.email = u.email
    WHERE u.email = ?
    LIMIT 1
";

$stmtDados = $conn->prepare($sqlDados);

if (!$stmtDados) {
    die("Erro ao carregar perfil: " . $conn->error);
}

$stmtDados->bind_param(
    "s",
    $emailSessao
);

$stmtDados->execute();

$resultadoDados = $stmtDados->get_result();

$dadosUsuario = $resultadoDados->fetch_assoc();

$stmtDados->close();


if (!$dadosUsuario) {
    session_destroy();

    die("Cadastro do morador não encontrado.");
}


/* =========================================================
   BUSCAR ENDEREÇO
========================================================= */

$dadosEndereco = [
    "cep" => "",
    "estado" => "",
    "cidade" => "",
    "rua" => "",
    "bairro" => "",
    "numero" => "",
    "complemento" => ""
];

$sqlEndereco = "
    SELECT
        cep,
        estado,
        cidade,
        rua,
        bairro,
        numero,
        complemento
    FROM endereco
    WHERE email = ?
    ORDER BY id ASC
    LIMIT 1
";

$stmtEndereco =
    $conn->prepare($sqlEndereco);

if ($stmtEndereco) {

    $stmtEndereco->bind_param(
        "s",
        $emailSessao
    );

    $stmtEndereco->execute();

    $resultadoEndereco =
        $stmtEndereco->get_result();

    if ($resultadoEndereco->num_rows > 0) {

        $dadosEndereco =
            $resultadoEndereco->fetch_assoc();
    }

    $stmtEndereco->close();
}


/* =========================================================
   INICIAIS
========================================================= */

$nomeAtual =
    $dadosUsuario["nome"] ?? "Morador";

$partesNome =
    preg_split('/\s+/', trim($nomeAtual));

$iniciais = "";

if (!empty($partesNome[0])) {
    $iniciais .=
        strtoupper(
            substr(
                $partesNome[0],
                0,
                1
            )
        );
}

if (count($partesNome) > 1) {

    $ultimaParte =
        $partesNome[
            count($partesNome) - 1
        ];

    $iniciais .=
        strtoupper(
            substr(
                $ultimaParte,
                0,
                1
            )
        );
}

$iniciais =
    substr(
        $iniciais ?: "M",
        0,
        2
    );


/* =========================================================
   DATA PARA INPUT DATE
========================================================= */

$nascimentoInput = "";

if (!empty($dadosUsuario["nascimento"])) {
    $nascimentoInput =
        date(
            "Y-m-d",
            strtotime(
                $dadosUsuario["nascimento"]
            )
        );
}

?>

<!DOCTYPE html>
<html lang="pt-BR">

<head>

    <meta charset="UTF-8">

    <meta
        name="viewport"
        content="width=device-width, initial-scale=1.0">

    <title>EcoAgenda - Meu Perfil</title>

    <link
        rel="stylesheet"
        href="perfil.css?v=20261001-logo-fix">

<link rel="stylesheet" href="../interface/base.css?v=20261009-4">
<link rel="stylesheet" href="../interface/interface.css?v=20261009-4">
<script src="../interface/interface.js?v=20261009-4" defer></script>
</head>

<body class="eco-interface ea-morador">

<div class="dashboard">


    <!-- =====================================================
         SIDEBAR
    ====================================================== -->

    <aside class="sidebar">

        <div class="logo">
            <img src="../../assets/icons/logo-ecoagenda-branco.png" alt="EcoAgenda">
        </div>

        <nav class="menu">

            <a
                href="dashboard_morador.php"
                class="menu-link">

                <span class="menu-icon">▦</span>
                <span>Dashboard</span>

            </a>

            <a
                href="novo_pedido.php"
                class="menu-link">

                <span class="menu-icon">＋</span>
                <span>Novo Pedido</span>

            </a>

            <a
                href="dashboard_morador.php?secao=acompanhar"
                class="menu-link">

                <span class="menu-icon">◷</span>
                <span>Acompanhar</span>

            </a>

            <a
                href="perfil.php"
                class="menu-link active">

                <img src="../../assets/icons/perfil-branco.png" alt="" aria-hidden="true" class="menu-icon-image perfil-icon-sidebar">
                <span>Perfil</span>

            </a>

        </nav>

    </aside>


    <!-- =====================================================
         MAIN
    ====================================================== -->

    <main class="main">

        <header class="topbar">

            <div class="topbar-left">

                <h1>Seu perfil</h1>

                <p>
                    Altere suas informações quando necessário.
                </p>

            </div>


            <div class="topbar-right">

                <a
                    href="../logout.php"
                    class="logout">

                    Sair

                </a>

                <div class="avatar">

                    <?= escape($iniciais) ?>

                </div>

            </div>

        </header>


        <div class="content">


            <?php if ($mensagem !== ""): ?>

                <div
                    class="mensagem <?= escape($tipoMensagem) ?>">

                    <?= escape($mensagem) ?>

                </div>

            <?php endif; ?>


            <!-- =================================================
                 ABAS
            ================================================== -->

            <div class="tabs">

                <button
                    type="button"
                    class="tab active"
                    data-tab="geral">

                    Geral

                </button>

                <button
                    type="button"
                    class="tab"
                    data-tab="endereco">

                    Endereço

                </button>

                <button
                    type="button"
                    class="tab"
                    data-tab="senha">

                    Senha

                </button>

            </div>


            <!-- =================================================
                 GERAL
            ================================================== -->

            <section
                id="tab-geral"
                class="tab-content active">

                <div class="profile-card">

                    <div class="profile-header">

                        <div class="big-avatar">

                            <?= escape($iniciais) ?>

                        </div>

                        <div class="profile-identification">

                            <span class="name-badge">

                                <?= escape(
                                    $dadosUsuario["nome"]
                                ) ?>

                            </span>

                            <strong>
                                <?= escape(
                                    $dadosUsuario["email"]
                                ) ?>
                            </strong>

                            <strong>
                                <?= escape(
                                    $dadosUsuario["telefone"]
                                ) ?>
                            </strong>

                        </div>

                    </div>


                    <?php if (!$etapaDados): ?>

                    <form
                        method="POST"
                        class="profile-form">

                        <input
                            type="hidden"
                            name="acao"
                            value="geral">


                        <div class="grid-2">

                            <div class="field">

                                <label for="nome">
                                    Nome completo*
                                </label>

                                <input
                                    type="text"
                                    id="nome"
                                    name="nome"
                                    value="<?= escape(
                                        $dadosUsuario["nome"]
                                    ) ?>"
                                    required>

                            </div>


                            <div class="field">

                                <label for="nascimento">
                                    Data de nascimento*
                                </label>

                                <input
                                    type="date"
                                    id="nascimento"
                                    name="nascimento"
                                    value="<?= escape(
                                        $nascimentoInput
                                    ) ?>"
                                    required>

                            </div>

                        </div>


                        <div class="field">

                            <label for="cpf">
                                CPF
                            </label>

                            <input
                                type="text"
                                id="cpf"
                                name="cpf"
                                value="<?= escape(
                                    $dadosUsuario["cpf"]
                                ) ?>"
                                maxlength="11"
                                inputmode="numeric"
                                required>

                            <small>
                                O CPF pode ser alterado. Ele deve possuir 11 dígitos e não pode pertencer a outro cadastro.
                            </small>

                        </div>


                        <div class="field">

                            <label for="email">
                                E-mail
                            </label>

                            <input
                                type="email"
                                id="email"
                                name="email"
                                value="<?= escape(
                                    $dadosUsuario["email"]
                                ) ?>"
                                required>

                            <small>
                                O e-mail pode ser alterado e será usado para o próximo acesso ao sistema.
                            </small>

                        </div>


                        <div class="field">

                            <label for="telefone">
                                Telefone*
                            </label>

                            <input
                                type="text"
                                id="telefone"
                                name="telefone"
                                value="<?= escape(
                                    $dadosUsuario["telefone"]
                                ) ?>"
                                required>

                        </div>


                        <div class="actions">

                            <a
                                href="dashboard_morador.php"
                                class="btn secondary">

                                Voltar

                            </a>

                            <button
                                type="submit"
                                class="btn primary">

                                Alterar dados

                            </button>

                        </div>

                    </form>

                    <?php else: ?>

                    <div class="password-help" style="margin: 18px 0;">
                        Enviamos um código de 6 dígitos para o e-mail atualmente cadastrado. Informe o código para confirmar as alterações. Ele expira em 15 minutos.
                    </div>

                    <form method="POST" action="perfil.php?aba=geral" class="profile-form" id="formConfirmarDados">
                        <input type="hidden" name="acao" value="confirmar_codigo_dados">
                        <div class="field">
                            <label for="codigo_dados">Código recebido por e-mail*</label>
                            <input type="text" id="codigo_dados" name="codigo_dados" inputmode="numeric" pattern="[0-9]{6}" maxlength="6" autocomplete="one-time-code" required>
                        </div>
                        <div class="actions">
                            <a href="perfil.php?aba=geral&amp;cancelar_codigo_dados=1" class="btn secondary">Voltar</a>
                            <button type="submit" class="btn primary">Confirmar alterações</button>
                        </div>
                    </form>

                    <form method="POST" action="perfil.php?aba=geral" style="margin-top: 12px;">
                        <input type="hidden" name="acao" value="reenviar_codigo_dados">
                        <button type="submit" class="btn secondary">Enviar outro código</button>
                    </form>

                    <?php endif; ?>

                </div>

            </section>


            <!-- =================================================
                 ENDEREÇO
            ================================================== -->

            <section
                id="tab-endereco"
                class="tab-content">

                <div class="profile-card">

                    <div class="card-title">

                        <div>
                            <h2>Seu endereço</h2>

                            <p>
                                Mantenha seu endereço atualizado.
                            </p>
                        </div>

                        <span class="pin">
                            <img
                                src="../../assets/icons/endereco-verde.png"
                                alt="Endereço"
                                class="profile-title-icon">
                        </span>

                    </div>


                    <form
                        method="POST"
                        class="profile-form">

                        <input
                            type="hidden"
                            name="acao"
                            value="endereco">


                        <div class="field">

                            <label for="cep">
                                CEP*
                            </label>

                            <input
                                type="text"
                                id="cep"
                                name="cep"
                                value="<?= escape(
                                    $dadosEndereco["cep"]
                                ) ?>"
                                maxlength="9"
                                required>

                        </div>


                        <div class="grid-2">

                            <div class="field">

                                <label for="estado">
                                    Estado*
                                </label>

                                <input
                                    type="text"
                                    id="estado"
                                    name="estado"
                                    value="<?= escape(
                                        $dadosEndereco["estado"]
                                    ) ?>"
                                    readonly
                                    required>

                            </div>


                            <div class="field">

                                <label for="cidade">
                                    Cidade*
                                </label>

                                <input
                                    type="text"
                                    id="cidade"
                                    name="cidade"
                                    value="<?= escape(
                                        $dadosEndereco["cidade"]
                                    ) ?>"
                                    readonly
                                    required>

                            </div>

                        </div>


                        <div class="field">

                            <label for="rua">
                                Rua*
                            </label>

                            <input
                                type="text"
                                id="rua"
                                name="rua"
                                value="<?= escape(
                                    $dadosEndereco["rua"]
                                ) ?>"
                                readonly
                                required>

                        </div>


                        <div class="field">

                            <label for="bairro">
                                Bairro*
                            </label>

                            <input
                                type="text"
                                id="bairro"
                                name="bairro"
                                value="<?= escape(
                                    $dadosEndereco["bairro"]
                                ) ?>"
                                readonly
                                required>

                        </div>


                        <div class="grid-2">

                            <div class="field">

                                <label for="numero">
                                    Número*
                                </label>

                                <input
                                    type="text"
                                    id="numero"
                                    name="numero"
                                    value="<?= escape(
                                        $dadosEndereco["numero"]
                                    ) ?>"
                                    required>

                            </div>


                            <div class="field">

                                <label for="complemento">
                                    Complemento
                                </label>

                                <input
                                    type="text"
                                    id="complemento"
                                    name="complemento"
                                    value="<?= escape(
                                        $dadosEndereco["complemento"]
                                    ) ?>">

                            </div>

                        </div>


                        <div class="location-warning">

                            Seu endereço cadastrado pode ser de qualquer cidade.
                            Para solicitar uma coleta, o endereço informado no pedido
                            deve estar localizado em <strong>Pinhais/PR</strong>.

                        </div>


                        <div class="actions">

                            <a
                                href="dashboard_morador.php"
                                class="btn secondary">

                                Voltar

                            </a>

                            <button
                                type="submit"
                                class="btn primary">

                                Salvar endereço

                            </button>

                        </div>

                    </form>

                </div>

            </section>


            <!-- =================================================
                 SENHA
            ================================================== -->

            <section
                id="tab-senha"
                class="tab-content">

                <div class="profile-card password-card">

                    <div class="card-title">

                        <div>
                            <h2>Alterar senha</h2>

                            <p>
                                Atualize sua senha de acesso.
                            </p>
                        </div>

                        <span class="pin">
                            <img
                                src="../../assets/icons/recuperar-senha-verde.png"
                                alt="Senha"
                                class="profile-title-icon">
                        </span>

                    </div>


                    <?php if (!$etapaSenha): ?>

                        <div class="password-help" style="margin: 18px 0;">
                            Para proteger sua conta, enviaremos um código de confirmação para o e-mail cadastrado.
                        </div>

                        <form method="POST" action="perfil.php?aba=senha" class="profile-form">
                            <input type="hidden" name="acao" value="solicitar_codigo_senha">
                            <div class="actions">
                                <a href="dashboard_morador.php" class="btn secondary">Voltar</a>
                                <button type="submit" class="btn primary">Enviar código por e-mail</button>
                            </div>
                        </form>

                    <?php else: ?>

                        <p class="password-help" style="margin: 18px 0;">
                            Digite o código de 6 dígitos enviado ao seu e-mail e escolha uma nova senha. O código expira em 15 minutos.
                        </p>

                        <form method="POST" action="perfil.php?aba=senha" class="profile-form" id="formConfirmarSenha">
                            <input type="hidden" name="acao" value="confirmar_codigo_senha">

                            <div class="field">
                                <label for="codigo">Código recebido por e-mail*</label>
                                <input type="text" id="codigo" name="codigo" inputmode="numeric" pattern="[0-9]{6}" maxlength="6" autocomplete="one-time-code" required>
                            </div>

                            <div class="field">
                                <label for="nova_senha">Nova senha*</label>
                                <input type="password" id="nova_senha" name="nova_senha" minlength="6" autocomplete="new-password" required>
                            </div>

                            <div class="field">
                                <label for="confirmar_senha">Confirmar nova senha*</label>
                                <input type="password" id="confirmar_senha" name="confirmar_senha" minlength="6" autocomplete="new-password" required>
                            </div>

                            <div id="senhaDiferente" class="client-error" hidden>As senhas não coincidem.</div>
                            <div class="password-help">Use pelo menos 6 caracteres.</div>

                            <div class="actions">
                                <a href="perfil.php?aba=senha" class="btn secondary">Voltar</a>
                                <button type="submit" class="btn primary">Confirmar e alterar senha</button>
                            </div>
                        </form>

                        <form method="POST" action="perfil.php?aba=senha" style="margin-top: 12px;">
                            <input type="hidden" name="acao" value="solicitar_codigo_senha">
                            <button type="submit" class="btn secondary">Enviar outro código</button>
                        </form>

                    <?php endif; ?>

                </div>

            </section>


        </div>

    </main>

</div>


<script src="perfil.js?v=20261001-logo-fix"></script>

</body>
</html>
