<?php
session_start();

if (!isset($_SESSION["email"]) || ($_SESSION["perfil"] ?? "") !== "morador") {
    header("Location: ../login.html");
    exit();
}

$nome = $_SESSION["nome"] ?? "Morador";

$partesNome = preg_split('/\s+/', trim($nome));
$iniciais = "";

if (!empty($partesNome[0])) {
    $iniciais .= strtoupper(substr($partesNome[0], 0, 1));
}

if (count($partesNome) > 1) {
    $ultimaParte = $partesNome[count($partesNome) - 1];
    $iniciais .= strtoupper(substr($ultimaParte, 0, 1));
}

$iniciais = substr($iniciais ?: "M", 0, 2);
?>
<!DOCTYPE html>
<html lang="pt-BR">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="description" content="Novo pedido de coleta - EcoAgenda">
    <title>EcoAgenda - Novo Pedido</title>
    <link rel="stylesheet" href="novo_pedido.css?v=20261001-logo-fix">
<link rel="stylesheet" href="../interface/base.css?v=20261009">
<link rel="stylesheet" href="../interface/interface.css?v=20261009-3">
<script src="../interface/interface.js?v=20261009-3" defer></script>
</head>

<body class="eco-interface ea-morador">

<div class="dashboard">

    <aside class="sidebar">

        <div class="logo"><img src="../../assets/icons/logo-ecoagenda-branco.png" alt="EcoAgenda"></div>

        <nav class="menu">

            <a href="dashboard_morador.php" class="menu-link">
                <span class="menu-icon">▦</span>
                <span>Dashboard</span>
            </a>

            <a href="novo_pedido.php" class="menu-link active">
                <span class="menu-icon">＋</span>
                <span>Novo Pedido</span>
            </a>

            <a href="dashboard_morador.php?secao=acompanhar" class="menu-link">
                <span class="menu-icon">◷</span>
                <span>Acompanhar</span>
            </a>

            <a href="perfil.php" class="menu-link">
                <img src="../../assets/icons/perfil-branco.png" alt="" aria-hidden="true" class="menu-icon-image perfil-icon-sidebar">
                <span>Perfil</span>
            </a>
            </a>

        </nav>

    </aside>


    <main class="main">

        <header class="topbar">

            <div class="topbar-left">
                <h1>Novo pedido de coleta</h1>
                <p>Preencha as informações abaixo para solicitar a coleta.</p>
            </div>

            <div class="topbar-right">

                <a href="../logout.php" class="logout">
                    Sair
                </a>

                <div class="avatar">
                    <?= htmlspecialchars($iniciais) ?>
                </div>

            </div>

        </header>


        <div class="content">

            <div class="form-card">

                <!-- =================================================
                     TIPO DE RESÍDUO
                ================================================== -->

                <div class="field">

                    <label for="tipo_residuo">
                        Tipo de resíduo
                        <span>(OBS: Não realizamos a coleta de colchões)*</span>
                    </label>

                    <input
                        type="text"
                        id="tipo_residuo"
                        placeholder="Ex.: móveis, cama, entulho de madeira..."
                        maxlength="100"
                    >

                </div>


                <!-- =================================================
                     QUANTIDADE
                ================================================== -->

                <div class="field">

                    <label for="quantidade">
                        Quantidade aproximada
                        <span class="optional">(opcional)</span>
                    </label>

                    <input
                        type="text"
                        id="quantidade"
                        placeholder="Ex.: 3 sofás, 2 portas..."
                        maxlength="100"
                    >

                </div>


                <!-- =================================================
                     ENDEREÇO CADASTRADO
                ================================================== -->

                <div
                    id="enderecoCadastrado"
                    class="address-card"
                >

                    <div class="address-title">
                        <strong>Seu endereço cadastrado</strong>
                    </div>

                    <div
                        id="textoEndereco"
                        class="address-text"
                    >
                        Carregando endereço...
                    </div>

                    <p class="address-question">
                        <strong>O endereço da coleta é este?</strong>
                    </p>

                    <div
                        id="confirmacaoEndereco"
                        class="address-selected-message"
                        hidden
                    >
                        ✓ <strong>Endereço selecionado para esta solicitação.</strong>
                        Este será o local considerado para a coleta.
                    </div>

                    <div class="address-actions">

                        <button
                            type="button"
                            class="btn green-btn"
                            id="btnUsarEndereco"
                        >
                            Sim, usar este endereço
                        </button>

                        <button
                            type="button"
                            class="btn outline-btn"
                            id="btnOutroEndereco"
                        >
                            Não, informar outro
                        </button>

                    </div>

                </div>


                <!-- =================================================
                     OUTRO ENDEREÇO
                ================================================== -->

                <div
                    id="outroEndereco"
                    class="other-address"
                    hidden
                >

                    <div class="address-title">
                        <strong>Endereço da coleta</strong>
                    </div>

                    <p class="address-help">
                        A coleta deve ser realizada somente em
                        <strong>Pinhais/PR</strong>.
                    </p>


                    <div class="field">

                        <label for="cep">
                            CEP*
                        </label>

                        <input
                            type="text"
                            id="cep"
                            placeholder="XXXXX-XXX"
                            maxlength="9"
                            inputmode="numeric"
                        >

                    </div>


                    <div class="grid-2">

                        <div class="field">

                            <label for="estado">
                                Estado
                            </label>

                            <input
                                type="text"
                                id="estado"
                                readonly
                            >

                        </div>

                        <div class="field">

                            <label for="cidade">
                                Cidade
                            </label>

                            <input
                                type="text"
                                id="cidade"
                                readonly
                            >

                        </div>

                    </div>


                    <div class="field">

                        <label for="rua">
                            Logradouro
                        </label>

                        <input
                            type="text"
                            id="rua"
                            readonly
                        >

                    </div>


                    <div class="field">

                        <label for="bairro">
                            Bairro
                        </label>

                        <input
                            type="text"
                            id="bairro"
                            readonly
                        >

                    </div>


                    <div class="grid-2">

                        <div class="field">

                            <label for="numero">
                                Número*
                            </label>

                            <input
                                type="text"
                                id="numero"
                                placeholder="Ex.: 123"
                                maxlength="20"
                            >

                        </div>

                        <div class="field">

                            <label for="complemento">
                                Complemento
                                <span class="optional">(opcional)</span>
                            </label>

                            <input
                                type="text"
                                id="complemento"
                                placeholder="Ex.: casa, bloco, apto."
                                maxlength="100"
                            >

                        </div>

                    </div>

                </div>


                <!-- =================================================
                     DESCRIÇÃO
                ================================================== -->

                <div class="field">

                    <label for="descricao">
                        Descrição do material*
                    </label>

                    <textarea
                        id="descricao"
                        rows="5"
                        maxlength="1000"
                        placeholder="Descreva o estado dos materiais, tamanho, condição..."
                    ></textarea>

                </div>


                <!-- =================================================
                     FOTO
                ================================================== -->

                <div class="field">

                    <label for="foto">
                        Foto do resíduo
                    </label>

                    <div
                        class="upload-box"
                        id="uploadBox"
                    >

                        <input
                            type="file"
                            id="foto"
                            accept="image/jpeg,image/png,image/webp"
                        >

                        <div class="upload-icon">
                            <img
                                src="../../assets/icons/foto-verde.png"
                                alt=""
                                aria-hidden="true"
                            >
                        </div>

                        <div class="upload-main">
                            Arraste fotos aqui ou clique para enviar
                        </div>

                        <div class="upload-help">
                            JPG, PNG ou WEBP • até 5 MB
                        </div>

                    </div>


                    <div
                        id="previewContainer"
                        class="preview-container"
                        hidden
                    >

                        <img
                            id="previewFoto"
                            src=""
                            alt="Pré-visualização da foto"
                        >

                        <button
                            type="button"
                            id="removerFoto"
                            class="remove-photo"
                        >
                            Remover foto
                        </button>

                    </div>

                </div>


                <!-- =================================================
                     BOTÕES
                ================================================== -->

                <div class="actions">

                    <a
                        href="dashboard_morador.php"
                        class="btn back-btn"
                    >
                        Voltar
                    </a>

                    <button
                        type="button"
                        id="enviarPedido"
                        class="btn submit-btn"
                    >
                        Enviar pedido
                    </button>

                </div>


                <div
                    id="mensagem"
                    class="message"
                    hidden
                ></div>

            </div>

        </div>

    </main>

</div>

<!-- MODAL PEDIDO ENVIADO -->
<div class="pedido-enviado-modal" id="pedidoEnviadoModal" hidden>
    <div class="pedido-enviado-box" role="dialog" aria-modal="true" aria-labelledby="pedidoEnviadoTitulo">
        <div class="pedido-enviado-icone">✓</div>
        <span class="pedido-enviado-etapa">Solicitação registrada</span>
        <h2 id="pedidoEnviadoTitulo">Pedido enviado com sucesso!</h2>

        <p id="pedidoEnviadoTexto">
            Seu pedido foi encaminhado para a Secretaria Municipal de Meio Ambiente da Prefeitura de Pinhais e está em análise.
        </p>

        <p class="pedido-enviado-orientacao">
            A Secretaria irá analisar a solicitação e, após a aprovação, encaminhá-la para um motorista. Enquanto isso, você pode acompanhar o status do pedido na área <strong>Acompanhar</strong> do Dashboard.
        </p>

        <a
            href="dashboard_morador.php?secao=acompanhar"
            class="pedido-enviado-btn"
            id="btnAcompanharPedido"
        >
            Acompanhar pedido
        </a>
    </div>
</div>

<script src="novo_pedido.js?v=20261001-logo-fix"></script>

</body>
</html>
