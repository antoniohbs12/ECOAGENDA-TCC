<?php

session_start();

require_once "../../config.php";

/*
|--------------------------------------------------------------------------
| PROTEÇÃO DO DASHBOARD
|--------------------------------------------------------------------------
*/

if (
    !isset($_SESSION["email"]) ||
    !isset($_SESSION["perfil"])
) {
    header("Location: ../login.html");
    exit();
}

if ($_SESSION["perfil"] !== "morador") {
    session_destroy();
    header("Location: ../login.html");
    exit();
}


/*
|--------------------------------------------------------------------------
| DADOS DO USUÁRIO
|--------------------------------------------------------------------------
*/

$email = $_SESSION["email"];
$nome  = $_SESSION["nome"] ?? "Morador";
$cpf   = $_SESSION["cpf"] ?? "";


/*
|--------------------------------------------------------------------------
| BUSCAR CPF DO MORADOR
|--------------------------------------------------------------------------
*/

if ($cpf === "") {

    $sqlCpf = "
        SELECT cpf
        FROM morador
        WHERE email = ?
        LIMIT 1
    ";

    $stmtCpf = $conn->prepare($sqlCpf);

    if ($stmtCpf) {

        $stmtCpf->bind_param("s", $email);
        $stmtCpf->execute();

        $resultadoCpf = $stmtCpf->get_result();

        if ($resultadoCpf->num_rows > 0) {

            $morador = $resultadoCpf->fetch_assoc();
            $cpf = $morador["cpf"];
            $_SESSION["cpf"] = $cpf;
        }

        $stmtCpf->close();
    }
}


/*
|--------------------------------------------------------------------------
| CONTADORES
|--------------------------------------------------------------------------
*/

$totalPedidos  = 0;
$pendentes     = 0;
$confirmados   = 0;
$aCaminho      = 0;
$emAndamento   = 0;
$concluidos    = 0;
$cancelados    = 0;

$sqlContadores = "
    SELECT
        COUNT(*) AS total,
        SUM(CASE WHEN a.status = 'Em análise' THEN 1 ELSE 0 END) AS pendentes,
        SUM(CASE WHEN a.status IN ('Agendado', 'Encaminhado') THEN 1 ELSE 0 END) AS confirmados,
        SUM(CASE WHEN a.status = 'A caminho' THEN 1 ELSE 0 END) AS a_caminho,
        SUM(CASE WHEN a.status = 'Em andamento' THEN 1 ELSE 0 END) AS em_andamento,
        SUM(CASE WHEN a.status = 'Concluído' THEN 1 ELSE 0 END) AS concluidos,
        SUM(CASE WHEN a.status IN ('Suspenso', 'Cancelado') THEN 1 ELSE 0 END) AS cancelados
    FROM agendamento a
    WHERE a.morador_email = ?
";

$stmtContadores = $conn->prepare($sqlContadores);

if ($stmtContadores) {

    $stmtContadores->bind_param("s", $email);
    $stmtContadores->execute();

    $resultadoContadores = $stmtContadores->get_result();

    if ($resultadoContadores->num_rows > 0) {

        $dados = $resultadoContadores->fetch_assoc();

        $totalPedidos = (int)($dados["total"] ?? 0);
        $pendentes    = (int)($dados["pendentes"] ?? 0);
        $confirmados  = (int)($dados["confirmados"] ?? 0);
        $aCaminho    = (int)($dados["a_caminho"] ?? 0);
        $emAndamento  = (int)($dados["em_andamento"] ?? 0);
        $concluidos   = (int)($dados["concluidos"] ?? 0);
        $cancelados   = (int)($dados["cancelados"] ?? 0);
    }

    $stmtContadores->close();
}


/*
|--------------------------------------------------------------------------
| TODOS OS PEDIDOS DO MORADOR
|--------------------------------------------------------------------------
|
| O acompanhamento agora acontece dentro do próprio dashboard.
| Não existe mais limite de 5 pedidos nem redirecionamento para
| meus_pedidos.php.
|
| A estrutura utiliza exclusivamente as tabelas do banco atual:
| agendamento, endereco, agendamento_morador_endereco, coleta,
| motorista e usuario.
|--------------------------------------------------------------------------
*/

$pedidos = [];

$sqlPedidos = "
    SELECT
        a.id,
        a.criado_por,
        a.descricao,
        a.data_pedido,
        a.foto,
        a.status,

        e.cep,
        e.estado,
        e.cidade,
        e.rua,
        e.bairro,
        e.numero,
        e.complemento

    FROM agendamento a

    LEFT JOIN endereco e
        ON e.id = (
            SELECT ame.endereco_id
            FROM agendamento_morador_endereco ame
            WHERE ame.agendamento_id = a.id
              AND ame.morador_email = a.morador_email
            ORDER BY ame.endereco_id DESC
            LIMIT 1
        )


    WHERE a.morador_email = ?

    ORDER BY a.id DESC
";

$stmtPedidos = $conn->prepare($sqlPedidos);

if ($stmtPedidos) {

    $stmtPedidos->bind_param("s", $email);
    $stmtPedidos->execute();

    $resultadoPedidos = $stmtPedidos->get_result();

    while ($pedido = $resultadoPedidos->fetch_assoc()) {
        $pedidos[] = $pedido;
    }

    $stmtPedidos->close();
}


/*
|--------------------------------------------------------------------------
| FUNÇÕES DE APOIO
|--------------------------------------------------------------------------
*/

function statusExibicao(?string $status): string
{
    $normalizado = mb_strtolower(trim((string)$status), "UTF-8");

    return match ($normalizado) {
        "encaminhado", "agendado", "confirmado" => "Agendado",
        "suspenso", "cancelado" => "Suspenso",
        default => $status ?: "Em análise"
    };
}

function classeStatus(string $status): string
{
    return match (
        mb_strtolower(trim($status), "UTF-8")
    ) {
        "em análise", "em analise" => "status-analise",
        "agendado" => "status-agendado",
        "a caminho" => "status-caminho",
        "em andamento" => "status-andamento",
        "concluído", "concluido" => "status-concluido",
        "suspenso", "cancelado" => "status-cancelado",
        default => "status-padrao"
    };
}

function formatarData(?string $data): string
{
    if (empty($data)) {
        return "—";
    }

    $timestamp = strtotime($data);

    return $timestamp
        ? date("d/m/Y", $timestamp)
        : "—";
}

function escapeHtml(?string $valor): string
{
    return htmlspecialchars(
        (string)$valor,
        ENT_QUOTES,
        "UTF-8"
    );
}

function caminhoFoto(?string $caminho): ?string
{
    if (empty($caminho)) {
        return null;
    }

    $caminho = ltrim($caminho, "/\\");

    $arquivoFisico = __DIR__ . "/../../agendamento/" . $caminho;

    if (!is_file($arquivoFisico)) {
        return null;
    }

    return "../../agendamento/" . str_replace("\\", "/", $caminho);
}

function etapaAtiva(string $status, int $etapa): bool
{
    $statusNormalizado = mb_strtolower(trim($status), "UTF-8");

    if (in_array($statusNormalizado, ["suspenso", "cancelado"], true)) {
        return false;
    }

    $ordem = [
        "em análise" => 1,
        "em analise" => 1,
        "agendado" => 2,
        "a caminho" => 3,
        "em andamento" => 4,
        "concluído" => 5,
        "concluido" => 5
    ];

    $etapaAtual = $ordem[$statusNormalizado] ?? 1;

    return $etapa <= $etapaAtual;
}

function explicacaoStatus(string $status): string
{
    return match (mb_strtolower(trim($status), "UTF-8")) {
        "em análise", "em analise" => "Sua solicitação foi recebida e está sendo analisada pela Secretaria.",
        "agendado", "encaminhado" => "A solicitação foi aprovada e encaminhada para um motorista. Aguarde o início do deslocamento.",
        "a caminho" => "O motorista iniciou o deslocamento até o endereço informado para realizar a coleta.",
        "em andamento" => "O motorista chegou ao local e a coleta está sendo realizada.",
        "concluído", "concluido" => "A coleta foi realizada e o pedido foi finalizado.",
        "suspenso", "cancelado" => "A coleta foi suspensa por uma ocorrência registrada no atendimento.",
        default => "Acompanhe aqui a atualização do seu pedido."
    };
}


function etapaAtualStatus(string $status): int
{
    return match (mb_strtolower(trim($status), "UTF-8")) {
        "em análise", "em analise" => 1,
        "agendado" => 2,
        "a caminho" => 3,
        "em andamento" => 4,
        "concluído", "concluido" => 5,
        default => 0
    };
}

function progressoStatus(string $status): string
{
    return match (etapaAtualStatus($status)) {
        1 => "10%",
        2 => "30%",
        3 => "50%",
        4 => "70%",
        5 => "90%",
        default => "10%"
    };
}


function etapasStatus(string $status): array
{
    return [
        [
            "numero" => 1,
            "nome" => "Em análise",
            "ativo" => etapaAtiva($status, 1)
        ],
        [
            "numero" => 2,
            "nome" => "Agendado",
            "ativo" => etapaAtiva($status, 2)
        ],
        [
            "numero" => 3,
            "nome" => "A caminho",
            "ativo" => etapaAtiva($status, 3)
        ],
        [
            "numero" => 4,
            "nome" => "Em andamento",
            "ativo" => etapaAtiva($status, 4)
        ],
        [
            "numero" => 5,
            "nome" => "Concluído",
            "ativo" => etapaAtiva($status, 5)
        ]
    ];
}


function chaveFiltroStatus(string $status): string
{
    return match (mb_strtolower(trim($status), "UTF-8")) {
        "em análise", "em analise" => "analise",
        "agendado" => "agendado",
        "a caminho" => "caminho",
        "em andamento" => "andamento",
        "concluído", "concluido" => "concluido",
        "suspenso", "cancelado" => "suspenso",
        default => "outro"
    };
}


/*
|--------------------------------------------------------------------------
| INICIAIS DO USUÁRIO
|--------------------------------------------------------------------------
*/

$partesNome = preg_split('/\s+/', trim($nome));
$iniciais = "";

if (!empty($partesNome[0])) {
    $iniciais .= strtoupper(substr($partesNome[0], 0, 1));
}

if (count($partesNome) > 1) {
    $ultimaParte = $partesNome[count($partesNome) - 1];
    $iniciais .= strtoupper(substr($ultimaParte, 0, 1));
}

$iniciais = substr($iniciais ?: "M", 0, 2);

/*
|--------------------------------------------------------------------------
| SEÇÃO ATUAL
|--------------------------------------------------------------------------
| A navegação continua dentro do próprio dashboard.
| inicio      = painel principal
| acompanhar  = acompanhamento detalhado dos pedidos
|--------------------------------------------------------------------------
*/
$secao = (($_GET["secao"] ?? "inicio") === "acompanhar")
    ? "acompanhar"
    : "inicio";

?>
<?php require_once __DIR__ . "/../interface/pedidos.php"; ?>
<!DOCTYPE html>
<html lang="pt-BR">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="description" content="Dashboard do Morador - EcoAgenda">
    <title>
        <?= $secao === "acompanhar" ? "EcoAgenda - Meus Pedidos" : "EcoAgenda - Dashboard" ?>
    </title>
    <link rel="stylesheet" href="dashboard_morador.css?v=20261001-logo-fix">
<link rel="stylesheet" href="../interface/base.css?v=20261009">
<link rel="stylesheet" href="../interface/interface.css?v=20261009-3">
<script src="../interface/interface.js?v=20261009-3" defer></script>
<script src="../interface/pedidos.js?v=20261009-3" defer></script>
</head>

<body class="eco-interface ea-morador">
<div class="dashboard">

    <!-- =====================================================
         SIDEBAR
    ====================================================== -->

    <aside class="sidebar">

        <div class="logo"><img src="../../assets/icons/logo-ecoagenda-branco.png" alt="EcoAgenda"></div>

        <nav class="menu">

            <a
                href="dashboard_morador.php?secao=inicio#inicio"
                class="menu-link <?= $secao === "inicio" ? "active" : "" ?>">
                <span class="menu-icon">▦</span>
                <span>Dashboard</span>
            </a>

            <a
                href="novo_pedido.php"
                class="menu-link">
                <span class="menu-icon">＋</span>
                <span>Novo Pedido</span>
            </a>

            <a
                href="dashboard_morador.php?secao=acompanhar"
                class="menu-link <?= $secao === "acompanhar" ? "active" : "" ?>">
                <span class="menu-icon">◷</span>
                <span>Acompanhar</span>
            </a>

            <a
                href="perfil.php"
                class="menu-link">
                <img src="../../assets/icons/perfil-branco.png" alt="" aria-hidden="true" class="menu-icon-image perfil-icon-sidebar">
                <span>Perfil</span>
            </a>

        </nav>

    </aside>


    <!-- =====================================================
         CONTEÚDO PRINCIPAL
    ====================================================== -->

    <main class="main">

        <header class="topbar">

            <div class="topbar-left">

                <?php if ($secao === "acompanhar"): ?>
                    <h1>Acompanhar pedidos</h1>
                    <p>Veja o status e o histórico das suas solicitações.</p>
                <?php else: ?>
                    <h1>Dashboard</h1>
                    <p>Visão geral dos seus pedidos de coleta.</p>
                <?php endif; ?>

            </div>

            <div class="topbar-right">

                <a href="../logout.php" class="logout">Sair</a>

                <div
                    class="avatar"
                    title="<?= escapeHtml($nome) ?>">
                    <?= escapeHtml($iniciais) ?>
                </div>

            </div>

        </header>


        <div class="content">

            <?php if ($secao === "inicio"): ?>

                <!-- =================================================
                     DASHBOARD PRINCIPAL
                ================================================== -->

                <section class="stats">

                    <div class="stat-card card-total">
                        <div class="stat-number"><?= $totalPedidos ?></div>
                        <div class="stat-label">Pedidos totais</div>
                    </div>

                    <div class="stat-card card-pendente">
                        <div class="stat-number"><?= $pendentes ?></div>
                        <div class="stat-label">Em análise</div>
                    </div>

                    <div class="stat-card card-confirmado">
                        <div class="stat-number"><?= $confirmados ?></div>
                        <div class="stat-label">Agendados</div>
                    </div>

                    <div class="stat-card card-caminho">
                        <div class="stat-number"><?= $aCaminho ?></div>
                        <div class="stat-label">A caminho</div>
                    </div>

                    <div class="stat-card card-andamento">
                        <div class="stat-number"><?= $emAndamento ?></div>
                        <div class="stat-label">Em andamento</div>
                    </div>

                    <div class="stat-card card-concluido">
                        <div class="stat-number"><?= $concluidos ?></div>
                        <div class="stat-label">Concluídos</div>
                    </div>

                    <div class="stat-card card-cancelado">
                        <div class="stat-number"><?= $cancelados ?></div>
                        <div class="stat-label">Suspensos</div>
                    </div>

                </section>


                <section class="recent-section">

                    <div class="section-header">
                        <div>
                            <h2>Pedidos recentes</h2>
                            <p>Veja um resumo e abra o acompanhamento detalhado.</p>
                        </div>

                        <a
                            href="dashboard_morador.php?secao=acompanhar"
                            class="see-all">
                            Ver todos →
                        </a>
                    </div>

                    <?php if (empty($pedidos)): ?>

                        <div class="empty-state">
                            <div class="empty-icon"><img src="../../assets/icons/residuos-verde.png" alt="Resíduos"></div>
                            <h3>Você ainda não possui pedidos.</h3>
                            <p>Crie sua primeira solicitação de coleta.</p>
                            <a href="novo_pedido.php" class="new-request-button">Novo Pedido</a>
                        </div>

                    <?php else: ?>

                        <div class="resumo-pedido-list">

                            <?php foreach (array_slice($pedidos, 0, 5) as $pedido): ?>

                                <?php
                                $statusResumo = statusExibicao($pedido["status"] ?? "Em análise");
                                $classeResumo = classeStatus($statusResumo);
                                ?>

                                <article class="resumo-pedido-card">

                                    <div class="resumo-pedido-icon"><img src="../../assets/icons/residuos-verde.png" alt="Resíduos"></div>

                                    <div class="resumo-pedido-info">
                                        <h3><?= escapeHtml($pedido["descricao"] ?? "Solicitação de coleta") ?></h3>
                                        <p>
                                            Pedido #<?= (int)$pedido["id"] ?>
                                            <span class="separator">•</span>
                                            realizado em <?= escapeHtml(formatarData($pedido["data_pedido"] ?? null)) ?>
                                        </p>
                                    </div>

                                    <span class="status <?= escapeHtml($classeResumo) ?>">
                                        <?= escapeHtml($statusResumo) ?>
                                    </span>

                                    <a
                                        href="dashboard_morador.php?secao=acompanhar#pedido-<?= (int)$pedido["id"] ?>"
                                        class="details-button">
                                        Ver detalhes
                                    </a>

                                </article>

                            <?php endforeach; ?>

                        </div>

                    <?php endif; ?>

                </section>


                <div class="important-notice">
                    <div class="notice-icon">!</div>
                    <div>
                        <strong>Informação importante</strong>
                        <p>
                            A Prefeitura tem <strong>ATÉ 5 dias úteis</strong>
                            para realizar a coleta.
                        </p>
                    </div>
                </div>


            <?php else: ?>

                <!-- =================================================
                     ACOMPANHAR PEDIDOS
                ================================================== -->

                <section class="tracking-section" id="meus-pedidos">

                    <?php eaFiltros(); ?>
                    <?php if (empty($pedidos)): ?>

                        <div class="empty-state">
                            <div class="empty-icon"><img src="../../assets/icons/residuos-verde.png" alt="Resíduos"></div>
                            <h3>Você ainda não possui pedidos.</h3>
                            <p>Crie sua primeira solicitação de coleta.</p>
                            <a href="novo_pedido.php" class="new-request-button">Novo Pedido</a>
                        </div>

                    <?php else: ?>

                        <div class="tracking-list ea-orders-list" id="trackingList">

                            <?php foreach ($pedidos as $pedido): ?>

                                <?php
                                $status = statusExibicao($pedido["status"] ?? "Em análise");
                                $classe = classeStatus($status);
                                $etapas = etapasStatus($status);
                                $filtroStatus = chaveFiltroStatus($status);

                                $fotoMorador = caminhoFoto($pedido["foto"] ?? null);

                                $endereco = [];

                                if (!empty($pedido["rua"])) {
                                    $linhaRua = $pedido["rua"];

                                    if (!empty($pedido["numero"])) {
                                        $linhaRua .= ", " . $pedido["numero"];
                                    }

                                    $endereco[] = $linhaRua;
                                }

                                if (!empty($pedido["complemento"])) {
                                    $endereco[] = $pedido["complemento"];
                                }

                                if (!empty($pedido["bairro"])) {
                                    $endereco[] = $pedido["bairro"];
                                }

                                if (!empty($pedido["cidade"])) {
                                    $cidadeEstado = $pedido["cidade"];

                                    if (!empty($pedido["estado"])) {
                                        $cidadeEstado .= " - " . $pedido["estado"];
                                    }

                                    $endereco[] = $cidadeEstado;
                                }

                                if (!empty($pedido["cep"])) {
                                    $endereco[] = "CEP: " . $pedido["cep"];
                                }

                                $enderecoResumo = !empty($endereco)
                                    ? implode(" • ", $endereco)
                                    : "Endereço não informado";

                                $statusNormalizado = mb_strtolower(trim($status), "UTF-8");

                                $iconePedido = in_array($statusNormalizado, ["concluído", "concluido"], true)
                                    ? '<img src="../../assets/icons/concluido-verde.png" alt="Pedido concluído" class="status-pedido-icon status-pedido-concluido">'
                                    : '<img src="../../assets/icons/residuos-verde.png" alt="Resíduos" class="status-pedido-icon">';
                                ?>

                                <?php $pedido['endereco']=$enderecoResumo; $prazoVisual=eaPrazo($pedido); ?>
                                <article
                                    class="tracking-item ea-order-card"
                                    id="pedido-<?= (int)$pedido["id"] ?>"
                                    data-status="<?= escapeHtml($filtroStatus) ?>" data-ea-status="<?= eaStatus($pedido['status']) ?>" data-ea-prazo="<?= eaEscape($prazoVisual['classe']) ?>">

                                    <?php eaResumoPedido($pedido,'ea-resident-details',true); ?>
                                    <div class="tracking-detail-panel" hidden>

                                        <div class="ea-detail-summary detalhes-grid">
                                            <div><span>Pedido realizado em</span><strong><?= eaEscape(eaData($pedido['data_pedido'])) ?></strong></div>
                                            <div><span>Prazo de atendimento</span><strong><?= eaEscape(eaData($prazoVisual['limite'])) ?></strong></div>
                                            <div><span>Status da coleta</span><strong><?= eaEscape(eaStatusNome($pedido['status'])) ?></strong></div>
                                        </div>
                                        <?php if (in_array($statusNormalizado, ["suspenso", "cancelado"], true)): ?>

                                            <div class="cancelled-box">
                                                <strong>Pedido suspenso.</strong>
                                                <span><?= escapeHtml(explicacaoStatus($status)) ?></span>
                                            </div>

                                        <?php else: ?>

                                            <ol class="ea-progress" aria-label="Andamento do pedido">

                                                <?php foreach ($etapas as $etapa): ?>

                                                    <li class="ea-progress-step <?= $etapa['numero'] < etapaAtualStatus($status) ? 'done' : '' ?> <?= etapaAtualStatus($status) === $etapa['numero'] ? 'current' : '' ?>" <?= etapaAtualStatus($status) === $etapa['numero'] ? 'aria-current="step"' : '' ?>>
                                                        <span class="ea-progress-circle" aria-hidden="true"><?= $etapa['numero'] < etapaAtualStatus($status) ? '✓' : $etapa['numero'] ?></span>
                                                        <span class="ea-progress-label"><?= escapeHtml($etapa['nome']) ?><small><?= $etapa['numero'] < etapaAtualStatus($status) ? 'Etapa concluída' : ($etapa['numero'] === etapaAtualStatus($status) ? 'Etapa atual' : 'Próxima etapa') ?></small></span>
                                                    </li>

                                                <?php endforeach; ?>
                                            </ol>
                                            <div class="current-status-explanation" aria-live="polite">
                                                <div class="current-status-explanation-icon">i</div>
                                                <div class="current-status-explanation-content">
                                                    <strong>O que este status significa?</strong>
                                                    <p><?= escapeHtml(explicacaoStatus($status)) ?></p>
                                                </div>
                                            </div>

                                        <?php endif; ?>

                                        <?php $descricaoVisual=eaDescricao((string)$pedido['descricao']); ?>
                                        <div class="detalhes-grid ea-resident-info">
                                            <div class="full"><span>Local de coleta</span><strong><?= eaEscape($enderecoResumo) ?></strong></div>
                                            <div><span>Material de coleta</span><strong><?= eaEscape($descricaoVisual['material']) ?></strong></div>
                                            <div><span>Quantidade aproximada</span><strong><?= eaEscape($descricaoVisual['quantidade']) ?></strong></div>
                                            <div class="full"><span>Descrição do pedido</span><strong><?= nl2br(eaEscape($descricaoVisual['descricao'])) ?></strong></div>
                                        </div>
                                        <div class="photos-section">

                                            <div class="photos-header">
                                                <h4>Fotos</h4>
                                                <span>Registro visual do pedido.</span>
                                            </div>

                                            <div class="photos-grid">

                                                <div class="photo-card">
                                                    <div class="photo-title">📷 Foto enviada no pedido</div>

                                                    <?php if ($fotoMorador): ?>
                                                        <a
                                                            href="<?= escapeHtml($fotoMorador) ?>"
                                                            target="_blank"
                                                            rel="noopener">
                                                            <img
                                                                src="<?= escapeHtml($fotoMorador) ?>"
                                                                alt="Foto enviada pelo morador">
                                                        </a>
                                                    <?php else: ?>
                                                        <div class="photo-empty">Nenhuma foto enviada.</div>
                                                    <?php endif; ?>
                                                </div>

                                            </div>

                                        </div>

                                    </div>

                                </article>

                            <?php endforeach; ?>

                        </div>

                        <div class="tracking-filter-empty" id="trackingFilterEmpty" hidden>
                            Nenhum pedido encontrado para este filtro.
                        </div>

                    <?php endif; ?>

                </section>

                <div class="modal" id="eaResidentModal" hidden role="dialog" aria-modal="true" aria-labelledby="eaResidentTitle">
                    <div class="modal-box"><div class="modal-header"><div><span id="eaResidentTitle">Pedido</span><h2>Detalhes da coleta</h2></div><button type="button" class="modal-close" data-ea-close aria-label="Fechar detalhes">×</button></div><div class="modal-body" id="eaResidentBody"></div><div class="modal-footer"><button type="button" class="btn-secondary" data-ea-close>Fechar</button></div></div>
                </div>



            <?php endif; ?>

        </div>

    </main>

</div>

</body>
</html>
