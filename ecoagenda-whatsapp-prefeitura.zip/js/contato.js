(function() {
  const WHATS_NUMBER = '5541987075000';
  const form = document.getElementById('contactForm');
  const nameInput = document.getElementById('name');

  function showNameError(show) {
    const fb = nameInput.parentNode.querySelector('.invalid-feedback');
    if (show) {
      nameInput.classList.add('is-invalid');
      if (fb) fb.style.display = 'block';
    } else {
      nameInput.classList.remove('is-invalid');
      if (fb) fb.style.display = 'none';
    }
  }

  form.addEventListener('submit', function(e) {
    e.preventDefault();
    const nome = (nameInput.value || '').trim();
    if (!nome) {
      showNameError(true);
      nameInput.focus();
      return;
    }
    showNameError(false);

    const mensagem = `Boa tarde! Eu me chamo ${nome} e estou com duvida sobre a coleta de materiais insersiveis. Poderia me ajudar?`;
    const url = 'https://wa.me/' + WHATS_NUMBER + '?text=' + encodeURIComponent(mensagem);

    window.open(url, '_blank');
  });
})();
