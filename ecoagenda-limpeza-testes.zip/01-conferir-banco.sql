-- Somente consulta: este arquivo não altera nenhum dado.
SELECT DATABASE() AS banco_selecionado, VERSION() AS versao_servidor;
SELECT 'Pedidos' AS registro, COUNT(*) AS quantidade FROM agendamento
UNION ALL SELECT 'Historico',COUNT(*) FROM agendamento_historico
UNION ALL SELECT 'Coletas',COUNT(*) FROM coleta
UNION ALL SELECT 'Moradores',COUNT(*) FROM morador
UNION ALL SELECT 'Usuarios',COUNT(*) FROM usuario;
SELECT u.email,
       CASE WHEN a.email IS NOT NULL THEN 'Administrador'
            WHEN s.email IS NOT NULL THEN 'Secretaria'
            WHEN m.email IS NOT NULL THEN 'Motorista' ELSE 'Perfil não encontrado' END AS perfil,
       CASE WHEN a.email IS NOT NULL THEN 'Sim'
            WHEN COALESCE(s.ativo,m.ativo,0)=1 THEN 'Sim' ELSE 'Não' END AS ativo
FROM usuario u
LEFT JOIN administrador a ON a.email=u.email
LEFT JOIN secretaria s ON s.email=u.email
LEFT JOIN motorista m ON m.email=u.email
WHERE u.email IN ('motorista@ecoagenda.com','secretaria@ecoagenda.com','admin@ecoagenda.com');
