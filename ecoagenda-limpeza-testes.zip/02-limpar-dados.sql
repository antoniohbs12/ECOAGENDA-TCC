-- ECOAGENDA: limpeza de dados de teste, para MariaDB 10.4+ (XAMPP).
-- ANTES: exporte o banco completo; encerre as sessões e não use o site durante a execução.
-- Selecione o banco do EcoAgenda no phpMyAdmin e importe este arquivo.
-- Mantém senhas, perfis e status. Não altera tabelas, triggers ou contadores de IDs.
-- Não desative FOREIGN_KEY_CHECKS. Este bloco desfaz todas as exclusões se houver erro.
DELIMITER $$
BEGIN NOT ATOMIC
    DECLARE v_tabelas INT DEFAULT 0;
    DECLARE v_preservados INT DEFAULT 0;
    DECLARE v_status INT DEFAULT 0;
    DECLARE v_restantes INT DEFAULT 0;
    DECLARE EXIT HANDLER FOR SQLEXCEPTION
    BEGIN
        ROLLBACK;
        RESIGNAL;
    END;

    IF DATABASE() IS NULL OR @@foreign_key_checks <> 1 THEN
        SIGNAL SQLSTATE '45000' SET MESSAGE_TEXT = 'Limpeza cancelada: selecione o banco EcoAgenda e mantenha FOREIGN_KEY_CHECKS ativo.';
    END IF;

    SELECT COUNT(*) INTO v_tabelas FROM information_schema.TABLES
    WHERE TABLE_SCHEMA = DATABASE() AND TABLE_TYPE = 'BASE TABLE';
    IF v_tabelas <> 13 THEN
        SIGNAL SQLSTATE '45000' SET MESSAGE_TEXT = 'Limpeza cancelada: estrutura diferente da versão verificada (13 tabelas). Nenhum dado foi excluído.';
    END IF;
    SELECT COUNT(*) INTO v_tabelas FROM information_schema.TABLES
    WHERE TABLE_SCHEMA = DATABASE() AND ENGINE = 'InnoDB'
      AND TABLE_NAME IN ('administrador','agendamento','agendamento_historico',
        'agendamento_morador_endereco','coleta','endereco','morador','morador_endereco',
        'motorista','secretaria','secretaria_agendamento','status_agendamento','usuario');
    IF v_tabelas <> 13 THEN
        SIGNAL SQLSTATE '45000' SET MESSAGE_TEXT = 'Limpeza cancelada: tabelas ou mecanismo de armazenamento incompatíveis com a transação.';
    END IF;
    IF EXISTS(SELECT 1 FROM information_schema.TRIGGERS WHERE TRIGGER_SCHEMA=DATABASE() AND EVENT_MANIPULATION='DELETE') THEN
        SIGNAL SQLSTATE '45000' SET MESSAGE_TEXT = 'Limpeza cancelada: há um trigger de exclusão não previsto. Revise o banco antes de continuar.';
    END IF;

    START TRANSACTION;
    SELECT COUNT(*) INTO v_preservados FROM usuario
    WHERE email IN ('motorista@ecoagenda.com','secretaria@ecoagenda.com','admin@ecoagenda.com');
    IF v_preservados <> 3 OR
       NOT EXISTS(SELECT 1 FROM motorista WHERE email='motorista@ecoagenda.com' AND ativo=1) OR
       NOT EXISTS(SELECT 1 FROM secretaria WHERE email='secretaria@ecoagenda.com' AND ativo=1) OR
       NOT EXISTS(SELECT 1 FROM administrador WHERE email='admin@ecoagenda.com') THEN
        SIGNAL SQLSTATE '45000' SET MESSAGE_TEXT = 'Limpeza cancelada: um dos três acessos a preservar está ausente ou inativo.';
    END IF;
    SELECT COUNT(*) INTO v_status FROM status_agendamento;
    IF v_status=0 THEN
        SIGNAL SQLSTATE '45000' SET MESSAGE_TEXT = 'Limpeza cancelada: a tabela de status está vazia.';
    END IF;

    -- Primeiro os registros dependentes; depois pedidos, endereços e contas.
    DELETE FROM agendamento_historico;
    DELETE FROM secretaria_agendamento;
    DELETE FROM coleta;
    DELETE FROM agendamento_morador_endereco;
    DELETE FROM agendamento;
    DELETE FROM morador_endereco;
    DELETE FROM endereco;
    DELETE FROM morador;
    DELETE FROM motorista WHERE email <> 'motorista@ecoagenda.com';
    DELETE FROM secretaria WHERE email <> 'secretaria@ecoagenda.com';
    DELETE FROM administrador WHERE email <> 'admin@ecoagenda.com';
    DELETE FROM usuario WHERE email NOT IN
        ('motorista@ecoagenda.com','secretaria@ecoagenda.com','admin@ecoagenda.com');

    SELECT (SELECT COUNT(*) FROM agendamento_historico)+
           (SELECT COUNT(*) FROM secretaria_agendamento)+
           (SELECT COUNT(*) FROM coleta)+(SELECT COUNT(*) FROM agendamento_morador_endereco)+
           (SELECT COUNT(*) FROM agendamento)+(SELECT COUNT(*) FROM morador_endereco)+
           (SELECT COUNT(*) FROM endereco)+(SELECT COUNT(*) FROM morador)
    INTO v_restantes;
    IF v_restantes<>0 OR (SELECT COUNT(*) FROM usuario)<>3 OR
       (SELECT COUNT(*) FROM motorista)<>1 OR (SELECT COUNT(*) FROM secretaria)<>1 OR
       (SELECT COUNT(*) FROM administrador)<>1 OR (SELECT COUNT(*) FROM status_agendamento)<>v_status THEN
        SIGNAL SQLSTATE '45000' SET MESSAGE_TEXT = 'Limpeza desfeita: a verificação final encontrou dados inesperados.';
    END IF;
    COMMIT;
    SELECT 'Limpeza concluída: pedidos e demais contas removidos; três acessos e suas senhas preservados.' AS resultado;
    SELECT email FROM usuario ORDER BY email;
END$$
DELIMITER ;
