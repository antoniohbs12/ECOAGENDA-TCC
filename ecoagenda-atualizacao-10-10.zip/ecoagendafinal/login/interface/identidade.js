(() => {
    const base=new URL('.',document.currentScript.src);
    const norm=s=>String(s||'').normalize('NFD').replace(/[\u0300-\u036f]/g,'').toLowerCase().replace(/\s+/g,' ').trim();
    function status(s){s=norm(s);if(/conclu/.test(s))return 'concluido';if(/suspens|cancelad/.test(s))return 'suspenso';if(/a caminho/.test(s))return 'caminho';if(/andamento/.test(s))return 'andamento';if(/agendad|encaminhad|confirmad/.test(s))return 'agendado';if(/analise|pendente/.test(s))return 'analise';return '';}
    const nomes={analise:'Em análise',agendado:'Agendado',caminho:'A caminho',andamento:'Em andamento',concluido:'Concluído',suspenso:'Suspenso'};
    window.EcoStatus={key:status,nomes,badge(value){const e=document.createElement('span');e.className='ea-status-token';e.dataset.statusKey=status(value);e.textContent=nomes[status(value)]||value;return e;}};
    function decorate(){
        document.querySelectorAll('.status,.historico-status,#modalStatus,.ea-status-token').forEach(el=>{if(el.id==='modalStatus'&&!el.classList.contains('status'))el.classList.add('status');const key=status(el.textContent);if(key&&el.dataset.statusKey!==key)el.dataset.statusKey=key;});
        document.querySelectorAll('.stat-card,.adm-resumo-card').forEach(el=>{const key=status(el.querySelector('.stat-label,.adm-resumo-label')?.textContent||el.textContent);if(key&&el.dataset.statusKey!==key)el.dataset.statusKey=key;});
        document.querySelectorAll('.ea-progress-step').forEach(el=>{const key=status(el.querySelector('.ea-progress-label')?.firstChild?.textContent);if(key&&el.dataset.statusKey!==key)el.dataset.statusKey=key;});
        document.querySelectorAll('.adm-weekly-item i').forEach(el=>{const key=status(el.parentElement.textContent);if(key&&el.dataset.statusKey!==key)el.dataset.statusKey=key;});
        document.querySelectorAll('.menu-link').forEach(link=>{
            const icon=link.querySelector('.ea-nav-icon,.menu-icon');if(!icon)return;
            if(norm(link.textContent).includes('secretaria')){
                if(!icon.querySelector('[data-secretaria]')){const img=document.createElement('img');img.dataset.secretaria='1';img.className='ea-img-icon';img.alt='';icon.replaceChildren(img);}
                const img=icon.firstElementChild;const url=new URL('icones/secretaria'+(link.classList.contains('active')?'-verde':'')+'.png',base).href;if(img.src!==url)img.src=url;
            }
        });
        document.querySelectorAll('.ea-password-control').forEach(button=>{
            const input=document.getElementById(button.dataset.passwordFor);if(!input)return;
            const open=input.type==='text',white=button.matches(':focus-visible')||open;
            button.setAttribute('aria-pressed',String(open));button.setAttribute('aria-label',open?'Ocultar senha':'Visualizar senha');
            const src=new URL(`icones/${open?'ocultar':'visualizar'}-senha${white?'':'-verde'}.png`,base).href;
            if(button.firstElementChild?.src!==src){const img=document.createElement('img');img.alt='';img.src=src;button.replaceChildren(img);}
        });
    }
    function passwords(){
        document.querySelectorAll('#mostrarSenha,.btn-toggle-pass').forEach(button=>{
            if(button.dataset.passwordFor)return;
            const input=button.closest('.senha,.senha-container')?.querySelector('input');if(!input)return;
            button.classList.add('ea-password-control');button.dataset.passwordFor=input.id;
            // Os scripts originais continuam alternando o tipo do campo.
            button.addEventListener('click',()=>queueMicrotask(decorate));button.addEventListener('focus',decorate);button.addEventListener('blur',decorate);
        });
    }
    let queued=false;
    const observer=new MutationObserver(()=>{if(queued)return;queued=true;requestAnimationFrame(()=>{queued=false;decorate();});});
    function init(){passwords();decorate();observer.observe(document.body,{subtree:true,childList:true,characterData:true,attributes:true,attributeFilter:['class','type']});}
    if(document.readyState==='loading')document.addEventListener('DOMContentLoaded',init);else init();
})();
